local Data = GameData.help_info.Data
Data[1] = {ID = 1, sortID = 1}
Data[2] = {ID = 2, sortID = 1}
Data[3] = {ID = 3, sortID = 1}
Data[4] = {ID = 4, sortID = 1}
Data[5] = {ID = 5, sortID = 1}
Data[6] = {ID = 6, sortID = 1}
Data[7] = {ID = 7, sortID = 1}
Data[8] = {ID = 8, sortID = 1}
Data[9] = {ID = 9, sortID = 1}
Data[10] = {ID = 10, sortID = 1}
Data[11] = {ID = 11, sortID = 2}
Data[12] = {ID = 12, sortID = 2}
Data[13] = {ID = 13, sortID = 2}
Data[14] = {ID = 14, sortID = 2}
Data[15] = {ID = 15, sortID = 2}
Data[16] = {ID = 16, sortID = 2}
Data[17] = {ID = 17, sortID = 2}
Data[18] = {ID = 18, sortID = 2}
Data[19] = {ID = 19, sortID = 2}
Data[20] = {ID = 20, sortID = 2}
Data[21] = {ID = 21, sortID = 3}
Data[22] = {ID = 22, sortID = 3}
Data[23] = {ID = 23, sortID = 3}
Data[24] = {ID = 24}
Data[25] = {ID = 25}
Data[26] = {ID = 26}
Data[27] = {ID = 27}
Data[28] = {ID = 28}
Data[29] = {ID = 29}
Data[30] = {ID = 30}
