GameData.ActInfo = {
  ACT1 = {Name = "ACT1"},
  ACT2 = {Name = "ACT2"},
  ACT3 = {Name = "ACT3"}
}
