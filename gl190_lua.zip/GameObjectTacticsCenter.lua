module("GameObjectTacticsCenter", package.seeall)
require("TacticsCenterDataManager.tfl")
local GameObjectTacticsCenter = LuaObjectManager:GetLuaObject("GameObjectTacticsCenter")
GameObjectTacticsCenter._vesselOpenNow = nil
GameObjectTacticsCenter._equipIdSelectNow = nil
GameObjectTacticsCenter._forceRecord = 0
GameObjectTacticsCenter.slotRedPointData = nil
local QuestTutorialTacticsCenter = TutorialQuestManager.QuestTutorialTacticsCenter
local QuestTutorialTacticsRefine = TutorialQuestManager.QuestTutorialTacticsRefine
local GameUICommonDialog = LuaObjectManager:GetLuaObject("GameUICommonDialog")
local RefineDataManager = LuaObjectManager:GetLuaObject("RefineDataManager")
local GameHelper = LuaObjectManager:GetLuaObject("GameHelper")
local GameUIWDStuff = LuaObjectManager:GetLuaObject("GameUIWDStuff")
local GameUIMessageDialog = LuaObjectManager:GetLuaObject("GameUIMessageDialog")
local GameUIMaster = LuaObjectManager:GetLuaObject("GameUIMaster")
local SubDebugging = require("data1/GameUITacticsCenterRefine.tfl")
local TacticsCenterDataManager = TacticsCenterDataManager.TacticsCenterDataManager
local tcdm = TacticsCenterDataManager
local GameUtils = GameUtils
local GameTip = LuaObjectManager:GetLuaObject("GameTip")
local GameHelper = LuaObjectManager:GetLuaObject("GameHelper")
local __equals = function(a, b)
  if nil == a then
    DebugOut("warning, you pass a nil to __equals first param, you really want?")
  end
  if nil == b then
    DebugOut("warning, you pass a nil to __equals second param, you really want?")
  end
  return a == b
end
local __table_find_if = function(table, predicate)
  for k, v in pairs(table) do
    if predicate(v) then
      return k, v
    end
  end
  return nil
end
function GameObjectTacticsCenter:OnInitGame()
end
function GameObjectTacticsCenter:OnFSCommand(cmd, arg)
  if "close_menu" == cmd then
    self:_handleFSCloseMenu(arg)
  elseif "press_slot_icon" == cmd then
    self:_handleFSPressSlotIcon(arg)
  elseif "press_slot_debugging" == cmd then
    self:_handleFSPressSlotDebugging(arg)
    tcdm:setShowState(tcdm.ShowLayerState.tacticsRefine)
  elseif "equip_recovery" == cmd then
    self:_handleFSEquipRecovery(arg)
  elseif "equip_on" == cmd then
    self:_handleFSEquipOn(arg)
  elseif "equip_off" == cmd then
    self:_handleFSEquipOff(arg)
  elseif "equip_exchange" == cmd then
    self:_handleFSEquipExchange(arg)
  elseif "select_equip" == cmd then
    self:_handleFSSelectEquip(arg)
    if QuestTutorialTacticsCenter:IsActive() then
      self:_invokeAS("_root", "hideTutorialShot")
    end
  elseif "closed_equip_info" == cmd then
    self:_handleFSClosedEquipInfo()
  elseif "EquipmentUnselectOver" == cmd then
    self:_setUIEquipInfoAndListVisible(false)
  elseif "release_btn_help" == cmd then
    self:_showUIHelpInfo()
  elseif "GoToMasterPage" == cmd then
    GameUIMaster.CurrentScope = {
      [1] = -1
    }
    GameUIMaster.CurrentSystemType = GameUIMaster.MasterSystem.ModuleMaster
    GameUIMaster.CurrentPageType = GameUIMaster.MasterPage.centrol_grade
    GameUIMaster.CurMatrixId = FleetMatrix.cur_index
    GameStateManager:GetCurrentGameState():AddObject(GameUIMaster)
  end
  SubDebugging:OnFSCommand(cmd, arg)
end
function GameObjectTacticsCenter:OnAddToGameState()
  DebugOut("GameObjectTacticsCenter:OnAddToGameState")
  self:TutorialCheckShot()
  tcdm:clearData()
  self._datachangeListener = tcdm:createADataChangeListener()
  function self._datachangeListener:onDebuggingSave(equip)
    GameObjectTacticsCenter:_updateUISlot(equip.vessel)
    GameObjectTacticsCenter:dataDrive_UpdateEquipInfoAndBtn()
    GameObjectTacticsCenter:dataDrive_UpdateAllSlotHighlightState()
  end
  tcdm:addDataChangeListener(self._datachangeListener)
  GameGlobalData:RegisterDataChangeCallback("fleetinfo", GameObjectTacticsCenter.fleetInfoCallback)
  GameGlobalData:RegisterDataChangeCallback("resource", GameUITacticsCenterRefine.RefreshGlobalData)
  GameGlobalData:RegisterDataChangeCallback("item_count", GameUITacticsCenterRefine.RefreshGlobalData)
  self:_invokeAS("_root", "luafs_setRefineUIVisible", false)
  self:_invokeAS("_root", "luafs_setRootVisible", false)
  self:_setUIEquipInfoAndListVisible(false)
  tcdm:setShowState(tcdm.ShowLayerState.tacticsCenter)
end
function GameObjectTacticsCenter:TutorialCheckShot(...)
  self:_invokeAS("_root", "_hideAllTutorial")
  if QuestTutorialTacticsCenter:IsActive() then
    local function callback()
      NetMessageMgr:SendMsg(NetAPIList.tactical_guide_req.Code, nil, GameObjectTacticsCenter._onNet, true, nil)
      self:_invokeAS("_root", "luafs_showSlotButtonTutorial", TacticsCenterDataManager.EvesselType.qi_jian)
    end
    GameUICommonDialog:PlayStory({1100087, 1100088}, callback)
  end
end
function GameObjectTacticsCenter:TutorialCheckRefinebutton(...)
  self:_invokeAS("_root", "_hideAllTutorial")
  if QuestTutorialTacticsCenter:IsActive() then
    self:_invokeAS("_root", "luafs_showSlotButtonTutorial", TacticsCenterDataManager.EvesselType.qi_jian)
  end
  if QuestTutorialTacticsRefine:IsActive() then
    local showTutorialRefineVessel = TacticsCenterDataManager:getHasEquipAndMin()
    if showTutorialRefineVessel ~= 0 then
      self:_invokeAS("_root", "luafs_showRefineButtonTutorial", showTutorialRefineVessel)
    end
  end
end
function GameObjectTacticsCenter.fleetInfoCallback()
  DebugOut("GameObjectTacticsCenter.fleetInfoCallback")
  local newForce = GameObjectTacticsCenter.getFleetsForce()
  local forceChange = newForce - GameObjectTacticsCenter._forceRecord
  DebugOut("newForce")
  DebugOut(newForce .. " " .. GameObjectTacticsCenter._forceRecord)
  if forceChange < 0 then
    GameObjectTacticsCenter:_runUIForceDownAnimation(math.abs(forceChange))
  elseif forceChange > 0 then
    GameObjectTacticsCenter:_runUIForceUpAnimation(forceChange)
  end
  GameObjectTacticsCenter:_updateUIForce()
end
function GameObjectTacticsCenter:OnEraseFromGameState()
  DebugOut("GameObjectTacticsCenter:OnEraseFromGameState")
  GameObjectTacticsCenter.slotRedPointData = nil
  tcdm:remvoeDataChangeListener(self._datachangeListener)
  self:UnloadFlashObject()
end
function GameObjectTacticsCenter:_handleFSClosedEquipInfo()
  self:TutorialCheckRefinebutton()
  self:_closeEquipInfoAndListUI()
end
function GameObjectTacticsCenter:_handleFSSelectEquip(arg)
  DebugOut("GameObjectTacticsCenter:_handleFSSelectEquip")
  DebugOut(arg)
  if tonumber(arg) == 0 then
    return
  end
  DebugOut(type(arg))
  local equipId = "" .. arg
  self._equipIdSelectNow = equipId
  self:dataDrive_UpdateEquipInfoAndBtn()
  self:dataDrive_UpdateEquipInListHighlightState()
end
function GameObjectTacticsCenter:_handleFSCloseMenu(arg)
  GameStateManager.GameStateTacticsCenter:quit()
end
function GameObjectTacticsCenter:_handleFSPressSlotIcon(arg)
  DebugOut("GameObjectTacticsCenter:_handleFSPressSlotIcon")
  DebugOut(arg)
  local vessel = tonumber(arg)
  DebugOut(vessel)
  assert(vessel)
  local slotState = TacticsCenterDataManager:getSlotState(vessel)
  if __equals(tcdm.ESlotState.equiped_, slotState) or __equals(tcdm.ESlotState.none_, slotState) then
    local _vesselOpenBefore = self._vesselOpenNow
    self._vesselOpenNow = vessel
    if _vesselOpenBefore ~= nil then
      self:_updateEquipInfoAndListUI(self._vesselOpenNow)
    else
      self:_setUIEquipInfoAndListVisible(true)
      self:_openEquipInfoAndListUI(self._vesselOpenNow)
    end
    self:dataDrive_UpdateAllSlotHighlightState()
  elseif __equals(tcdm.ESlotState.lock_, slotState) then
    self:_tipUISlotUnavailableReasonOrPopUnlockConfirming()
  else
    error("logic error")
  end
end
function GameObjectTacticsCenter:_handleFSPressSlotDebugging(arg)
  DebugOut("GameObjectTacticsCenter:_handleFSPressSlotDebugging")
  DebugOut(arg)
  local vessel = tonumber(arg)
  local slotState = TacticsCenterDataManager:getSlotState(vessel)
  if __equals(tcdm.ESlotState.equiped_, slotState) then
    local equip = TacticsCenterDataManager:getEquipInSlot(vessel)
    assert(equip)
    self:_openDebuggingUI(vessel, equip.id)
  elseif __equals(tcdm.ESlotState.none_, slotState) then
  elseif __equals(tcdm.ESlotState.lock_, slotState) then
    self:_tipUISlotUnavailableReasonOrPopUnlockConfirming()
  else
    error("logic error")
  end
end
function GameObjectTacticsCenter:_handleFSEquipRecovery(arg)
  assert(self._equipIdSelectNow)
  self:_requestForEquipRecoverAward(self._equipIdSelectNow)
end
function GameObjectTacticsCenter:_handleFSEquipOn(arg)
  if QuestTutorialTacticsCenter:IsActive() then
    local function callback()
      GameObjectTacticsCenter:_handleFSClosedEquipInfo()
    end
    QuestTutorialTacticsCenter:SetFinish(true, false)
    QuestTutorialTacticsRefine:SetActive(true, false)
    GameUICommonDialog:PlayStory({1100089}, callback)
  end
  self:_requestForEquipOn(self._vesselOpenNow, self._equipIdSelectNow)
end
function GameObjectTacticsCenter:_handleFSEquipOff(arg)
  self:_requestForEquipOff(self._vesselOpenNow)
end
function GameObjectTacticsCenter:_handleFSEquipExchange(arg)
  self:_requestForEquipOn(self._vesselOpenNow, self._equipIdSelectNow)
end
function GameObjectTacticsCenter:_requestForEnter()
  DebugOut("GameObjectTacticsCenter:_requestForEnter")
  NetMessageMgr:SendMsg(NetAPIList.enter_tactical_req.Code, nil, GameObjectTacticsCenter._onNet, true, nil)
end
function GameObjectTacticsCenter:_requestForEquipOn(vessel, equipId)
  local param = {
    vessel = vessel or 1,
    equip_id = equipId
  }
  NetMessageMgr:SendMsg(NetAPIList.tactical_equip_on_req.Code, param, GameObjectTacticsCenter._onNet, true, nil)
end
function GameObjectTacticsCenter:_requestForEquipOff(vessel)
  local param = {
    vessel = vessel or 1
  }
  NetMessageMgr:SendMsg(NetAPIList.tactical_equip_off_req.Code, param, GameObjectTacticsCenter._onNet, true, nil)
end
function GameObjectTacticsCenter:_requestForUnlockNextSlot()
  DebugOut("GameObjectTacticsCenter:_requestForUnlockNextSlot")
  NetMessageMgr:SendMsg(NetAPIList.tactical_unlock_slot_req.Code, nil, GameObjectTacticsCenter._onNet, true, nil)
end
function GameObjectTacticsCenter:_requestForEquipRecoverAward(equipId)
  local param = {equip_id = equipId}
  NetMessageMgr:SendMsg(NetAPIList.tactical_delete_awards_req.Code, param, GameObjectTacticsCenter._onNet, true, nil)
end
function GameObjectTacticsCenter:_requestForEquipRecover(equipId)
  local param = {equip_id = equipId}
  NetMessageMgr:SendMsg(NetAPIList.tactical_equip_delete_req.Code, param, GameObjectTacticsCenter._onNet, true, nil)
end
function GameObjectTacticsCenter:enter()
  DebugOut("GameObjectTacticsCenter:enter")
  self:_requestForEnter()
end
function GameObjectTacticsCenter._onNet(msgType, content)
  DebugOut("GameObjectTacticsCenter._onNet")
  DebugOut(msgType)
  DebugTable(content)
  if content.code and 0 ~= content.code and (__equals(msgType, NetAPIList.tactical_equip_on_ack.Code) or __equals(msgType, NetAPIList.tactical_equip_off_ack.Code) or __equals(msgType, NetAPIList.tactical_unlock_slot_ack.Code) or __equals(msgType, NetAPIList.tactical_equip_delete_ack.Code) or __equals(msgType, NetAPIList.tactical_guide_req.Code)) then
    GameObjectTacticsCenter:_commonNetErrorHandle(content)
  elseif __equals(msgType, NetAPIList.enter_tactical_ack.Code) then
    GameObjectTacticsCenter.slotRedPointData = {}
    for k, v in ipairs(content.slots) do
      local data = {}
      data.vessel = v.vessel
      data.red_point = v.red_point
      table.insert(GameObjectTacticsCenter.slotRedPointData, data)
    end
    GameObjectTacticsCenter:_handleEnterTacticalACK(content)
  elseif __equals(msgType, NetAPIList.tactical_equip_on_ack.Code) then
    GameObjectTacticsCenter:_handleEquipOnACK(content)
    GameObjectTacticsCenter:ReRequestData()
  elseif __equals(msgType, NetAPIList.tactical_equip_off_ack.Code) then
    GameObjectTacticsCenter:_handleEquipOffACK(content)
    GameObjectTacticsCenter:ReRequestData()
  elseif __equals(msgType, NetAPIList.tactical_unlock_slot_ack.Code) then
    GameObjectTacticsCenter:_handleUnlockSlotACK(content)
    GameObjectTacticsCenter:ReRequestData()
  elseif __equals(msgType, NetAPIList.tactical_equip_delete_ack.Code) then
    GameObjectTacticsCenter:_handleEquipDeleteACK(content)
    GameObjectTacticsCenter:ReRequestData()
  elseif __equals(msgType, NetAPIList.common_ack.Code) and __equals(content.api, NetAPIList.tactical_guide_req.Code) then
    GameObjectTacticsCenter:enter()
    return true
  elseif __equals(msgType, NetAPIList.tactical_delete_awards_ack.Code) then
    GameObjectTacticsCenter:_handleEquipDeleteAward(content)
  else
    return false
  end
  return true
end
function GameObjectTacticsCenter:_handleEquipDeleteAward(content)
  DebugOut("_handleEquipDeleteAward = ")
  DebugTable(content)
  GameUIMessageDialog:SetStyle(GameUIMessageDialog.DialogStyle.YesNo)
  GameUIMessageDialog:SetYesButton(function()
    GameObjectTacticsCenter:_requestForEquipRecover(self._equipIdSelectNow)
  end)
  GameUIMessageDialog:SetNoButton(function()
  end)
  local infoTable = {}
  for _, item in ipairs(content.awards) do
    local itemText = GameHelper:GetAwardText(item.item_type, item.number, item.no)
    table.insert(infoTable, itemText)
  end
  local infoStr = table.concat(infoTable, " ")
  local textInfo = string.format(GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_DECOMPOSING_INFO"), infoStr)
  local textTitle = GameLoader:GetGameText("LC_MENU_TITLE_VERIFY")
  GameUIMessageDialog:Display(textTitle, textInfo)
end
function GameObjectTacticsCenter:_commonNetErrorHandle(content)
  if content.code ~= 0 then
    local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
    GameUIGlobalScreen:ShowAlert("error", content.code, nil)
  end
end
function GameObjectTacticsCenter:_handleEquipDeleteACK(content)
  local equipDeleted = tcdm:deleteAUnusedEquip(content.equip_id)
  assert(equipDeleted and "logic error")
  local infoTable = {}
  for _, gameItem in ipairs(equipDeleted.decompose) do
    local itemText = GameHelper:GetAwardText(gameItem.item_type, gameItem.number, gameItem.no)
    table.insert(infoTable, itemText)
  end
  local infoStr = table.concat(infoTable, " ")
  local nowfoStr = string.format(GameLoader:GetGameText("LC_MENU_ITEM_REWARDS_ALERT"), infoStr)
  self._equipIdSelectNow = nil
  self:_updateUIEquipList(self._vesselOpenNow)
  self:dataDrive_UpdateEquipInfoAndBtn()
  self:dataDrive_UpdateEquipInListHighlightState()
end
function GameObjectTacticsCenter:ReRequestData()
  NetMessageMgr:SendMsg(NetAPIList.enter_tactical_req.Code, nil, GameObjectTacticsCenter.ReConstructData, false, nil)
end
function GameObjectTacticsCenter.ReConstructData(msgType, content)
  if msgType == NetAPIList.enter_tactical_ack.Code then
    GameObjectTacticsCenter.slotRedPointData = {}
    for k, v in ipairs(content.slots) do
      local data = {}
      data.vessel = v.vessel
      data.red_point = v.red_point
      table.insert(GameObjectTacticsCenter.slotRedPointData, data)
    end
    TacticsCenterDataManager:initDataUseEnterTacticalACK(content)
    GameObjectTacticsCenter:RefreshRedPoint()
  end
  return false
end
function GameObjectTacticsCenter:_handleEnterTacticalACK(content)
  DebugOut("GameObjectTacticsCenter:_handleEnterTacticalACK")
  TacticsCenterDataManager:initDataUseEnterTacticalACK(content)
  self:_invokeAS("_root", "luafs_setRootVisible", true)
  self:_moveUIIn()
  self:_updateUIMain()
  self:TutorialCheckRefinebutton()
  self:RefreshRedPoint()
end
function GameObjectTacticsCenter:RefreshRedPoint()
  self:_invokeAS("_root", "setSlotFixRedPoint", false)
  if RefineDataManager.used_times and RefineDataManager.used_times > 0 then
    self:_invokeAS("_root", "setSlotFixRedPoint", true)
  else
    self:_invokeAS("_root", "setSlotFixRedPoint", false)
  end
  if self.slotRedPointData then
    for k, v in ipairs(self.slotRedPointData) do
      if 0 < v.red_point then
        self:_invokeAS("_root", "setSlotEquipRedPoint", v.vessel, true)
      else
        self:_invokeAS("_root", "setSlotEquipRedPoint", v.vessel, false)
      end
    end
  end
end
function GameObjectTacticsCenter:_handleEquipOnACK(content)
  if __equals(0, content.code) then
    if __equals("0", content.old_equip_id) then
      TacticsCenterDataManager:equipEquip(content.vessel, content.new_equip_id)
    else
      TacticsCenterDataManager:exchangeEquip(content.vessel, content.new_equip_id)
    end
    self._equipIdSelectNow = content.new_equip_id
    self:_updateUIMain()
    self:_updateUIEquipList(self._vesselOpenNow)
    self:dataDrive_UpdateEquipInfoAndBtn()
    self:dataDrive_UpdateEquipInListHighlightState()
    self:dataDrive_UpdateAllSlotHighlightState()
  else
  end
end
function GameObjectTacticsCenter:_handleEquipOffACK(content)
  if __equals(0, content.code) then
    TacticsCenterDataManager:unequipEquip(content.vessel)
    self._equipIdSelectNow = nil
    self:_updateUIMain()
    self:_updateUIEquipList(self._vesselOpenNow)
    self:dataDrive_UpdateEquipInfoAndBtn()
    self:dataDrive_UpdateEquipInListHighlightState()
    self:dataDrive_UpdateAllSlotHighlightState()
  else
  end
end
function GameObjectTacticsCenter:_handleUnlockSlotACK(content)
  DebugOut("GameObjectTacticsCenter:_handleUnlockSlotACK")
  DebugOut(content)
  if __equals(0, content.code) then
    TacticsCenterDataManager:updateUnlockSlotConditionAndCast(content.next)
    self:_updateUIMain()
    self:dataDrive_UpdateAllSlotHighlightState()
  else
  end
end
function GameObjectTacticsCenter:_invokeAS(...)
  if not self:GetFlashObject() then
    return
  end
  self:GetFlashObject():InvokeASCallback(...)
end
function GameObjectTacticsCenter:_moveUIIn()
  self:_invokeAS("_root", "luafs_moveInUI")
end
function GameObjectTacticsCenter:_openEquipInfoAndListUI(vessel)
  DebugOut("GameObjectTacticsCenter:_openEquipInfoAndListUI")
  self:_moveInUIEquipInfoAndList()
  self:_updateEquipInfoAndListUI(vessel)
end
function GameObjectTacticsCenter:_updateEquipInfoAndListUI(vessel)
  DebugOut("GameObjectTacticsCenter:_updateEquipInfoAndListUI")
  self._vesselOpenNow = vessel
  local equipInSlot = tcdm:getEquipInSlot(self._vesselOpenNow)
  self._equipIdSelectNow = equipInSlot and equipInSlot.id
  self:_updateUIEquipList(self._vesselOpenNow)
  self:dataDrive_UpdateEquipInfoAndBtn()
  if self._equipIdSelectNow then
  end
  self:dataDrive_UpdateEquipInListHighlightState()
  self:_highLightSlot(self._vesselOpenNow)
end
function GameObjectTacticsCenter:_selectEquipListIfSlotHaveEquip(vessel)
  local equipNow = tcdm:getEquipInSlot(vessel)
  if equipNow then
    self:_locateAndSelectEquip(equipNow.id)
  end
end
function GameObjectTacticsCenter:_locateAndSelectEquip(equipId)
  assert(equipId)
  self._equipIdSelectNow = equipId
  self:_invokeAS("_root", "luafs_locateAndSelectEquip", equipId)
end
function GameObjectTacticsCenter:_closeEquipInfoAndListUI()
  if not self._vesselOpenNow then
    DebugOut("logic error the _vesselOpenNow cant be nil here")
    return
  end
  self:_moveOutUIEquipInfoAndList()
  self:_unhighlightSlot(self._vesselOpenNow)
  self._vesselOpenNow = nil
  self._equipIdSelectNow = nil
end
function GameObjectTacticsCenter:_highLightSlot(vessel)
  local slotState = TacticsCenterDataManager:getSlotState(vessel)
  if __equals(TacticsCenterDataManager.ESlotState.none_, slotState) then
    self:_invokeAS("_root", "luafs_highLightSlot", vessel, 0)
  else
    if __equals(TacticsCenterDataManager.ESlotState.equiped_, slotState) then
      self:_invokeAS("_root", "luafs_highLightSlot", vessel, 1)
    else
    end
  end
end
function GameObjectTacticsCenter:_unhighlightSlot(vessel)
  local slotState = TacticsCenterDataManager:getSlotState(vessel)
  if __equals(TacticsCenterDataManager.ESlotState.none_, slotState) then
    self:_invokeAS("_root", "luafs_unhighLightSlot", vessel, 0)
  else
    if __equals(TacticsCenterDataManager.ESlotState.equiped_, slotState) then
      self:_invokeAS("_root", "luafs_unhighLightSlot", vessel, 1)
    else
    end
  end
end
function GameObjectTacticsCenter:_moveInUIEquipInfoAndList()
  self:_invokeAS("_root", "luafs_moveInEquipInfoAndList")
end
function GameObjectTacticsCenter:_moveOutUIEquipInfoAndList()
  self:_invokeAS("_root", "luafs_moveOutEquipInfoAndList")
end
function GameObjectTacticsCenter:_setUIEquipInfoAndListVisible(isVisible)
  if isVisible then
    self:_invokeAS("_root", "luafs_setEquipInfoAndListVisible", 1)
  else
    self:_invokeAS("_root", "luafs_setEquipInfoAndListVisible", 0)
  end
end
function GameObjectTacticsCenter:_updateUIMain()
  self:_updateUIForce()
  self:_updateUIAreadyEquipedText()
  self:_updateUIAllSlot()
  self:_updateUICenter()
end
function GameObjectTacticsCenter:_updateUIForce()
  DebugOut("GameObjectTacticsCenter:_updateUIForce")
  local forceValue = GameObjectTacticsCenter:getFleetsForce()
  self._forceRecord = forceValue
  DebugOut("value:" .. forceValue)
  self:_invokeAS("_root", "luafs_updateForce", forceValue)
end
function GameObjectTacticsCenter:_updateUIAreadyEquipedText()
  local text = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_EQUIP_COUNT")
  local countAlreadyEquipSlot = tcdm:getUsedSlotCount()
  local countAvailableSlot = tcdm:getAvailableSlotCount()
  local info = string.format("%s %d/%d", text, countAlreadyEquipSlot, countAvailableSlot)
  self:_invokeAS("_root", "luafs_updateEquipedText", info)
end
function GameObjectTacticsCenter:_createSlotInfoBarAttrWrap(equip)
  DebugOut("GameObjectTacticsCenter:_createSlotInfoBarAttrWrap")
  local attrEffectWraps = self:_createAttrEffectsListForEquip(equip)
  local resultTable = {}
  for i, attrEffectWrap in ipairs(attrEffectWraps) do
    local singleTable = {}
    table.insert(singleTable, GameLoader:GetGameText("LC_MENU_Equip_param_" .. attrEffectWrap.id) or "attr" .. attrEffectWrap.id)
    if __equals(tcdm.EAttrType.main_, attrEffectWrap.type) then
      table.insert(singleTable, self:_convertToPercentStr(attrEffectWrap.effect.value))
    else
      table.insert(singleTable, self:_convertToPercentStr(attrEffectWrap.effect.value))
    end
    table.insert(singleTable, attrEffectWrap.rank)
    local singleStr = table.concat(singleTable, ",")
    DebugOut(singleStr)
    table.insert(resultTable, singleStr)
  end
  local resultStr = table.concat(resultTable, "|")
  DebugOut("resultStr:")
  DebugOut(resultStr)
  return resultStr
end
function GameObjectTacticsCenter:_updateUISlot(vessel)
  DebugOut("GameObjectTacticsCenter:_updateUISlot")
  local slotState = tcdm:getSlotState(vessel)
  DebugOut(vessel)
  DebugOut(slotState)
  if __equals(tcdm.ESlotState.none_, slotState) then
    local textInfo = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_9")
    self:_invokeAS("_root", "luafs_setSlotStateNone", vessel, textInfo)
  elseif __equals(tcdm.ESlotState.lock_, slotState) then
    DebugOut("__equals( tcdm.ESlotState.lock_, slotState )")
    local textInfo = ""
    local unlockCondition = tcdm:getUnlockSlotConditionAndCast()
    DebugTable(unlockCondition)
    if unlockCondition.level > 0 and 0 < unlockCondition.vip then
      textInfo = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_8")
      textInfo = string.gsub(textInfo, "<playerLevel_num>", unlockCondition.level)
      textInfo = string.gsub(textInfo, "<vipLevel_num>", unlockCondition.vip)
    elseif unlockCondition.level == 0 and 0 < unlockCondition.vip then
      textInfo = string.format(GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_7"), unlockCondition.vip)
    elseif unlockCondition.level > 0 and unlockCondition.vip == 0 then
      textInfo = string.format(GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_6"), unlockCondition.level)
    end
    self:_invokeAS("_root", "luafs_setSlotStateLocked", vessel, textInfo)
  elseif __equals(tcdm.ESlotState.equiped_, slotState) then
    local slot = tcdm:getSlotDataByVessel(vessel)
    DebugTable(slot)
    local equip = tcdm:getEquipInSlot(vessel)
    assert(equip)
    local icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(RefineDataManager:EquipToItem(equip.type), nil, nil)
    local attrWrap = self:_createSlotInfoBarAttrWrap(equip)
    self:_invokeAS("_root", "luafs_setSlotStateEquiped", vessel, icon, attrWrap)
  end
end
function GameObjectTacticsCenter:_updateUIAllSlot()
  for _, vessel in pairs(tcdm.EvesselType) do
    self:_updateUISlot(vessel)
  end
end
function GameObjectTacticsCenter:_updateUICenter()
  DebugOut("GameObjectTacticsCenter:_updateUICenter")
  local paramTable = {}
  local equipedVesselCount = 0
  for _, vessel in pairs(tcdm.EvesselType) do
    local slotEquipingState = tcdm:getSlotState(vessel)
    if __equals(tcdm.ESlotState.equiped_, slotEquipingState) then
      table.insert(paramTable, {vessel = vessel, uiState = 2})
      equipedVesselCount = equipedVesselCount + 1
    else
      table.insert(paramTable, {vessel = vessel, uiState = 1})
    end
  end
  DebugTable(paramTable)
  local centerState = 0
  if __equals(tcdm:getVesselAmount(), equipedVesselCount) then
    for k, param in pairs(paramTable) do
      param.uiState = 3
    end
    centerState = 3
  elseif __equals(0, equipedVesselCount) then
    centerState = 1
  else
    centerState = 2
  end
  local paramStrTable = {}
  for k, param in ipairs(paramTable) do
    table.insert(paramStrTable, param.vessel)
    table.insert(paramStrTable, ",")
    table.insert(paramStrTable, param.uiState)
    local equip = tcdm:getEquipInSlot(param.vessel)
    if equip then
      table.insert(paramStrTable, ",")
      local icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(RefineDataManager:EquipToItem(equip.type), nil, nil)
      table.insert(paramStrTable, icon)
    end
    table.insert(paramStrTable, "|")
  end
  table.insert(paramStrTable, centerState)
  local paramStr = table.concat(paramStrTable, "")
  DebugOut(paramStr)
  self:_invokeAS("_root", "luafs_updateUICenter", paramStr)
end
function GameObjectTacticsCenter:_createBlueText(text)
  return "<font color='#73dcff'>" .. text .. "</font>"
end
function GameObjectTacticsCenter:_createRedText(text)
  return "<font color='#ff4c2f'>" .. text .. "</font>"
end
function GameObjectTacticsCenter:_createGreenText(text)
  return "<font color='#95eb95'>" .. text .. "</font>"
end
function GameObjectTacticsCenter:_convertToPercentStr(val)
  local resultVal = val / 10
  local result = string.format("%.1f%%", resultVal)
  return result
end
function GameObjectTacticsCenter:__createAttrCompareText(oldValue, newValue, isPercent)
  local resultStrTable = {}
  local newValueText = "" .. newValue
  if isPercent then
    newValueText = self:_convertToPercentStr(newValue)
  end
  table.insert(resultStrTable, self:_createBlueText(newValueText))
  if not __equals(oldValue, newValue) then
    table.insert(resultStrTable, self:_createBlueText("("))
    if oldValue < newValue then
      table.insert(resultStrTable, self:_createGreenText("+"))
      local addValue = newValue - oldValue
      local addValueText = "" .. addValue
      if isPercent then
        addValueText = self:_convertToPercentStr(addValue)
      end
      table.insert(resultStrTable, self:_createGreenText(addValueText))
    else
      table.insert(resultStrTable, self:_createRedText("-"))
      local minusValue = oldValue - newValue
      local minusValueText = "" .. minusValue
      if isPercent then
        minusValueText = self:_convertToPercentStr(minusValue)
      end
      table.insert(resultStrTable, self:_createRedText(minusValueText))
    end
    table.insert(resultStrTable, self:_createBlueText(")"))
  end
  return table.concat(resultStrTable, "")
end
function GameObjectTacticsCenter:_createAttrCompareText(oldValue, newValue)
  return self:__createAttrCompareText(oldValue, newValue, false)
end
function GameObjectTacticsCenter:_createAttrCompareTextInPercent(oldValue, newValue)
  return self:__createAttrCompareText(oldValue, newValue, true)
end
function GameObjectTacticsCenter:_findMainAttrInEquip(equip)
  for i, equipAttr in ipairs(equip.equip_attrs) do
    if __equals(tcdm.EAttrType.main_, equipAttr.type) then
      return equipAttr
    end
  end
  assert(false and "logic error must have a main attr for equip")
end
function GameObjectTacticsCenter:_findAttrEffectInEquipByVessel(attrEffects, vessel)
  for i, attrEffect in ipairs(attrEffects) do
    if __equals(attrEffect.effect_vessel, vessel) then
      return attrEffect
    end
  end
  return nil
end
function GameObjectTacticsCenter:_isPossibleEquipHaveAttr(equip, attrId)
  for i, aPossibleAttr in ipairs(equip.possible_attrs) do
    if __equals(aPossibleAttr, attrId) then
      return true
    end
  end
  return false
end
function GameObjectTacticsCenter:_isExactEquipHaveAttr(equip, attrId)
  for i, attr in ipairs(equip.equip_attrs) do
    if __equals(attr.id, attrId) then
      return true
    end
  end
  return false
end
function GameObjectTacticsCenter:_createAttrEffectsListForEquip(equip)
  DebugOut("GameObjectTacticsCenter:_createAttrEffectsListForEquip")
  DebugTable(euqip)
  local attrEffects = {}
  local createAEffectWrap = function(id, type, color, effect)
    return {
      id = id,
      type = type,
      rank = color,
      effect = effect
    }
  end
  for i, attr in ipairs(equip.equip_attrs) do
    DebugOut("attr:" .. i)
    DebugTable(attr)
    for i, effect in ipairs(attr.effects) do
      if __equals(effect.effect_vessel, equip.vessel) then
        local effectWrap = createAEffectWrap(attr.id, attr.type, attr.color, effect)
        DebugOut("effectWrap:")
        DebugTable(effectWrap)
        if __equals(tcdm.EAttrType.main_, attr.type) then
          table.insert(attrEffects, 1, effectWrap)
        else
          table.insert(attrEffects, effectWrap)
        end
      end
    end
  end
  DebugOut(attrEffects)
  return attrEffects
end
function GameObjectTacticsCenter:_createEquipOnPopBarAttrWrap(equipSelect)
  DebugOut("GameObjectTacticsCenter:_createEquipOnPopBarAttrWrap")
  local resultTable = {}
  local attrEffectWraps = self:_createAttrEffectsListForEquip(equipSelect)
  if attrEffectWraps then
    DebugTable(attrEffectWraps)
  end
  for i, attrEffectWrap in ipairs(attrEffectWraps) do
    DebugOut("attrEffectWrap")
    DebugTable(attrEffectWrap)
    local singleResultTable = {}
    local name = GameLoader:GetGameText("LC_MENU_Equip_param_" .. attrEffectWrap.id) or "attr" .. attrEffectWrap.id
    local attrExsits = tcdm.EAttrExist.new_
    local rank = attrEffectWrap.rank
    local valueText = "to pass"
    local maxText = "to pass"
    if __equals(tcdm.EAttrType.main_, attrEffectWrap.type) then
      valueText = self:_createAttrCompareTextInPercent(0, attrEffectWrap.effect.value)
      maxText = self:_createAttrCompareTextInPercent(0, attrEffectWrap.effect.max)
    elseif __equals(tcdm.EAttrType.bonus_, attrEffectWrap.type) then
      valueText = self:_createAttrCompareTextInPercent(0, attrEffectWrap.effect.value)
      maxText = self:_createAttrCompareTextInPercent(0, attrEffectWrap.effect.max)
    else
      assert(false)
    end
    table.insert(singleResultTable, name)
    table.insert(singleResultTable, attrExsits)
    table.insert(singleResultTable, valueText)
    table.insert(singleResultTable, rank)
    table.insert(singleResultTable, maxText)
    table.insert(resultTable, table.concat(singleResultTable, ","))
  end
  DebugTable(resultTable)
  return table.concat(resultTable, "|")
end
function GameObjectTacticsCenter:_createEquipOffPopBarAttrWrap(equipNow)
  local resultTable = {}
  local attrEffectWraps = self:_createAttrEffectsListForEquip(equipNow)
  for i, attrEffectWrap in ipairs(attrEffectWraps) do
    local singleResultTable = {}
    local name = GameLoader:GetGameText("LC_MENU_Equip_param_" .. attrEffectWrap.id) or "attr" .. attrEffectWrap.id
    local attrExsits = tcdm.EAttrExist.com_
    local rank = attrEffectWrap.rank
    local valueText = "to pass"
    local maxText = "to pass"
    if __equals(tcdm.EAttrType.main_, attrEffectWrap.type) then
      valueText = self:_createAttrCompareTextInPercent(attrEffectWrap.effect.value, attrEffectWrap.effect.value)
      maxText = self:_createAttrCompareTextInPercent(attrEffectWrap.effect.max, attrEffectWrap.effect.max)
    elseif __equals(tcdm.EAttrType.bonus_, attrEffectWrap.type) then
      valueText = self:_createAttrCompareTextInPercent(attrEffectWrap.effect.value, attrEffectWrap.effect.value)
      maxText = self:_createAttrCompareTextInPercent(attrEffectWrap.effect.max, attrEffectWrap.effect.max)
    else
      assert(false)
    end
    table.insert(singleResultTable, name)
    table.insert(singleResultTable, attrExsits)
    table.insert(singleResultTable, valueText)
    table.insert(singleResultTable, rank)
    table.insert(singleResultTable, maxText)
    table.insert(resultTable, table.concat(singleResultTable, ","))
  end
  return table.concat(resultTable, "|")
end
function GameObjectTacticsCenter:_createEquipExchangePopBarAttrWrap(equipNow, equipSelect)
  DebugOut("GameObjectTacticsCenter:_createEquipExchangePopBarAttrWrap")
  DebugOut("eweryrtoidg")
  DebugTable(equipNow)
  DebugOut("wehtrjgbf")
  DebugTable(equipSelect)
  local resultTable = {}
  local resultTableMid = {}
  local attrEffectWrapsNow = self:_createAttrEffectsListForEquip(equipNow)
  local attrEffectWrapsSelect = self:_createAttrEffectsListForEquip(equipSelect)
  DebugOut("attrEffectWrapNow")
  DebugTable(attrEffectWrapNow)
  DebugOut("attrEffectWrapsSelect")
  DebugTable(attrEffectWrapsSelect)
  local possibleAttrs = equipNow.possible_attrs
  DebugOut("possibleAttrs")
  DebugTable(possibpossibleAttrsleAttr)
  for i, possibleAttr in ipairs(possibleAttrs) do
    DebugOut("srterdgcvdf")
    DebugOut("possibleAttr:" .. possibleAttr.id)
    local _, attrEffectWrapNow = __table_find_if(attrEffectWrapsNow, function(attrEffectWrap)
      return __equals(attrEffectWrap.id, possibleAttr.id)
    end)
    local _, attrEffectWrapSelect = __table_find_if(attrEffectWrapsSelect, function(attrEffectWrap)
      return __equals(attrEffectWrap.id, possibleAttr.id)
    end)
    if nil == attrEffectWrapNow and nil == attrEffectWrapSelect then
      DebugOut("pass")
    else
      local singleResultTable = {}
      local name = "undefine"
      local attrExsits, valueText, rank, maxText, sort
      if nil ~= attrEffectWrapNow and nil == attrEffectWrapSelect then
        local isAttrShowPercent = __equals(tcdm.EAttrType.main_, attrEffectWrapNow.type)
        attrExsits = tcdm.EAttrExist.del_
        valueText = self:_createAttrCompareTextInPercent(attrEffectWrapNow.effect.value, 0, isAttrShowPercent)
        maxText = self:_createAttrCompareTextInPercent(attrEffectWrapNow.effect.max, 0, isAttrShowPercent)
        rank = attrEffectWrapNow.rank
        name = GameLoader:GetGameText("LC_MENU_Equip_param_" .. attrEffectWrapNow.id) or "attr" .. attrEffectWrapNow.id
        sort = 3
      elseif nil == attrEffectWrapNow and nil ~= attrEffectWrapSelect then
        local isAttrShowPercent = __equals(tcdm.EAttrType.main_, attrEffectWrapSelect.type)
        attrExsits = tcdm.EAttrExist.new_
        valueText = self:_createAttrCompareTextInPercent(0, attrEffectWrapSelect.effect.value, isAttrShowPercent)
        maxText = self:_createAttrCompareTextInPercent(0, attrEffectWrapSelect.effect.max, isAttrShowPercent)
        rank = attrEffectWrapSelect.rank
        name = GameLoader:GetGameText("LC_MENU_Equip_param_" .. attrEffectWrapSelect.id) or "attr" .. attrEffectWrapSelect.id
        sort = 2
      elseif nil ~= attrEffectWrapNow and nil ~= attrEffectWrapSelect then
        local isAttrShowPercent = __equals(tcdm.EAttrType.main_, attrEffectWrapSelect.type)
        attrExsits = tcdm.EAttrExist.com_
        valueText = self:_createAttrCompareTextInPercent(attrEffectWrapNow.effect.value, attrEffectWrapSelect.effect.value, isAttrShowPercent)
        maxText = self:_createAttrCompareTextInPercent(attrEffectWrapNow.effect.max, attrEffectWrapSelect.effect.max, isAttrShowPercent)
        rank = attrEffectWrapSelect.rank
        name = GameLoader:GetGameText("LC_MENU_Equip_param_" .. attrEffectWrapSelect.id) or "attr" .. attrEffectWrapSelect.id
        sort = 1
      end
      local t = {
        name = name,
        attrExsits = attrExsits,
        valueText = valueText,
        rank = rank,
        maxText = maxText,
        sort = sort
      }
      table.insert(resultTableMid, t)
    end
  end
  DebugOut("resultTableMid:")
  DebugTable(resultTableMid)
  table.sort(resultTableMid, function(v1, v2)
    return v1.sort < v2.sort
  end)
  for _, v in ipairs(resultTableMid) do
    local str = ""
    str = str .. v.name .. ","
    str = str .. v.attrExsits .. ","
    str = str .. v.valueText .. ","
    str = str .. v.rank .. ","
    str = str .. v.maxText
    table.insert(resultTable, str)
  end
  DebugTable(resultTable)
  assert(#resultTable ~= 0)
  return table.concat(resultTable, "|")
end
function GameObjectTacticsCenter:_createSortedEffectArray(attr)
  local effectArray = {}
  for i, effect in ipairs(attr.effects) do
    table.insert(effectArray, effect)
  end
  table.sort(effectArray, function(effect1, effect2)
    return effect1.value > effect2.value
  end)
  return effectArray
end
function GameObjectTacticsCenter:_createIconBarAttrWrap(equipNow, equipSelect)
  DebugOut("GameObjectTacticsCenter:_createIconBarAttrWrap")
  local resultTable = {}
  local mainAttr = self:_findMainAttrInEquip(equipSelect)
  local effectArray = self:_createSortedEffectArray(mainAttr)
  local mainAttrNow, effectArrayNow
  if equipNow then
    mainAttrNow = self:_findMainAttrInEquip(equipNow)
    effectArrayNow = self:_createSortedEffectArray(mainAttrNow)
  end
  DebugOut("mainAttrNow:")
  DebugTable(mainAttrNow)
  DebugOut("effectArrayNow")
  DebugTable(effectArrayNow)
  for i, effect in ipairs(effectArray) do
    local singleTable = {}
    local vessel = effect.effect_vessel
    if equipNow then
      local _, effectNow = __table_find_if(effectArrayNow, function(aEffect)
        return __equals(vessel, aEffect.effect_vessel)
      end)
      assert(effectNow)
      if effectNow then
        valueText = self:_createAttrCompareTextInPercent(effectNow.value, effect.value)
      else
        valueText = self:_createAttrCompareTextInPercent(0, effect.value)
      end
    else
      valueText = self:_createAttrCompareTextInPercent(0, effect.value)
    end
    table.insert(singleTable, vessel)
    table.insert(singleTable, valueText)
    table.insert(resultTable, table.concat(singleTable, ","))
  end
  return table.concat(resultTable, "|")
end
function GameObjectTacticsCenter:_createEquipOnIconBarAttrWrap(equipSelect)
  return self:_createIconBarAttrWrap(nil, equipSelect)
end
function GameObjectTacticsCenter:_createEquipOffIconBarAttrWrap(equipNow)
  return self:_createIconBarAttrWrap(equipNow, equipNow)
end
function GameObjectTacticsCenter:_createEquipExchangeIconBarAttrWrap(equipNow, equipSelect)
  return self:_createIconBarAttrWrap(equipNow, equipSelect)
end
function GameObjectTacticsCenter:__setUIEquipBtn(equipNow, equipSelect)
  self:_invokeAS("_root", "hideTutorialEquip")
  self:_invokeAS("_root", "_hideAllTutorial")
  self:_invokeAS("_root", "hideTutorialFengjie")
  local textRecovery = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_BREAK_DOWN") or "recovery"
  if nil == equipNow and nil ~= equipSelect then
    local textEquipOn = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_EQUIPMENT_BUTTON") or "equip on"
    self:_invokeAS("_root", "luafs_setEquipUIBtnModleEquipOn", textRecovery, textEquipOn)
    if QuestTutorialTacticsCenter:IsActive() then
      self:_invokeAS("_root", "showTutorialEquip")
    end
  elseif nil ~= equipNow and nil ~= equipSelect then
    if __equals(equipNow.id, equipSelect.id) then
      local textEquipOff = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_UNLOAD_BUTTON") or "equip off"
      self:_invokeAS("_root", "luafs_setEquipUIBtnModleEquipOff", textEquipOff)
    else
      local textEquipExchange = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_EXCHANGE_BUTTON") or "exchange"
      self:_invokeAS("_root", "luafs_setEquipUIBtnModleEquipExchange", textRecovery, textEquipExchange)
    end
  elseif nil ~= equipNow and nil == equipSelect then
    local textEquipOff = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_UNLOAD_BUTTON") or "equip off"
    self:_invokeAS("_root", "luafs_setEquipUIBtnModleEquipOff", textEquipOff)
  else
    assert("logic error, can't be here")
  end
  if QuestTutorialTacticsRefine:IsActive() or QuestTutorialTacticsCenter:IsActive() then
    self:_invokeAS("_root", "showTutorialFengjie")
  end
end
function GameObjectTacticsCenter:__setUIEquipInfo(equip, popBarAttrWrap, iconBarAttrWrap)
  DebugOut("GameObjectTacticsCenter:__setUIEquipInfo")
  DebugOut("popBarAttrWrap:")
  DebugOut(popBarAttrWrap)
  DebugOut("iconBarAttrWrap:")
  DebugOut(iconBarAttrWrap)
  DebugOut(tostring(equip == nil))
  if not equip then
    return
  end
  local vessel = equip.vessel
  local icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(RefineDataManager:EquipToItem(equip.type), nil, nil)
  local equipName = GameLoader:GetGameText("LC_ITEM_ITEM_NAME_" .. equip.type)
  if nil == equipName or "" == equipName then
    equipName = "equipid:" .. equip.type
  end
  local equipDes = GameLoader:GetGameText("LC_ITEM_ITEM_DESC_" .. equip.type)
  if nil == equipDes or "" == equipNequipDesame then
    equipDes = "equip description"
  end
  local des = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_PROFESSION_LIMIT")
  des = string.format(des, "" .. GameObjectTacticsCenter:getVesselText(equip.vessel))
  self:_invokeAS("_root", "luafs_updateEquipUIEquipInfo", vessel, icon, equipName, equipDes, popBarAttrWrap, iconBarAttrWrap, des)
end
function GameObjectTacticsCenter:getVesselText(vessel)
  local info = ""
  if vessel == 1 then
    info = GameLoader:GetGameText("LC_FLEET_TYPE_1")
  elseif vessel == 2 then
    info = GameLoader:GetGameText("LC_FLEET_TYPE_2")
  elseif vessel == 3 then
    info = GameLoader:GetGameText("LC_FLEET_TYPE_3")
  elseif vessel == 4 then
    info = GameLoader:GetGameText("LC_FLEET_TYPE_4")
  elseif vessel == 5 then
    info = GameLoader:GetGameText("LC_FLEET_TYPE_5")
  elseif vessel == 6 then
    info = GameLoader:GetGameText("LC_FLEET_TYPE_6")
  end
  return info
end
function GameObjectTacticsCenter.donamicDownloadFinishCallback(...)
  if not GameObjectTacticsCenter:GetFlashObject() then
    return
  end
  GameObjectTacticsCenter:dataDrive_UpdateEquipInfoAndBtn()
end
function GameObjectTacticsCenter:_updateUIEquipInfoAndBtn(vessel, equipIdInSlot, equipId)
  DebugOut("GameObjectTacticsCenter:_updateUIEquipInfoAndBtn")
  DebugOut("equipIdInSlot:" .. tostring(equipIdInSlot))
  DebugOut("equipId:" .. tostring(equipId))
  local equipNow = equipIdInSlot and tcdm:getEquipById(equipIdInSlot)
  local equipSelect = equipId and tcdm:getEquipById(equipId)
  local equipListMetaData = tcdm:getEquipListRemoveSlotInEquip(vessel)
  DebugTable(equipNow)
  DebugTable(equipSelect)
  self:__setUIEquipBtn(equipNow, equipSelect)
  self:_invokeAS("_root", "_hideAllTutorial")
  if nil == equipId and nil == equipIdInSlot then
    self:_invokeAS("_root", "luafs_setEquipUIModuleNone", vessel, GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_9"))
    DebugOut("equipListMetaData:")
    DebugOut(#equipListMetaData)
    if QuestTutorialTacticsCenter:IsActive() and #equipListMetaData > 0 then
      DebugOut("---")
      self:_invokeAS("_root", "showTutorialShot")
    end
  elseif nil ~= equipId and nil == equipIdInSlot then
    local popBarAttrWrap = self:_createEquipOnPopBarAttrWrap(equipSelect)
    local iconBarAttrWrap = self:_createEquipOnIconBarAttrWrap(equipSelect)
    self:__setUIEquipInfo(equipSelect, popBarAttrWrap, iconBarAttrWrap)
  elseif nil == equipId and nil ~= equipIdInSlot then
    local popBarAttrWrap = self:_createEquipOffPopBarAttrWrap(equipNow)
    local iconBarAttrWrap = self:_createEquipOffIconBarAttrWrap(equipNow)
    self:__setUIEquipInfo(equipNow, popBarAttrWrap, iconBarAttrWrap)
  elseif nil ~= equipId and nil ~= equipIdInSlot then
    if __equals(equipId, equipIdInSlot) then
      local popBarAttrWrap = self:_createEquipOffPopBarAttrWrap(equipSelect)
      local iconBarAttrWrap = self:_createEquipOffIconBarAttrWrap(equipSelect)
      self:__setUIEquipInfo(equipSelect, popBarAttrWrap, iconBarAttrWrap)
    else
      local popBarAttrWrap = self:_createEquipExchangePopBarAttrWrap(equipNow, equipSelect)
      local iconBarAttrWrap = self:_createEquipExchangeIconBarAttrWrap(equipNow, equipSelect)
      self:__setUIEquipInfo(equipSelect, popBarAttrWrap, iconBarAttrWrap)
    end
  else
    assert(" imposible here ")
  end
end
function GameObjectTacticsCenter:_updateUIEquipList(vessel)
  DebugOut("GameObjectTacticsCenter:_updateUIEquipList")
  DebugOut(vessel)
  self:_invokeAS("_root", "luafs_clearEquipListBox")
  local equipListMetaData = tcdm:getEquipListRemoveSlotInEquip(vessel)
  DebugOut("equipListMetaData")
  DebugTable(equipListMetaData)
  local newEquipList = {}
  LuaUtils:table_merge(newEquipList, equipListMetaData)
  table.sort(newEquipList, function(equip1, equip2)
    if not __equals(equip1.rank, equip2.rank) then
      return equip1.rank > equip2.rank
    end
    if not __equals(equip1.type, equip2.type) then
      return equip1.type > equip2.type
    end
    local equip1MainAttr = self:_findMainAttrInEquip(equip1)
    local equip2MainAttr = self:_findMainAttrInEquip(equip2)
    return equip1MainAttr.color > equip2MainAttr.color
  end)
  DebugTable(newEquipList)
  for idex, equip in ipairs(newEquipList) do
    local icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(RefineDataManager:EquipToItem(equip.type), nil, GameObjectTacticsCenter.DownloadFinishCallback)
    self:_invokeAS("_root", "luafs_addItemInEquipListBox", equip.vessel, equip.id, equip.type, icon)
  end
  if #newEquipList < 5 then
    for i = 0, 4 - #newEquipList do
      self:_invokeAS("_root", "luafs_addItemInEquipListBox", 0, 0, 0, 0)
    end
  end
  if #newEquipList > 5 then
    self:_invokeAS("_root", "luafs_setCanMoveList", 1)
  else
    self:_invokeAS("_root", "luafs_setCanMoveList", 0)
  end
end
function GameObjectTacticsCenter.DownloadFinishCallback(...)
  if not GameObjectTacticsCenter:GetFlashObject() then
    return
  end
  DebugOut("DownloadFinishCallback")
  GameObjectTacticsCenter:_updateUIEquipList(GameObjectTacticsCenter._vesselOpenNow)
end
function GameObjectTacticsCenter:_tipUISlotUnavailableReasonOrPopUnlockConfirming()
  local unlockCondition = tcdm:getUnlockSlotConditionAndCast()
  DebugOut("unlockCondition:")
  DebugTable(unlockCondition)
  local tipInfo = ""
  if unlockCondition.level > 0 and 0 < unlockCondition.vip then
    if self:getPlayerLevel() >= unlockCondition.level or self:getPlayerVipLevel() >= unlockCondition.vip then
      GameObjectTacticsCenter:_onUnlockSlot(unlockCondition)
    else
      tipInfo = GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_8")
      tipInfo = string.gsub(tipInfo, "<playerLevel_num>", unlockCondition.level)
      tipInfo = string.gsub(tipInfo, "<vipLevel_num>", unlockCondition.vip)
    end
  elseif unlockCondition.level > 0 and unlockCondition.vip == 0 then
    if self:getPlayerLevel() >= unlockCondition.level then
      GameObjectTacticsCenter:_onUnlockSlot(unlockCondition)
    else
      tipInfo = string.format(GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_6"), unlockCondition.level)
    end
  elseif unlockCondition.level == 0 and 0 < unlockCondition.vip then
    if self:getPlayerVipLevel() >= unlockCondition.vip then
      GameObjectTacticsCenter:_onUnlockSlot(unlockCondition)
    else
      tipInfo = string.format(GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_7"), unlockCondition.vip)
    end
  end
  if tipInfo ~= "" then
    GameTip:Show(tipInfo)
  end
end
function GameObjectTacticsCenter:_onUnlockSlot(unlockCondition)
  local confirmingTable = {}
  local resourceCount
  for i, gameItem in ipairs(unlockCondition.cost) do
    resourceCount = GameHelper:GetAwardCount(gameItem.item_type, gameItem.number, gameItem.no)
  end
  DebugOut("resourceCount = ", resourceCount)
  if resourceCount > 0 then
    GameUIMessageDialog:SetStyle(GameUIMessageDialog.DialogStyle.YesNo)
    GameUIMessageDialog:SetYesButton(function()
      GameObjectTacticsCenter._onConfirmUnlockSlot()
    end)
    GameUIMessageDialog:SetNoButton(function()
    end)
    local textTitle = GameLoader:GetGameText("LC_MENU_TITLE_VERIFY")
    local confirmingInfo = string.format(GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_INFO_17"), resourceCount)
    GameUIMessageDialog:Display(textTitle, confirmingInfo)
  else
    GameObjectTacticsCenter._onConfirmUnlockSlot()
  end
end
function GameObjectTacticsCenter._onConfirmUnlockSlot()
  GameObjectTacticsCenter:_requestForUnlockNextSlot()
end
function GameObjectTacticsCenter:_showUIHelpInfo()
  GameUIWDStuff:Show(GameUIWDStuff.menuType.menu_type_help)
  GameUIWDStuff:SetHelpText(GameLoader:GetGameText("LC_MENU_TACTICAL_CENTER_HELP_1"))
end
function GameObjectTacticsCenter:_runUIForceUpAnimation(valUp)
  self:_invokeAS("_root", "luafs_runForceUpAnimation", "" .. math.abs(valUp))
end
function GameObjectTacticsCenter:_runUIForceDownAnimation(valDown)
  self:_invokeAS("_root", "luafs_runForceDownAnimation", "" .. math.abs(valDown))
end
function GameObjectTacticsCenter:Update(dt)
  if not self:GetFlashObject() then
    return
  end
  self:GetFlashObject():Update(dt)
  self:_invokeAS("_root", "luafs_update", dt)
  GameUITacticsCenterRefine:Update(dt)
end
function GameObjectTacticsCenter:_openDebuggingUI(vessel, equipId)
  local equip = tcdm:getEquipById(equipId)
  assert(equip)
  SubDebugging:AddRefineToTacticsCenter(vessel, self:GetFlashObject(), equip)
end
function GameObjectTacticsCenter:_locateListToEquip(equipId)
  self:_invokeAS("_root", "luafs_locateEquipListToEquip", equipId)
end
function GameObjectTacticsCenter:dataDrive_UpdateEquipInfoAndBtn()
  if self._vesselOpenNow then
    local equipInSlot = tcdm:getEquipInSlot(self._vesselOpenNow)
    self:_updateUIEquipInfoAndBtn(self._vesselOpenNow, equipInSlot and equipInSlot.id, self._equipIdSelectNow)
  end
end
function GameObjectTacticsCenter:dataDrive_UpdateEquipInListHighlightState()
  self:_invokeAS("_root", "luafs_unhighlightAllEquip")
  if self._equipIdSelectNow then
    self:_invokeAS("_root", "luafs_highlightEquip", self._equipIdSelectNow)
  end
end
function GameObjectTacticsCenter:dataDrive_UpdateAllSlotHighlightState()
  for _, vessel in pairs(tcdm.EvesselType) do
    self:_unhighlightSlot(vessel)
  end
  if self._vesselOpenNow then
    self:_highLightSlot(self._vesselOpenNow)
  end
end
function GameObjectTacticsCenter:getPlayerVipLevel()
  local vipinfo = GameGlobalData:GetData("vipinfo")
  DebugTable(vipinfo)
  return vipinfo.level
end
function GameObjectTacticsCenter:getPlayerLevel()
  local levelinfo = GameGlobalData:GetData("levelinfo")
  DebugTable(levelinfo)
  return levelinfo.level
end
function GameObjectTacticsCenter:getFleetsForce()
  local fleets = GameGlobalData:GetData("fleetinfo").fleets
  local InMatrix = GameGlobalData:GetData("matrix").cells
  DebugOut("fleets:")
  DebugTable(fleets)
  DebugOut("InMatrix:")
  DebugTable(InMatrix)
  local newForce = 0
  for i, fleet in pairs(fleets) do
    if GameUtils:IsInMatrix(fleet.identity) then
      newForce = newForce + fleet.force
    end
  end
  return newForce
end
if AutoUpdate.isAndroidDevice then
  function GameObjectTacticsCenter.OnAndroidBack()
    if tcdm:getShowState() == tcdm.ShowLayerState.tacticsCenter then
      GameObjectTacticsCenter:_invokeAS("_root", "luafs_closeMain")
    elseif tcdm:getShowState() == tcdm.ShowLayerState.tacticsRefine then
      GameUITacticsCenterRefine:OnFSCommand("close_refine", "")
    end
  end
end
