local consume = GameData.equip_enhance.consume
table.insert(consume, {
  EQUIP_TYPE = 100001,
  CONSUME = 20,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100002,
  CONSUME = 26,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100003,
  CONSUME = 21,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100004,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100005,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100006,
  CONSUME = 28,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100011,
  CONSUME = 20,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100012,
  CONSUME = 26,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100013,
  CONSUME = 21,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100014,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100015,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100016,
  CONSUME = 28,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100021,
  CONSUME = 20,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100022,
  CONSUME = 26,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100023,
  CONSUME = 21,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100024,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100025,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100026,
  CONSUME = 28,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100031,
  CONSUME = 20,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100032,
  CONSUME = 26,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100033,
  CONSUME = 21,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100034,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100035,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100036,
  CONSUME = 28,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100041,
  CONSUME = 20,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100042,
  CONSUME = 26,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100043,
  CONSUME = 21,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100044,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100045,
  CONSUME = 13,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100046,
  CONSUME = 28,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100051,
  CONSUME = 30,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100052,
  CONSUME = 39,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100053,
  CONSUME = 31,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100054,
  CONSUME = 19,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100055,
  CONSUME = 19,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100056,
  CONSUME = 42,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100061,
  CONSUME = 45,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100062,
  CONSUME = 58,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100063,
  CONSUME = 46,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100064,
  CONSUME = 28,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100065,
  CONSUME = 28,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100066,
  CONSUME = 63,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100071,
  CONSUME = 67,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100072,
  CONSUME = 87,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100073,
  CONSUME = 69,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100074,
  CONSUME = 42,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100075,
  CONSUME = 42,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100076,
  CONSUME = 94,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100081,
  CONSUME = 100,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100082,
  CONSUME = 130,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100083,
  CONSUME = 103,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100084,
  CONSUME = 63,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100085,
  CONSUME = 63,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100086,
  CONSUME = 141,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100091,
  CONSUME = 150,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100092,
  CONSUME = 195,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100093,
  CONSUME = 154,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100094,
  CONSUME = 94,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100095,
  CONSUME = 94,
  CDTIME = 120
})
table.insert(consume, {
  EQUIP_TYPE = 100096,
  CONSUME = 211,
  CDTIME = 120
})
