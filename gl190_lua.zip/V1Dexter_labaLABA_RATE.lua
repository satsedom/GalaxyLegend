local LABA_RATE = GameData.Dexter_laba.LABA_RATE
LABA_RATE[1] = {rateType = 1}
LABA_RATE[2] = {rateType = 2}
LABA_RATE[3] = {rateType = 3}
LABA_RATE[4] = {rateType = 4}
