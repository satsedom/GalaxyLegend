module("TacticsCenterDataManager", package.seeall)
local __equals = function(a, b)
  return a == b
end
TacticsCenterDataManager = {}
TacticsCenterDataManager.EequipRank = {
  green_ = 1,
  blue_ = 2,
  purple_ = 3,
  glod_ = 4
}
TacticsCenterDataManager.EattrRank = {
  white_ = 0,
  green_ = 1,
  blue_ = 2,
  purple_ = 3,
  glod_ = 4
}
TacticsCenterDataManager.EvesselType = {
  qi_jian = 6,
  tu_ji = 1,
  da_ji = 2,
  pai_huai = 5,
  hui_mie = 4,
  hu_wei = 3
}
TacticsCenterDataManager.ESlotState = {
  none_ = {},
  equiped_ = {},
  lock_ = {}
}
TacticsCenterDataManager.EAttrType = {main_ = 1, bonus_ = 2}
TacticsCenterDataManager.EAttrExist = {
  new_ = 1,
  del_ = 2,
  com_ = 3
}
TacticsCenterDataManager.ShowLayerState = {
  tacticsCenter = 1,
  tacticsCenterHelp = 2,
  tacticsRefine = 3,
  tacticsRefineHelp = 4
}
function TacticsCenterDataManager:clearData()
  TacticsCenterDataManager._dataChangeListeners = {}
  TacticsCenterDataManager._slotDatas = {}
  TacticsCenterDataManager._equipDatas = {
    [TacticsCenterDataManager.EvesselType.qi_jian] = {},
    [TacticsCenterDataManager.EvesselType.tu_ji] = {},
    [TacticsCenterDataManager.EvesselType.da_ji] = {},
    [TacticsCenterDataManager.EvesselType.pai_huai] = {},
    [TacticsCenterDataManager.EvesselType.hui_mie] = {},
    [TacticsCenterDataManager.EvesselType.hu_wei] = {}
  }
  TacticsCenterDataManager._usedSlotCount = 0
  TacticsCenterDataManager._availableSlotCount = 0
  TacticsCenterDataManager._unlockSlotConditionAndCast = {}
  TacticsCenterDataManager._showState = 0
end
function TacticsCenterDataManager:initDataUseEnterTacticalACK(content)
  DebugOut("TacticsCenterDataManager:initDataUseEnterTacticalACK")
  DebugTable(content)
  DebugOut(content.equip_num)
  self._usedSlotCount = content.equip_num
  self._availableSlotCount = content.equip_max
  self._unlockSlotConditionAndCast = content.unlock_slot
  self._slotDatas = content.slots
  for i, slot in ipairs(self._slotDatas) do
    assert(self:_isEvesselValue(slot.vessel))
    self._equipDatas[slot.vessel] = slot.equips
  end
end
function TacticsCenterDataManager:createADataChangeListener()
  local listener = {}
  function listener:onEquipOff(slot, equip)
  end
  function listener:onEquipOn(equip)
  end
  function listener:onEquipChange(oldEquip, newEquip)
  end
  function listener:onDebuggingSave(equip)
  end
  function listener:onUnlockSlotCount(oldCount, newCount)
  end
  return listener
end
TacticsCenterDataManager.EDataChange = {
  equip_off = {},
  equip_on = {},
  equip_change = {},
  debugging_save = {},
  available_slot_count_change = {}
}
function TacticsCenterDataManager:getEquipList(vessel)
  assert(self:_isEvesselValue(vessel))
  return self._equipDatas[vessel]
end
function TacticsCenterDataManager:getEquipListRemoveSlotInEquip(vessel)
  assert(self:_isEvesselValue(vessel))
  local slotEquip = self:getEquipInSlot(vessel)
  local equipListRemoveSlotEquip = {}
  if slotEquip then
    for i, v in ipairs(self._equipDatas[vessel]) do
      if v.id ~= slotEquip.id then
        table.insert(equipListRemoveSlotEquip, v)
      end
    end
  else
    return self._equipDatas[vessel]
  end
  return equipListRemoveSlotEquip
end
function TacticsCenterDataManager:_dispathDataChange(changeType, ...)
  assert(self:_isEDataChangeValue(changeType))
  for _, lr in ipairs(self._dataChangeListeners) do
    if __equals(self.EDataChange.equip_off, changeType) then
      lr:onEquipOff(...)
    elseif __equals(self.EDataChange.equip_on, changeType) then
      lr:onEquipOn(...)
    elseif __equals(self.EDataChange.equip_change, changeType) then
      lr:onEquipChange(...)
    elseif __equals(self.EDataChange.debugging_save, changeType) then
      lr:onDebuggingSave(...)
    elseif __equals(self.EDataChange.available_slot_count_change, changeType) then
      lr:onUnlockSlotCount(...)
    else
      assert(false)
    end
  end
end
function TacticsCenterDataManager.__isAEnumValue(val, enumTable)
  for k, v in pairs(enumTable) do
    if v == val then
      return true
    end
  end
  return false
end
function TacticsCenterDataManager:_isEDataChangeValue(val)
  return self.__isAEnumValue(val, self.EDataChange)
end
function TacticsCenterDataManager:_isEvesselValue(val)
  return self.__isAEnumValue(val, self.EvesselType)
end
function TacticsCenterDataManager:_isEattrRankValue(val)
  return self.__isAEnumValue(val, self.EattrRank)
end
function TacticsCenterDataManager:_isEequipRankValue(val)
  return self.__isAEnumValue(val, self.EequipRank)
end
function TacticsCenterDataManager:getSlotDataByVessel(vessel)
  assert(self:_isEvesselValue(vessel))
  for i, aSlot in ipairs(self._slotDatas) do
    if __equals(aSlot.vessel, vessel) then
      return aSlot
    end
  end
  assert("logic error, here always get the data")
end
function TacticsCenterDataManager:getUsedSlotCount()
  return self._usedSlotCount
end
function TacticsCenterDataManager:getAvailableSlotCount()
  return self._availableSlotCount
end
function TacticsCenterDataManager:getEquipById(id)
  DebugOut("TacticsCenterDataManager:getEquipById")
  DebugOut(id)
  for i, equipList in ipairs(self._equipDatas) do
    for i, equip in ipairs(equipList) do
      if __equals(equip.id, id) then
        return equip
      end
    end
  end
  return nil
end
function TacticsCenterDataManager:addDataChangeListener(lr)
  assert(lr)
  table.insert(self._dataChangeListeners, lr)
end
function TacticsCenterDataManager:remvoeDataChangeListener(lr)
  if not lr then
    return
  end
  for i, aLr in ipairs(self._dataChangeListeners) do
    if __equals(aLr, lr) then
      table.remove(self._dataChangeListeners, i)
      break
    end
  end
end
function TacticsCenterDataManager.__isSlotUsed(slot)
  return slot.equip_id ~= "0"
end
function TacticsCenterDataManager.__setSoltUnused(slot)
  slot.equip_id = "0"
end
function TacticsCenterDataManager.__setEquipUnused(equip)
  equip.is_equip = false
end
function TacticsCenterDataManager.__setSoltEquip(slot, equipId)
  slot.equip_id = equipId
end
function TacticsCenterDataManager.__setEquipUsed(equip)
  equip.is_equip = true
end
function TacticsCenterDataManager:_unequipEquip(vessel)
  assert(self:_isEvesselValue(vessel))
  local slot = self:getSlotDataByVessel(vessel)
  assert(slot and self.__isSlotUsed(slot))
  local equip = self:getEquipById(slot.equip_id)
  assert(equip)
  self.__setSoltUnused(slot)
  self.__setEquipUnused(equip)
  self._usedSlotCount = self._usedSlotCount - 1
end
function TacticsCenterDataManager:unequipEquip(vessel)
  local slot = self:getSlotDataByVessel(vessel)
  assert(slot and self.__isSlotUsed(slot))
  local oldEquip = self:getEquipById(slot.equip_id)
  self:_unequipEquip(vessel)
  self:_dispathDataChange(self.EDataChange.equip_off, slot, oldEquip)
end
function TacticsCenterDataManager:_equipEquip(vessel, equipId)
  assert(self:_isEvesselValue(vessel))
  local slot = self:getSlotDataByVessel(vessel)
  assert(slot and not self.__isSlotUsed(slot))
  local equip = self:getEquipById(equipId)
  assert(equip)
  self.__setSoltEquip(slot, equipId)
  self.__setEquipUsed(equip)
  self._usedSlotCount = self._usedSlotCount + 1
end
function TacticsCenterDataManager:exchangeEquip(vessel, newEquipId)
  local slot = self:getSlotDataByVessel(vessel)
  assert(slot and self.__isSlotUsed(slot))
  local oldEquipId = slot.equip_id
  self:_unequipEquip(vessel)
  self:_equipEquip(vessel, newEquipId)
  local oldEquip = self:getEquipById(oldEquipId)
  local newEquip = self:getEquipById(newEquipId)
  self:_dispathDataChange(self.EDataChange.equip_change, oldEquip, newEquip)
end
function TacticsCenterDataManager:equipEquip(vessel, equipId)
  self:_equipEquip(vessel, equipId)
  local equip = self:getEquipById(equipId)
  self:_dispathDataChange(self.EDataChange.equip_on, equip)
end
function TacticsCenterDataManager:saveDebuggingResult(vessel, equipId, newAttrs)
  assert(self:_isEvesselValue(vessel))
  local equipList = self._equipDatas[vessel]
  for i, equip in ipairs(equipList) do
    if __equals(equip.id, equipId) then
      equip.equip_attrs = newAttrs
      self:_dispathDataChange(self.EDataChange.debugging_save, equip)
      break
    end
  end
end
function TacticsCenterDataManager:_isLockUnusedSlot()
  return self:getUsedSlotCount() == self:getAvailableSlotCount()
end
function TacticsCenterDataManager:getSlotDataByVessel(vessel)
  DebugOut(vessel)
  DebugOut(type(vessel))
  assert(self:_isEvesselValue(vessel))
  local idex, slot = LuaUtils:array_find_if(self._slotDatas, function(aSlot)
    return __equals(vessel, aSlot.vessel)
  end)
  assert(slot)
  return slot
end
function TacticsCenterDataManager:getSlotState(vessel)
  local slot = self:getSlotDataByVessel(vessel)
  if self.__isSlotUsed(slot) then
    return self.ESlotState.equiped_
  end
  if self:_isLockUnusedSlot() then
    return self.ESlotState.lock_
  end
  return self.ESlotState.none_
end
function TacticsCenterDataManager:getEquipInSlot(vessel)
  local slotState = self:getSlotState(vessel)
  if not __equals(self.ESlotState.equiped_, slotState) then
    return nil
  end
  local slot = self:getSlotDataByVessel(vessel)
  return self:getEquipById(slot.equip_id)
end
function TacticsCenterDataManager:getUnlockSlotConditionAndCast()
  return self._unlockSlotConditionAndCast
end
function TacticsCenterDataManager:updateUnlockSlotConditionAndCast(newData)
  local oldCount = self._availableSlotCount
  local newCount = self._unlockSlotConditionAndCast.benefit
  self._availableSlotCount = newCount
  self._unlockSlotConditionAndCast = newData
  self:_dispathDataChange(self.EDataChange.available_slot_count_change, oldCount, newCount)
end
function TacticsCenterDataManager:getVesselAmount()
  local count = 0
  for k, v in pairs(self.EvesselType) do
    count = count + 1
  end
  return count
end
function TacticsCenterDataManager:deleteAUnusedEquip(equipid)
  DebugOut("TacticsCenterDataManager:deleteAUnusedEquip")
  DebugOut("equipId:" .. equipid)
  for vessel, equipList in pairs(self._equipDatas) do
    DebugTable(equipList)
    local index = LuaUtils:array_find_if(equipList, function(equip)
      return __equals(equip.id, equipid)
    end)
    if not __equals(0, index) then
      return table.remove(equipList, index)
    end
  end
  return nil
end
function TacticsCenterDataManager:getHasEquipAndMin(...)
  local showTutorialVessel = 0
  for key, value in ipairs(self._slotDatas) do
    if tonumber(value.equip_id) ~= 0 and showTutorialVessel < value.vessel then
      showTutorialVessel = value.vessel
    end
  end
  DebugOut("getHasEquipAndMin:" .. showTutorialVessel)
  return showTutorialVessel
end
function TacticsCenterDataManager:setShowState(showstate)
  TacticsCenterDataManager._showState = showstate
end
function TacticsCenterDataManager:getShowState(...)
  return self._showState
end
