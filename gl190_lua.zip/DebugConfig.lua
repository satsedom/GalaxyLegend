DebugConfig = {
  isDebugOut = false,
  isDebugTable = false,
  isDebugValue = false,
  isDebugStack = false,
  isDebugState = false,
  isDebugTutorial = false,
  isDebugFlurry = false,
  isDebugActivity = false,
  isDebugNews = false,
  isDebugStore = false,
  isDebugFestival = false,
  isDebugColonial = false,
  isDebugOutBattle = false,
  isDebugBattlePlay = false,
  isDebugBattlePlayBattle = false,
  isDebugWD = false,
  isDebugMem = false,
  isWriteToLogFile = false,
  isWriteTableToFile = false,
  isDebugTip = false,
  isAssertAddObject = false,
  isDebugFPS = false,
  isDebugBattle = false,
  isAutoSkipBattle = false,
  isSkipFirstScene = false,
  isDebugBattllePlayLoad = false,
  isDebugTutorialQuest = false,
  isSuperMode = false,
  isEnterGameDirectly = false,
  isDebugWelcome = false
}
local m_sendingWarning = {}
if not AutoUpdate.isDeveloper then
  DebugConfig = {}
end
function DebugWarning(assertSuccess, info)
  if assertSuccess then
    return
  end
  DebugOut("DebugWarning: " .. info)
  do return end
  if m_sendingWarning[info] ~= nil then
    return
  end
  m_sendingWarning[info] = true
  local warn_info = {
    device_name = ext.GetDeviceName(),
    device_real_name = ext.GetDeviceName(),
    udid = ext.GetIOSOpenUdid(),
    player_id = GameGlobalData:GetData("userinfo") and GameGlobalData:GetData("userinfo").player_id or -1,
    level = GameGlobalData:GetData("levelinfo") and GameGlobalData:GetData("levelinfo").level or 0,
    info_type = "Warning",
    info_code = info
  }
  DebugTable(warn_info)
  NetMessageMgr:SendMsg(NetAPIList.warn_req.Code, warn_info, nil, false, nil)
end
function DebugTraceStack()
  if DebugConfig.isDebugStack then
    print("------------------------------traceback start------------------------------\n")
    print(debug.traceback())
    print("------------------------------traceback end------------------------------\n")
  end
end
function DebugOut(...)
  if DebugConfig.isDebugOut then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugState(...)
  if DebugConfig.isDebugState then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugTutorial(...)
  if DebugConfig.isDebugTutorial then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugFlurry(...)
  if DebugConfig.isDebugFlurry then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugNews(...)
  if DebugConfig.isDebugNews then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugNewsTable(...)
  if DebugConfig.isDebugNews then
    GameUtils:printTable(...)
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    wrtieLogToFile(...)
  end
end
function DebugActivity(...)
  if DebugConfig.isDebugActivity then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugActivityTable(...)
  if DebugConfig.isDebugActivity then
    GameUtils:printTable(...)
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    wrtieLogToFile(...)
  end
end
function DebugStore(...)
  if DebugConfig.isDebugStore then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugStoreTable(...)
  if DebugConfig.isDebugStore then
    GameUtils:printTable(...)
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    wrtieLogToFile(...)
  end
end
function DebugWD(...)
  if DebugConfig.isDebugWD then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugMem(...)
  if DebugConfig.isDebugMem then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugWDTable(...)
  if DebugConfig.isDebugWD then
    GameUtils:printTable(...)
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    wrtieLogToFile(...)
  end
end
function DebugFestival(...)
  if DebugConfig.isDebugFestival then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugFestivalTable(...)
  if DebugConfig.isDebugFestival then
    GameUtils:printTable(...)
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    wrtieLogToFile(...)
  end
end
function DebugColonial(...)
  if DebugConfig.isDebugColonial then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugColonialTable(...)
  if DebugConfig.isDebugColonial then
    GameUtils:printTable(...)
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    wrtieLogToFile(...)
  end
end
function DebugTable(...)
  if DebugConfig.isDebugTable then
    GameUtils:printTable(...)
    if AutoUpdate.isAndroidDevice then
      GameUtils:DebugOutTableInAndroid(...)
    end
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    wrtieLogToFile(...)
  end
end
function DebugOutPutTable(...)
  if DebugConfig.isDebugTable then
    GameUtils:outputTable(...)
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    flushTableAndName(...)
  end
end
function DebugOutBattle(...)
  if DebugConfig.isDebugOutBattle then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugOutBattlePlay(...)
  if DebugConfig.isDebugBattlePlay then
    print(...)
  end
  if DebugConfig.isWriteToLogFile then
    wrtieLogToFile(...)
  end
end
function DebugOutBattlePlayTable(...)
  if DebugConfig.isDebugBattlePlayBattle then
    GameUtils:printTable(...)
  end
  if DebugConfig.isWriteToLogFile and DebugConfig.isWriteTableToFile then
    wrtieLogToFile(...)
  end
end
function flushTableAndName(t, name)
  ext.SaveLuaLogToFile("tableName:" .. name .. "\n" .. LuaUtils:serializeTable(t))
end
function wrtieLogToFile(...)
  dataType = type(...)
  if dataType == "table" then
    return
  else
    local WholeString = ""
    for i = 1, select("#", ...) do
      arg = select(i, ...)
      if arg then
        WholeString = WholeString .. " " .. tostring(arg)
      end
    end
    ext.SaveLuaLogToFile(tostring(WholeString))
  end
end
