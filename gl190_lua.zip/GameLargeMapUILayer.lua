local GameUILargeMap = LuaObjectManager:GetLuaObject("GameUILargeMap")
function GameUILargeMap:updateExcuAndStatus()
  if self:GetFlashObject() then
    local data = {}
    local player_main_fleet = GameGlobalData:GetFleetInfo(1)
    local player_avatar = GameUtils:GetPlayerAvatar(nil, player_main_fleet.level)
    local leaderlist = GameGlobalData:GetData("leaderlist")
    if leaderlist and GameGlobalData.GlobalData and GameGlobalData.GlobalData.curMatrixIndex and leaderlist.leader_ids and leaderlist.leader_ids[GameGlobalData.GlobalData.curMatrixIndex] then
      player_avatar = GameDataAccessHelper:GetFleetAvatar(leaderlist.leader_ids[GameGlobalData.GlobalData.curMatrixIndex], player_main_fleet.level)
      DebugOut("fix")
    elseif GameGlobalData:GetUserInfo().icon ~= 0 and GameGlobalData:GetUserInfo().icon ~= 1 then
      player_avatar = GameDataAccessHelper:GetFleetAvatar(GameGlobalData:GetUserInfo().icon, player_main_fleet.level)
    end
    data.avatar = player_avatar
    data.executxt = self.MyPlayerData.cur_energy .. "/" .. self.MyPlayerData.max_energy
    data.statustxt = ""
    self:GetFlashObject():InvokeASCallback("_root", "updateHeadInfo", data)
  end
end
