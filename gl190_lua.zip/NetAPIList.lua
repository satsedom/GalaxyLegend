NetAPIList = {
  keylist_ntf = {Code = 10000, S = "keylist"},
  udid_step_req = {Code = 10001, S = "udid_step"},
  udid_track_req = {Code = 10002, S = "udid_track"},
  common_ack = {Code = 0, S = "common_ack"},
  user_register_req = {
    Code = 1,
    S = "user_register_info"
  },
  user_register_ack = {
    Code = 2,
    S = "user_snapshot"
  },
  user_login_req = {
    Code = 3,
    S = "user_login_info"
  },
  user_login_ack = {
    Code = 4,
    S = "user_snapshot"
  },
  building_upgrade_req = {
    Code = 5,
    S = "building_upgrade_info"
  },
  user_snapshot_req = {Code = 7, S = "null"},
  user_snapshot_ack = {
    Code = 8,
    S = "user_snapshot"
  },
  chat_req = {Code = 9, S = "chat_req"},
  chat_ntf = {Code = 10, S = "chat_ntf"},
  user_logout_req = {Code = 11, S = "null"},
  fleets_req = {Code = 12, S = "null"},
  fleets_ack = {
    Code = 13,
    S = "fleets_info"
  },
  pve_battle_req = {
    Code = 14,
    S = "battle_request"
  },
  user_rush_req = {
    Code = 15,
    S = "battle_request"
  },
  rush_result_ack = {
    Code = 16,
    S = "rush_result_ack"
  },
  user_cdtime_ack = {
    Code = 19,
    S = "user_cdtime_info"
  },
  user_cdtime_req = {Code = 20, S = "null"},
  pve_map_status_req = {
    Code = 21,
    S = "map_status_req"
  },
  user_map_status_ack = {
    Code = 22,
    S = "user_map_status"
  },
  battle_status_req = {
    Code = 23,
    S = "battle_status_req"
  },
  battle_status_ack = {
    Code = 24,
    S = "battle_status_ack"
  },
  battle_matrix_req = {
    Code = 25,
    S = "battle_matrix_req"
  },
  battle_matrix_ack = {
    Code = 26,
    S = "battle_matrix_ack"
  },
  user_matrix_save_req = {Code = 27, S = "matrix"},
  battle_result_ack = {
    Code = 28,
    S = "battle_result_ack"
  },
  bag_req = {Code = 30, S = "bag_req"},
  bag_ack = {Code = 31, S = "bag_info"},
  swap_bag_grid_req = {
    Code = 32,
    S = "swap_bag_grid_req"
  },
  swap_bag_grid_ack = {
    Code = 33,
    S = "swap_bag_grid_info"
  },
  techniques_req = {Code = 34, S = "null"},
  techniques_ack = {
    Code = 35,
    S = "techniques_ack"
  },
  gm_cmd_req = {Code = 36, S = "gm_cmd"},
  pack_bag_req = {Code = 37, S = "pack_bag"},
  techniques_upgrade_req = {
    Code = 38,
    S = "techniques_upgrade_req"
  },
  techniques_upgrade_ack = {
    Code = 39,
    S = "techniques_upgrade_ack"
  },
  revenue_info_req = {Code = 40, S = "null"},
  revenue_info_ack = {
    Code = 41,
    S = "revenue_info_ack"
  },
  revenue_do_req = {
    Code = 42,
    S = "revenue_do_req"
  },
  revenue_do_ack = {
    Code = 43,
    S = "revenue_do_ack"
  },
  add_friend_req = {
    Code = 45,
    S = "add_friend_req"
  },
  del_friend_req = {
    Code = 46,
    S = "del_friend_req"
  },
  officers_req = {Code = 47, S = "null"},
  officers_ack = {
    Code = 48,
    S = "officers_ack"
  },
  officer_buy_req = {
    Code = 49,
    S = "officer_buy_req"
  },
  officer_buy_ack = {
    Code = 50,
    S = "officer_buy_ack"
  },
  recruit_list_req = {Code = 54, S = "null"},
  recruit_list_ack = {
    Code = 55,
    S = "recruit_list_ack"
  },
  recruit_fleet_req = {
    Code = 56,
    S = "recruit_fleet_req"
  },
  recruit_fleet_ack = {
    Code = 57,
    S = "recruit_fleet_ack"
  },
  dismiss_fleet_req = {
    Code = 58,
    S = "dismiss_fleet_req"
  },
  dismiss_fleet_ack = {
    Code = 59,
    S = "dismiss_fleet_ack"
  },
  friends_req = {Code = 60, S = "null"},
  friends_ack = {
    Code = 61,
    S = "friends_ack"
  },
  friend_detail_req = {
    Code = 63,
    S = "friend_detail_req"
  },
  equipment_detail_req = {
    Code = 64,
    S = "equipment_detail_req"
  },
  equipment_detail_ack = {
    Code = 65,
    S = "equipment_detail_ack"
  },
  friend_detail_ack = {
    Code = 66,
    S = "friend_detail"
  },
  friend_search_req = {
    Code = 67,
    S = "friend_search_req"
  },
  friend_search_ack = {
    Code = 68,
    S = "friend_search_ack"
  },
  friend_ban_req = {
    Code = 69,
    S = "friend_ban_req"
  },
  warpgate_status_req = {Code = 70, S = "null"},
  warpgate_status_ack = {
    Code = 71,
    S = "warpgate_info"
  },
  warpgate_charge_req = {
    Code = 72,
    S = "warpgate_charge_req"
  },
  warpgate_charge_ack = {
    Code = 73,
    S = "warpgate_charge_ack"
  },
  warpgate_collect_req = {Code = 74, S = "null"},
  warpgate_collect_ack = {
    Code = 75,
    S = "warpgate_collect_ack"
  },
  warpgate_upgrade_req = {
    Code = 76,
    S = "warpgate_upgrade_req"
  },
  warpgate_upgrade_ack = {
    Code = 77,
    S = "warpgate_upgrade_ack"
  },
  mail_page_req = {
    Code = 78,
    S = "mail_page_req"
  },
  mail_page_ack = {
    Code = 79,
    S = "mail_page_ack"
  },
  mail_content_req = {
    Code = 80,
    S = "mail_content_req"
  },
  mail_content_ack = {
    Code = 81,
    S = "mail_content_ack"
  },
  mail_send_req = {
    Code = 82,
    S = "mail_send_req"
  },
  mail_delete_req = {
    Code = 83,
    S = "mail_delete_req"
  },
  mail_set_read_req = {
    Code = 84,
    S = "mail_set_read_req"
  },
  fight_ack = {
    Code = 86,
    S = "fight_report"
  },
  equipment_enhance_req = {
    Code = 87,
    S = "equipment_enhance_req"
  },
  equipment_evolution_req = {
    Code = 90,
    S = "equipment_evolution_req"
  },
  equipments_req = {Code = 93, S = "null"},
  equipments_ack = {
    Code = 94,
    S = "equipments_ack"
  },
  quark_exchange_req = {
    Code = 95,
    S = "quark_exchange_req"
  },
  quark_exchange_ack = {
    Code = 96,
    S = "quark_exchange_ack"
  },
  shop_purchase_req = {
    Code = 97,
    S = "shop_purchase_req"
  },
  shop_purchase_ack = {
    Code = 98,
    S = "shop_purchase_ack"
  },
  shop_sell_req = {
    Code = 99,
    S = "shop_sell_req"
  },
  shop_sell_ack = {
    Code = 100,
    S = "shop_sell_ack"
  },
  shop_purchase_back_list_req = {Code = 101, S = "null"},
  shop_purchase_back_list_ack = {
    Code = 102,
    S = "shop_purchase_back_list_ack"
  },
  shop_purchase_back_req = {
    Code = 103,
    S = "shop_purchase_back_req"
  },
  shop_purchase_back_ack = {
    Code = 104,
    S = "shop_purchase_back_ack"
  },
  user_offline_info_req = {Code = 105, S = "null"},
  user_offline_info_ack = {
    Code = 106,
    S = "user_offline_info_ack"
  },
  user_collect_offline_expr_req = {Code = 107, S = "null"},
  user_collect_offline_expr_ack = {
    Code = 108,
    S = "user_collect_offline_expr_ack"
  },
  fleet_repair_all_req = {
    Code = 109,
    S = "fleet_repair_all_req"
  },
  fleet_repair_req = {
    Code = 110,
    S = "fleet_repair_req"
  },
  friend_ban_del_req = {
    Code = 112,
    S = "friend_ban_del_req"
  },
  messages_req = {Code = 113, S = "null"},
  messages_ack = {
    Code = 114,
    S = "messages_ack"
  },
  message_del_req = {
    Code = 115,
    S = "message_del_req"
  },
  alliances_req = {
    Code = 116,
    S = "alliances_req"
  },
  alliances_ack = {
    Code = 117,
    S = "alliances_ack"
  },
  alliance_members_req = {
    Code = 118,
    S = "alliance_members_req"
  },
  alliance_members_ack = {
    Code = 119,
    S = "alliance_members_ack"
  },
  alliance_logs_req = {
    Code = 120,
    S = "alliance_logs_req"
  },
  alliance_logs_ack = {
    Code = 121,
    S = "alliance_logs_ack"
  },
  alliance_aduits_req = {
    Code = 122,
    S = "alliance_aduits_req"
  },
  alliance_aduits_ack = {
    Code = 123,
    S = "alliance_aduits_ack"
  },
  alliance_create_req = {
    Code = 124,
    S = "alliance_create_req"
  },
  alliance_create_ack = {
    Code = 125,
    S = "alliance_create_ack"
  },
  alliance_create_fail_ack = {
    Code = 126,
    S = "alliance_create_fail_ack"
  },
  alliance_delete_req = {Code = 127, S = "null"},
  alliance_delete_ack = {
    Code = 128,
    S = "alliance_delete_ack"
  },
  alliance_delete_fail_ack = {
    Code = 129,
    S = "alliance_delete_fail_ack"
  },
  alliance_apply_req = {
    Code = 130,
    S = "alliance_apply_req"
  },
  alliance_apply_ack = {
    Code = 131,
    S = "alliance_apply_ack"
  },
  alliance_apply_fail_ack = {
    Code = 132,
    S = "alliance_apply_fail_ack"
  },
  alliance_unapply_req = {
    Code = 133,
    S = "alliance_unapply_req"
  },
  alliance_unapply_ack = {
    Code = 134,
    S = "alliance_unapply_ack"
  },
  alliance_info_req = {
    Code = 135,
    S = "alliance_info_req"
  },
  alliance_info_ack = {
    Code = 136,
    S = "alliance_info_ack"
  },
  add_friend_ack = {
    Code = 137,
    S = "add_friend_ack"
  },
  krypton_store_req = {
    Code = 140,
    S = "krypton_store_req"
  },
  krypton_store_ack = {
    Code = 141,
    S = "krypton_store_ack"
  },
  krypton_enhance_req = {
    Code = 142,
    S = "krypton_enhance_req"
  },
  krypton_enhance_ack = {
    Code = 143,
    S = "krypton_enhance_ack"
  },
  krypton_equip_req = {
    Code = 144,
    S = "krypton_equip_req"
  },
  krypton_gacha_one_req = {
    Code = 145,
    S = "krypton_gacha_one_req"
  },
  krypton_gacha_one_ack = {
    Code = 146,
    S = "krypton_gacha_one_ack"
  },
  krypton_gacha_some_req = {
    Code = 147,
    S = "krypton_gacha_some_req"
  },
  krypton_gacha_some_ack = {
    Code = 148,
    S = "krypton_gacha_some_ack"
  },
  krypton_equip_off_req = {
    Code = 149,
    S = "krypton_equip_off_req"
  },
  krypton_decompose_req = {
    Code = 150,
    S = "krypton_decompose_req"
  },
  krypton_decompose_ack = {
    Code = 151,
    S = "krypton_decompose_ack"
  },
  alliance_ratify_req = {
    Code = 153,
    S = "alliance_ratify_req"
  },
  alliance_ratify_ack = {
    Code = 154,
    S = "alliance_ratify_ack"
  },
  alliance_refuse_req = {
    Code = 155,
    S = "alliance_refuse_req"
  },
  alliance_refuse_ack = {
    Code = 156,
    S = "alliance_refuse_ack"
  },
  alliance_memo_req = {
    Code = 157,
    S = "alliance_memo_req"
  },
  alliance_memo_ack = {
    Code = 158,
    S = "alliance_memo_ack"
  },
  alliance_memo_fail_ack = {
    Code = 159,
    S = "alliance_memo_fail_ack"
  },
  champion_list_req = {Code = 160, S = "null"},
  champion_list_ack = {
    Code = 161,
    S = "champion_list_ack"
  },
  champion_challenge_req = {
    Code = 162,
    S = "champion_challenge_req"
  },
  champion_challenge_ack = {
    Code = 163,
    S = "champion_challenge_ack"
  },
  champion_top_req = {Code = 164, S = "null"},
  champion_top_ack = {
    Code = 165,
    S = "champion_top_ack"
  },
  champion_reset_cd_req = {Code = 166, S = "null"},
  champion_reset_cd_ack = {
    Code = 167,
    S = "champion_reset_cd_ack"
  },
  champion_get_award_req = {Code = 168, S = "null"},
  champion_get_award_ack = {
    Code = 169,
    S = "champion_get_award_ack"
  },
  krypton_store_swap_req = {
    Code = 179,
    S = "krypton_store_swap_req"
  },
  alliance_quit_req = {Code = 180, S = "null"},
  alliance_quit_ack = {
    Code = 181,
    S = "alliance_quit_ack"
  },
  alliance_quit_fail_ack = {
    Code = 182,
    S = "alliance_quit_fail_ack"
  },
  alliance_transfer_req = {
    Code = 183,
    S = "alliance_transfer_req"
  },
  alliance_transfer_ack = {
    Code = 184,
    S = "alliance_transfer_ack"
  },
  alliance_transfer_fail_ack = {
    Code = 185,
    S = "alliance_transfer_fail_ack"
  },
  alliance_demote_req = {
    Code = 186,
    S = "alliance_demote_req"
  },
  alliance_demote_ack = {
    Code = 187,
    S = "alliance_demote_ack"
  },
  alliance_demote_fail_ack = {
    Code = 188,
    S = "alliance_demote_fail_ack"
  },
  alliance_promote_req = {
    Code = 189,
    S = "alliance_promote_req"
  },
  alliance_promote_ack = {
    Code = 191,
    S = "alliance_promote_ack"
  },
  alliance_promote_fail_ack = {
    Code = 192,
    S = "alliance_promote_fail_ack"
  },
  alliance_kick_req = {
    Code = 193,
    S = "alliance_kick_req"
  },
  alliance_kick_ack = {
    Code = 194,
    S = "alliance_kick_ack"
  },
  alliance_kick_fail_ack = {
    Code = 195,
    S = "alliance_kick_fail_ack"
  },
  krypton_equip_ack = {
    Code = 196,
    S = "krypton_equip_ack"
  },
  krypton_fleet_equip_req = {
    Code = 197,
    S = "krypton_fleet_equip_req"
  },
  user_fight_history_req = {Code = 198, S = "null"},
  user_fight_history_ack = {
    Code = 199,
    S = "user_fight_history_ack"
  },
  user_brief_info_req = {
    Code = 200,
    S = "user_brief_info_req"
  },
  user_brief_info_ack = {
    Code = 201,
    S = "user_brief_info"
  },
  krypton_fleet_move_req = {
    Code = 202,
    S = "krypton_fleet_move_req"
  },
  alliance_unapply_fail_ack = {
    Code = 203,
    S = "alliance_unapply_fail_ack"
  },
  alliance_info_ntf = {
    Code = 204,
    S = "alliance_info_ntf"
  },
  user_challenged_ack = {
    Code = 205,
    S = "user_challenged_ack"
  },
  task_list_req = {Code = 206, S = "null"},
  task_list_ack = {
    Code = 207,
    S = "task_list_ack"
  },
  get_task_reward_req = {
    Code = 208,
    S = "get_task_reward_req"
  },
  battle_fight_report_req = {
    Code = 210,
    S = "battle_fight_report_req"
  },
  battle_fight_report_ack = {
    Code = 211,
    S = "battle_fight_report_ack"
  },
  shop_buy_and_wear_req = {
    Code = 212,
    S = "shop_buy_and_wear_req"
  },
  prestige_info_req = {Code = 214, S = "null"},
  prestige_info_ack = {
    Code = 215,
    S = "prestige_info_ack"
  },
  prestige_obtain_award_req = {
    Code = 216,
    S = "prestige_obtain_award_req"
  },
  prestige_obtain_award_ack = {
    Code = 217,
    S = "prestige_obtain_award_ack"
  },
  prestige_complete_ntf = {
    Code = 218,
    S = "prestige_complete_ntf"
  },
  achievement_list_req = {Code = 219, S = "null"},
  achievement_list_ack = {
    Code = 220,
    S = "achievement_list_ack"
  },
  achievement_finish_ntf = {
    Code = 223,
    S = "achievement_finish_ntf"
  },
  fleets_ntf = {
    Code = 226,
    S = "fleets_info"
  },
  resource_ntf = {
    Code = 227,
    S = "user_resource"
  },
  cd_time_ntf = {
    Code = 228,
    S = "user_cdtime_info"
  },
  fleet_kryptons_ntf = {
    Code = 229,
    S = "fleet_kryptons_array"
  },
  supply_ntf = {
    Code = 230,
    S = "supply_notify"
  },
  level_ntf = {Code = 231, S = "level_info"},
  equipments_update_ntf = {
    Code = 232,
    S = "equipments_update_ntf"
  },
  attributes_change_ntf = {
    Code = 233,
    S = "attributes_change_ntf"
  },
  progress_ntf = {
    Code = 234,
    S = "user_progress"
  },
  buildings_ntf = {
    Code = 235,
    S = "user_buildings"
  },
  offline_changed_ntf = {
    Code = 236,
    S = "user_offline_info"
  },
  fleet_matrix_ntf = {Code = 238, S = "matrix"},
  heart_beat_req = {Code = 239, S = "null"},
  task_finished_ntf = {
    Code = 240,
    S = "task_statistic_info"
  },
  mail_unread_ntf = {
    Code = 241,
    S = "mail_unread_info"
  },
  passport_bind_req = {
    Code = 242,
    S = "passport_bind_req"
  },
  passport_bind_ack = {
    Code = 243,
    S = "passport_bind_ack"
  },
  act_status_req = {
    Code = 245,
    S = "act_status_req"
  },
  act_status_ack = {
    Code = 246,
    S = "act_status_ack"
  },
  vip_info_ntf = {Code = 247, S = "vip_info"},
  revenue_exchange_req = {Code = 248, S = "null"},
  supply_info_req = {
    Code = 249,
    S = "supply_type"
  },
  supply_info_ack = {
    Code = 250,
    S = "supply_info_ack"
  },
  supply_exchange_req = {
    Code = 251,
    S = "supply_type"
  },
  connection_close_req = {Code = 252, S = "null"},
  cdtimes_clear_req = {
    Code = 253,
    S = "cdtimes_clear_req"
  },
  system_configuration_req = {
    Code = 254,
    S = "system_configuration_req"
  },
  system_configuration_ack = {
    Code = 255,
    S = "system_configuration_ack"
  },
  pay_verify_req = {
    Code = 256,
    S = "pay_verify_req"
  },
  pay_list_req = {
    Code = 257,
    S = "pay_list_req"
  },
  pay_list_ack = {
    Code = 258,
    S = "pay_list_ack"
  },
  use_item_req = {
    Code = 259,
    S = "use_item_req"
  },
  sign_activity_req = {Code = 260, S = "null"},
  sign_activity_ack = {
    Code = 261,
    S = "sign_activite"
  },
  sign_activity_reward_req = {
    Code = 262,
    S = "sign_activity_reward_req"
  },
  create_tipoff_req = {
    Code = 263,
    S = "create_tipoff_req"
  },
  server_kick_user_ntf = {
    Code = 264,
    S = "server_kick"
  },
  bag_grid_ntf = {Code = 265, S = "bag_info"},
  update_spell_ntf = {Code = 266, S = "null"},
  level_up_ntf = {
    Code = 267,
    S = "level_up_ntf"
  },
  pve_awards_get_req = {
    Code = 268,
    S = "battle_request"
  },
  pve_awards_get_ack = {
    Code = 269,
    S = "battle_result"
  },
  price_req = {
    Code = 270,
    S = "price_request"
  },
  price_ack = {
    Code = 271,
    S = "price_response"
  },
  module_status_ntf = {
    Code = 272,
    S = "modules_status"
  },
  all_act_status_req = {
    Code = 273,
    S = "all_act_status_req"
  },
  all_act_status_ack = {
    Code = 274,
    S = "all_act_status_ack"
  },
  special_battle_req = {
    Code = 275,
    S = "battle_request"
  },
  special_battle_ack = {
    Code = 276,
    S = "special_battle_ack"
  },
  battle_money_collect_req = {
    Code = 277,
    S = "battle_money_collect_req"
  },
  quest_ntf = {Code = 278, S = "quest"},
  quest_loot_req = {
    Code = 279,
    S = "quest_loot_req"
  },
  quest_req = {Code = 280, S = "null"},
  event_loot_ack = {
    Code = 281,
    S = "event_loot_ack"
  },
  battle_event_status_ack = {
    Code = 282,
    S = "battle_event_status_ack"
  },
  adventure_map_status_req = {
    Code = 283,
    S = "map_status_req"
  },
  adventure_battle_req = {
    Code = 284,
    S = "battle_request"
  },
  adventure_cd_clear_req = {
    Code = 285,
    S = "adv_chapter"
  },
  adventure_rush_req = {
    Code = 286,
    S = "battle_request"
  },
  adventure_cd_price_req = {
    Code = 288,
    S = "adv_chapter"
  },
  loud_cast_ntf = {Code = 292, S = "loud_cast"},
  mine_list_req = {Code = 293, S = "null"},
  mine_refresh_req = {
    Code = 294,
    S = "mine_refresh_req"
  },
  mine_digg_req = {
    Code = 295,
    S = "mine_digg_req"
  },
  mine_atk_req = {
    Code = 296,
    S = "mine_atk_req"
  },
  mine_speedup_req = {Code = 297, S = "null"},
  mine_boost_req = {Code = 298, S = "null"},
  mine_list_ntf = {
    Code = 299,
    S = "mine_list_ntf"
  },
  mine_refresh_ntf = {
    Code = 300,
    S = "mine_refresh_ntf"
  },
  mine_info_ntf = {
    Code = 301,
    S = "mine_info_ntf"
  },
  mine_complete_ntf = {
    Code = 304,
    S = "mine_complete_ntf"
  },
  mine_atk_ntf = {
    Code = 305,
    S = "mine_atk_ntf"
  },
  mine_info_req = {Code = 306, S = "null"},
  mine_reset_atk_cd_req = {Code = 307, S = "null"},
  event_supply_ack = {
    Code = 310,
    S = "pve_supply_ack"
  },
  supply_loot_req = {Code = 311, S = "null"},
  supply_loot_ack = {
    Code = 312,
    S = "supply_loot_ack"
  },
  supply_loot_get_req = {Code = 313, S = "null"},
  update_guide_progress_req = {
    Code = 314,
    S = "guide_progress"
  },
  guide_progress_ntf = {
    Code = 315,
    S = "guide_progress"
  },
  laba_req = {Code = 316, S = "laba_req"},
  laba_ntf = {Code = 317, S = "laba_info"},
  laba_rate_reroll_req = {Code = 318, S = "null"},
  laba_info_req = {Code = 319, S = "null"},
  laba_award_req = {
    Code = 320,
    S = "laba_award_req"
  },
  dexter_libs_ntf = {
    Code = 321,
    S = "dexter_libs_ntf"
  },
  center_ntf = {
    Code = 322,
    S = "player_center_ntf"
  },
  chat_error_ntf = {
    Code = 323,
    S = "chat_error_ntf"
  },
  top_force_list_req = {Code = 324, S = "null"},
  top_force_list_ntf = {
    Code = 325,
    S = "top_force_list_ntf"
  },
  supply_loot_ntf = {
    Code = 326,
    S = "supply_loot_ntf"
  },
  ver_check_req = {Code = 327, S = "client_ver"},
  refresh_time_ntf = {
    Code = 328,
    S = "refresh_time_ntf"
  },
  ac_info_req = {Code = 329, S = "null"},
  ac_ntf = {Code = 330, S = "ac_ntf"},
  ac_battle_req = {Code = 331, S = "null"},
  ac_energy_charge_req = {Code = 332, S = "null"},
  ac_energy_charge_ack = {
    Code = 333,
    S = "ac_energy_charge_ack"
  },
  ac_jam_req = {Code = 334, S = "null"},
  ac_battle_info_req = {Code = 335, S = "null"},
  ac_matrix_req = {Code = 336, S = "null"},
  gateway_info_ntf = {
    Code = 337,
    S = "gateway_info_ntf"
  },
  notice_set_read_req = {
    Code = 338,
    S = "notice_info"
  },
  gateway_clear_req = {
    Code = 339,
    S = "gateway_info"
  },
  alliance_activities_req = {
    Code = 340,
    S = "alliance_activities_req"
  },
  alliance_activities_ack = {
    Code = 341,
    S = "alliance_activities_ack"
  },
  alliance_weekend_award_req = {Code = 342, S = "null"},
  alliance_weekend_award_ack = {
    Code = 343,
    S = "alliance_weekend_award_ack"
  },
  block_devil_info_req = {
    Code = 344,
    S = "block_devil_info_req"
  },
  block_devil_ntf = {
    Code = 345,
    S = "block_devil_ntf"
  },
  block_devil_req = {
    Code = 346,
    S = "block_devil_req"
  },
  block_devil_complete_ntf = {
    Code = 347,
    S = "block_devil_complete_ntf"
  },
  donate_req = {Code = 348, S = "donate_req"},
  donate_ack = {Code = 349, S = "donate_ack"},
  donate_info_req = {Code = 350, S = "null"},
  donate_info_ack = {
    Code = 351,
    S = "donate_info_ack"
  },
  alliance_level_info_ntf = {
    Code = 352,
    S = "alliance_level_info"
  },
  login_first_ntf = {
    Code = 353,
    S = "login_first_ntf"
  },
  champion_top_record_req = {Code = 354, S = "null"},
  champion_top_record_ack = {
    Code = 355,
    S = "user_fight_history_ack"
  },
  login_time_current_ntf = {
    Code = 356,
    S = "login_time_current_ntf"
  },
  champion_rank_reward_req = {Code = 357, S = "null"},
  champion_rank_reward_ack = {
    Code = 358,
    S = "champion_rank_reward_ack"
  },
  first_purchase_ntf = {
    Code = 359,
    S = "first_purchase"
  },
  vip_loot_req = {Code = 360, S = "null"},
  vip_loot_ack = {
    Code = 361,
    S = "level_loots"
  },
  level_loot_req = {Code = 362, S = "null"},
  level_loot_ack = {
    Code = 363,
    S = "level_loots"
  },
  vip_loot_get_req = {
    Code = 364,
    S = "level_loot_req"
  },
  level_loot_get_req = {
    Code = 365,
    S = "level_loot_req"
  },
  active_gifts_ntf = {
    Code = 366,
    S = "active_gifts_ntf"
  },
  active_gifts_req = {
    Code = 367,
    S = "active_gifts_req"
  },
  krypton_energy_req = {Code = 368, S = "null"},
  promotions_ntf = {
    Code = 369,
    S = "promotions_ntf"
  },
  promotions_req = {Code = 370, S = "null"},
  promotion_award_req = {
    Code = 371,
    S = "promotion_award_req"
  },
  promotion_award_ack = {
    Code = 372,
    S = "promotion_award_ack"
  },
  ready_world_boss_req = {
    Code = 373,
    S = "ready_world_boss_req"
  },
  challenge_world_boss_req = {Code = 374, S = "null"},
  exit_world_boss_req = {Code = 375, S = "null"},
  world_boss_info_ntf = {
    Code = 376,
    S = "world_boss_info_ntf"
  },
  challenge_world_boss_ack = {
    Code = 377,
    S = "challenge_world_boss_ack"
  },
  ready_world_boss_ack = {
    Code = 378,
    S = "ready_world_boss_ack"
  },
  add_world_boss_force_rate_req = {Code = 379, S = "null"},
  clean_world_boss_cd_req = {Code = 380, S = "null"},
  add_world_boss_force_rate_ack = {
    Code = 381,
    S = "add_world_boss_force_rate_ack"
  },
  allstars_reward_req = {
    Code = 382,
    S = "allstars_reward_req"
  },
  allstars_reward_ack = {
    Code = 383,
    S = "allstars_reward_ack"
  },
  timelimit_hero_id_req = {Code = 384, S = "null"},
  timelimit_hero_id_ack = {
    Code = 385,
    S = "timelimit_hero_id_ack"
  },
  fleet_sale_with_rebate_list_req = {Code = 386, S = "null"},
  fleet_sale_with_rebate_list_ack = {
    Code = 387,
    S = "fleet_sale_with_rebate_list_ack"
  },
  promotion_detail_req = {
    Code = 388,
    S = "promotion_detail_req"
  },
  promotion_detail_ack = {
    Code = 389,
    S = "promotion_detail_ack"
  },
  cut_off_list_req = {Code = 390, S = "null"},
  cut_off_list_ack = {
    Code = 391,
    S = "cut_off_list_ack"
  },
  buy_cut_off_req = {
    Code = 392,
    S = "buy_cut_off_req"
  },
  promotion_award_ntf = {
    Code = 393,
    S = "promotion_award_ntf"
  },
  new_activities_compare_req = {
    Code = 394,
    S = "new_activities_compare_req"
  },
  activities_button_status_ntf = {
    Code = 395,
    S = "activities_button_status_ntf"
  },
  krypton_fragment_core_ntf = {
    Code = 396,
    S = "krypton_fragment_core_ntf"
  },
  activities_button_first_status_req = {
    Code = 397,
    S = "activities_button_first_status_req"
  },
  stores_req = {Code = 400, S = "stores_req"},
  stores_ack = {Code = 401, S = "stores_ack"},
  stores_buy_req = {
    Code = 403,
    S = "stores_buy_req"
  },
  equipment_action_list_req = {
    Code = 404,
    S = "equipment_action_list_req"
  },
  equipment_action_list_ack = {
    Code = 405,
    S = "equipment_action_list_ack"
  },
  mail_to_alliance_req = {
    Code = 406,
    S = "mail_to_alliance_req"
  },
  chat_history_async_req = {Code = 407, S = "null"},
  thanksgiven_rank_req = {Code = 408, S = "null"},
  thanksgiven_rank_ack = {
    Code = 409,
    S = "thanksgiven_box_rank"
  },
  festival_req = {Code = 410, S = "null"},
  festival_ack = {
    Code = 411,
    S = "festival_info"
  },
  verify_redeem_code_req = {
    Code = 412,
    S = "verify_redeem_code_req"
  },
  verify_redeem_code_ack = {
    Code = 413,
    S = "verify_redeem_code_ack"
  },
  items_count_ntf = {
    Code = 414,
    S = "items_count_ntf"
  },
  thanksgiven_champion_ntf = {
    Code = 415,
    S = "thanksgiven_champion_ntf"
  },
  item_use_award_ntf = {
    Code = 416,
    S = "item_use_award_ntf"
  },
  game_addtion_req = {
    Code = 417,
    S = "addition_info"
  },
  colony_info_ntf = {
    Code = 418,
    S = "colony_info_ntf"
  },
  colony_exp_ntf = {
    Code = 419,
    S = "colony_exp_ntf"
  },
  colony_times_ntf = {
    Code = 420,
    S = "colony_times_ntf"
  },
  colony_logs_ntf = {
    Code = 421,
    S = "colony_logs_ntf"
  },
  colony_users_req = {
    Code = 422,
    S = "colony_users_req"
  },
  colony_users_ack = {
    Code = 423,
    S = "colony_users_ack"
  },
  colony_challenge_req = {
    Code = 424,
    S = "colony_challenge_req"
  },
  colony_challenge_ack = {
    Code = 425,
    S = "colony_challenge_ack"
  },
  colony_info_test_req = {Code = 426, S = "null"},
  colony_info_test_ack = {
    Code = 427,
    S = "colony_info_test_ack"
  },
  colony_exploit_req = {
    Code = 428,
    S = "colony_exploit_req"
  },
  colony_exploit_ack = {
    Code = 429,
    S = "colony_exploit_ack"
  },
  colony_fawn_req = {
    Code = 430,
    S = "colony_fawn_req"
  },
  colony_fawn_ack = {
    Code = 431,
    S = "colony_fawn_ack"
  },
  activity_stores_req = {
    Code = 432,
    S = "activity_stores_req"
  },
  activity_stores_ack = {
    Code = 433,
    S = "activity_stores_ack"
  },
  activity_stores_buy_req = {
    Code = 434,
    S = "activity_stores_buy_req"
  },
  yys_ntf = {Code = 435, S = "yys_dict"},
  colony_release_req = {
    Code = 436,
    S = "colony_release_req"
  },
  colony_release_ack = {
    Code = 437,
    S = "colony_release_ack"
  },
  colony_action_purchase_req = {
    Code = 438,
    S = "colony_action_purchase_req"
  },
  colony_players_req = {
    Code = 439,
    S = "colony_players_req"
  },
  colony_players_ack = {
    Code = 440,
    S = "colony_players_ack"
  },
  prestige_get_req = {
    Code = 441,
    S = "prestige_get_req"
  },
  alliance_defence_req = {Code = 442, S = "null"},
  alliance_defence_ntf = {
    Code = 443,
    S = "alliance_defence_ntf"
  },
  alliance_set_defender_req = {
    Code = 444,
    S = "alliance_set_defender_req"
  },
  alliance_notifies_req = {
    Code = 445,
    S = "alliance_notifies_req"
  },
  alliance_resource_ntf = {
    Code = 446,
    S = "alliance_resource_ntf"
  },
  alliance_defence_repair_req = {Code = 447, S = "null"},
  alliance_defence_donate_req = {
    Code = 448,
    S = "alliance_defence_donate_req"
  },
  alliance_activity_times_ntf = {
    Code = 449,
    S = "alliance_activity_times_ntf"
  },
  fleet_info_req = {
    Code = 450,
    S = "fleet_info_req"
  },
  fleet_info_ack = {
    Code = 451,
    S = "fleet_info_ack"
  },
  common_ntf = {Code = 452, S = "common_ntf"},
  warn_req = {Code = 453, S = "warn_info"},
  krypton_info_req = {
    Code = 454,
    S = "krypton_info_req"
  },
  krypton_info_ack = {
    Code = 455,
    S = "krypton_info_ack"
  },
  items_req = {Code = 456, S = "items_req"},
  items_ack = {Code = 457, S = "items_ack"},
  client_effect_req = {
    Code = 458,
    S = "client_device_info"
  },
  client_effect_ack = {
    Code = 459,
    S = "client_device_ack"
  },
  award_receive_req = {
    Code = 460,
    S = "award_receive_req"
  },
  client_fps_req = {
    Code = 461,
    S = "client_fps_info"
  },
  taobao_trade_req = {
    Code = 462,
    S = "taobao_trade_req"
  },
  domination_join_req = {
    Code = 464,
    S = "domination_join_req"
  },
  alliance_domination_ntf = {
    Code = 465,
    S = "alliance_domination_ntf"
  },
  alliance_flag_req = {
    Code = 466,
    S = "alliance_flag_req"
  },
  domination_challenge_req = {
    Code = 467,
    S = "domination_challenge_req"
  },
  domination_challenge_ack = {
    Code = 468,
    S = "domination_challenge_ack"
  },
  domination_awards_list_req = {Code = 469, S = "null"},
  domination_awards_list_ack = {
    Code = 470,
    S = "domination_awards_list_ack"
  },
  domination_ranks_req = {
    Code = 471,
    S = "domination_ranks_req"
  },
  domination_ranks_ack = {
    Code = 472,
    S = "domination_ranks_ack"
  },
  alliance_domination_battle_ntf = {
    Code = 473,
    S = "alliance_domination_battle_ntf"
  },
  alliance_domination_defence_ntf = {
    Code = 474,
    S = "alliance_domination_defence_ntf"
  },
  alliance_defence_revive_req = {Code = 475, S = "null"},
  wd_star_req = {Code = 476, S = "null"},
  wd_star_ack = {
    Code = 477,
    S = "all_wd_star"
  },
  wd_award_req = {
    Code = 478,
    S = "wd_award_req"
  },
  wd_award_ack = {
    Code = 479,
    S = "wd_award_lists"
  },
  alliance_domination_total_rank_ntf = {
    Code = 480,
    S = "alliance_domination_total_rank_ntf"
  },
  wd_last_champion_req = {Code = 481, S = "null"},
  wd_last_champion_ack = {
    Code = 482,
    S = "wd_last_champion"
  },
  device_info_req = {
    Code = 483,
    S = "device_info_req"
  },
  wd_ranking_rank_req = {Code = 484, S = "null"},
  wd_ranking_rank_ack = {
    Code = 485,
    S = "wd_ranking_box_rank"
  },
  wd_ranking_champion_ntf = {
    Code = 486,
    S = "wd_ranking_champion_ntf"
  },
  open_box_info_req = {
    Code = 487,
    S = "open_box_info_req"
  },
  open_box_info_ack = {
    Code = 488,
    S = "open_box_info"
  },
  open_box_open_req = {
    Code = 489,
    S = "open_box_open_req"
  },
  open_box_open_ack = {
    Code = 490,
    S = "open_box_open_ack"
  },
  open_box_refresh_req = {
    Code = 491,
    S = "open_box_refresh_req"
  },
  open_box_refresh_ack = {
    Code = 492,
    S = "open_box_refresh_ack"
  },
  open_box_recent_ntf = {
    Code = 493,
    S = "open_box_recent_ntf"
  },
  battle_rate_ntf = {
    Code = 494,
    S = "battle_rate_ntf"
  },
  set_game_local_req = {
    Code = 495,
    S = "set_game_local_req"
  },
  contention_map_req = {
    Code = 496,
    S = "contention_map_req"
  },
  contention_map_ack = {
    Code = 497,
    S = "contention_map_ack"
  },
  contention_notifies_req = {
    Code = 498,
    S = "contention_notifies_req"
  },
  contention_info_ntf = {
    Code = 499,
    S = "contention_info_ntf"
  },
  contention_trip_ntf = {
    Code = 500,
    S = "contention_trip_ntf"
  },
  contention_station_ntf = {
    Code = 501,
    S = "contention_station_ntf"
  },
  contention_starting_req = {
    Code = 502,
    S = "contention_starting_req"
  },
  contention_revive_req = {
    Code = 503,
    S = "contention_revive_req"
  },
  contention_stop_req = {
    Code = 504,
    S = "contention_stop_req"
  },
  contention_stop_ack = {
    Code = 505,
    S = "contention_stop_ack"
  },
  alliance_domination_status_req = {Code = 506, S = "null"},
  alliance_domination_status_ack = {
    Code = 507,
    S = "alliance_domination_status_ack"
  },
  domination_buffer_of_rank_ntf = {
    Code = 508,
    S = "domination_buffer_of_rank_ntf"
  },
  activity_task_list_req = {Code = 509, S = "null"},
  activity_task_list_ack = {
    Code = 510,
    S = "activity_task_list_ack"
  },
  activity_task_reward_req = {
    Code = 511,
    S = "activity_task_reward_req"
  },
  activity_task_list_ntf = {
    Code = 512,
    S = "activity_task_list_ntf"
  },
  contention_battle_ntf = {
    Code = 513,
    S = "contention_battle_ntf"
  },
  contention_name_ntf = {
    Code = 514,
    S = "contention_name_ntf"
  },
  contention_occupier_req = {
    Code = 515,
    S = "contention_occupier_req"
  },
  contention_occupier_ack = {
    Code = 516,
    S = "contention_occupier_ack"
  },
  contention_transfer_req = {
    Code = 517,
    S = "contention_transfer_req"
  },
  contention_production_ntf = {
    Code = 518,
    S = "contention_production_ntf"
  },
  contention_collect_req = {
    Code = 519,
    S = "contention_collect_req"
  },
  contention_collect_ack = {
    Code = 520,
    S = "contention_collect_ack"
  },
  contention_logs_req = {
    Code = 521,
    S = "contention_logs_req"
  },
  contention_logs_ack = {
    Code = 522,
    S = "contention_logs_ack"
  },
  contention_logbattle_detail_req = {
    Code = 523,
    S = "contention_logbattle_detail_req"
  },
  contention_logbattle_detail_ack = {
    Code = 524,
    S = "contention_logbattle_detail_ack"
  },
  activity_status_req = {
    Code = 525,
    S = "activity_status_req"
  },
  activity_status_ack = {
    Code = 526,
    S = "activity_status_ack"
  },
  screen_track_req = {
    Code = 527,
    S = "screen_track"
  },
  contention_jump_ntf = {
    Code = 528,
    S = "contention_jump_ntf"
  },
  tango_invited_friends_req = {
    Code = 529,
    S = "tango_invited_friends_req"
  },
  tango_invited_friends_ack = {
    Code = 530,
    S = "tango_invited_friends_ack"
  },
  tango_invite_req = {
    Code = 531,
    S = "tango_invite_req"
  },
  dungeon_open_req = {Code = 532, S = "null"},
  dungeon_open_ack = {
    Code = 533,
    S = "dungeon_open_ack"
  },
  dungeon_enter_req = {
    Code = 534,
    S = "dungeon_enter_req"
  },
  ladder_enter_ack = {
    Code = 535,
    S = "ladder_enter_ack"
  },
  ladder_search_req = {
    Code = 536,
    S = "ladder_search_req"
  },
  ladder_search_ack = {
    Code = 537,
    S = "ladder_search_ack"
  },
  ladder_raids_req = {
    Code = 538,
    S = "ladder_raids_req"
  },
  ladder_raids_ack = {
    Code = 539,
    S = "ladder_raids_ack"
  },
  ladder_cancel_req = {
    Code = 540,
    S = "ladder_cancel_req"
  },
  ladder_fresh_req = {
    Code = 541,
    S = "ladder_fresh_req"
  },
  ladder_fresh_ack = {
    Code = 542,
    S = "ladder_fresh_ack"
  },
  ladder_gain_req = {
    Code = 543,
    S = "ladder_gain_req"
  },
  ladder_buy_search_req = {
    Code = 544,
    S = "ladder_buy_search_req"
  },
  ladder_buy_search_ack = {
    Code = 545,
    S = "ladder_buy_search_ack"
  },
  ladder_buy_reset_req = {
    Code = 546,
    S = "ladder_buy_reset_req"
  },
  ladder_buy_reset_ack = {
    Code = 547,
    S = "ladder_buy_reset_ack"
  },
  ladder_rank_req = {
    Code = 548,
    S = "ladder_rank_req"
  },
  ladder_rank_ack = {
    Code = 549,
    S = "ladder_rank_ack"
  },
  ladder_special_req = {
    Code = 550,
    S = "ladder_special_req"
  },
  ladder_special_ack = {
    Code = 551,
    S = "ladder_special_ack"
  },
  pay_animation_ntf = {
    Code = 552,
    S = "pay_animation_ntf"
  },
  hero_level_attr_diff_req = {
    Code = 553,
    S = "hero_level_attr_diff_req"
  },
  hero_level_attr_diff_ack = {
    Code = 554,
    S = "hero_level_attr_diff_ack"
  },
  fleet_enhance_req = {
    Code = 555,
    S = "fleet_enhance_req"
  },
  fleet_weaken_req = {
    Code = 556,
    S = "fleet_weaken_req"
  },
  contention_rank_req = {
    Code = 557,
    S = "contention_rank_req"
  },
  contention_rank_ack = {
    Code = 558,
    S = "contention_rank_ack"
  },
  fleet_show_req = {
    Code = 559,
    S = "fleet_show_req"
  },
  fleet_show_ack = {
    Code = 560,
    S = "fleet_show_ack"
  },
  contention_award_req = {
    Code = 561,
    S = "contention_award_req"
  },
  contention_award_ack = {
    Code = 562,
    S = "contention_award_ack"
  },
  contention_history_req = {
    Code = 563,
    S = "contention_history_req"
  },
  contention_history_ack = {
    Code = 564,
    S = "contention_history_ack"
  },
  orders_ntf = {Code = 565, S = "orders_ntf"},
  pay_list2_req = {
    Code = 566,
    S = "pay_list2_req"
  },
  pay_list2_ack = {
    Code = 567,
    S = "pay_list2_ack"
  },
  pay_verify2_req = {
    Code = 568,
    S = "pay_verify2_req"
  },
  pay_verify2_ack = {
    Code = 569,
    S = "pay_verify2_ack"
  },
  pay_confirm_req = {
    Code = 570,
    S = "pay_confirm_req"
  },
  contention_hit_ntf = {
    Code = 571,
    S = "contention_hit_ntf"
  },
  items_ntf = {Code = 572, S = "items_ntf"},
  user_notifies_req = {
    Code = 573,
    S = "user_notifies_req"
  },
  ip_ntf = {Code = 574, S = "ip_ntf"},
  mail_goods_req = {
    Code = 575,
    S = "mail_goods_req"
  },
  mail_goods_ack = {
    Code = 576,
    S = "mail_goods_ack"
  },
  mulmatrix_get_req = {Code = 577, S = "null"},
  mulmatrix_get_ack = {
    Code = 578,
    S = "mulmatrix_info"
  },
  mulmatrix_save_req = {
    Code = 579,
    S = "mulmatrix_one"
  },
  mulmatrix_buy_req = {Code = 580, S = "null"},
  mulmatrix_blank_ntf = {
    Code = 581,
    S = "mulmatrix_blank"
  },
  mulmatrix_price_req = {Code = 582, S = "null"},
  mulmatrix_price_ack = {
    Code = 583,
    S = "mulmatrix_price"
  },
  equip_info_req = {
    Code = 584,
    S = "equip_info_req"
  },
  equip_info_ack = {
    Code = 585,
    S = "equip_info_ack"
  },
  mycard_error_ntf = {
    Code = 586,
    S = "mycard_error"
  },
  ladder_reset_req = {
    Code = 587,
    S = "ladder_reset_req"
  },
  ladder_reset_ack = {
    Code = 588,
    S = "ladder_fresh_ack"
  },
  contention_king_info_req = {Code = 589, S = "null"},
  contention_king_info_ack = {
    Code = 590,
    S = "contention_king_info_ack"
  },
  contention_king_change_ntf = {
    Code = 591,
    S = "contention_king_change_ntf"
  },
  award_list_req = {Code = 592, S = "null"},
  award_list_ack = {
    Code = 593,
    S = "award_list_ack"
  },
  award_get_req = {
    Code = 594,
    S = "award_get_req"
  },
  award_get_all_req = {Code = 595, S = "null"},
  award_count_ntf = {
    Code = 596,
    S = "award_count_ntf"
  },
  contention_mission_info_req = {
    Code = 597,
    S = "contention_mission_info_req"
  },
  contention_mission_info_ack = {
    Code = 598,
    S = "contention_mission_info_ack"
  },
  contention_mission_award_req = {
    Code = 599,
    S = "contention_mission_award_req"
  },
  contention_leave_req = {Code = 600, S = "null"},
  adventure_chapter_status_ntf = {
    Code = 601,
    S = "adv_chapter_status_ntf"
  },
  pay_record_ntf = {
    Code = 602,
    S = "pay_record_ntf"
  },
  login_token_ntf = {
    Code = 603,
    S = "login_token_ntf"
  },
  dungeon_enter_ack = {
    Code = 604,
    S = "dungeon_enter_ack"
  },
  change_auto_decompose_req = {
    Code = 605,
    S = "change_auto_decompose"
  },
  change_auto_decompose_ntf = {
    Code = 606,
    S = "change_auto_decompose_ntf"
  },
  enchant_req = {
    Code = 607,
    S = "enchant_req"
  },
  enchant_ack = {
    Code = 608,
    S = "enchant_ack"
  },
  activity_dna_req = {
    Code = 609,
    S = "activity_dna_req"
  },
  activity_dna_ack = {
    Code = 610,
    S = "activity_dna_ack"
  },
  activity_dna_charge_req = {
    Code = 611,
    S = "activity_dna_charge_req"
  },
  akt_dna_next_stg_req = {
    Code = 612,
    S = "activity_dna_req"
  },
  crusade_enter_req = {Code = 613, S = "null"},
  crusade_enter_ack = {
    Code = 614,
    S = "crusade_enter_ack"
  },
  crusade_fight_req = {
    Code = 615,
    S = "crusade_fight_req"
  },
  crusade_fight_ack = {
    Code = 616,
    S = "crusade_fight_ack"
  },
  crusade_cross_req = {
    Code = 617,
    S = "crusade_cross_req"
  },
  crusade_cross_ack = {
    Code = 618,
    S = "crusade_cross_ack"
  },
  crusade_repair_req = {
    Code = 619,
    S = "crusade_repair_req"
  },
  crusade_reward_req = {
    Code = 620,
    S = "crusade_reward_req"
  },
  crusade_reward_ack = {
    Code = 621,
    S = "crusade_reward_ack"
  },
  crusade_buy_cross_req = {Code = 622, S = "null"},
  crusade_buy_cross_ack = {
    Code = 623,
    S = "crusade_buy_cross_ack"
  },
  crusade_first_req = {Code = 624, S = "null"},
  crusade_first_ack = {
    Code = 625,
    S = "crusade_first_ack"
  },
  akt_dna_get_award_req = {
    Code = 626,
    S = "activity_dna_req"
  },
  dna_gacha_ntf = {
    Code = 627,
    S = "open_box_recent_ntf"
  },
  contention_income_req = {Code = 628, S = "null"},
  contention_income_ack = {
    Code = 629,
    S = "contention_income_ack"
  },
  contention_missiles_ntf = {
    Code = 630,
    S = "contention_missiles_ntf"
  },
  budo_req = {Code = 631, S = "null"},
  budo_test_req = {
    Code = 632,
    S = "activity_dna_req"
  },
  budo_stage_ntf = {
    Code = 633,
    S = "budo_stage_ntf"
  },
  budo_sign_up_ntf = {
    Code = 634,
    S = "budo_sign_up_ntf"
  },
  budo_join_req = {Code = 635, S = "null"},
  budo_join_ack = {
    Code = 636,
    S = "budo_join_ack"
  },
  budo_mass_election_ntf = {
    Code = 637,
    S = "budo_mass_election_ntf"
  },
  budo_change_formation_req = {
    Code = 638,
    S = "budo_change_formation_req"
  },
  budo_change_formation_ack = {
    Code = 639,
    S = "budo_join_ack"
  },
  budo_promotion_req = {
    Code = 640,
    S = "budo_promotion_req"
  },
  budo_promotion_ntf = {
    Code = 642,
    S = "budo_promotion_ntf"
  },
  support_one_player_req = {
    Code = 643,
    S = "support_one_player_req"
  },
  battle_report_req = {
    Code = 644,
    S = "battle_report_req"
  },
  battle_report_ack = {
    Code = 645,
    S = "battle_report_ack"
  },
  get_my_support_req = {Code = 646, S = "null"},
  get_my_support_ack = {
    Code = 647,
    S = "get_my_support_ack"
  },
  get_budo_rank_req = {
    Code = 648,
    S = "get_budo_rank_req"
  },
  get_budo_rank_ack = {
    Code = 649,
    S = "get_budo_rank_ack"
  },
  get_budo_replay_req = {
    Code = 650,
    S = "get_budo_replay_req"
  },
  get_budo_replay_ack = {
    Code = 651,
    S = "get_budo_replay_ack"
  },
  get_promotion_reward_req = {
    Code = 652,
    S = "get_promotion_reward_req"
  },
  special_efficacy_ntf = {
    Code = 654,
    S = "special_efficacy_ntf"
  },
  activity_rank_req = {
    Code = 655,
    S = "activity_rank_req"
  },
  activity_rank_ack = {
    Code = 656,
    S = "activity_box_rank"
  },
  support_one_player_ack = {
    Code = 657,
    S = "support_one_player_ack"
  },
  all_gd_fleets_req = {Code = 658, S = "null"},
  all_gd_fleets_ack = {
    Code = 659,
    S = "all_gd_fleets_ack"
  },
  fleet_fight_report_req = {
    Code = 660,
    S = "fleet_fight_report_req"
  },
  fleet_fight_report_ack = {
    Code = 661,
    S = "fleet_fight_report_ack"
  },
  stores_refresh_req = {Code = 662, S = "null"},
  stores_refresh_ack = {
    Code = 663,
    S = "stores_refresh_ack"
  },
  laba_times_ntf = {
    Code = 664,
    S = "laba_times_ntf"
  },
  change_name_ntf = {Code = 665, S = "user_info"},
  pay_list_carrier_req = {
    Code = 666,
    S = "pay_list_carrier_req"
  },
  pay_list_carrier_ack = {
    Code = 667,
    S = "pay_list_carrier_ack"
  },
  laba_type_ntf = {
    Code = 668,
    S = "laba_type_ntf"
  },
  mail_to_all_req = {
    Code = 669,
    S = "mail_to_all_req"
  },
  champion_matrix_req = {
    Code = 670,
    S = "champion_matrix_req"
  },
  champion_matrix_ack = {
    Code = 671,
    S = "champion_matrix_ack"
  },
  add_adjutant_req = {
    Code = 672,
    S = "add_adjutant_req"
  },
  release_adjutant_req = {
    Code = 673,
    S = "release_adjutant_req"
  },
  month_card_list_req = {
    Code = 674,
    S = "month_card_list_req"
  },
  month_card_list_ack = {
    Code = 675,
    S = "month_card_list_ack"
  },
  month_card_buy_req = {
    Code = 676,
    S = "month_card_buy_req"
  },
  month_card_use_req = {
    Code = 677,
    S = "month_card_use_req"
  },
  chat_channel_switch_ntf = {
    Code = 678,
    S = "chat_channel_switch_ntf"
  },
  fleet_dismiss_req = {Code = 679, S = "null"},
  fleet_dismiss_ack = {
    Code = 680,
    S = "fleets_info"
  },
  adjutant_max_ntf = {
    Code = 681,
    S = "adjutant_max_ntf"
  },
  max_level_ntf = {
    Code = 682,
    S = "max_level_ntf"
  },
  game_items_trans_req = {
    Code = 683,
    S = "game_items_trans_req"
  },
  game_items_trans_ack = {
    Code = 684,
    S = "game_items_trans_ack"
  },
  budo_champion_req = {
    Code = 685,
    S = "budo_champion_req"
  },
  budo_champion_ack = {
    Code = 686,
    S = "budo_champion_ack"
  },
  budo_champion_report_req = {
    Code = 687,
    S = "budo_champion_report_req"
  },
  budo_champion_report_ack = {
    Code = 688,
    S = "get_budo_replay_ack"
  },
  client_version_ntf = {
    Code = 689,
    S = "client_version_ntf"
  },
  apply_limit_update_req = {
    Code = 690,
    S = "apply_limit_update_req"
  },
  version_code_ntf = {
    Code = 691,
    S = "version_code_ntf"
  },
  version_code_update_req = {
    Code = 692,
    S = "version_code_update_req"
  },
  remodel_info_req = {Code = 693, S = "null"},
  remodel_info_ack = {
    Code = 694,
    S = "remodel_info_ack"
  },
  remodel_info_ntf = {
    Code = 695,
    S = "remodel_info_ntf"
  },
  remodel_levelup_req = {
    Code = 696,
    S = "remodel_levelup_req"
  },
  remodel_help_req = {Code = 697, S = "null"},
  remodel_help_others_req = {
    Code = 698,
    S = "remodel_help_others_req"
  },
  remodel_speed_req = {
    Code = 699,
    S = "remodel_speed_req"
  },
  remodel_help_info_req = {Code = 700, S = "null"},
  remodel_help_info_ack = {
    Code = 701,
    S = "remodel_help_info_ack"
  },
  remodel_help_ntf = {
    Code = 702,
    S = "remodel_help_ntf"
  },
  remodel_push_ntf = {
    Code = 703,
    S = "remodel_push_ntf"
  },
  give_friends_gift_req = {
    Code = 704,
    S = "give_friends_gift_req"
  },
  give_share_awards_req = {
    Code = 705,
    S = "give_share_awards_req"
  },
  remodel_event_ntf = {
    Code = 706,
    S = "remodel_event_ntf"
  },
  give_friends_gift_ack = {
    Code = 707,
    S = "give_friends_gift_ack"
  },
  update_passport_req = {
    Code = 708,
    S = "update_passport_req"
  },
  financial_req = {Code = 709, S = "null"},
  financial_ack = {
    Code = 710,
    S = "financial_info"
  },
  financial_upgrade_req = {Code = 711, S = "null"},
  facebook_friends_req = {
    Code = 712,
    S = "facebook_friends_req"
  },
  facebook_friends_ack = {
    Code = 713,
    S = "facebook_friends_ack"
  },
  financial_gifts_get_req = {
    Code = 714,
    S = "financial_gifts_get_req"
  },
  financial_amount_ntf = {
    Code = 715,
    S = "financial_amount_ntf"
  },
  multi_acc_req = {Code = 716, S = "null"},
  multi_acc_ack = {
    Code = 717,
    S = "multi_acc_ack"
  },
  multi_acc_loot_req = {Code = 718, S = "int_param"},
  facebook_friends_ntf = {
    Code = 719,
    S = "facebook_friends_ntf"
  },
  financial_ntf = {
    Code = 720,
    S = "financial_info"
  },
  push_button_req = {
    Code = 721,
    S = "push_button_req"
  },
  push_button_info_req = {Code = 722, S = "null"},
  push_button_info_ack = {
    Code = 723,
    S = "push_button_info_ack"
  },
  push_button_ntf = {
    Code = 724,
    S = "push_button_ntf"
  },
  treasure_info_ntf = {
    Code = 725,
    S = "treasure_info"
  },
  invite_friends_req = {
    Code = 726,
    S = "invite_friends_req"
  },
  get_energy_req = {
    Code = 727,
    S = "get_energy_req"
  },
  open_treasure_box_req = {Code = 728, S = "null"},
  open_treasure_box_ack = {
    Code = 729,
    S = "open_treasure_box_ack"
  },
  treasure_info_req = {Code = 730, S = "null"},
  friend_role_req = {
    Code = 731,
    S = "friend_role_req"
  },
  friend_role_ack = {
    Code = 732,
    S = "user_brief_info"
  },
  send_global_email_req = {
    Code = 733,
    S = "send_global_email_req"
  },
  collect_energy_req = {
    Code = 734,
    S = "collect_energy_req"
  },
  krypton_refine_req = {
    Code = 735,
    S = "krypton_refine_req"
  },
  krypton_refine_ack = {
    Code = 736,
    S = "krypton_refine_ack"
  },
  krypton_inject_req = {
    Code = 737,
    S = "krypton_inject_req"
  },
  krypton_inject_ack = {
    Code = 738,
    S = "krypton_inject_ack"
  },
  krypton_refine_info_req = {Code = 739, S = "null"},
  krypton_refine_info_ack = {
    Code = 740,
    S = "krypton_refine_info_ack"
  },
  krypton_inject_buy_req = {Code = 741, S = "null"},
  krypton_inject_buy_ack = {
    Code = 742,
    S = "krypton_inject_buy_ack"
  },
  krypton_inject_list_req = {
    Code = 743,
    S = "krypton_inject_list_req"
  },
  krypton_inject_list_ack = {
    Code = 744,
    S = "krypton_inject_list_ack"
  },
  krypton_refine_list_req = {
    Code = 745,
    S = "krypton_refine_list_req"
  },
  krypton_refine_list_ack = {
    Code = 746,
    S = "krypton_refine_list_ack"
  },
  user_info_req = {Code = 747, S = "null"},
  user_info_ack = {
    Code = 748,
    S = "user_info_ack"
  },
  prime_map_req = {Code = 800, S = "null"},
  prime_map_ack = {
    Code = 801,
    S = "prime_map_ack"
  },
  prime_active_req = {Code = 802, S = "null"},
  prime_active_ntf = {
    Code = 803,
    S = "prime_active_ntf"
  },
  prime_jump_req = {
    Code = 804,
    S = "prime_jump_req"
  },
  prime_quit_req = {Code = 805, S = "null"},
  prime_my_info_ntf = {
    Code = 806,
    S = "prime_my_info"
  },
  prime_dot_occupy_ntf = {
    Code = 807,
    S = "prime_dot_occupy_ntf"
  },
  prime_dot_status_ntf = {
    Code = 808,
    S = "prime_dot_status_ntf"
  },
  prime_march_ntf = {
    Code = 809,
    S = "prime_march_ntf"
  },
  prime_march_req = {
    Code = 810,
    S = "prime_march_req"
  },
  prime_rank_ntf = {
    Code = 811,
    S = "prime_rank_ntf"
  },
  prime_fight_history_req = {
    Code = 812,
    S = "prime_fight_history_req"
  },
  prime_fight_history_ack = {
    Code = 813,
    S = "prime_fight_history_ack"
  },
  prime_increase_power_req = {Code = 814, S = "null"},
  prime_site_info_req = {
    Code = 815,
    S = "prime_site_info_req"
  },
  prime_site_info_ack = {
    Code = 816,
    S = "prime_site_info_ack"
  },
  revive_self_req = {Code = 817, S = "null"},
  prime_increase_power_info_req = {Code = 818, S = "null"},
  prime_increase_power_info_ack = {
    Code = 819,
    S = "prime_increase_power_info_ack"
  },
  prime_enemy_info_req = {Code = 820, S = "null"},
  prime_enemy_info_ack = {
    Code = 821,
    S = "prime_enemy_info_ack"
  },
  prime_fight_report_req = {
    Code = 822,
    S = "prime_fight_report_req"
  },
  prime_last_report_req = {
    Code = 823,
    S = "prime_last_report_req"
  },
  prime_dot_occupy_no_ntf = {
    Code = 824,
    S = "prime_dot_occupy_no_ntf"
  },
  prime_award_req = {
    Code = 825,
    S = "prime_award_req"
  },
  prime_award_ack = {
    Code = 826,
    S = "prime_award_lists"
  },
  prime_round_result_ntf = {
    Code = 827,
    S = "prime_round_result_ntf"
  },
  krypton_sort_req = {
    Code = 828,
    S = "krypton_sort_req"
  },
  krypton_sort_ack = {
    Code = 829,
    S = "krypton_store_ack"
  },
  prestige_info_ntf = {
    Code = 830,
    S = "prestige_info_ntf"
  },
  levelup_unlock_ntf = {
    Code = 831,
    S = "levelup_unlock_ntf"
  },
  champion_promote_ntf = {
    Code = 832,
    S = "champion_promote_ntf"
  },
  champion_straight_req = {Code = 833, S = "null"},
  champion_straight_ack = {
    Code = 834,
    S = "champion_straight_ack"
  },
  champion_straight_award_req = {
    Code = 835,
    S = "champion_straight_award_req"
  },
  vip_sign_item_use_award_ntf = {
    Code = 836,
    S = "vip_sign_item_use_award_ntf"
  },
  pay_sign_req = {Code = 837, S = "null"},
  pay_sign_ack = {
    Code = 838,
    S = "pay_sign_ack"
  },
  pay_sign_reward_req = {
    Code = 839,
    S = "pay_sign_reward_req"
  },
  equip_push_ntf = {
    Code = 840,
    S = "equip_push_ntf"
  },
  equip_pushed_req = {Code = 841, S = "null"},
  open_server_fund_req = {
    Code = 842,
    S = "open_server_fund_req"
  },
  open_server_fund_ack = {
    Code = 843,
    S = "open_server_fund_ack"
  },
  charge_open_server_fund_req = {Code = 844, S = "null"},
  open_server_fund_award_req = {
    Code = 845,
    S = "open_server_fund_award_req"
  },
  all_welfare_req = {
    Code = 846,
    S = "all_welfare_req"
  },
  all_welfare_ack = {
    Code = 847,
    S = "all_welfare_ack"
  },
  all_welfare_award_req = {
    Code = 848,
    S = "all_welfare_award_req"
  },
  vip_level_ntf = {
    Code = 849,
    S = "vip_level_ntf"
  },
  temp_vip_ntf = {
    Code = 850,
    S = "temp_vip_ntf"
  },
  pay_push_pop_ntf = {
    Code = 851,
    S = "pay_push_pop_ntf"
  },
  pay_push_pop_set_req = {Code = 852, S = "null"},
  prime_do_wve_boss_left_ntf = {
    Code = 853,
    S = "prime_do_wve_boss_left_ntf"
  },
  prime_time_wve_boss_left_ntf = {
    Code = 854,
    S = "prime_time_wve_boss_left_ntf"
  },
  prime_round_fight_ntf = {
    Code = 856,
    S = "prime_round_fight_ntf"
  },
  sell_item_ntf = {
    Code = 857,
    S = "sell_item_ntf"
  },
  url_push_ntf = {
    Code = 858,
    S = "url_push_ntf"
  },
  enhance_info_req = {
    Code = 859,
    S = "enhance_info_req"
  },
  enhance_info_ack = {
    Code = 860,
    S = "enhance_info_ack"
  },
  combo_guide_req = {
    Code = 861,
    S = "combo_guide_req"
  },
  combo_guide_ack = {
    Code = 862,
    S = "combo_guide_ack"
  },
  player_pay_price_req = {
    Code = 863,
    S = "player_pay_price_req"
  },
  pay_status_ntf = {
    Code = 864,
    S = "pay_status_ntf"
  },
  daily_benefits_req = {Code = 865, S = "null"},
  daily_benefits_ack = {
    Code = 866,
    S = "daily_benefits_ack"
  },
  daily_benefits_award_req = {
    Code = 867,
    S = "daily_benefits_award_req"
  },
  enter_seven_day_req = {Code = 868, S = "null"},
  seven_day_ntf = {
    Code = 869,
    S = "seven_day_ntf"
  },
  goal_info_req = {Code = 870, S = "null"},
  goal_info_ack = {
    Code = 871,
    S = "goal_info_ack"
  },
  get_goal_award_req = {
    Code = 872,
    S = "get_goal_award_req"
  },
  cutoff_info_req = {Code = 873, S = "null"},
  cutoff_info_ack = {
    Code = 874,
    S = "cutoff_info_ack"
  },
  buy_cutoff_item_req = {
    Code = 875,
    S = "buy_cutoff_item_req"
  },
  get_goal_award_ack = {
    Code = 876,
    S = "get_goal_award_ack"
  },
  enter_seven_day_ack = {
    Code = 879,
    S = "enter_seven_day_ack"
  },
  prime_jump_price_req = {
    Code = 880,
    S = "prime_jump_req"
  },
  prime_jump_price_ack = {
    Code = 881,
    S = "prime_jump_price_ack"
  },
  select_goal_type_req = {
    Code = 882,
    S = "select_goal_type_req"
  },
  gp_test_pay_group_req = {
    Code = 883,
    S = "gp_test_pay_group_req"
  },
  store_quick_buy_count_req = {
    Code = 884,
    S = "store_quick_buy_count_req"
  },
  store_quick_buy_count_ack = {
    Code = 885,
    S = "store_quick_buy_count_ack"
  },
  store_quick_buy_price_req = {
    Code = 886,
    S = "store_quick_buy_price_req"
  },
  store_quick_buy_price_ack = {
    Code = 887,
    S = "store_quick_buy_price_ack"
  },
  activity_store_count_req = {
    Code = 888,
    S = "activity_store_count_req"
  },
  activity_store_count_ack = {
    Code = 889,
    S = "activity_store_count_ack"
  },
  activity_store_price_req = {
    Code = 890,
    S = "activity_store_price_req"
  },
  activity_store_price_ack = {
    Code = 891,
    S = "activity_store_price_ack"
  },
  daily_benefits_ntf = {
    Code = 892,
    S = "daily_benefits_ntf"
  },
  client_login_ok_req = {Code = 893, S = "null"},
  prime_push_show_round_req = {
    Code = 894,
    S = "prime_push_show_round_req"
  },
  refresh_type_req = {Code = 895, S = "null"},
  refresh_type_ack = {
    Code = 896,
    S = "refresh_type_ack"
  },
  force_add_fleet_req = {
    Code = 897,
    S = "force_add_fleet_req"
  },
  max_step_req = {
    Code = 898,
    S = "max_step_req"
  },
  max_step_ack = {
    Code = 899,
    S = "max_step_ack"
  },
  ladder_report_req = {
    Code = 900,
    S = "ladder_report_req"
  },
  ladder_report_ack = {
    Code = 901,
    S = "ladder_report_ack"
  },
  ladder_jump_req = {
    Code = 902,
    S = "ladder_jump_req"
  },
  ladder_jump_ack = {
    Code = 903,
    S = "ladder_jump_ack"
  },
  ladder_award_req = {
    Code = 904,
    S = "ladder_award_req"
  },
  ladder_award_ntf = {
    Code = 905,
    S = "ladder_award_ntf"
  },
  ladder_report_detail_req = {
    Code = 906,
    S = "ladder_report_detail_req"
  },
  ladder_report_detail_ack = {
    Code = 907,
    S = "ladder_report_detail_ack"
  },
  stores_buy_ack = {
    Code = 908,
    S = "stores_buy_ack"
  },
  enter_tactical_req = {Code = 920, S = "null"},
  enter_tactical_ack = {
    Code = 921,
    S = "tactical_info"
  },
  tactical_equip_on_req = {
    Code = 922,
    S = "tactical_equip_on_req"
  },
  tactical_equip_on_ack = {
    Code = 923,
    S = "tactical_equip_on_ack"
  },
  tactical_equip_off_req = {
    Code = 924,
    S = "tactical_equip_off_req"
  },
  tactical_equip_off_ack = {
    Code = 925,
    S = "tactical_equip_off_ack"
  },
  tactical_resource_ntf = {
    Code = 926,
    S = "tactical_resource_ntf"
  },
  tactical_refine_price_req = {
    Code = 927,
    S = "tactical_refine_info"
  },
  tactical_refine_price_ack = {
    Code = 928,
    S = "tactical_refine_price_ack"
  },
  tactical_refine_req = {
    Code = 929,
    S = "tactical_refine_info"
  },
  tactical_refine_ack = {
    Code = 930,
    S = "tactical_refine_ack"
  },
  tactical_refine_save_req = {
    Code = 931,
    S = "tactical_refine_save_req"
  },
  tactical_unlock_slot_req = {Code = 932, S = "null"},
  tactical_unlock_slot_ack = {
    Code = 933,
    S = "tactical_unlock_slot_ack"
  },
  tactical_enter_refine_req = {
    Code = 934,
    S = "tactical_enter_refine_req"
  },
  tactical_enter_refine_ack = {
    Code = 935,
    S = "tactical_enter_refine_ack"
  },
  tactical_status_ntf = {
    Code = 936,
    S = "tactical_status_ntf"
  },
  tactical_equip_delete_req = {
    Code = 937,
    S = "tactical_equip_delete_req"
  },
  tactical_equip_delete_ack = {
    Code = 938,
    S = "tactical_equip_delete_ack"
  },
  pay_limit_ntf = {
    Code = 939,
    S = "pay_limit_ntf"
  },
  pay_sign_board_ntf = {
    Code = 940,
    S = "pay_sign_board_ntf"
  },
  tactical_guide_req = {Code = 941, S = "null"},
  enter_plante_req = {
    Code = 942,
    S = "enter_plante_req"
  },
  enter_plante_ack = {
    Code = 943,
    S = "enter_plante_ack"
  },
  plante_explore_req = {
    Code = 944,
    S = "plante_explore_req"
  },
  plante_explore_ack = {
    Code = 945,
    S = "plante_explore_ack"
  },
  plante_refresh_req = {
    Code = 946,
    S = "plante_refresh_req"
  },
  plante_refresh_ack = {
    Code = 947,
    S = "plante_refresh_ack"
  },
  show_price_ntf = {
    Code = 948,
    S = "show_price_ntf"
  },
  get_invite_gift_req = {
    Code = 949,
    S = "get_invite_gift_req"
  },
  get_invite_gift_ack = {
    Code = 950,
    S = "get_invite_gift_ack"
  },
  facebook_switch_ntf = {
    Code = 951,
    S = "facebook_switch_ntf"
  },
  can_enhance_req = {Code = 952, S = "null"},
  can_enhance_ack = {
    Code = 953,
    S = "can_enhance_ack"
  },
  tactical_delete_awards_req = {
    Code = 954,
    S = "tactical_delete_awards_req"
  },
  tactical_delete_awards_ack = {
    Code = 955,
    S = "tactical_delete_awards_ack"
  },
  first_login_ntf = {
    Code = 956,
    S = "first_login_ntf"
  },
  alliance_guid_ntf = {
    Code = 957,
    S = "alliance_guid_ntf"
  },
  remodel_help_others_ack = {
    Code = 958,
    S = "remodel_help_others_ack"
  },
  ltv_ajust_ntf = {
    Code = 959,
    S = "ltv_ajust_ntf"
  },
  story_status_ntf = {
    Code = 970,
    S = "story_status_ntf"
  },
  story_award_req = {
    Code = 971,
    S = "story_award_req"
  },
  story_award_ack = {
    Code = 972,
    S = "story_award_ack"
  },
  thumb_up_info_req = {Code = 973, S = "null"},
  thumb_up_info_ack = {
    Code = 974,
    S = "thumb_up_info_ack"
  },
  thumb_up_req = {
    Code = 975,
    S = "thumb_up_req"
  },
  thumb_up_ack = {
    Code = 976,
    S = "thumb_up_ack"
  },
  credit_exchange_ack = {
    Code = 977,
    S = "credit_exchange_ack"
  },
  today_act_task_req = {Code = 978, S = "null"},
  today_act_task_ack = {
    Code = 979,
    S = "today_act_task_ack"
  },
  enter_monthly_req = {Code = 980, S = "null"},
  enter_monthly_ack = {
    Code = 981,
    S = "enter_monthly_ack"
  },
  view_each_task_req = {
    Code = 982,
    S = "view_each_task_req"
  },
  view_each_task_ack = {
    Code = 983,
    S = "view_each_task_ack"
  },
  view_award_req = {Code = 984, S = "null"},
  view_award_ack = {
    Code = 985,
    S = "view_award_ack"
  },
  redo_task_req = {
    Code = 986,
    S = "redo_task_req"
  },
  redo_task_ack = {
    Code = 987,
    S = "redo_task_ack"
  },
  get_award_req = {
    Code = 988,
    S = "get_award_req"
  },
  get_award_ack = {
    Code = 989,
    S = "get_award_ack"
  },
  get_today_award_req = {
    Code = 990,
    S = "get_today_award_req"
  },
  get_today_award_ack = {
    Code = 991,
    S = "get_today_award_ack"
  },
  other_monthly_req = {
    Code = 992,
    S = "other_monthly_req"
  },
  other_monthly_ack = {
    Code = 993,
    S = "other_monthly_ack"
  },
  today_task_ntf = {
    Code = 994,
    S = "task_statistic_info"
  },
  switch_formation_req = {
    Code = 995,
    S = "switch_formation_req"
  },
  switch_formation_ack = {
    Code = 996,
    S = "switch_formation_ack"
  },
  mulmatrix_switch_req = {
    Code = 997,
    S = "mulmatrix_switch_req"
  },
  mulmatrix_switch_ack = {
    Code = 998,
    S = "mulmatrix_switch_ack"
  },
  mulmatrix_equip_info_req = {
    Code = 999,
    S = "mulmatrix_equip_info_req"
  },
  mulmatrix_equip_info_ack = {
    Code = 1000,
    S = "mulmatrix_equip_info_ack"
  },
  change_matrix_type_req = {
    Code = 1001,
    S = "change_matrix_type_req"
  },
  change_matrix_type_ack = {
    Code = 1002,
    S = "change_matrix_type_ack"
  },
  user_bag_info_ntf = {
    Code = 1003,
    S = "user_bag_info_ntf"
  },
  client_req_stat_req = {
    Code = 1004,
    S = "client_req_stat_info"
  },
  bugly_data_ntf = {
    Code = 1005,
    S = "bugly_data_ntf"
  },
  enter_champion_req = {Code = 1101, S = "null"},
  enter_champion_ack = {
    Code = 1102,
    S = "enter_champion_ack"
  },
  wdc_enter_req = {Code = 1103, S = "null"},
  wdc_enter_ack = {
    Code = 1104,
    S = "wdc_enter_ack"
  },
  wdc_match_req = {Code = 1105, S = "null"},
  wdc_match_ack = {
    Code = 1106,
    S = "wdc_match_ack"
  },
  wdc_fight_req = {
    Code = 1107,
    S = "wdc_fight_req"
  },
  wdc_fight_ack = {
    Code = 1108,
    S = "wdc_fight_ack"
  },
  wdc_report_req = {Code = 1109, S = "null"},
  wdc_report_ack = {
    Code = 1110,
    S = "wdc_report_ack"
  },
  wdc_report_detail_req = {
    Code = 1111,
    S = "wdc_report_detail_req"
  },
  wdc_report_detail_ack = {
    Code = 1112,
    S = "wdc_report_detail_ack"
  },
  wdc_info_ntf = {
    Code = 1113,
    S = "wdc_info_ntf"
  },
  wdc_awards_req = {Code = 1114, S = "null"},
  wdc_awards_ack = {
    Code = 1115,
    S = "wdc_awards_ack"
  },
  wdc_rank_board_req = {Code = 1116, S = "null"},
  wdc_rank_board_ack = {
    Code = 1117,
    S = "wdc_rank_board_ack"
  },
  wdc_honor_wall_req = {Code = 1118, S = "null"},
  wdc_honor_wall_ack = {
    Code = 1119,
    S = "wdc_honor_wall_ack"
  },
  wdc_enemy_release_req = {Code = 1120, S = "null"},
  wdc_awards_ntf = {
    Code = 1121,
    S = "wdc_awards_ntf"
  },
  wdc_awards_get_req = {
    Code = 1122,
    S = "wdc_awards_get_req"
  },
  wdc_awards_get_ack = {
    Code = 1123,
    S = "wdc_awards_get_ack"
  },
  wdc_rankup_ntf = {
    Code = 1124,
    S = "wdc_rankup_ntf"
  },
  wdc_fight_status_req = {Code = 1125, S = "null"},
  wdc_fight_status_ack = {
    Code = 1126,
    S = "wdc_fight_status_ack"
  },
  wdc_status_ntf = {
    Code = 1127,
    S = "wdc_status_ntf"
  },
  translate_info_req = {Code = 1128, S = "null"},
  translate_info_ack = {
    Code = 1129,
    S = "translate_info_ack"
  },
  welcome_screen_req = {Code = 1130, S = "null"},
  welcome_screen_ack = {
    Code = 1131,
    S = "welcome_screen_ack"
  },
  welcome_mask_req = {
    Code = 1132,
    S = "welcome_mask_req"
  },
  first_charge_ntf = {
    Code = 1133,
    S = "first_charge_ntf"
  },
  enter_dice_req = {
    Code = 1134,
    S = "enter_dice_req"
  },
  enter_dice_ack = {
    Code = 1135,
    S = "dice_detail"
  },
  throw_dice_req = {
    Code = 1136,
    S = "throw_dice_req"
  },
  throw_dice_ack = {
    Code = 1137,
    S = "throw_dice_ack"
  },
  dice_awards_req = {
    Code = 1138,
    S = "dice_awards_req"
  },
  reset_dice_req = {
    Code = 1139,
    S = "reset_dice_req"
  },
  reset_dice_ack = {
    Code = 1140,
    S = "dice_detail"
  },
  speed_resource_req = {Code = 1141, S = "null"},
  speed_resource_ack = {
    Code = 1142,
    S = "speed_resource_ack"
  },
  finish_speed_task_req = {
    Code = 1143,
    S = "finish_speed_task_req"
  },
  dice_board_ntf = {
    Code = 1144,
    S = "dice_board_ntf"
  },
  wdc_rank_board_ntf = {
    Code = 1145,
    S = "wdc_rank_board_ntf"
  },
  speed_resource_ntf = {
    Code = 1146,
    S = "speed_resource_ack"
  },
  event_activity_ntf = {
    Code = 1147,
    S = "event_activity_ntf"
  },
  event_activity_req = {
    Code = 1148,
    S = "event_activity_req"
  },
  event_activity_ack = {
    Code = 1149,
    S = "event_activity_info"
  },
  event_activity_award_req = {
    Code = 1150,
    S = "event_activity_award_req"
  },
  user_change_req = {
    Code = 1151,
    S = "user_change_info"
  },
  user_change_ack = {Code = 1152, S = "user_info"},
  event_progress_award_req = {
    Code = 1153,
    S = "event_progress_award_req"
  },
  star_craft_data_ntf = {
    Code = 1154,
    S = "star_craft_data_ntf"
  },
  star_craft_sign_up_req = {
    Code = 1155,
    S = "star_craft_sign_up_req"
  },
  event_ntf_req = {Code = 1156, S = "null"},
  adventure_add_req = {Code = 1157, S = "adv_battle"},
  adventure_add_ack = {
    Code = 1158,
    S = "adventure_add_ack"
  },
  adventure_add_price_req = {Code = 1159, S = "adv_battle"},
  recruit_list_new_req = {
    Code = 1160,
    S = "recruit_list_new_req"
  },
  recruit_list_new_ack = {
    Code = 1161,
    S = "recruit_list_new_ack"
  },
  recruit_req = {
    Code = 1162,
    S = "recruit_req"
  },
  recruit_ack = {
    Code = 1163,
    S = "recruit_ack"
  },
  recruit_look_req = {
    Code = 1164,
    S = "recruit_look_req"
  },
  recruit_look_ack = {
    Code = 1165,
    S = "recruit_look_ack"
  },
  master_req = {Code = 1166, S = "master_req"},
  master_ack = {
    Code = 1167,
    S = "master_all_ack"
  },
  hero_union_req = {Code = 1168, S = "null"},
  hero_union_ack = {
    Code = 1169,
    S = "hero_union_ack"
  },
  hero_collect_req = {Code = 1170, S = "null"},
  hero_collect_ack = {
    Code = 1171,
    S = "hero_collect_ack"
  },
  hero_collect_rank_req = {
    Code = 1172,
    S = "hero_collect_rank_req"
  },
  hero_collect_rank_ack = {
    Code = 1173,
    S = "hero_collect_rank_ack"
  },
  red_point_ntf = {
    Code = 1174,
    S = "red_point_ntf"
  },
  area_id_req = {
    Code = 1175,
    S = "area_id_req"
  },
  area_id_ack = {
    Code = 1176,
    S = "area_id_ack"
  },
  master_ntf = {Code = 1177, S = "master_ntf"},
  mining_world_req = {
    Code = 1178,
    S = "mining_world_req"
  },
  mining_world_ack = {
    Code = 1179,
    S = "mining_world_ack"
  },
  mining_world_log_req = {Code = 1180, S = "null"},
  mining_world_log_ack = {
    Code = 1181,
    S = "mining_world_log_ack"
  },
  mining_world_pe_req = {Code = 1182, S = "null"},
  mining_world_pe_ack = {
    Code = 1183,
    S = "mining_world_pe_ack"
  },
  mining_wars_req = {
    Code = 1184,
    S = "mining_wars_req"
  },
  mining_wars_ack = {
    Code = 1185,
    S = "mining_wars_ack"
  },
  mining_wars_buy_count_req = {
    Code = 1186,
    S = "mining_wars_buy_count_req"
  },
  mining_wars_buy_count_ack = {
    Code = 1187,
    S = "mining_wars_buy_count_ack"
  },
  mining_wars_refresh_req = {
    Code = 1188,
    S = "mining_wars_refresh_req"
  },
  mining_wars_star_req = {
    Code = 1189,
    S = "mining_wars_star_req"
  },
  mining_wars_star_ack = {
    Code = 1190,
    S = "mining_wars_star_data"
  },
  mining_wars_battle_req = {
    Code = 1191,
    S = "mining_wars_battle_req"
  },
  mining_wars_battle_ack = {
    Code = 1192,
    S = "mining_wars_battle_ack"
  },
  mining_wars_collect_req = {
    Code = 1193,
    S = "mining_wars_collect_req"
  },
  mining_wars_collect_ack = {
    Code = 1194,
    S = "mining_wars_collect_ack"
  },
  mining_wars_change_ntf = {
    Code = 1195,
    S = "mining_wars_change_ntf"
  },
  mining_world_battle_req = {
    Code = 1196,
    S = "mining_world_battle_req"
  },
  mining_world_battle_ack = {
    Code = 1197,
    S = "mining_world_battle_ack"
  },
  mining_battle_report_req = {
    Code = 1198,
    S = "mining_battle_report_req"
  },
  mining_battle_report_ack = {
    Code = 1199,
    S = "mining_battle_report_ack"
  },
  mining_reward_ntf = {
    Code = 1200,
    S = "mining_reward_ntf"
  },
  version_info_req = {
    Code = 1201,
    S = "version_info_req"
  },
  art_main_req = {
    Code = 1202,
    S = "art_main_req"
  },
  art_main_ack = {
    Code = 1203,
    S = "art_main_ack"
  },
  art_point_req = {
    Code = 1204,
    S = "art_point_req"
  },
  art_point_ack = {
    Code = 1205,
    S = "art_point_ack"
  },
  art_point_upgrade_req = {
    Code = 1206,
    S = "art_point_upgrade_req"
  },
  art_point_upgrade_ack = {
    Code = 1207,
    S = "art_point_upgrade_ack"
  },
  art_core_list_req = {
    Code = 1208,
    S = "art_core_list_req"
  },
  art_core_list_ack = {
    Code = 1209,
    S = "art_core_list_ack"
  },
  art_core_down_req = {
    Code = 1210,
    S = "art_core_down_req"
  },
  art_core_down_ack = {
    Code = 1211,
    S = "art_core_down_ack"
  },
  art_core_equip_req = {
    Code = 1212,
    S = "art_core_equip_req"
  },
  art_core_equip_ack = {
    Code = 1213,
    S = "art_core_equip_ack"
  },
  art_reset_req = {
    Code = 1214,
    S = "art_reset_req"
  },
  art_reset_ack = {
    Code = 1215,
    S = "art_reset_ack"
  },
  art_core_decompose_req = {
    Code = 1216,
    S = "art_core_decompose_req"
  },
  art_core_decompose_ack = {
    Code = 1217,
    S = "art_core_decompose_ack"
  },
  art_can_upgrade_req = {
    Code = 1218,
    S = "art_can_upgrade_req"
  },
  art_can_upgrade_ack = {
    Code = 1219,
    S = "art_can_upgrade_ack"
  },
  main_city_ntf = {
    Code = 1251,
    S = "main_city_ntf"
  },
  mask_modules_req = {
    Code = 1252,
    S = "mask_modules_req"
  },
  mask_show_index_req = {
    Code = 1253,
    S = "mask_show_index_req"
  },
  space_door_req = {Code = 1254, S = "null"},
  space_door_ntf = {
    Code = 1255,
    S = "space_door_ntf"
  },
  helper_buttons_req = {Code = 1256, S = "null"},
  helper_buttons_ack = {
    Code = 1257,
    S = "helper_buttons_ack"
  },
  event_log_ntf = {
    Code = 1258,
    S = "event_log_ntf"
  },
  choosable_item_req = {
    Code = 1259,
    S = "choosable_item_req"
  },
  choosable_item_ack = {
    Code = 1260,
    S = "choosable_item_ack"
  },
  choosable_item_use_req = {
    Code = 1261,
    S = "choosable_item_use_req"
  },
  fte_req = {Code = 1263, S = "fte_req"},
  fte_ack = {Code = 1264, S = "fte_ack"},
  fte_ntf = {Code = 1265, S = "fte_ntf"},
  achievement_reward_receive_req = {
    Code = 1266,
    S = "achievement_reward_receive_req"
  },
  achievement_reward_receive_ack = {
    Code = 1267,
    S = "achievement_reward_receive_ack"
  },
  pay_gifts_req = {Code = 1268, S = "null"},
  pay_gifts_ack = {
    Code = 1269,
    S = "pay_gifts_ack"
  },
  wish_pay_req = {
    Code = 1270,
    S = "wish_pay_req"
  },
  vip_reward_req = {Code = 1271, S = "null"},
  vip_reward_ack = {
    Code = 1272,
    S = "vip_reward_ack"
  },
  month_card_req = {Code = 1273, S = "null"},
  month_card_ack = {
    Code = 1274,
    S = "month_card_ack"
  },
  month_card_receive_reward_req = {
    Code = 1275,
    S = "month_card_receive_reward_req"
  },
  month_card_receive_reward_ack = {
    Code = 1276,
    S = "month_card_receive_reward_ack"
  },
  change_leader_req = {
    Code = 1277,
    S = "change_leader_req"
  },
  leader_info_ntf = {
    Code = 1278,
    S = "leader_info_ntf"
  },
  get_reward_detail_req = {
    Code = 1279,
    S = "get_reward_detail_req"
  },
  get_reward_detail_ack = {
    Code = 1280,
    S = "reward_detail"
  },
  save_user_id_req = {
    Code = 1281,
    S = "save_user_id_req"
  },
  user_id_status_ntf = {
    Code = 1282,
    S = "user_id_status_ntf"
  },
  item_classify_ntf = {
    Code = 1283,
    S = "item_classify_ntf"
  },
  forces_req = {Code = 1284, S = "null"},
  forces_ack = {Code = 1285, S = "forces_ack"},
  concentrate_req = {
    Code = 1286,
    S = "concentrate_req"
  },
  concentrate_ack = {
    Code = 1287,
    S = "concentrate_ack"
  },
  concentrate_end_req = {
    Code = 1288,
    S = "concentrate_end_req"
  },
  concentrate_end_ack = {
    Code = 1289,
    S = "concentrate_end_ack"
  },
  force_join_req = {
    Code = 1290,
    S = "force_join_req"
  },
  force_join_ack = {
    Code = 1291,
    S = "force_join_ack"
  },
  concentrate_atk_req = {
    Code = 1292,
    S = "concentrate_atk_req"
  },
  concentrate_atk_ack = {
    Code = 1293,
    S = "concentrate_atk_ack"
  },
  group_fight_ntf = {
    Code = 1294,
    S = "group_fight_ntf"
  },
  change_atk_seq_req = {
    Code = 1295,
    S = "change_atk_seq_req"
  },
  change_atk_seq_ack = {
    Code = 1296,
    S = "change_atk_seq_ack"
  },
  forces_ntf = {Code = 1297, S = "forces_ntf"},
  my_forces_req = {Code = 1298, S = "null"},
  my_forces_ack = {
    Code = 1299,
    S = "my_forces_ack"
  },
  mining_team_log_req = {Code = 1300, S = "null"},
  mining_team_log_ack = {
    Code = 1301,
    S = "mining_team_log_ack"
  },
  team_fight_report_req = {
    Code = 1302,
    S = "team_fight_report_req"
  },
  fair_arena_req = {Code = 1303, S = "null"},
  fair_arena_ack = {
    Code = 1304,
    S = "fair_arena_ack"
  },
  fair_arena_rank_req = {Code = 1305, S = "null"},
  fair_arena_rank_ack = {
    Code = 1306,
    S = "fair_arena_rank_ack"
  },
  fair_arena_season_req = {
    Code = 1307,
    S = "fair_arena_season_req"
  },
  fair_arena_season_ack = {
    Code = 1308,
    S = "fair_arena_rank_ack"
  },
  fair_arena_reward_req = {Code = 1309, S = "null"},
  fair_arena_reward_ack = {
    Code = 1310,
    S = "fair_arena_reward_ack"
  },
  fair_arena_reward_get_req = {
    Code = 1311,
    S = "fair_arena_reward_get_req"
  },
  fair_arena_report_req = {
    Code = 1312,
    S = "fair_arena_report_req"
  },
  fair_arena_report_ack = {
    Code = 1313,
    S = "fair_arena_report_ack"
  },
  fair_arena_report_battle_req = {
    Code = 1314,
    S = "fair_arena_report_battle_req"
  },
  fair_arena_report_battle_ack = {
    Code = 1315,
    S = "fair_arena_report_battle_ack"
  },
  fair_arena_formation_all_req = {Code = 1316, S = "null"},
  fair_arena_formation_all_ack = {
    Code = 1317,
    S = "fair_arena_formation_all_ack"
  },
  update_formations_req = {
    Code = 1318,
    S = "update_formations_req"
  },
  update_formations_ack = {
    Code = 1319,
    S = "update_formations_ack"
  },
  refresh_fleet_pool_req = {Code = 1320, S = "null"},
  refresh_fleet_pool_ack = {
    Code = 1321,
    S = "refresh_fleet_pool_ack"
  },
  fair_arena_fleet_info_req = {
    Code = 1322,
    S = "fair_arena_fleet_info_req"
  },
  fair_arena_fleet_info_ack = {
    Code = 1323,
    S = "fair_fleet_info_ack"
  },
  price_off_store_ntf = {
    Code = 1324,
    S = "price_off_store_ntf"
  },
  fte_gift_ntf = {
    Code = 1325,
    S = "fte_gift_ntf"
  },
  enter_scratch_req = {
    Code = 1326,
    S = "enter_scratch_req"
  },
  enter_scratch_ack = {
    Code = 1327,
    S = "enter_scratch_ack"
  },
  buy_scratch_card_req = {
    Code = 1328,
    S = "buy_scratch_card_req"
  },
  buy_scratch_card_ack = {
    Code = 1329,
    S = "buy_scratch_card_ack"
  },
  reset_scratch_card_req = {
    Code = 1330,
    S = "reset_scratch_card_req"
  },
  reset_scratch_card_ack = {
    Code = 1331,
    S = "reseting_ack"
  },
  get_process_award_req = {
    Code = 1332,
    S = "get_process_award_req"
  },
  get_process_award_ack = {
    Code = 1333,
    S = "get_process_award_ack"
  },
  exchange_award_req = {
    Code = 1334,
    S = "exchange_award_req"
  },
  exchange_award_ack = {
    Code = 1335,
    S = "exchange_award_ack"
  },
  end_scratch_req = {
    Code = 1336,
    S = "end_scratch_req"
  },
  end_scratch_ack = {
    Code = 1337,
    S = "end_scratch_ack"
  },
  uc_pay_sign_req = {
    Code = 1338,
    S = "uc_pay_sign_req"
  },
  uc_pay_sign_ack = {
    Code = 1339,
    S = "uc_pay_sign_ack"
  },
  ac_sweep_req = {Code = 1340, S = "null"},
  art_one_upgrade_data_req = {
    Code = 1341,
    S = "art_one_upgrade_data_req"
  },
  art_one_upgrade_data_ack = {
    Code = 1342,
    S = "art_one_upgrade_data_ack"
  },
  art_one_upgrade_req = {
    Code = 1343,
    S = "art_one_upgrade_req"
  },
  art_one_upgrade_ack = {
    Code = 1344,
    S = "art_one_upgrade_ack"
  },
  scratch_board_ntf = {
    Code = 1345,
    S = "scratch_board_ntf"
  },
  confirm_exchange_req = {
    Code = 1346,
    S = "confirm_exchange_req"
  },
  credit_exchange_ntf = {
    Code = 1347,
    S = "credit_exchange_ntf"
  },
  normal_ntf = {Code = 1348, S = "normal_ntf"},
  change_fleets_data_req = {
    Code = 1349,
    S = "change_fleets_data_req"
  },
  change_fleets_data_ack = {
    Code = 1350,
    S = "change_fleets_data_ack"
  },
  change_fleets_req = {
    Code = 1351,
    S = "change_fleets_req"
  },
  enter_login_sign_req = {Code = 1352, S = "null"},
  enter_login_sign_ack = {
    Code = 1353,
    S = "login_sign_ack"
  },
  get_login_sign_award_req = {
    Code = 1354,
    S = "get_login_sign_award_req"
  },
  get_login_sign_award_ack = {
    Code = 1355,
    S = "get_login_sign_award_ack"
  },
  krypton_redpoint_req = {
    Code = 1356,
    S = "krypton_redpoint_req"
  },
  krypton_redpoint_ack = {
    Code = 1357,
    S = "krypton_redpoint_ack"
  },
  event_click_req = {Code = 1358, S = "null"},
  wxpay_info_ntf = {
    Code = 1359,
    S = "wxpay_info_ntf"
  },
  redownload_res_req = {Code = 1360, S = "null"},
  redownload_res_ack = {
    Code = 1361,
    S = "redownload_res_ack"
  },
  open_box_progress_award_req = {
    Code = 1362,
    S = "open_box_progress_award_req"
  },
  exchange_regulation_ntf = {
    Code = 1363,
    S = "exchange_regulation_ntf"
  },
  mul_credit_exchange_ack = {
    Code = 1364,
    S = "mul_credit_exchange_ack"
  },
  mul_credit_exchange_ntf = {
    Code = 1365,
    S = "mul_credit_exchange_ntf"
  },
  enter_medal_store_req = {Code = 1366, S = "null"},
  enter_medal_store_ack = {
    Code = 1367,
    S = "enter_medal_store_ack"
  },
  medal_store_buy_req = {
    Code = 1368,
    S = "medal_store_buy_req"
  },
  medal_store_buy_ack = {
    Code = 1369,
    S = "medal_store_buy_ack"
  },
  medal_store_refresh_req = {
    Code = 1370,
    S = "medal_store_refresh_req"
  },
  medal_store_refresh_ack = {
    Code = 1371,
    S = "medal_store_refresh_ack"
  },
  medal_list_req = {Code = 1372, S = "null"},
  medal_list_ack = {
    Code = 1373,
    S = "medal_list_ack"
  },
  medal_decompose_confirm_req = {
    Code = 1374,
    S = "medal_decompose_confirm_req"
  },
  medal_decompose_confirm_ack = {
    Code = 1375,
    S = "medal_decompose_confirm_ack"
  },
  medal_reset_confirm_req = {
    Code = 1376,
    S = "medal_reset_confirm_req"
  },
  medal_reset_confirm_ack = {
    Code = 1377,
    S = "medal_reset_confirm_ack"
  },
  medal_equip_req = {Code = 1378, S = "null"},
  medal_equip_ack = {
    Code = 1379,
    S = "medal_equip_ack"
  },
  medal_level_up_req = {
    Code = 1380,
    S = "medal_level_up_req"
  },
  medal_level_up_ack = {
    Code = 1381,
    S = "medal_level_up_ack"
  },
  medal_rank_up_req = {
    Code = 1382,
    S = "medal_rank_up_req"
  },
  medal_rank_up_ack = {
    Code = 1383,
    S = "medal_rank_up_ack"
  },
  medal_list_ntf = {
    Code = 1384,
    S = "medal_list_ntf"
  },
  medal_fleet_formation_ntf = {
    Code = 1385,
    S = "medal_fleet_formation_ntf"
  },
  medal_fleet_red_point_ntf = {
    Code = 1386,
    S = "medal_fleet_red_point_ntf"
  },
  medal_equip_on_req = {
    Code = 1387,
    S = "medal_equip_on_req"
  },
  medal_equip_on_ack = {
    Code = 1388,
    S = "medal_equip_on_ack"
  },
  medal_equip_off_req = {
    Code = 1389,
    S = "medal_equip_off_req"
  },
  medal_equip_off_ack = {
    Code = 1390,
    S = "medal_equip_off_ack"
  },
  medal_equip_replace_req = {
    Code = 1391,
    S = "medal_equip_replace_req"
  },
  medal_equip_replace_ack = {
    Code = 1392,
    S = "medal_equip_replace_ack"
  },
  medal_fleet_btn_red_point_ntf = {
    Code = 1393,
    S = "medal_fleet_btn_red_point_ntf"
  },
  medal_config_info_req = {
    Code = 1398,
    S = "medal_config_info_req"
  },
  medal_config_info_ack = {
    Code = 1399,
    S = "medal_config_info_ack"
  },
  fight_report_round_ntf = {
    Code = 1400,
    S = "fight_report_round_ntf"
  },
  medal_glory_collection_ntf = {
    Code = 1401,
    S = "medal_glory_collection_ntf"
  },
  medal_glory_collection_req = {Code = 1402, S = "null"},
  medal_glory_collection_ack = {
    Code = 1403,
    S = "medal_glory_collection_ack"
  },
  medal_glory_activate_req = {
    Code = 1404,
    S = "medal_glory_activate_req"
  },
  medal_glory_activate_ack = {
    Code = 1405,
    S = "medal_glory_activate_ack"
  },
  medal_glory_rank_up_req = {
    Code = 1406,
    S = "medal_glory_rank_up_req"
  },
  medal_glory_rank_up_ack = {
    Code = 1407,
    S = "medal_glory_rank_up_ack"
  },
  medal_glory_reset_req = {
    Code = 1408,
    S = "medal_glory_reset_req"
  },
  medal_glory_reset_ack = {
    Code = 1409,
    S = "medal_glory_reset_ack"
  },
  medal_glory_achievement_req = {Code = 1410, S = "null"},
  medal_glory_achievement_ack = {
    Code = 1411,
    S = "medal_glory_achievement_ack"
  },
  medal_glory_achievement_activate_req = {Code = 1412, S = "null"},
  medal_glory_achievement_activate_ack = {
    Code = 1413,
    S = "medal_glory_achievement_activate_ack"
  },
  medal_glory_collection_rank_req = {Code = 1414, S = "null"},
  medal_glory_collection_rank_ack = {
    Code = 1415,
    S = "medal_glory_collection_rank_ack"
  },
  battle_rate_req = {
    Code = 1500,
    S = "battle_rate_req"
  },
  hero_union_unlock_ntf = {
    Code = 1501,
    S = "hero_union_unlock_ntf"
  },
  large_map_block_req = {
    Code = 1502,
    S = "large_map_block_req"
  },
  large_map_block_ack = {
    Code = 1503,
    S = "large_map_block_ack"
  },
  large_map_base_req = {Code = 1504, S = "null"},
  large_map_base_ack = {
    Code = 1505,
    S = "large_map_base_ack"
  },
  large_map_block_update_ntf = {
    Code = 1506,
    S = "large_map_block_update_ntf"
  },
  large_map_route_req = {
    Code = 1507,
    S = "large_map_route_req"
  },
  large_map_route_ack = {
    Code = 1508,
    S = "large_map_route_info"
  },
  large_map_route_ntf = {
    Code = 1509,
    S = "large_map_route_ntf"
  },
  large_map_event_ntf = {
    Code = 1510,
    S = "large_map_event_ntf"
  },
  large_map_battle_req = {
    Code = 1511,
    S = "large_map_battle_req"
  }
}
NetAPIList.CodeToMsgType = {
  MSGTYPE632 = NetAPIList.budo_test_req.S,
  MSGTYPE563 = NetAPIList.contention_history_req.S,
  MSGTYPE1348 = NetAPIList.normal_ntf.S,
  MSGTYPE579 = NetAPIList.mulmatrix_save_req.S,
  MSGTYPE383 = NetAPIList.allstars_reward_ack.S,
  MSGTYPE345 = NetAPIList.block_devil_ntf.S,
  MSGTYPE667 = NetAPIList.pay_list_carrier_ack.S,
  MSGTYPE358 = NetAPIList.champion_rank_reward_ack.S,
  MSGTYPE433 = NetAPIList.activity_stores_ack.S,
  MSGTYPE1398 = NetAPIList.medal_config_info_req.S,
  MSGTYPE899 = NetAPIList.max_step_ack.S,
  MSGTYPE724 = NetAPIList.push_button_ntf.S,
  MSGTYPE587 = NetAPIList.ladder_reset_req.S,
  MSGTYPE1111 = NetAPIList.wdc_report_detail_req.S,
  MSGTYPE1169 = NetAPIList.hero_union_ack.S,
  MSGTYPE949 = NetAPIList.get_invite_gift_req.S,
  MSGTYPE1190 = NetAPIList.mining_wars_star_ack.S,
  MSGTYPE301 = NetAPIList.mine_info_ntf.S,
  MSGTYPE1137 = NetAPIList.throw_dice_ack.S,
  MSGTYPE540 = NetAPIList.ladder_cancel_req.S,
  MSGTYPE972 = NetAPIList.story_award_ack.S,
  MSGTYPE361 = NetAPIList.vip_loot_ack.S,
  MSGTYPE147 = NetAPIList.krypton_gacha_some_req.S,
  MSGTYPE180 = NetAPIList.alliance_quit_req.S,
  MSGTYPE281 = NetAPIList.event_loot_ack.S,
  MSGTYPE1153 = NetAPIList.event_progress_award_req.S,
  MSGTYPE160 = NetAPIList.champion_list_req.S,
  MSGTYPE958 = NetAPIList.remodel_help_others_ack.S,
  MSGTYPE982 = NetAPIList.view_each_task_req.S,
  MSGTYPE922 = NetAPIList.tactical_equip_on_req.S,
  MSGTYPE664 = NetAPIList.laba_times_ntf.S,
  MSGTYPE188 = NetAPIList.alliance_demote_fail_ack.S,
  MSGTYPE562 = NetAPIList.contention_award_ack.S,
  MSGTYPE559 = NetAPIList.fleet_show_req.S,
  MSGTYPE459 = NetAPIList.client_effect_ack.S,
  MSGTYPE0 = NetAPIList.common_ack.S,
  MSGTYPE1160 = NetAPIList.recruit_list_new_req.S,
  MSGTYPE456 = NetAPIList.items_req.S,
  MSGTYPE699 = NetAPIList.remodel_speed_req.S,
  MSGTYPE1381 = NetAPIList.medal_level_up_ack.S,
  MSGTYPE943 = NetAPIList.enter_plante_ack.S,
  MSGTYPE1121 = NetAPIList.wdc_awards_ntf.S,
  MSGTYPE464 = NetAPIList.domination_join_req.S,
  MSGTYPE300 = NetAPIList.mine_refresh_ntf.S,
  MSGTYPE572 = NetAPIList.items_ntf.S,
  MSGTYPE130 = NetAPIList.alliance_apply_req.S,
  MSGTYPE195 = NetAPIList.alliance_kick_fail_ack.S,
  MSGTYPE623 = NetAPIList.crusade_buy_cross_ack.S,
  MSGTYPE336 = NetAPIList.ac_matrix_req.S,
  MSGTYPE10000 = NetAPIList.keylist_ntf.S,
  MSGTYPE133 = NetAPIList.alliance_unapply_req.S,
  MSGTYPE1179 = NetAPIList.mining_world_ack.S,
  MSGTYPE1184 = NetAPIList.mining_wars_req.S,
  MSGTYPE1412 = NetAPIList.medal_glory_achievement_activate_req.S,
  MSGTYPE7 = NetAPIList.user_snapshot_req.S,
  MSGTYPE553 = NetAPIList.hero_level_attr_diff_req.S,
  MSGTYPE258 = NetAPIList.pay_list_ack.S,
  MSGTYPE196 = NetAPIList.krypton_equip_ack.S,
  MSGTYPE297 = NetAPIList.mine_speedup_req.S,
  MSGTYPE273 = NetAPIList.all_act_status_req.S,
  MSGTYPE1136 = NetAPIList.throw_dice_req.S,
  MSGTYPE554 = NetAPIList.hero_level_attr_diff_ack.S,
  MSGTYPE467 = NetAPIList.domination_challenge_req.S,
  MSGTYPE40 = NetAPIList.revenue_info_req.S,
  MSGTYPE1364 = NetAPIList.mul_credit_exchange_ack.S,
  MSGTYPE890 = NetAPIList.activity_store_price_req.S,
  MSGTYPE602 = NetAPIList.pay_record_ntf.S,
  MSGTYPE404 = NetAPIList.equipment_action_list_req.S,
  MSGTYPE447 = NetAPIList.alliance_defence_repair_req.S,
  MSGTYPE257 = NetAPIList.pay_list_req.S,
  MSGTYPE64 = NetAPIList.equipment_detail_req.S,
  MSGTYPE1383 = NetAPIList.medal_rank_up_ack.S,
  MSGTYPE103 = NetAPIList.shop_purchase_back_req.S,
  MSGTYPE569 = NetAPIList.pay_verify2_ack.S,
  MSGTYPE419 = NetAPIList.colony_exp_ntf.S,
  MSGTYPE838 = NetAPIList.pay_sign_ack.S,
  MSGTYPE212 = NetAPIList.shop_buy_and_wear_req.S,
  MSGTYPE895 = NetAPIList.refresh_type_req.S,
  MSGTYPE606 = NetAPIList.change_auto_decompose_ntf.S,
  MSGTYPE87 = NetAPIList.equipment_enhance_req.S,
  MSGTYPE527 = NetAPIList.screen_track_req.S,
  MSGTYPE872 = NetAPIList.get_goal_award_req.S,
  MSGTYPE294 = NetAPIList.mine_refresh_req.S,
  MSGTYPE1144 = NetAPIList.dice_board_ntf.S,
  MSGTYPE526 = NetAPIList.activity_status_ack.S,
  MSGTYPE1280 = NetAPIList.get_reward_detail_ack.S,
  MSGTYPE223 = NetAPIList.achievement_finish_ntf.S,
  MSGTYPE851 = NetAPIList.pay_push_pop_ntf.S,
  MSGTYPE1271 = NetAPIList.vip_reward_req.S,
  MSGTYPE45 = NetAPIList.add_friend_req.S,
  MSGTYPE716 = NetAPIList.multi_acc_req.S,
  MSGTYPE127 = NetAPIList.alliance_delete_req.S,
  MSGTYPE615 = NetAPIList.crusade_fight_req.S,
  MSGTYPE23 = NetAPIList.battle_status_req.S,
  MSGTYPE249 = NetAPIList.supply_info_req.S,
  MSGTYPE439 = NetAPIList.colony_players_req.S,
  MSGTYPE200 = NetAPIList.user_brief_info_req.S,
  MSGTYPE96 = NetAPIList.quark_exchange_ack.S,
  MSGTYPE1207 = NetAPIList.art_point_upgrade_ack.S,
  MSGTYPE1209 = NetAPIList.art_core_list_ack.S,
  MSGTYPE1310 = NetAPIList.fair_arena_reward_ack.S,
  MSGTYPE666 = NetAPIList.pay_list_carrier_req.S,
  MSGTYPE1251 = NetAPIList.main_city_ntf.S,
  MSGTYPE121 = NetAPIList.alliance_logs_ack.S,
  MSGTYPE396 = NetAPIList.krypton_fragment_core_ntf.S,
  MSGTYPE743 = NetAPIList.krypton_inject_list_req.S,
  MSGTYPE387 = NetAPIList.fleet_sale_with_rebate_list_ack.S,
  MSGTYPE421 = NetAPIList.colony_logs_ntf.S,
  MSGTYPE850 = NetAPIList.temp_vip_ntf.S,
  MSGTYPE328 = NetAPIList.refresh_time_ntf.S,
  MSGTYPE519 = NetAPIList.contention_collect_req.S,
  MSGTYPE271 = NetAPIList.price_ack.S,
  MSGTYPE1152 = NetAPIList.user_change_ack.S,
  MSGTYPE1388 = NetAPIList.medal_equip_on_ack.S,
  MSGTYPE820 = NetAPIList.prime_enemy_info_req.S,
  MSGTYPE2 = NetAPIList.user_register_ack.S,
  MSGTYPE1266 = NetAPIList.achievement_reward_receive_req.S,
  MSGTYPE155 = NetAPIList.alliance_refuse_req.S,
  MSGTYPE542 = NetAPIList.ladder_fresh_ack.S,
  MSGTYPE39 = NetAPIList.techniques_upgrade_ack.S,
  MSGTYPE1274 = NetAPIList.month_card_ack.S,
  MSGTYPE56 = NetAPIList.recruit_fleet_req.S,
  MSGTYPE574 = NetAPIList.ip_ntf.S,
  MSGTYPE1107 = NetAPIList.wdc_fight_req.S,
  MSGTYPE557 = NetAPIList.contention_rank_req.S,
  MSGTYPE75 = NetAPIList.warpgate_collect_ack.S,
  MSGTYPE119 = NetAPIList.alliance_members_ack.S,
  MSGTYPE684 = NetAPIList.game_items_trans_ack.S,
  MSGTYPE659 = NetAPIList.all_gd_fleets_ack.S,
  MSGTYPE971 = NetAPIList.story_award_req.S,
  MSGTYPE108 = NetAPIList.user_collect_offline_expr_ack.S,
  MSGTYPE1386 = NetAPIList.medal_fleet_red_point_ntf.S,
  MSGTYPE700 = NetAPIList.remodel_help_info_req.S,
  MSGTYPE38 = NetAPIList.techniques_upgrade_req.S,
  MSGTYPE591 = NetAPIList.contention_king_change_ntf.S,
  MSGTYPE892 = NetAPIList.daily_benefits_ntf.S,
  MSGTYPE317 = NetAPIList.laba_ntf.S,
  MSGTYPE253 = NetAPIList.cdtimes_clear_req.S,
  MSGTYPE1500 = NetAPIList.battle_rate_req.S,
  MSGTYPE363 = NetAPIList.level_loot_ack.S,
  MSGTYPE619 = NetAPIList.crusade_repair_req.S,
  MSGTYPE84 = NetAPIList.mail_set_read_req.S,
  MSGTYPE1213 = NetAPIList.art_core_equip_ack.S,
  MSGTYPE672 = NetAPIList.add_adjutant_req.S,
  MSGTYPE207 = NetAPIList.task_list_ack.S,
  MSGTYPE1135 = NetAPIList.enter_dice_ack.S,
  MSGTYPE324 = NetAPIList.top_force_list_req.S,
  MSGTYPE210 = NetAPIList.battle_fight_report_req.S,
  MSGTYPE681 = NetAPIList.adjutant_max_ntf.S,
  MSGTYPE132 = NetAPIList.alliance_apply_fail_ack.S,
  MSGTYPE603 = NetAPIList.login_token_ntf.S,
  MSGTYPE923 = NetAPIList.tactical_equip_on_ack.S,
  MSGTYPE448 = NetAPIList.alliance_defence_donate_req.S,
  MSGTYPE821 = NetAPIList.prime_enemy_info_ack.S,
  MSGTYPE937 = NetAPIList.tactical_equip_delete_req.S,
  MSGTYPE883 = NetAPIList.gp_test_pay_group_req.S,
  MSGTYPE675 = NetAPIList.month_card_list_ack.S,
  MSGTYPE145 = NetAPIList.krypton_gacha_one_req.S,
  MSGTYPE693 = NetAPIList.remodel_info_req.S,
  MSGTYPE323 = NetAPIList.chat_error_ntf.S,
  MSGTYPE1413 = NetAPIList.medal_glory_achievement_activate_ack.S,
  MSGTYPE12 = NetAPIList.fleets_req.S,
  MSGTYPE816 = NetAPIList.prime_site_info_ack.S,
  MSGTYPE592 = NetAPIList.award_list_req.S,
  MSGTYPE745 = NetAPIList.krypton_refine_list_req.S,
  MSGTYPE545 = NetAPIList.ladder_buy_search_ack.S,
  MSGTYPE1106 = NetAPIList.wdc_match_ack.S,
  MSGTYPE445 = NetAPIList.alliance_notifies_req.S,
  MSGTYPE1408 = NetAPIList.medal_glory_reset_req.S,
  MSGTYPE589 = NetAPIList.contention_king_info_req.S,
  MSGTYPE10002 = NetAPIList.udid_track_req.S,
  MSGTYPE1263 = NetAPIList.fte_req.S,
  MSGTYPE10001 = NetAPIList.udid_step_req.S,
  MSGTYPE902 = NetAPIList.ladder_jump_req.S,
  MSGTYPE314 = NetAPIList.update_guide_progress_req.S,
  MSGTYPE163 = NetAPIList.champion_challenge_ack.S,
  MSGTYPE1148 = NetAPIList.event_activity_req.S,
  MSGTYPE275 = NetAPIList.special_battle_req.S,
  MSGTYPE58 = NetAPIList.dismiss_fleet_req.S,
  MSGTYPE43 = NetAPIList.revenue_do_ack.S,
  MSGTYPE493 = NetAPIList.open_box_recent_ntf.S,
  MSGTYPE270 = NetAPIList.price_req.S,
  MSGTYPE344 = NetAPIList.block_devil_info_req.S,
  MSGTYPE106 = NetAPIList.user_offline_info_ack.S,
  MSGTYPE806 = NetAPIList.prime_my_info_ntf.S,
  MSGTYPE1414 = NetAPIList.medal_glory_collection_rank_req.S,
  MSGTYPE973 = NetAPIList.thumb_up_info_req.S,
  MSGTYPE164 = NetAPIList.champion_top_req.S,
  MSGTYPE255 = NetAPIList.system_configuration_ack.S,
  MSGTYPE805 = NetAPIList.prime_quit_req.S,
  MSGTYPE1329 = NetAPIList.buy_scratch_card_ack.S,
  MSGTYPE376 = NetAPIList.world_boss_info_ntf.S,
  MSGTYPE618 = NetAPIList.crusade_cross_ack.S,
  MSGTYPE217 = NetAPIList.prestige_obtain_award_ack.S,
  MSGTYPE282 = NetAPIList.battle_event_status_ack.S,
  MSGTYPE47 = NetAPIList.officers_req.S,
  MSGTYPE546 = NetAPIList.ladder_buy_reset_req.S,
  MSGTYPE369 = NetAPIList.promotions_ntf.S,
  MSGTYPE1281 = NetAPIList.save_user_id_req.S,
  MSGTYPE1343 = NetAPIList.art_one_upgrade_req.S,
  MSGTYPE1185 = NetAPIList.mining_wars_ack.S,
  MSGTYPE539 = NetAPIList.ladder_raids_ack.S,
  MSGTYPE581 = NetAPIList.mulmatrix_blank_ntf.S,
  MSGTYPE10 = NetAPIList.chat_ntf.S,
  MSGTYPE1178 = NetAPIList.mining_world_req.S,
  MSGTYPE1355 = NetAPIList.get_login_sign_award_ack.S,
  MSGTYPE995 = NetAPIList.switch_formation_req.S,
  MSGTYPE1174 = NetAPIList.red_point_ntf.S,
  MSGTYPE141 = NetAPIList.krypton_store_ack.S,
  MSGTYPE137 = NetAPIList.add_friend_ack.S,
  MSGTYPE158 = NetAPIList.alliance_memo_ack.S,
  MSGTYPE429 = NetAPIList.colony_exploit_ack.S,
  MSGTYPE265 = NetAPIList.bag_grid_ntf.S,
  MSGTYPE392 = NetAPIList.buy_cut_off_req.S,
  MSGTYPE588 = NetAPIList.ladder_reset_ack.S,
  MSGTYPE357 = NetAPIList.champion_rank_reward_req.S,
  MSGTYPE610 = NetAPIList.activity_dna_ack.S,
  MSGTYPE656 = NetAPIList.activity_rank_ack.S,
  MSGTYPE203 = NetAPIList.alliance_unapply_fail_ack.S,
  MSGTYPE243 = NetAPIList.passport_bind_ack.S,
  MSGTYPE858 = NetAPIList.url_push_ntf.S,
  MSGTYPE996 = NetAPIList.switch_formation_ack.S,
  MSGTYPE340 = NetAPIList.alliance_activities_req.S,
  MSGTYPE125 = NetAPIList.alliance_create_ack.S,
  MSGTYPE494 = NetAPIList.battle_rate_ntf.S,
  MSGTYPE889 = NetAPIList.activity_store_count_ack.S,
  MSGTYPE364 = NetAPIList.vip_loot_get_req.S,
  MSGTYPE412 = NetAPIList.verify_redeem_code_req.S,
  MSGTYPE1203 = NetAPIList.art_main_ack.S,
  MSGTYPE186 = NetAPIList.alliance_demote_req.S,
  MSGTYPE1128 = NetAPIList.translate_info_req.S,
  MSGTYPE530 = NetAPIList.tango_invited_friends_ack.S,
  MSGTYPE427 = NetAPIList.colony_info_test_ack.S,
  MSGTYPE73 = NetAPIList.warpgate_charge_ack.S,
  MSGTYPE1393 = NetAPIList.medal_fleet_btn_red_point_ntf.S,
  MSGTYPE11 = NetAPIList.user_logout_req.S,
  MSGTYPE261 = NetAPIList.sign_activity_ack.S,
  MSGTYPE80 = NetAPIList.mail_content_req.S,
  MSGTYPE516 = NetAPIList.contention_occupier_ack.S,
  MSGTYPE993 = NetAPIList.other_monthly_ack.S,
  MSGTYPE687 = NetAPIList.budo_champion_report_req.S,
  MSGTYPE449 = NetAPIList.alliance_activity_times_ntf.S,
  MSGTYPE144 = NetAPIList.krypton_equip_req.S,
  MSGTYPE382 = NetAPIList.allstars_reward_req.S,
  MSGTYPE1003 = NetAPIList.user_bag_info_ntf.S,
  MSGTYPE927 = NetAPIList.tactical_refine_price_req.S,
  MSGTYPE520 = NetAPIList.contention_collect_ack.S,
  MSGTYPE541 = NetAPIList.ladder_fresh_req.S,
  MSGTYPE555 = NetAPIList.fleet_enhance_req.S,
  MSGTYPE1199 = NetAPIList.mining_battle_report_ack.S,
  MSGTYPE1129 = NetAPIList.translate_info_ack.S,
  MSGTYPE575 = NetAPIList.mail_goods_req.S,
  MSGTYPE1309 = NetAPIList.fair_arena_reward_req.S,
  MSGTYPE241 = NetAPIList.mail_unread_ntf.S,
  MSGTYPE452 = NetAPIList.common_ntf.S,
  MSGTYPE254 = NetAPIList.system_configuration_req.S,
  MSGTYPE1132 = NetAPIList.welcome_mask_req.S,
  MSGTYPE388 = NetAPIList.promotion_detail_req.S,
  MSGTYPE373 = NetAPIList.ready_world_boss_req.S,
  MSGTYPE202 = NetAPIList.krypton_fleet_move_req.S,
  MSGTYPE267 = NetAPIList.level_up_ntf.S,
  MSGTYPE524 = NetAPIList.contention_logbattle_detail_ack.S,
  MSGTYPE14 = NetAPIList.pve_battle_req.S,
  MSGTYPE663 = NetAPIList.stores_refresh_ack.S,
  MSGTYPE295 = NetAPIList.mine_digg_req.S,
  MSGTYPE604 = NetAPIList.dungeon_enter_ack.S,
  MSGTYPE189 = NetAPIList.alliance_promote_req.S,
  MSGTYPE863 = NetAPIList.player_pay_price_req.S,
  MSGTYPE102 = NetAPIList.shop_purchase_back_list_ack.S,
  MSGTYPE645 = NetAPIList.battle_report_ack.S,
  MSGTYPE1382 = NetAPIList.medal_rank_up_req.S,
  MSGTYPE343 = NetAPIList.alliance_weekend_award_ack.S,
  MSGTYPE296 = NetAPIList.mine_atk_req.S,
  MSGTYPE547 = NetAPIList.ladder_buy_reset_ack.S,
  MSGTYPE128 = NetAPIList.alliance_delete_ack.S,
  MSGTYPE8 = NetAPIList.user_snapshot_ack.S,
  MSGTYPE154 = NetAPIList.alliance_ratify_ack.S,
  MSGTYPE999 = NetAPIList.mulmatrix_equip_info_req.S,
  MSGTYPE347 = NetAPIList.block_devil_complete_ntf.S,
  MSGTYPE679 = NetAPIList.fleet_dismiss_req.S,
  MSGTYPE313 = NetAPIList.supply_loot_get_req.S,
  MSGTYPE848 = NetAPIList.all_welfare_award_req.S,
  MSGTYPE525 = NetAPIList.activity_status_req.S,
  MSGTYPE1154 = NetAPIList.star_craft_data_ntf.S,
  MSGTYPE844 = NetAPIList.charge_open_server_fund_req.S,
  MSGTYPE906 = NetAPIList.ladder_report_detail_req.S,
  MSGTYPE94 = NetAPIList.equipments_ack.S,
  MSGTYPE1176 = NetAPIList.area_id_ack.S,
  MSGTYPE104 = NetAPIList.shop_purchase_back_ack.S,
  MSGTYPE900 = NetAPIList.ladder_report_req.S,
  MSGTYPE531 = NetAPIList.tango_invite_req.S,
  MSGTYPE862 = NetAPIList.combo_guide_ack.S,
  MSGTYPE538 = NetAPIList.ladder_raids_req.S,
  MSGTYPE1308 = NetAPIList.fair_arena_season_ack.S,
  MSGTYPE1349 = NetAPIList.change_fleets_data_req.S,
  MSGTYPE1357 = NetAPIList.krypton_redpoint_ack.S,
  MSGTYPE571 = NetAPIList.contention_hit_ntf.S,
  MSGTYPE41 = NetAPIList.revenue_info_ack.S,
  MSGTYPE54 = NetAPIList.recruit_list_req.S,
  MSGTYPE561 = NetAPIList.contention_award_req.S,
  MSGTYPE288 = NetAPIList.adventure_cd_price_req.S,
  MSGTYPE150 = NetAPIList.krypton_decompose_req.S,
  MSGTYPE22 = NetAPIList.user_map_status_ack.S,
  MSGTYPE409 = NetAPIList.thanksgiven_rank_ack.S,
  MSGTYPE633 = NetAPIList.budo_stage_ntf.S,
  MSGTYPE533 = NetAPIList.dungeon_open_ack.S,
  MSGTYPE354 = NetAPIList.champion_top_record_req.S,
  MSGTYPE250 = NetAPIList.supply_info_ack.S,
  MSGTYPE665 = NetAPIList.change_name_ntf.S,
  MSGTYPE183 = NetAPIList.alliance_transfer_req.S,
  MSGTYPE95 = NetAPIList.quark_exchange_req.S,
  MSGTYPE59 = NetAPIList.dismiss_fleet_ack.S,
  MSGTYPE321 = NetAPIList.dexter_libs_ntf.S,
  MSGTYPE191 = NetAPIList.alliance_promote_ack.S,
  MSGTYPE46 = NetAPIList.del_friend_req.S,
  MSGTYPE509 = NetAPIList.activity_task_list_req.S,
  MSGTYPE278 = NetAPIList.quest_ntf.S,
  MSGTYPE286 = NetAPIList.adventure_rush_req.S,
  MSGTYPE714 = NetAPIList.financial_gifts_get_req.S,
  MSGTYPE492 = NetAPIList.open_box_refresh_ack.S,
  MSGTYPE1001 = NetAPIList.change_matrix_type_req.S,
  MSGTYPE1346 = NetAPIList.confirm_exchange_req.S,
  MSGTYPE612 = NetAPIList.akt_dna_next_stg_req.S,
  MSGTYPE1320 = NetAPIList.refresh_fleet_pool_req.S,
  MSGTYPE1318 = NetAPIList.update_formations_req.S,
  MSGTYPE26 = NetAPIList.battle_matrix_ack.S,
  MSGTYPE1294 = NetAPIList.group_fight_ntf.S,
  MSGTYPE229 = NetAPIList.fleet_kryptons_ntf.S,
  MSGTYPE260 = NetAPIList.sign_activity_req.S,
  MSGTYPE1370 = NetAPIList.medal_store_refresh_req.S,
  MSGTYPE262 = NetAPIList.sign_activity_reward_req.S,
  MSGTYPE168 = NetAPIList.champion_get_award_req.S,
  MSGTYPE1102 = NetAPIList.enter_champion_ack.S,
  MSGTYPE414 = NetAPIList.items_count_ntf.S,
  MSGTYPE305 = NetAPIList.mine_atk_ntf.S,
  MSGTYPE356 = NetAPIList.login_time_current_ntf.S,
  MSGTYPE952 = NetAPIList.can_enhance_req.S,
  MSGTYPE1282 = NetAPIList.user_id_status_ntf.S,
  MSGTYPE550 = NetAPIList.ladder_special_req.S,
  MSGTYPE377 = NetAPIList.challenge_world_boss_ack.S,
  MSGTYPE310 = NetAPIList.event_supply_ack.S,
  MSGTYPE1316 = NetAPIList.fair_arena_formation_all_req.S,
  MSGTYPE385 = NetAPIList.timelimit_hero_id_ack.S,
  MSGTYPE192 = NetAPIList.alliance_promote_fail_ack.S,
  MSGTYPE881 = NetAPIList.prime_jump_price_ack.S,
  MSGTYPE718 = NetAPIList.multi_acc_loot_req.S,
  MSGTYPE936 = NetAPIList.tactical_status_ntf.S,
  MSGTYPE1211 = NetAPIList.art_core_down_ack.S,
  MSGTYPE341 = NetAPIList.alliance_activities_ack.S,
  MSGTYPE596 = NetAPIList.award_count_ntf.S,
  MSGTYPE688 = NetAPIList.budo_champion_report_ack.S,
  MSGTYPE276 = NetAPIList.special_battle_ack.S,
  MSGTYPE395 = NetAPIList.activities_button_status_ntf.S,
  MSGTYPE389 = NetAPIList.promotion_detail_ack.S,
  MSGTYPE1312 = NetAPIList.fair_arena_report_req.S,
  MSGTYPE148 = NetAPIList.krypton_gacha_some_ack.S,
  MSGTYPE491 = NetAPIList.open_box_refresh_req.S,
  MSGTYPE1400 = NetAPIList.fight_report_round_ntf.S,
  MSGTYPE836 = NetAPIList.vip_sign_item_use_award_ntf.S,
  MSGTYPE976 = NetAPIList.thumb_up_ack.S,
  MSGTYPE69 = NetAPIList.friend_ban_req.S,
  MSGTYPE1286 = NetAPIList.concentrate_req.S,
  MSGTYPE593 = NetAPIList.award_list_ack.S,
  MSGTYPE120 = NetAPIList.alliance_logs_req.S,
  MSGTYPE903 = NetAPIList.ladder_jump_ack.S,
  MSGTYPE446 = NetAPIList.alliance_resource_ntf.S,
  MSGTYPE25 = NetAPIList.battle_matrix_req.S,
  MSGTYPE338 = NetAPIList.notice_set_read_req.S,
  MSGTYPE185 = NetAPIList.alliance_transfer_fail_ack.S,
  MSGTYPE1399 = NetAPIList.medal_config_info_ack.S,
  MSGTYPE1330 = NetAPIList.reset_scratch_card_req.S,
  MSGTYPE1287 = NetAPIList.concentrate_ack.S,
  MSGTYPE118 = NetAPIList.alliance_members_req.S,
  MSGTYPE235 = NetAPIList.buildings_ntf.S,
  MSGTYPE882 = NetAPIList.select_goal_type_req.S,
  MSGTYPE651 = NetAPIList.get_budo_replay_ack.S,
  MSGTYPE473 = NetAPIList.alliance_domination_battle_ntf.S,
  MSGTYPE5 = NetAPIList.building_upgrade_req.S,
  MSGTYPE876 = NetAPIList.get_goal_award_ack.S,
  MSGTYPE114 = NetAPIList.messages_ack.S,
  MSGTYPE813 = NetAPIList.prime_fight_history_ack.S,
  MSGTYPE65 = NetAPIList.equipment_detail_ack.S,
  MSGTYPE30 = NetAPIList.bag_req.S,
  MSGTYPE841 = NetAPIList.equip_pushed_req.S,
  MSGTYPE1256 = NetAPIList.helper_buttons_req.S,
  MSGTYPE1215 = NetAPIList.art_reset_ack.S,
  MSGTYPE1358 = NetAPIList.event_click_req.S,
  MSGTYPE219 = NetAPIList.achievement_list_req.S,
  MSGTYPE840 = NetAPIList.equip_push_ntf.S,
  MSGTYPE1255 = NetAPIList.space_door_ntf.S,
  MSGTYPE1172 = NetAPIList.hero_collect_rank_req.S,
  MSGTYPE930 = NetAPIList.tactical_refine_ack.S,
  MSGTYPE897 = NetAPIList.force_add_fleet_req.S,
  MSGTYPE460 = NetAPIList.award_receive_req.S,
  MSGTYPE1361 = NetAPIList.redownload_res_ack.S,
  MSGTYPE959 = NetAPIList.ltv_ajust_ntf.S,
  MSGTYPE466 = NetAPIList.alliance_flag_req.S,
  MSGTYPE708 = NetAPIList.update_passport_req.S,
  MSGTYPE834 = NetAPIList.champion_straight_ack.S,
  MSGTYPE1196 = NetAPIList.mining_world_battle_req.S,
  MSGTYPE1116 = NetAPIList.wdc_rank_board_req.S,
  MSGTYPE110 = NetAPIList.fleet_repair_req.S,
  MSGTYPE329 = NetAPIList.ac_info_req.S,
  MSGTYPE1195 = NetAPIList.mining_wars_change_ntf.S,
  MSGTYPE1143 = NetAPIList.finish_speed_task_req.S,
  MSGTYPE515 = NetAPIList.contention_occupier_req.S,
  MSGTYPE239 = NetAPIList.heart_beat_req.S,
  MSGTYPE988 = NetAPIList.get_award_req.S,
  MSGTYPE577 = NetAPIList.mulmatrix_get_req.S,
  MSGTYPE1284 = NetAPIList.forces_req.S,
  MSGTYPE330 = NetAPIList.ac_ntf.S,
  MSGTYPE942 = NetAPIList.enter_plante_req.S,
  MSGTYPE833 = NetAPIList.champion_straight_req.S,
  MSGTYPE312 = NetAPIList.supply_loot_ack.S,
  MSGTYPE334 = NetAPIList.ac_jam_req.S,
  MSGTYPE99 = NetAPIList.shop_sell_req.S,
  MSGTYPE424 = NetAPIList.colony_challenge_req.S,
  MSGTYPE16 = NetAPIList.rush_result_ack.S,
  MSGTYPE1359 = NetAPIList.wxpay_info_ntf.S,
  MSGTYPE187 = NetAPIList.alliance_demote_ack.S,
  MSGTYPE635 = NetAPIList.budo_join_req.S,
  MSGTYPE490 = NetAPIList.open_box_open_ack.S,
  MSGTYPE122 = NetAPIList.alliance_aduits_req.S,
  MSGTYPE216 = NetAPIList.prestige_obtain_award_req.S,
  MSGTYPE989 = NetAPIList.get_award_ack.S,
  MSGTYPE1175 = NetAPIList.area_id_req.S,
  MSGTYPE1296 = NetAPIList.change_atk_seq_ack.S,
  MSGTYPE981 = NetAPIList.enter_monthly_ack.S,
  MSGTYPE4 = NetAPIList.user_login_ack.S,
  MSGTYPE991 = NetAPIList.get_today_award_ack.S,
  MSGTYPE339 = NetAPIList.gateway_clear_req.S,
  MSGTYPE256 = NetAPIList.pay_verify_req.S,
  MSGTYPE929 = NetAPIList.tactical_refine_req.S,
  MSGTYPE438 = NetAPIList.colony_action_purchase_req.S,
  MSGTYPE9 = NetAPIList.chat_req.S,
  MSGTYPE1402 = NetAPIList.medal_glory_collection_req.S,
  MSGTYPE1372 = NetAPIList.medal_list_req.S,
  MSGTYPE809 = NetAPIList.prime_march_ntf.S,
  MSGTYPE824 = NetAPIList.prime_dot_occupy_no_ntf.S,
  MSGTYPE585 = NetAPIList.equip_info_ack.S,
  MSGTYPE351 = NetAPIList.donate_info_ack.S,
  MSGTYPE331 = NetAPIList.ac_battle_req.S,
  MSGTYPE496 = NetAPIList.contention_map_req.S,
  MSGTYPE1157 = NetAPIList.adventure_add_req.S,
  MSGTYPE709 = NetAPIList.financial_req.S,
  MSGTYPE161 = NetAPIList.champion_list_ack.S,
  MSGTYPE1295 = NetAPIList.change_atk_seq_req.S,
  MSGTYPE733 = NetAPIList.send_global_email_req.S,
  MSGTYPE60 = NetAPIList.friends_req.S,
  MSGTYPE869 = NetAPIList.seven_day_ntf.S,
  MSGTYPE284 = NetAPIList.adventure_battle_req.S,
  MSGTYPE1291 = NetAPIList.force_join_ack.S,
  MSGTYPE370 = NetAPIList.promotions_req.S,
  MSGTYPE1216 = NetAPIList.art_core_decompose_req.S,
  MSGTYPE1279 = NetAPIList.get_reward_detail_req.S,
  MSGTYPE601 = NetAPIList.adventure_chapter_status_ntf.S,
  MSGTYPE86 = NetAPIList.fight_ack.S,
  MSGTYPE1258 = NetAPIList.event_log_ntf.S,
  MSGTYPE722 = NetAPIList.push_button_info_req.S,
  MSGTYPE807 = NetAPIList.prime_dot_occupy_ntf.S,
  MSGTYPE327 = NetAPIList.ver_check_req.S,
  MSGTYPE582 = NetAPIList.mulmatrix_price_req.S,
  MSGTYPE566 = NetAPIList.pay_list2_req.S,
  MSGTYPE362 = NetAPIList.level_loot_req.S,
  MSGTYPE479 = NetAPIList.wd_award_ack.S,
  MSGTYPE565 = NetAPIList.orders_ntf.S,
  MSGTYPE535 = NetAPIList.ladder_enter_ack.S,
  MSGTYPE1411 = NetAPIList.medal_glory_achievement_ack.S,
  MSGTYPE101 = NetAPIList.shop_purchase_back_list_req.S,
  MSGTYPE1218 = NetAPIList.art_can_upgrade_req.S,
  MSGTYPE843 = NetAPIList.open_server_fund_ack.S,
  MSGTYPE482 = NetAPIList.wd_last_champion_ack.S,
  MSGTYPE857 = NetAPIList.sell_item_ntf.S,
  MSGTYPE397 = NetAPIList.activities_button_first_status_req.S,
  MSGTYPE134 = NetAPIList.alliance_unapply_ack.S,
  MSGTYPE474 = NetAPIList.alliance_domination_defence_ntf.S,
  MSGTYPE738 = NetAPIList.krypton_inject_ack.S,
  MSGTYPE710 = NetAPIList.financial_ack.S,
  MSGTYPE564 = NetAPIList.contention_history_ack.S,
  MSGTYPE63 = NetAPIList.friend_detail_req.S,
  MSGTYPE381 = NetAPIList.add_world_boss_force_rate_ack.S,
  MSGTYPE205 = NetAPIList.user_challenged_ack.S,
  MSGTYPE723 = NetAPIList.push_button_info_ack.S,
  MSGTYPE517 = NetAPIList.contention_transfer_req.S,
  MSGTYPE629 = NetAPIList.contention_income_ack.S,
  MSGTYPE208 = NetAPIList.get_task_reward_req.S,
  MSGTYPE193 = NetAPIList.alliance_kick_req.S,
  MSGTYPE28 = NetAPIList.battle_result_ack.S,
  MSGTYPE484 = NetAPIList.wd_ranking_rank_req.S,
  MSGTYPE1141 = NetAPIList.speed_resource_req.S,
  MSGTYPE552 = NetAPIList.pay_animation_ntf.S,
  MSGTYPE925 = NetAPIList.tactical_equip_off_ack.S,
  MSGTYPE415 = NetAPIList.thanksgiven_champion_ntf.S,
  MSGTYPE1313 = NetAPIList.fair_arena_report_ack.S,
  MSGTYPE607 = NetAPIList.enchant_req.S,
  MSGTYPE875 = NetAPIList.buy_cutoff_item_req.S,
  MSGTYPE166 = NetAPIList.champion_reset_cd_req.S,
  MSGTYPE674 = NetAPIList.month_card_list_req.S,
  MSGTYPE136 = NetAPIList.alliance_info_ack.S,
  MSGTYPE311 = NetAPIList.supply_loot_req.S,
  MSGTYPE455 = NetAPIList.krypton_info_ack.S,
  MSGTYPE416 = NetAPIList.item_use_award_ntf.S,
  MSGTYPE705 = NetAPIList.give_share_awards_req.S,
  MSGTYPE502 = NetAPIList.contention_starting_req.S,
  MSGTYPE112 = NetAPIList.friend_ban_del_req.S,
  MSGTYPE49 = NetAPIList.officer_buy_req.S,
  MSGTYPE1252 = NetAPIList.mask_modules_req.S,
  MSGTYPE1299 = NetAPIList.my_forces_ack.S,
  MSGTYPE231 = NetAPIList.level_ntf.S,
  MSGTYPE432 = NetAPIList.activity_stores_req.S,
  MSGTYPE365 = NetAPIList.level_loot_get_req.S,
  MSGTYPE483 = NetAPIList.device_info_req.S,
  MSGTYPE617 = NetAPIList.crusade_cross_req.S,
  MSGTYPE1170 = NetAPIList.hero_collect_req.S,
  MSGTYPE741 = NetAPIList.krypton_inject_buy_req.S,
  MSGTYPE325 = NetAPIList.top_force_list_ntf.S,
  MSGTYPE658 = NetAPIList.all_gd_fleets_req.S,
  MSGTYPE422 = NetAPIList.colony_users_req.S,
  MSGTYPE272 = NetAPIList.module_status_ntf.S,
  MSGTYPE159 = NetAPIList.alliance_memo_fail_ack.S,
  MSGTYPE1198 = NetAPIList.mining_battle_report_req.S,
  MSGTYPE1504 = NetAPIList.large_map_base_req.S,
  MSGTYPE182 = NetAPIList.alliance_quit_fail_ack.S,
  MSGTYPE204 = NetAPIList.alliance_info_ntf.S,
  MSGTYPE151 = NetAPIList.krypton_decompose_ack.S,
  MSGTYPE1337 = NetAPIList.end_scratch_ack.S,
  MSGTYPE153 = NetAPIList.alliance_ratify_req.S,
  MSGTYPE98 = NetAPIList.shop_purchase_ack.S,
  MSGTYPE1334 = NetAPIList.exchange_award_req.S,
  MSGTYPE568 = NetAPIList.pay_verify2_req.S,
  MSGTYPE1253 = NetAPIList.mask_show_index_req.S,
  MSGTYPE1301 = NetAPIList.mining_team_log_ack.S,
  MSGTYPE248 = NetAPIList.revenue_exchange_req.S,
  MSGTYPE511 = NetAPIList.activity_task_reward_req.S,
  MSGTYPE904 = NetAPIList.ladder_award_req.S,
  MSGTYPE1163 = NetAPIList.recruit_ack.S,
  MSGTYPE634 = NetAPIList.budo_sign_up_ntf.S,
  MSGTYPE320 = NetAPIList.laba_award_req.S,
  MSGTYPE888 = NetAPIList.activity_store_count_req.S,
  MSGTYPE19 = NetAPIList.user_cdtime_ack.S,
  MSGTYPE481 = NetAPIList.wd_last_champion_req.S,
  MSGTYPE742 = NetAPIList.krypton_inject_buy_ack.S,
  MSGTYPE600 = NetAPIList.contention_leave_req.S,
  MSGTYPE228 = NetAPIList.cd_time_ntf.S,
  MSGTYPE194 = NetAPIList.alliance_kick_ack.S,
  MSGTYPE368 = NetAPIList.krypton_energy_req.S,
  MSGTYPE558 = NetAPIList.contention_rank_ack.S,
  MSGTYPE835 = NetAPIList.champion_straight_award_req.S,
  MSGTYPE79 = NetAPIList.mail_page_ack.S,
  MSGTYPE734 = NetAPIList.collect_energy_req.S,
  MSGTYPE701 = NetAPIList.remodel_help_info_ack.S,
  MSGTYPE626 = NetAPIList.akt_dna_get_award_req.S,
  MSGTYPE668 = NetAPIList.laba_type_ntf.S,
  MSGTYPE20 = NetAPIList.user_cdtime_req.S,
  MSGTYPE1165 = NetAPIList.recruit_look_ack.S,
  MSGTYPE66 = NetAPIList.friend_detail_ack.S,
  MSGTYPE76 = NetAPIList.warpgate_upgrade_req.S,
  MSGTYPE885 = NetAPIList.store_quick_buy_count_ack.S,
  MSGTYPE67 = NetAPIList.friend_search_req.S,
  MSGTYPE27 = NetAPIList.user_matrix_save_req.S,
  MSGTYPE1142 = NetAPIList.speed_resource_ack.S,
  MSGTYPE1002 = NetAPIList.change_matrix_type_ack.S,
  MSGTYPE523 = NetAPIList.contention_logbattle_detail_req.S,
  MSGTYPE908 = NetAPIList.stores_buy_ack.S,
  MSGTYPE1005 = NetAPIList.bugly_data_ntf.S,
  MSGTYPE1505 = NetAPIList.large_map_base_ack.S,
  MSGTYPE1126 = NetAPIList.wdc_fight_status_ack.S,
  MSGTYPE451 = NetAPIList.fleet_info_ack.S,
  MSGTYPE74 = NetAPIList.warpgate_collect_req.S,
  MSGTYPE471 = NetAPIList.domination_ranks_req.S,
  MSGTYPE1115 = NetAPIList.wdc_awards_ack.S,
  MSGTYPE616 = NetAPIList.crusade_fight_ack.S,
  MSGTYPE140 = NetAPIList.krypton_store_req.S,
  MSGTYPE293 = NetAPIList.mine_list_req.S,
  MSGTYPE921 = NetAPIList.enter_tactical_ack.S,
  MSGTYPE884 = NetAPIList.store_quick_buy_count_req.S,
  MSGTYPE827 = NetAPIList.prime_round_result_ntf.S,
  MSGTYPE437 = NetAPIList.colony_release_ack.S,
  MSGTYPE410 = NetAPIList.festival_req.S,
  MSGTYPE655 = NetAPIList.activity_rank_req.S,
  MSGTYPE802 = NetAPIList.prime_active_req.S,
  MSGTYPE660 = NetAPIList.fleet_fight_report_req.S,
  MSGTYPE676 = NetAPIList.month_card_buy_req.S,
  MSGTYPE1183 = NetAPIList.mining_world_pe_ack.S,
  MSGTYPE746 = NetAPIList.krypton_refine_list_ack.S,
  MSGTYPE146 = NetAPIList.krypton_gacha_one_ack.S,
  MSGTYPE35 = NetAPIList.techniques_ack.S,
  MSGTYPE650 = NetAPIList.get_budo_replay_req.S,
  MSGTYPE907 = NetAPIList.ladder_report_detail_ack.S,
  MSGTYPE226 = NetAPIList.fleets_ntf.S,
  MSGTYPE453 = NetAPIList.warn_req.S,
  MSGTYPE436 = NetAPIList.colony_release_req.S,
  MSGTYPE657 = NetAPIList.support_one_player_ack.S,
  MSGTYPE379 = NetAPIList.add_world_boss_force_rate_req.S,
  MSGTYPE1000 = NetAPIList.mulmatrix_equip_info_ack.S,
  MSGTYPE605 = NetAPIList.change_auto_decompose_req.S,
  MSGTYPE378 = NetAPIList.ready_world_boss_ack.S,
  MSGTYPE90 = NetAPIList.equipment_evolution_req.S,
  MSGTYPE83 = NetAPIList.mail_delete_req.S,
  MSGTYPE13 = NetAPIList.fleets_ack.S,
  MSGTYPE36 = NetAPIList.gm_cmd_req.S,
  MSGTYPE853 = NetAPIList.prime_do_wve_boss_left_ntf.S,
  MSGTYPE478 = NetAPIList.wd_award_req.S,
  MSGTYPE81 = NetAPIList.mail_content_ack.S,
  MSGTYPE238 = NetAPIList.fleet_matrix_ntf.S,
  MSGTYPE928 = NetAPIList.tactical_refine_price_ack.S,
  MSGTYPE576 = NetAPIList.mail_goods_ack.S,
  MSGTYPE1323 = NetAPIList.fair_arena_fleet_info_ack.S,
  MSGTYPE55 = NetAPIList.recruit_list_ack.S,
  MSGTYPE859 = NetAPIList.enhance_info_req.S,
  MSGTYPE677 = NetAPIList.month_card_use_req.S,
  MSGTYPE211 = NetAPIList.battle_fight_report_ack.S,
  MSGTYPE685 = NetAPIList.budo_champion_req.S,
  MSGTYPE259 = NetAPIList.use_item_req.S,
  MSGTYPE825 = NetAPIList.prime_award_req.S,
  MSGTYPE1319 = NetAPIList.update_formations_ack.S,
  MSGTYPE123 = NetAPIList.alliance_aduits_ack.S,
  MSGTYPE818 = NetAPIList.prime_increase_power_info_req.S,
  MSGTYPE1117 = NetAPIList.wdc_rank_board_ack.S,
  MSGTYPE638 = NetAPIList.budo_change_formation_req.S,
  MSGTYPE590 = NetAPIList.contention_king_info_ack.S,
  MSGTYPE129 = NetAPIList.alliance_delete_fail_ack.S,
  MSGTYPE595 = NetAPIList.award_get_all_req.S,
  MSGTYPE731 = NetAPIList.friend_role_req.S,
  MSGTYPE318 = NetAPIList.laba_rate_reroll_req.S,
  MSGTYPE234 = NetAPIList.progress_ntf.S,
  MSGTYPE15 = NetAPIList.user_rush_req.S,
  MSGTYPE375 = NetAPIList.exit_world_boss_req.S,
  MSGTYPE408 = NetAPIList.thanksgiven_rank_req.S,
  MSGTYPE48 = NetAPIList.officers_ack.S,
  MSGTYPE24 = NetAPIList.battle_status_ack.S,
  MSGTYPE227 = NetAPIList.resource_ntf.S,
  MSGTYPE3 = NetAPIList.user_login_req.S,
  MSGTYPE359 = NetAPIList.first_purchase_ntf.S,
  MSGTYPE269 = NetAPIList.pve_awards_get_ack.S,
  MSGTYPE488 = NetAPIList.open_box_info_ack.S,
  MSGTYPE285 = NetAPIList.adventure_cd_clear_req.S,
  MSGTYPE390 = NetAPIList.cut_off_list_req.S,
  MSGTYPE31 = NetAPIList.bag_ack.S,
  MSGTYPE954 = NetAPIList.tactical_delete_awards_req.S,
  MSGTYPE868 = NetAPIList.enter_seven_day_req.S,
  MSGTYPE886 = NetAPIList.store_quick_buy_price_req.S,
  MSGTYPE485 = NetAPIList.wd_ranking_rank_ack.S,
  MSGTYPE1155 = NetAPIList.star_craft_sign_up_req.S,
  MSGTYPE1289 = NetAPIList.concentrate_end_ack.S,
  MSGTYPE861 = NetAPIList.combo_guide_req.S,
  MSGTYPE245 = NetAPIList.act_status_req.S,
  MSGTYPE279 = NetAPIList.quest_loot_req.S,
  MSGTYPE497 = NetAPIList.contention_map_ack.S,
  MSGTYPE367 = NetAPIList.active_gifts_req.S,
  MSGTYPE537 = NetAPIList.ladder_search_ack.S,
  MSGTYPE394 = NetAPIList.new_activities_compare_req.S,
  MSGTYPE730 = NetAPIList.treasure_info_req.S,
  MSGTYPE814 = NetAPIList.prime_increase_power_req.S,
  MSGTYPE21 = NetAPIList.pve_map_status_req.S,
  MSGTYPE1273 = NetAPIList.month_card_req.S,
  MSGTYPE646 = NetAPIList.get_my_support_req.S,
  MSGTYPE598 = NetAPIList.contention_mission_info_ack.S,
  MSGTYPE501 = NetAPIList.contention_station_ntf.S,
  MSGTYPE1202 = NetAPIList.art_main_req.S,
  MSGTYPE472 = NetAPIList.domination_ranks_ack.S,
  MSGTYPE252 = NetAPIList.connection_close_req.S,
  MSGTYPE360 = NetAPIList.vip_loot_req.S,
  MSGTYPE435 = NetAPIList.yys_ntf.S,
  MSGTYPE1347 = NetAPIList.credit_exchange_ntf.S,
  MSGTYPE887 = NetAPIList.store_quick_buy_price_ack.S,
  MSGTYPE926 = NetAPIList.tactical_resource_ntf.S,
  MSGTYPE1156 = NetAPIList.event_ntf_req.S,
  MSGTYPE924 = NetAPIList.tactical_equip_off_req.S,
  MSGTYPE692 = NetAPIList.version_code_update_req.S,
  MSGTYPE1269 = NetAPIList.pay_gifts_ack.S,
  MSGTYPE536 = NetAPIList.ladder_search_req.S,
  MSGTYPE470 = NetAPIList.domination_awards_list_ack.S,
  MSGTYPE1368 = NetAPIList.medal_store_buy_req.S,
  MSGTYPE828 = NetAPIList.krypton_sort_req.S,
  MSGTYPE1373 = NetAPIList.medal_list_ack.S,
  MSGTYPE251 = NetAPIList.supply_exchange_req.S,
  MSGTYPE1507 = NetAPIList.large_map_route_req.S,
  MSGTYPE974 = NetAPIList.thumb_up_info_ack.S,
  MSGTYPE528 = NetAPIList.contention_jump_ntf.S,
  MSGTYPE430 = NetAPIList.colony_fawn_req.S,
  MSGTYPE70 = NetAPIList.warpgate_status_req.S,
  MSGTYPE854 = NetAPIList.prime_time_wve_boss_left_ntf.S,
  MSGTYPE986 = NetAPIList.redo_task_req.S,
  MSGTYPE1339 = NetAPIList.uc_pay_sign_ack.S,
  MSGTYPE82 = NetAPIList.mail_send_req.S,
  MSGTYPE1201 = NetAPIList.version_info_req.S,
  MSGTYPE648 = NetAPIList.get_budo_rank_req.S,
  MSGTYPE1510 = NetAPIList.large_map_event_ntf.S,
  MSGTYPE1123 = NetAPIList.wdc_awards_get_ack.S,
  MSGTYPE1509 = NetAPIList.large_map_route_ntf.S,
  MSGTYPE704 = NetAPIList.give_friends_gift_req.S,
  MSGTYPE1506 = NetAPIList.large_map_block_update_ntf.S,
  MSGTYPE1503 = NetAPIList.large_map_block_ack.S,
  MSGTYPE1206 = NetAPIList.art_point_upgrade_req.S,
  MSGTYPE77 = NetAPIList.warpgate_upgrade_ack.S,
  MSGTYPE1502 = NetAPIList.large_map_block_req.S,
  MSGTYPE1501 = NetAPIList.hero_union_unlock_ntf.S,
  MSGTYPE521 = NetAPIList.contention_logs_req.S,
  MSGTYPE1380 = NetAPIList.medal_level_up_req.S,
  MSGTYPE931 = NetAPIList.tactical_refine_save_req.S,
  MSGTYPE522 = NetAPIList.contention_logs_ack.S,
  MSGTYPE1415 = NetAPIList.medal_glory_collection_rank_ack.S,
  MSGTYPE1410 = NetAPIList.medal_glory_achievement_req.S,
  MSGTYPE1409 = NetAPIList.medal_glory_reset_ack.S,
  MSGTYPE1104 = NetAPIList.wdc_enter_ack.S,
  MSGTYPE181 = NetAPIList.alliance_quit_ack.S,
  MSGTYPE124 = NetAPIList.alliance_create_req.S,
  MSGTYPE1407 = NetAPIList.medal_glory_rank_up_ack.S,
  MSGTYPE126 = NetAPIList.alliance_create_fail_ack.S,
  MSGTYPE1406 = NetAPIList.medal_glory_rank_up_req.S,
  MSGTYPE1210 = NetAPIList.art_core_down_req.S,
  MSGTYPE348 = NetAPIList.donate_req.S,
  MSGTYPE846 = NetAPIList.all_welfare_req.S,
  MSGTYPE1404 = NetAPIList.medal_glory_activate_req.S,
  MSGTYPE165 = NetAPIList.champion_top_ack.S,
  MSGTYPE1403 = NetAPIList.medal_glory_collection_ack.S,
  MSGTYPE661 = NetAPIList.fleet_fight_report_ack.S,
  MSGTYPE979 = NetAPIList.today_act_task_ack.S,
  MSGTYPE374 = NetAPIList.challenge_world_boss_req.S,
  MSGTYPE93 = NetAPIList.equipments_req.S,
  MSGTYPE1401 = NetAPIList.medal_glory_collection_ntf.S,
  MSGTYPE732 = NetAPIList.friend_role_ack.S,
  MSGTYPE1315 = NetAPIList.fair_arena_report_battle_ack.S,
  MSGTYPE218 = NetAPIList.prestige_complete_ntf.S,
  MSGTYPE1181 = NetAPIList.mining_world_log_ack.S,
  MSGTYPE1392 = NetAPIList.medal_equip_replace_ack.S,
  MSGTYPE1391 = NetAPIList.medal_equip_replace_req.S,
  MSGTYPE1390 = NetAPIList.medal_equip_off_ack.S,
  MSGTYPE815 = NetAPIList.prime_site_info_req.S,
  MSGTYPE983 = NetAPIList.view_each_task_ack.S,
  MSGTYPE1177 = NetAPIList.master_ntf.S,
  MSGTYPE717 = NetAPIList.multi_acc_ack.S,
  MSGTYPE1389 = NetAPIList.medal_equip_off_req.S,
  MSGTYPE1387 = NetAPIList.medal_equip_on_req.S,
  MSGTYPE1385 = NetAPIList.medal_fleet_formation_ntf.S,
  MSGTYPE1340 = NetAPIList.ac_sweep_req.S,
  MSGTYPE1384 = NetAPIList.medal_list_ntf.S,
  MSGTYPE567 = NetAPIList.pay_list2_ack.S,
  MSGTYPE1379 = NetAPIList.medal_equip_ack.S,
  MSGTYPE938 = NetAPIList.tactical_equip_delete_ack.S,
  MSGTYPE1322 = NetAPIList.fair_arena_fleet_info_req.S,
  MSGTYPE1344 = NetAPIList.art_one_upgrade_ack.S,
  MSGTYPE37 = NetAPIList.pack_bag_req.S,
  MSGTYPE1378 = NetAPIList.medal_equip_req.S,
  MSGTYPE1377 = NetAPIList.medal_reset_confirm_ack.S,
  MSGTYPE1376 = NetAPIList.medal_reset_confirm_req.S,
  MSGTYPE940 = NetAPIList.pay_sign_board_ntf.S,
  MSGTYPE678 = NetAPIList.chat_channel_switch_ntf.S,
  MSGTYPE529 = NetAPIList.tango_invited_friends_req.S,
  MSGTYPE1371 = NetAPIList.medal_store_refresh_ack.S,
  MSGTYPE1369 = NetAPIList.medal_store_buy_ack.S,
  MSGTYPE1140 = NetAPIList.reset_dice_ack.S,
  MSGTYPE1307 = NetAPIList.fair_arena_season_req.S,
  MSGTYPE1259 = NetAPIList.choosable_item_req.S,
  MSGTYPE715 = NetAPIList.financial_amount_ntf.S,
  MSGTYPE1205 = NetAPIList.art_point_ack.S,
  MSGTYPE642 = NetAPIList.budo_promotion_ntf.S,
  MSGTYPE711 = NetAPIList.financial_upgrade_req.S,
  MSGTYPE206 = NetAPIList.task_list_req.S,
  MSGTYPE639 = NetAPIList.budo_change_formation_ack.S,
  MSGTYPE1366 = NetAPIList.enter_medal_store_req.S,
  MSGTYPE264 = NetAPIList.server_kick_user_ntf.S,
  MSGTYPE719 = NetAPIList.facebook_friends_ntf.S,
  MSGTYPE970 = NetAPIList.story_status_ntf.S,
  MSGTYPE1363 = NetAPIList.exchange_regulation_ntf.S,
  MSGTYPE162 = NetAPIList.champion_challenge_req.S,
  MSGTYPE236 = NetAPIList.offline_changed_ntf.S,
  MSGTYPE1360 = NetAPIList.redownload_res_req.S,
  MSGTYPE1345 = NetAPIList.scratch_board_ntf.S,
  MSGTYPE1290 = NetAPIList.force_join_req.S,
  MSGTYPE1118 = NetAPIList.wdc_honor_wall_req.S,
  MSGTYPE866 = NetAPIList.daily_benefits_ack.S,
  MSGTYPE149 = NetAPIList.krypton_equip_off_req.S,
  MSGTYPE1354 = NetAPIList.get_login_sign_award_req.S,
  MSGTYPE1353 = NetAPIList.enter_login_sign_ack.S,
  MSGTYPE1352 = NetAPIList.enter_login_sign_req.S,
  MSGTYPE1351 = NetAPIList.change_fleets_req.S,
  MSGTYPE1350 = NetAPIList.change_fleets_data_ack.S,
  MSGTYPE1342 = NetAPIList.art_one_upgrade_data_ack.S,
  MSGTYPE1341 = NetAPIList.art_one_upgrade_data_req.S,
  MSGTYPE1105 = NetAPIList.wdc_match_req.S,
  MSGTYPE1338 = NetAPIList.uc_pay_sign_req.S,
  MSGTYPE1336 = NetAPIList.end_scratch_req.S,
  MSGTYPE1127 = NetAPIList.wdc_status_ntf.S,
  MSGTYPE1335 = NetAPIList.exchange_award_ack.S,
  MSGTYPE1333 = NetAPIList.get_process_award_ack.S,
  MSGTYPE443 = NetAPIList.alliance_defence_ntf.S,
  MSGTYPE811 = NetAPIList.prime_rank_ntf.S,
  MSGTYPE683 = NetAPIList.game_items_trans_req.S,
  MSGTYPE1332 = NetAPIList.get_process_award_req.S,
  MSGTYPE232 = NetAPIList.equipments_update_ntf.S,
  MSGTYPE461 = NetAPIList.client_fps_req.S,
  MSGTYPE326 = NetAPIList.supply_loot_ntf.S,
  MSGTYPE1331 = NetAPIList.reset_scratch_card_ack.S,
  MSGTYPE1328 = NetAPIList.buy_scratch_card_req.S,
  MSGTYPE1327 = NetAPIList.enter_scratch_ack.S,
  MSGTYPE1326 = NetAPIList.enter_scratch_req.S,
  MSGTYPE247 = NetAPIList.vip_info_ntf.S,
  MSGTYPE1325 = NetAPIList.fte_gift_ntf.S,
  MSGTYPE1324 = NetAPIList.price_off_store_ntf.S,
  MSGTYPE740 = NetAPIList.krypton_refine_info_ack.S,
  MSGTYPE1321 = NetAPIList.refresh_fleet_pool_ack.S,
  MSGTYPE440 = NetAPIList.colony_players_ack.S,
  MSGTYPE1317 = NetAPIList.fair_arena_formation_all_ack.S,
  MSGTYPE1314 = NetAPIList.fair_arena_report_battle_req.S,
  MSGTYPE735 = NetAPIList.krypton_refine_req.S,
  MSGTYPE654 = NetAPIList.special_efficacy_ntf.S,
  MSGTYPE230 = NetAPIList.supply_ntf.S,
  MSGTYPE299 = NetAPIList.mine_list_ntf.S,
  MSGTYPE721 = NetAPIList.push_button_req.S,
  MSGTYPE423 = NetAPIList.colony_users_ack.S,
  MSGTYPE403 = NetAPIList.stores_buy_req.S,
  MSGTYPE468 = NetAPIList.domination_challenge_ack.S,
  MSGTYPE1306 = NetAPIList.fair_arena_rank_ack.S,
  MSGTYPE1168 = NetAPIList.hero_union_req.S,
  MSGTYPE1305 = NetAPIList.fair_arena_rank_req.S,
  MSGTYPE1304 = NetAPIList.fair_arena_ack.S,
  MSGTYPE1303 = NetAPIList.fair_arena_req.S,
  MSGTYPE214 = NetAPIList.prestige_info_req.S,
  MSGTYPE695 = NetAPIList.remodel_info_ntf.S,
  MSGTYPE1300 = NetAPIList.mining_team_log_req.S,
  MSGTYPE507 = NetAPIList.alliance_domination_status_ack.S,
  MSGTYPE1114 = NetAPIList.wdc_awards_req.S,
  MSGTYPE72 = NetAPIList.warpgate_charge_req.S,
  MSGTYPE1297 = NetAPIList.forces_ntf.S,
  MSGTYPE1293 = NetAPIList.concentrate_atk_ack.S,
  MSGTYPE199 = NetAPIList.user_fight_history_ack.S,
  MSGTYPE1292 = NetAPIList.concentrate_atk_req.S,
  MSGTYPE1288 = NetAPIList.concentrate_end_req.S,
  MSGTYPE1110 = NetAPIList.wdc_report_ack.S,
  MSGTYPE240 = NetAPIList.task_finished_ntf.S,
  MSGTYPE352 = NetAPIList.alliance_level_info_ntf.S,
  MSGTYPE1283 = NetAPIList.item_classify_ntf.S,
  MSGTYPE1278 = NetAPIList.leader_info_ntf.S,
  MSGTYPE1277 = NetAPIList.change_leader_req.S,
  MSGTYPE1151 = NetAPIList.user_change_req.S,
  MSGTYPE1182 = NetAPIList.mining_world_pe_req.S,
  MSGTYPE292 = NetAPIList.loud_cast_ntf.S,
  MSGTYPE1276 = NetAPIList.month_card_receive_reward_ack.S,
  MSGTYPE1275 = NetAPIList.month_card_receive_reward_req.S,
  MSGTYPE1272 = NetAPIList.vip_reward_ack.S,
  MSGTYPE1270 = NetAPIList.wish_pay_req.S,
  MSGTYPE1101 = NetAPIList.enter_champion_req.S,
  MSGTYPE1268 = NetAPIList.pay_gifts_req.S,
  MSGTYPE349 = NetAPIList.donate_ack.S,
  MSGTYPE109 = NetAPIList.fleet_repair_all_req.S,
  MSGTYPE597 = NetAPIList.contention_mission_info_req.S,
  MSGTYPE1204 = NetAPIList.art_point_req.S,
  MSGTYPE1265 = NetAPIList.fte_ntf.S,
  MSGTYPE1264 = NetAPIList.fte_ack.S,
  MSGTYPE1261 = NetAPIList.choosable_item_use_req.S,
  MSGTYPE631 = NetAPIList.budo_req.S,
  MSGTYPE1367 = NetAPIList.enter_medal_store_ack.S,
  MSGTYPE518 = NetAPIList.contention_production_ntf.S,
  MSGTYPE1257 = NetAPIList.helper_buttons_ack.S,
  MSGTYPE1254 = NetAPIList.space_door_req.S,
  MSGTYPE1219 = NetAPIList.art_can_upgrade_ack.S,
  MSGTYPE1188 = NetAPIList.mining_wars_refresh_req.S,
  MSGTYPE1214 = NetAPIList.art_reset_req.S,
  MSGTYPE946 = NetAPIList.plante_refresh_req.S,
  MSGTYPE32 = NetAPIList.swap_bag_grid_req.S,
  MSGTYPE1405 = NetAPIList.medal_glory_activate_ack.S,
  MSGTYPE826 = NetAPIList.prime_award_ack.S,
  MSGTYPE1208 = NetAPIList.art_core_list_req.S,
  MSGTYPE142 = NetAPIList.krypton_enhance_req.S,
  MSGTYPE78 = NetAPIList.mail_page_req.S,
  MSGTYPE1267 = NetAPIList.achievement_reward_receive_ack.S,
  MSGTYPE1511 = NetAPIList.large_map_battle_req.S,
  MSGTYPE401 = NetAPIList.stores_ack.S,
  MSGTYPE720 = NetAPIList.financial_ntf.S,
  MSGTYPE1197 = NetAPIList.mining_world_battle_ack.S,
  MSGTYPE263 = NetAPIList.create_tipoff_req.S,
  MSGTYPE682 = NetAPIList.max_level_ntf.S,
  MSGTYPE1192 = NetAPIList.mining_wars_battle_ack.S,
  MSGTYPE1191 = NetAPIList.mining_wars_battle_req.S,
  MSGTYPE306 = NetAPIList.mine_info_req.S,
  MSGTYPE1189 = NetAPIList.mining_wars_star_req.S,
  MSGTYPE1217 = NetAPIList.art_core_decompose_ack.S,
  MSGTYPE1187 = NetAPIList.mining_wars_buy_count_ack.S,
  MSGTYPE143 = NetAPIList.krypton_enhance_ack.S,
  MSGTYPE1186 = NetAPIList.mining_wars_buy_count_req.S,
  MSGTYPE1180 = NetAPIList.mining_world_log_req.S,
  MSGTYPE1004 = NetAPIList.client_req_stat_req.S,
  MSGTYPE1171 = NetAPIList.hero_collect_ack.S,
  MSGTYPE476 = NetAPIList.wd_star_req.S,
  MSGTYPE832 = NetAPIList.champion_promote_ntf.S,
  MSGTYPE107 = NetAPIList.user_collect_offline_expr_req.S,
  MSGTYPE1167 = NetAPIList.master_ack.S,
  MSGTYPE1158 = NetAPIList.adventure_add_ack.S,
  MSGTYPE1166 = NetAPIList.master_req.S,
  MSGTYPE624 = NetAPIList.crusade_first_req.S,
  MSGTYPE727 = NetAPIList.get_energy_req.S,
  MSGTYPE644 = NetAPIList.battle_report_req.S,
  MSGTYPE1162 = NetAPIList.recruit_req.S,
  MSGTYPE1161 = NetAPIList.recruit_list_new_ack.S,
  MSGTYPE506 = NetAPIList.alliance_domination_status_req.S,
  MSGTYPE985 = NetAPIList.view_award_ack.S,
  MSGTYPE1150 = NetAPIList.event_activity_award_req.S,
  MSGTYPE686 = NetAPIList.budo_champion_ack.S,
  MSGTYPE1149 = NetAPIList.event_activity_ack.S,
  MSGTYPE1147 = NetAPIList.event_activity_ntf.S,
  MSGTYPE71 = NetAPIList.warpgate_status_ack.S,
  MSGTYPE1146 = NetAPIList.speed_resource_ntf.S,
  MSGTYPE1145 = NetAPIList.wdc_rank_board_ntf.S,
  MSGTYPE1139 = NetAPIList.reset_dice_req.S,
  MSGTYPE1138 = NetAPIList.dice_awards_req.S,
  MSGTYPE386 = NetAPIList.fleet_sale_with_rebate_list_req.S,
  MSGTYPE514 = NetAPIList.contention_name_ntf.S,
  MSGTYPE891 = NetAPIList.activity_store_price_ack.S,
  MSGTYPE1362 = NetAPIList.open_box_progress_award_req.S,
  MSGTYPE1133 = NetAPIList.first_charge_ntf.S,
  MSGTYPE1131 = NetAPIList.welcome_screen_ack.S,
  MSGTYPE1130 = NetAPIList.welcome_screen_req.S,
  MSGTYPE1125 = NetAPIList.wdc_fight_status_req.S,
  MSGTYPE669 = NetAPIList.mail_to_all_req.S,
  MSGTYPE1124 = NetAPIList.wdc_rankup_ntf.S,
  MSGTYPE277 = NetAPIList.battle_money_collect_req.S,
  MSGTYPE116 = NetAPIList.alliances_req.S,
  MSGTYPE1122 = NetAPIList.wdc_awards_get_req.S,
  MSGTYPE1120 = NetAPIList.wdc_enemy_release_req.S,
  MSGTYPE1119 = NetAPIList.wdc_honor_wall_ack.S,
  MSGTYPE454 = NetAPIList.krypton_info_req.S,
  MSGTYPE1298 = NetAPIList.my_forces_req.S,
  MSGTYPE1113 = NetAPIList.wdc_info_ntf.S,
  MSGTYPE945 = NetAPIList.plante_explore_ack.S,
  MSGTYPE1112 = NetAPIList.wdc_report_detail_ack.S,
  MSGTYPE1109 = NetAPIList.wdc_report_req.S,
  MSGTYPE233 = NetAPIList.attributes_change_ntf.S,
  MSGTYPE393 = NetAPIList.promotion_award_ntf.S,
  MSGTYPE57 = NetAPIList.recruit_fleet_ack.S,
  MSGTYPE1108 = NetAPIList.wdc_fight_ack.S,
  MSGTYPE1103 = NetAPIList.wdc_enter_req.S,
  MSGTYPE939 = NetAPIList.pay_limit_ntf.S,
  MSGTYPE830 = NetAPIList.prestige_info_ntf.S,
  MSGTYPE1173 = NetAPIList.hero_collect_rank_ack.S,
  MSGTYPE998 = NetAPIList.mulmatrix_switch_ack.S,
  MSGTYPE935 = NetAPIList.tactical_enter_refine_ack.S,
  MSGTYPE957 = NetAPIList.alliance_guid_ntf.S,
  MSGTYPE371 = NetAPIList.promotion_award_req.S,
  MSGTYPE117 = NetAPIList.alliances_ack.S,
  MSGTYPE992 = NetAPIList.other_monthly_req.S,
  MSGTYPE990 = NetAPIList.get_today_award_req.S,
  MSGTYPE987 = NetAPIList.redo_task_ack.S,
  MSGTYPE879 = NetAPIList.enter_seven_day_ack.S,
  MSGTYPE184 = NetAPIList.alliance_transfer_ack.S,
  MSGTYPE1159 = NetAPIList.adventure_add_price_req.S,
  MSGTYPE870 = NetAPIList.goal_info_req.S,
  MSGTYPE873 = NetAPIList.cutoff_info_req.S,
  MSGTYPE978 = NetAPIList.today_act_task_req.S,
  MSGTYPE609 = NetAPIList.activity_dna_req.S,
  MSGTYPE977 = NetAPIList.credit_exchange_ack.S,
  MSGTYPE975 = NetAPIList.thumb_up_req.S,
  MSGTYPE442 = NetAPIList.alliance_defence_req.S,
  MSGTYPE1365 = NetAPIList.mul_credit_exchange_ntf.S,
  MSGTYPE956 = NetAPIList.first_login_ntf.S,
  MSGTYPE955 = NetAPIList.tactical_delete_awards_ack.S,
  MSGTYPE444 = NetAPIList.alliance_set_defender_req.S,
  MSGTYPE628 = NetAPIList.contention_income_req.S,
  MSGTYPE951 = NetAPIList.facebook_switch_ntf.S,
  MSGTYPE950 = NetAPIList.get_invite_gift_ack.S,
  MSGTYPE556 = NetAPIList.fleet_weaken_req.S,
  MSGTYPE413 = NetAPIList.verify_redeem_code_ack.S,
  MSGTYPE947 = NetAPIList.plante_refresh_ack.S,
  MSGTYPE1212 = NetAPIList.art_core_equip_req.S,
  MSGTYPE406 = NetAPIList.mail_to_alliance_req.S,
  MSGTYPE737 = NetAPIList.krypton_inject_req.S,
  MSGTYPE941 = NetAPIList.tactical_guide_req.S,
  MSGTYPE33 = NetAPIList.swap_bag_grid_ack.S,
  MSGTYPE307 = NetAPIList.mine_reset_atk_cd_req.S,
  MSGTYPE156 = NetAPIList.alliance_refuse_ack.S,
  MSGTYPE694 = NetAPIList.remodel_info_ack.S,
  MSGTYPE1375 = NetAPIList.medal_decompose_confirm_ack.S,
  MSGTYPE549 = NetAPIList.ladder_rank_ack.S,
  MSGTYPE997 = NetAPIList.mulmatrix_switch_req.S,
  MSGTYPE671 = NetAPIList.champion_matrix_ack.S,
  MSGTYPE933 = NetAPIList.tactical_unlock_slot_ack.S,
  MSGTYPE469 = NetAPIList.domination_awards_list_req.S,
  MSGTYPE920 = NetAPIList.enter_tactical_req.S,
  MSGTYPE905 = NetAPIList.ladder_award_ntf.S,
  MSGTYPE157 = NetAPIList.alliance_memo_req.S,
  MSGTYPE901 = NetAPIList.ladder_report_ack.S,
  MSGTYPE898 = NetAPIList.max_step_req.S,
  MSGTYPE896 = NetAPIList.refresh_type_ack.S,
  MSGTYPE647 = NetAPIList.get_my_support_ack.S,
  MSGTYPE465 = NetAPIList.alliance_domination_ntf.S,
  MSGTYPE894 = NetAPIList.prime_push_show_round_req.S,
  MSGTYPE893 = NetAPIList.client_login_ok_req.S,
  MSGTYPE548 = NetAPIList.ladder_rank_req.S,
  MSGTYPE880 = NetAPIList.prime_jump_price_req.S,
  MSGTYPE874 = NetAPIList.cutoff_info_ack.S,
  MSGTYPE366 = NetAPIList.active_gifts_ntf.S,
  MSGTYPE980 = NetAPIList.enter_monthly_req.S,
  MSGTYPE871 = NetAPIList.goal_info_ack.S,
  MSGTYPE984 = NetAPIList.view_award_req.S,
  MSGTYPE594 = NetAPIList.award_get_req.S,
  MSGTYPE867 = NetAPIList.daily_benefits_award_req.S,
  MSGTYPE1356 = NetAPIList.krypton_redpoint_req.S,
  MSGTYPE167 = NetAPIList.champion_reset_cd_ack.S,
  MSGTYPE865 = NetAPIList.daily_benefits_req.S,
  MSGTYPE864 = NetAPIList.pay_status_ntf.S,
  MSGTYPE580 = NetAPIList.mulmatrix_buy_req.S,
  MSGTYPE845 = NetAPIList.open_server_fund_award_req.S,
  MSGTYPE860 = NetAPIList.enhance_info_ack.S,
  MSGTYPE856 = NetAPIList.prime_round_fight_ntf.S,
  MSGTYPE1302 = NetAPIList.team_fight_report_req.S,
  MSGTYPE849 = NetAPIList.vip_level_ntf.S,
  MSGTYPE847 = NetAPIList.all_welfare_ack.S,
  MSGTYPE842 = NetAPIList.open_server_fund_req.S,
  MSGTYPE622 = NetAPIList.crusade_buy_cross_req.S,
  MSGTYPE839 = NetAPIList.pay_sign_reward_req.S,
  MSGTYPE837 = NetAPIList.pay_sign_req.S,
  MSGTYPE831 = NetAPIList.levelup_unlock_ntf.S,
  MSGTYPE829 = NetAPIList.krypton_sort_ack.S,
  MSGTYPE621 = NetAPIList.crusade_reward_ack.S,
  MSGTYPE823 = NetAPIList.prime_last_report_req.S,
  MSGTYPE800 = NetAPIList.prime_map_req.S,
  MSGTYPE822 = NetAPIList.prime_fight_report_req.S,
  MSGTYPE819 = NetAPIList.prime_increase_power_info_ack.S,
  MSGTYPE817 = NetAPIList.revive_self_req.S,
  MSGTYPE812 = NetAPIList.prime_fight_history_req.S,
  MSGTYPE50 = NetAPIList.officer_buy_ack.S,
  MSGTYPE543 = NetAPIList.ladder_gain_req.S,
  MSGTYPE810 = NetAPIList.prime_march_req.S,
  MSGTYPE808 = NetAPIList.prime_dot_status_ntf.S,
  MSGTYPE384 = NetAPIList.timelimit_hero_id_req.S,
  MSGTYPE804 = NetAPIList.prime_jump_req.S,
  MSGTYPE803 = NetAPIList.prime_active_ntf.S,
  MSGTYPE801 = NetAPIList.prime_map_ack.S,
  MSGTYPE748 = NetAPIList.user_info_ack.S,
  MSGTYPE532 = NetAPIList.dungeon_open_req.S,
  MSGTYPE744 = NetAPIList.krypton_inject_list_ack.S,
  MSGTYPE739 = NetAPIList.krypton_refine_info_req.S,
  MSGTYPE346 = NetAPIList.block_devil_req.S,
  MSGTYPE944 = NetAPIList.plante_explore_req.S,
  MSGTYPE135 = NetAPIList.alliance_info_req.S,
  MSGTYPE169 = NetAPIList.champion_get_award_ack.S,
  MSGTYPE407 = NetAPIList.chat_history_async_req.S,
  MSGTYPE736 = NetAPIList.krypton_refine_ack.S,
  MSGTYPE115 = NetAPIList.message_del_req.S,
  MSGTYPE729 = NetAPIList.open_treasure_box_ack.S,
  MSGTYPE728 = NetAPIList.open_treasure_box_req.S,
  MSGTYPE726 = NetAPIList.invite_friends_req.S,
  MSGTYPE725 = NetAPIList.treasure_info_ntf.S,
  MSGTYPE713 = NetAPIList.facebook_friends_ack.S,
  MSGTYPE1200 = NetAPIList.mining_reward_ntf.S,
  MSGTYPE712 = NetAPIList.facebook_friends_req.S,
  MSGTYPE707 = NetAPIList.give_friends_gift_ack.S,
  MSGTYPE450 = NetAPIList.fleet_info_req.S,
  MSGTYPE61 = NetAPIList.friends_ack.S,
  MSGTYPE503 = NetAPIList.contention_revive_req.S,
  MSGTYPE220 = NetAPIList.achievement_list_ack.S,
  MSGTYPE691 = NetAPIList.version_code_ntf.S,
  MSGTYPE34 = NetAPIList.techniques_req.S,
  MSGTYPE131 = NetAPIList.alliance_apply_ack.S,
  MSGTYPE105 = NetAPIList.user_offline_info_req.S,
  MSGTYPE1508 = NetAPIList.large_map_route_ack.S,
  MSGTYPE350 = NetAPIList.donate_info_req.S,
  MSGTYPE620 = NetAPIList.crusade_reward_req.S,
  MSGTYPE702 = NetAPIList.remodel_help_ntf.S,
  MSGTYPE698 = NetAPIList.remodel_help_others_req.S,
  MSGTYPE697 = NetAPIList.remodel_help_req.S,
  MSGTYPE696 = NetAPIList.remodel_levelup_req.S,
  MSGTYPE690 = NetAPIList.apply_limit_update_req.S,
  MSGTYPE689 = NetAPIList.client_version_ntf.S,
  MSGTYPE1193 = NetAPIList.mining_wars_collect_req.S,
  MSGTYPE434 = NetAPIList.activity_stores_buy_req.S,
  MSGTYPE573 = NetAPIList.user_notifies_req.S,
  MSGTYPE332 = NetAPIList.ac_energy_charge_req.S,
  MSGTYPE355 = NetAPIList.champion_top_record_ack.S,
  MSGTYPE673 = NetAPIList.release_adjutant_req.S,
  MSGTYPE934 = NetAPIList.tactical_enter_refine_req.S,
  MSGTYPE670 = NetAPIList.champion_matrix_req.S,
  MSGTYPE662 = NetAPIList.stores_refresh_req.S,
  MSGTYPE652 = NetAPIList.get_promotion_reward_req.S,
  MSGTYPE649 = NetAPIList.get_budo_rank_ack.S,
  MSGTYPE584 = NetAPIList.equip_info_req.S,
  MSGTYPE636 = NetAPIList.budo_join_ack.S,
  MSGTYPE1164 = NetAPIList.recruit_look_req.S,
  MSGTYPE643 = NetAPIList.support_one_player_req.S,
  MSGTYPE640 = NetAPIList.budo_promotion_req.S,
  MSGTYPE42 = NetAPIList.revenue_do_req.S,
  MSGTYPE630 = NetAPIList.contention_missiles_ntf.S,
  MSGTYPE637 = NetAPIList.budo_mass_election_ntf.S,
  MSGTYPE197 = NetAPIList.krypton_fleet_equip_req.S,
  MSGTYPE1260 = NetAPIList.choosable_item_ack.S,
  MSGTYPE627 = NetAPIList.dna_gacha_ntf.S,
  MSGTYPE625 = NetAPIList.crusade_first_ack.S,
  MSGTYPE703 = NetAPIList.remodel_push_ntf.S,
  MSGTYPE614 = NetAPIList.crusade_enter_ack.S,
  MSGTYPE613 = NetAPIList.crusade_enter_req.S,
  MSGTYPE611 = NetAPIList.activity_dna_charge_req.S,
  MSGTYPE608 = NetAPIList.enchant_ack.S,
  MSGTYPE342 = NetAPIList.alliance_weekend_award_req.S,
  MSGTYPE586 = NetAPIList.mycard_error_ntf.S,
  MSGTYPE405 = NetAPIList.equipment_action_list_ack.S,
  MSGTYPE578 = NetAPIList.mulmatrix_get_ack.S,
  MSGTYPE570 = NetAPIList.pay_confirm_req.S,
  MSGTYPE560 = NetAPIList.fleet_show_ack.S,
  MSGTYPE948 = NetAPIList.show_price_ntf.S,
  MSGTYPE266 = NetAPIList.update_spell_ntf.S,
  MSGTYPE551 = NetAPIList.ladder_special_ack.S,
  MSGTYPE544 = NetAPIList.ladder_buy_search_req.S,
  MSGTYPE304 = NetAPIList.mine_complete_ntf.S,
  MSGTYPE534 = NetAPIList.dungeon_enter_req.S,
  MSGTYPE747 = NetAPIList.user_info_req.S,
  MSGTYPE1374 = NetAPIList.medal_decompose_confirm_req.S,
  MSGTYPE513 = NetAPIList.contention_battle_ntf.S,
  MSGTYPE512 = NetAPIList.activity_task_list_ntf.S,
  MSGTYPE510 = NetAPIList.activity_task_list_ack.S,
  MSGTYPE508 = NetAPIList.domination_buffer_of_rank_ntf.S,
  MSGTYPE505 = NetAPIList.contention_stop_ack.S,
  MSGTYPE504 = NetAPIList.contention_stop_req.S,
  MSGTYPE706 = NetAPIList.remodel_event_ntf.S,
  MSGTYPE500 = NetAPIList.contention_trip_ntf.S,
  MSGTYPE499 = NetAPIList.contention_info_ntf.S,
  MSGTYPE498 = NetAPIList.contention_notifies_req.S,
  MSGTYPE495 = NetAPIList.set_game_local_req.S,
  MSGTYPE953 = NetAPIList.can_enhance_ack.S,
  MSGTYPE457 = NetAPIList.items_ack.S,
  MSGTYPE486 = NetAPIList.wd_ranking_champion_ntf.S,
  MSGTYPE333 = NetAPIList.ac_energy_charge_ack.S,
  MSGTYPE100 = NetAPIList.shop_sell_ack.S,
  MSGTYPE480 = NetAPIList.alliance_domination_total_rank_ntf.S,
  MSGTYPE477 = NetAPIList.wd_star_ack.S,
  MSGTYPE475 = NetAPIList.alliance_defence_revive_req.S,
  MSGTYPE201 = NetAPIList.user_brief_info_ack.S,
  MSGTYPE932 = NetAPIList.tactical_unlock_slot_req.S,
  MSGTYPE462 = NetAPIList.taobao_trade_req.S,
  MSGTYPE418 = NetAPIList.colony_info_ntf.S,
  MSGTYPE319 = NetAPIList.laba_info_req.S,
  MSGTYPE458 = NetAPIList.client_effect_req.S,
  MSGTYPE487 = NetAPIList.open_box_info_req.S,
  MSGTYPE280 = NetAPIList.quest_req.S,
  MSGTYPE298 = NetAPIList.mine_boost_req.S,
  MSGTYPE489 = NetAPIList.open_box_open_req.S,
  MSGTYPE441 = NetAPIList.prestige_get_req.S,
  MSGTYPE431 = NetAPIList.colony_fawn_ack.S,
  MSGTYPE428 = NetAPIList.colony_exploit_req.S,
  MSGTYPE426 = NetAPIList.colony_info_test_req.S,
  MSGTYPE425 = NetAPIList.colony_challenge_ack.S,
  MSGTYPE420 = NetAPIList.colony_times_ntf.S,
  MSGTYPE179 = NetAPIList.krypton_store_swap_req.S,
  MSGTYPE411 = NetAPIList.festival_ack.S,
  MSGTYPE583 = NetAPIList.mulmatrix_price_ack.S,
  MSGTYPE1311 = NetAPIList.fair_arena_reward_get_req.S,
  MSGTYPE400 = NetAPIList.stores_req.S,
  MSGTYPE391 = NetAPIList.cut_off_list_ack.S,
  MSGTYPE242 = NetAPIList.passport_bind_req.S,
  MSGTYPE380 = NetAPIList.clean_world_boss_cd_req.S,
  MSGTYPE372 = NetAPIList.promotion_award_ack.S,
  MSGTYPE994 = NetAPIList.today_task_ntf.S,
  MSGTYPE680 = NetAPIList.fleet_dismiss_ack.S,
  MSGTYPE353 = NetAPIList.login_first_ntf.S,
  MSGTYPE113 = NetAPIList.messages_req.S,
  MSGTYPE1 = NetAPIList.user_register_req.S,
  MSGTYPE599 = NetAPIList.contention_mission_award_req.S,
  MSGTYPE337 = NetAPIList.gateway_info_ntf.S,
  MSGTYPE335 = NetAPIList.ac_battle_info_req.S,
  MSGTYPE322 = NetAPIList.center_ntf.S,
  MSGTYPE316 = NetAPIList.laba_req.S,
  MSGTYPE315 = NetAPIList.guide_progress_ntf.S,
  MSGTYPE283 = NetAPIList.adventure_map_status_req.S,
  MSGTYPE274 = NetAPIList.all_act_status_ack.S,
  MSGTYPE852 = NetAPIList.pay_push_pop_set_req.S,
  MSGTYPE1194 = NetAPIList.mining_wars_collect_ack.S,
  MSGTYPE246 = NetAPIList.act_status_ack.S,
  MSGTYPE1285 = NetAPIList.forces_ack.S,
  MSGTYPE1134 = NetAPIList.enter_dice_req.S,
  MSGTYPE215 = NetAPIList.prestige_info_ack.S,
  MSGTYPE268 = NetAPIList.pve_awards_get_req.S,
  MSGTYPE198 = NetAPIList.user_fight_history_req.S,
  MSGTYPE417 = NetAPIList.game_addtion_req.S,
  MSGTYPE97 = NetAPIList.shop_purchase_req.S,
  MSGTYPE68 = NetAPIList.friend_search_ack.S
}
function NetAPIList:getDataStructFromMsgType(msgType)
  return self.CodeToMsgType[msgType]
end
