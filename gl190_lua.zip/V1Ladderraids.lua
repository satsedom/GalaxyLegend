local raids = GameData.Ladder.raids
table.insert(raids, {
  level = 1,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 2,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 3,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 4,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 5,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 6,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 7,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 8,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 9,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 10,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 11,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 12,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 13,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 14,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 15,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 16,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 17,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 18,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 19,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 20,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 21,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 22,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 23,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 24,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 25,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 26,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 27,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 28,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 29,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 30,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 31,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 32,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 33,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 34,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 35,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 36,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 37,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 38,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 39,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 40,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 41,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 42,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 43,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 44,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 45,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 46,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 47,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 48,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 49,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 50,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 51,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 52,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 53,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 54,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 55,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 56,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 57,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 58,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 59,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 60,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 61,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 62,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 63,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 64,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 65,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 66,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 67,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 68,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 69,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 70,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 71,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 72,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 73,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 74,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 75,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 76,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 77,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 78,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 79,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 80,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 81,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 82,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 83,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 84,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 85,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 86,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 87,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 88,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 89,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 90,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 91,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 92,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 93,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 94,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 95,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 96,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 97,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 98,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 99,
  reset = 20,
  raids = 5
})
table.insert(raids, {
  level = 100,
  reset = 20,
  raids = 5
})
