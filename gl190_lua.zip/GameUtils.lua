GameUtils = {
  DOUBLE_CLICK_TIMER = 200,
  lastRequestRecord = {url = "", statusCode = 0}
}
GameUtils.curFacebookInfo = {}
function GameUtils:RequestTranslateInfo()
  NetMessageMgr:SendMsg(NetAPIList.translate_info_req.Code, null, self.RequestTranslateInfoCallback, false, nil)
end
function GameUtils:isIDNumberCorrect(id)
  if id == nil then
    return false
  end
  local weight = {
    [1] = 7,
    [2] = 9,
    [3] = 10,
    [4] = 5,
    [5] = 8,
    [6] = 4,
    [7] = 2,
    [8] = 1,
    [9] = 6,
    [10] = 3,
    [11] = 7,
    [12] = 9,
    [13] = 10,
    [14] = 5,
    [15] = 8,
    [16] = 4,
    [17] = 2
  }
  local comp = {
    [1] = "1",
    [2] = "0",
    [3] = "X",
    [4] = "9",
    [5] = "8",
    [6] = "7",
    [7] = "6",
    [8] = "5",
    [9] = "4",
    [10] = "3",
    [11] = "2"
  }
  if string.len(id) ~= 18 then
    return false
  else
    local sum = 0
    local res = {}
    for i = 1, 18 do
      local txt = string.sub(id, i, i)
      if string.byte(txt) > 128 then
        return false
      end
      local num = tonumber(txt)
      if num == nil and i ~= 18 then
        return false
      end
      if i == 18 and num == nil and txt ~= "X" and txt ~= "x" then
        return false
      end
      table.insert(res, txt)
    end
    if tonumber(res[7] .. res[8]) < 19 then
      return false
    end
    if 12 < tonumber(res[11] .. res[12]) or tonumber(res[11] .. res[12]) == 0 then
      return false
    end
    if tonumber(res[13] .. res[14]) > 31 or tonumber(res[13] .. res[14]) == 0 then
      return false
    end
    for i = 1, 17 do
      sum = tonumber(res[i]) * weight[i] + sum
    end
    local mod = sum % 11
    if comp[mod + 1] == string.upper(res[18]) then
      return true
    else
      return false
    end
  end
end
function GameUtils:isOlderThan18(id)
  if id and id ~= "" then
    local currentYear = os.date("%Y")
    local currentMonth = os.date("%m")
    local currentDay = os.date("%d")
    local birthYear = string.sub(id, 7, 10)
    local birthMonth = string.sub(id, 11, 12)
    local birthDay = string.sub(id, 13, 14)
    DebugOut("id:", id, "currentYear", currentYear, "currentMonth", currentMonth, "currentDay", currentDay)
    if tonumber(currentYear) - tonumber(birthYear) < 18 then
      return false
    elseif tonumber(currentYear) - tonumber(birthYear) == 18 then
      if tonumber(currentMonth) < tonumber(birthMonth) then
        return false
      elseif tonumber(currentMonth) == tonumber(birthMonth) then
        if tonumber(currentDay) < tonumber(birthDay) then
          return false
        else
          return true
        end
      else
        return true
      end
    else
      return true
    end
  end
  return true
end
function GameUtils:isNameCorrect(name)
  if name == nil then
    return false
  end
  if string.len(name) < 6 then
    return false
  else
    local lenInByte = #name
    for i = 1, lenInByte, 3 do
      local firstb = string.byte(name, i)
      local secondb = string.byte(name, i + 1)
      local thirdb = string.byte(name, i + 2)
      if firstb < 228 or firstb > 233 then
        return false
      end
      if secondb < 128 or secondb > 191 then
        return false
      end
      if thirdb < 128 or thirdb > 191 then
        return false
      end
    end
    return true
  end
end
function GameUtils:isPlayerMaxLevel(nowLevel)
  if nowLevel < 110 then
    return false
  else
    return true
  end
end
function GameUtils.RequestTranslateInfoCallback(msgType, content)
  if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.translate_info_req.Code then
    assert(content.code ~= 0)
    local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
    GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    return true
  end
  if msgType == NetAPIList.translate_info_ack.Code then
    local platformToken = content.token
    local platformUrl = content.url
    if platformUrl == nil then
      platformUrl = ""
    end
    DebugOut("RequestTranslateInfoCallback")
    DebugTable(content)
    GameUtils:InitTranstale(platformToken, platformUrl)
    return true
  end
  return false
end
function GameUtils:InitTranstale(platformToken, platformUrl)
  GameUtils.mTranslation = GetTranslation()
  local appId = "20151123000006216"
  local key = "FgGYFJU9e7oqd6lZH3Cg"
  local token = ""
  local statUrl = ""
  local ret1 = 0
  local ret2 = ""
  if ext.GetDeviceInfo then
    ret1, ret2 = ext.GetDeviceInfo()
  end
  local udid = ret2
  local abroadMode = true
  if self:IsChinese() then
    abroadMode = false
  end
  GameUtils.mTranslation:setConfig(appId, key, platformToken, platformUrl, token, statUrl, udid, abroadMode)
end
function GameUtils.EndSocialShare(success)
  DebugOut("EndSocialShare:")
  DebugOut(success)
end
function GameUtils.BeginSocialShare()
  DebugOut("BeginSocialShare")
end
function GameUtils:GetTimeChar(ti)
  local charMap = {
    en_Y = "Y",
    en_M = "M",
    en_d = "d",
    en_h = "h",
    en_m = "m",
    en_s = "s",
    en_ago = " ago",
    ru_Y = "\208\179",
    ru_M = "\208\188",
    ru_d = "\208\180",
    ru_h = "\209\135",
    ru_m = "\208\188",
    ru_s = "\209\129",
    ru_ago = " \208\189\208\176\208\183\208\176\208\180"
  }
  local lang = "en"
  if GameSettingData and GameSettingData.Save_Lang then
    lang = GameSettingData.Save_Lang
    if string.find(lang, "ru") == 1 then
      lang = "ru"
    else
      lang = "en"
    end
  end
  local key = lang .. "_" .. ti
  return charMap[key] or ti
end
function GameUtils:formatTimeStringAsPartion(time)
  local timeText = ""
  if time < 60 then
    return "<1" .. GameUtils:GetTimeChar("m")
  end
  if time >= 86400 then
    local count = math.floor(time / 86400)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("d"), tostring(count))
    time = time - count * 86400
    return timeText
  end
  hasHours = false
  if time >= 3600 then
    local count = math.floor(time / 3600)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("h"), tostring(count))
    time = time - count * 3600
    hasHours = true
  end
  if time >= 60 then
    local count = math.floor(time / 60)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("m"), tostring(count))
    time = time - count * 60
  end
  if hasHours then
    return timeText
  end
  if time > 0 then
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("s"), tostring(time))
  end
  return timeText
end
function GameUtils:formatTimeStringAsPartion2(time)
  local timeText = ""
  if time < 60 then
    return time .. GameUtils:GetTimeChar("s")
  end
  local haveDay = false
  if time >= 86400 then
    local count = math.floor(time / 86400)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("d"), tostring(count))
    time = time - count * 86400
    haveDay = true
    return timeText
  end
  local hasHours = false
  if time >= 3600 then
    local count = math.floor(time / 3600)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("h"), tostring(count))
    time = time - count * 3600
    hasHours = true
  end
  if haveDay then
    return timeText
  end
  if time >= 60 then
    local count = math.floor(time / 60)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("m"), tostring(count))
    time = time - count * 60
  end
  if hasHours then
    return timeText
  end
  if time > 0 then
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("s"), tostring(time))
  end
  return timeText
end
function GameUtils:formatTimeStringAsTwitterStyle(time)
  local timeText = ""
  if time < 60 then
    return "<1" .. GameUtils:GetTimeChar("m")
  end
  if time >= 86400 then
    local count = math.floor(time / 86400)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("d"), tostring(count))
    time = time - count * 86400
  end
  if time >= 3600 then
    local count = math.floor(time / 3600)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("h"), tostring(count))
    time = time - count * 3600
  end
  if time >= 60 then
    local count = math.floor(time / 60)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("m"), tostring(count))
    time = time - count * 60
  end
  if time > 0 then
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("s"), tostring(time))
  end
  return timeText
end
function GameUtils:formatTimeStringAsTwitterStyle2(time)
  local timeText = ""
  if time < 60 then
    return time
  end
  if time >= 86400 then
    local count = math.floor(time / 86400)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("d"), tostring(count))
    time = time - count * 86400
  end
  if time >= 3600 then
    local count = math.floor(time / 3600)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("h"), tostring(count))
    time = time - count * 3600
  end
  if time >= 60 then
    local count = math.floor(time / 60)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("m"), tostring(count))
    time = time - count * 60
  end
  if time > 0 then
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("s"), tostring(time))
  end
  return timeText
end
function GameUtils:formatTimeStringAsTwitterStyle3(time)
  local timeText = ""
  if time < 60 then
    return time .. GameUtils:GetTimeChar("s")
  end
  if time >= 86400 then
    local count = math.floor(time / 86400)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("d"), tostring(count))
    time = time - count * 86400
  end
  if time >= 3600 then
    local count = math.floor(time / 3600)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("h"), tostring(count))
    time = time - count * 3600
  end
  if time >= 60 then
    local count = math.floor(time / 60)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("m"), tostring(count))
    time = time - count * 60
  end
  if time > 0 then
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("s"), tostring(time))
  end
  return timeText
end
function GameUtils:formatTimeStringAsTwitterStyleWithOutSecond(time)
  local timeText = ""
  if time < 60 then
    return "<1" .. GameUtils:GetTimeChar("m")
  end
  if time >= 86400 then
    local count = math.floor(time / 86400)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("d"), tostring(count))
    time = time - count * 86400
  end
  if time >= 3600 then
    local count = math.floor(time / 3600)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("h"), tostring(count))
    time = time - count * 3600
  end
  if time >= 60 then
    local count = math.floor(time / 60)
    timeText = timeText .. string.format("%d" .. GameUtils:GetTimeChar("m"), tostring(count))
    time = time - count * 60
  end
  return timeText
end
function GameUtils:formatTimeStringAsAgoStyle(time)
  local timeText = ""
  if time >= 31536000 then
    local count = math.floor(time / 31536000)
    timeText = string.format("%d" .. GameUtils:GetTimeChar("Y"), tostring(count))
  elseif time >= 2592000 then
    local count = math.floor(time / 2592000)
    timeText = string.format("%d" .. GameUtils:GetTimeChar("M"), tostring(count))
  elseif time >= 86400 then
    local count = math.floor(time / 86400)
    timeText = string.format("%d" .. GameUtils:GetTimeChar("d"), tostring(count))
  elseif time >= 3600 then
    local count = math.floor(time / 3600)
    timeText = string.format("%d" .. GameUtils:GetTimeChar("h"), tostring(count))
  elseif time >= 60 then
    local count = math.floor(time / 60)
    timeText = string.format("%d" .. GameUtils:GetTimeChar("m"), tostring(count))
  elseif time > 0 then
    timeText = string.format("%d" .. GameUtils:GetTimeChar("s"), tostring(time))
  else
    timeText = string.format("%d" .. GameUtils:GetTimeChar("s"), tostring(time))
  end
  return timeText .. GameUtils:GetTimeChar("ago")
end
function GameUtils:formatTimeStringWithoutSeconds(time)
  time = time / 60
  local minutes = time % 60
  time = time / 60
  local hours = time
  return string.format("%02d:%02d", hours, minutes)
end
function GameUtils:formatTimeStringWithoutHour(time)
  local seconds = time % 60
  time = time / 60
  local minutes = time % 60
  time = time / 60
  local hours = time
  return string.format("%02d:%02d", minutes, seconds)
end
function GameUtils:formatTimeStringByMinutes(timeMinutes)
  local minutes = timeMinutes % 60
  local hours = timeMinutes / 60
  return string.format("%02d:%02d", hours, minutes)
end
function GameUtils:formatTimeString(time)
  if time < 0 then
    return ""
  end
  local seconds = time % 60
  time = time / 60
  local minutes = time % 60
  time = time / 60
  local hours = time
  return string.format("%02d:%02d:%02d", hours, minutes, seconds)
end
function GameUtils:formatTimeToDateStr(time)
  return os.date("%m-%d %H:%M", time)
end
function GameUtils:formatTimeToDate(time)
  return os.date("%y-%m-%d", time)
end
function GameUtils:SetHTTPPostData(data, dataType)
  self._httpData = data
  self._httpDataType = dataType
end
function GameUtils:GetShortActivityID(itemid)
  local itemId = tostring(itemid)
  if string.len(itemId) > 10 then
    itemId = string.sub(itemId, -10)
  end
  return tonumber(itemId)
end
function GameUtils:HTTP_SendRequest(requestType, requestParam, responseFunc, isNeedLoading, responseErrFunc, httpMethod, requestMode)
  local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
  DebugOut("-------------------HTTP_REQUEST-----------------", requestType)
  if isNeedLoading then
    local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
    GameWaiting:ShowLoadingScreen()
  end
  httpMethod = httpMethod or "GET"
  requestMode = requestMode or "normal"
  assert(requestMode ~= "notencrypt" or string.lower(httpMethod) ~= "post")
  local loginInfo = GameUtils:GetLoginInfo()
  DebugOut("ajksdjaksdkjjkaskd")
  DebugTable(loginInfo)
  DebugOut(requestType)
  local outList = {
    ["gamers/servers_v2"] = false,
    ["gamers/register"] = false,
    ["gamers/udid_v2"] = false,
    ["gamers/validate"] = false
  }
  local url = ""
  if GameUtils._httpServer ~= nil then
    url = GameUtils._httpServer .. requestType
  else
    url = AutoUpdate.gameGateway .. requestType
  end
  DebugOut("url ", url)
  local header = {}
  if GameUtils._httpHeader ~= nil then
    header = GameUtils._httpHeader
  end
  if GameUtils._httpServer == nil and loginInfo and loginInfo.ServerInfo and outList[requestType] == nil then
    header.logic_id = loginInfo.ServerInfo.logic_id
  end
  DebugOutPutTable(header, "header")
  if httpMethod == "POST" then
    if GameUtils._httpData == "" or GameUtils._httpData == nil then
      DebugOut("warning: no body data")
    end
    DebugOut("GameUtils._httpData", GameUtils._httpData)
    DebugOut("requestMode", requestMode)
    DebugOut("GameUtils._httpDataType", GameUtils._httpDataType)
  end
  local attpTime = os.time()
  ext.http.request({
    url,
    param = requestParam,
    mode = requestMode,
    header = header,
    method = httpMethod,
    body = GameUtils._httpData,
    contentType = GameUtils._httpDataType,
    callback = function(statusCode, responseContent, errstr)
      GameUtils.lastRequestRecord.url = url or GameUtils.lastRequestRecord.url
      GameUtils.lastRequestRecord.statusCode = statusCode or GameUtils.lastRequestRecord.statusCode
      DebugOut("---------------NOW CALL BACK HTTP------------")
      if type(responseContent) == "table" then
        DebugOutPutTable(responseContent, "responseContent")
      end
      if isNeedLoading then
        local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
        GameWaiting:HideLoadingScreen()
        DebugOut(string.format("%s msg send-receive used time:%d", url, os.time() - attpTime))
      end
      DebugOut("NOW STATUS CODE::" .. statusCode .. tostring(responseContent))
      if errstr ~= nil or statusCode ~= 200 then
        if responseErrFunc then
          responseErrFunc(statusCode, responseContent)
        end
        if errstr and errstr ~= "" then
          GameUtils:ShowTips(errstr)
        end
        return
      elseif responseFunc then
        responseFunc(responseContent)
      end
    end
  })
  GameUtils._httpData = nil
  GameUtils._httpDataType = nil
  GameUtils._httpServer = nil
  GameUtils._httpHeader = nil
end
function GameUtils:HTTP_SendBaseRequest(requestType, requestParam, responseFunc, isNeedLoading, responseErrFunc, httpMethod, requestMode)
  local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
  DebugOut("-------------------HTTP_REQUEST-----------------", requestType)
  if isNeedLoading then
    local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
    GameWaiting:ShowLoadingScreen()
  end
  httpMethod = httpMethod or "GET"
  requestMode = requestMode or "normal"
  local outList = {
    ["gamers/servers_v2"] = false,
    ["gamers/register"] = false,
    ["gamers/udid_v2"] = false,
    ["gamers/validate"] = false
  }
  local url = ""
  if GameUtils._httpServer ~= nil then
    url = GameUtils._httpServer .. requestType
  else
    url = AutoUpdate.gameGateway .. requestType
  end
  DebugOut("url ", url)
  local header = {}
  if GameUtils._httpHeader ~= nil then
    header = GameUtils._httpHeader
    DebugOutPutTable(header, "header")
  end
  if GameUtils._httpServer == nil and loginInfo and loginInfo.ServerInfo and outList[requestType] == nil then
    header.logic_id = loginInfo.ServerInfo.logic_id
  end
  if httpMethod == "POST" then
    if GameUtils._httpData == "" or GameUtils._httpData == nil then
      DebugOut("warning: no body data")
    end
    DebugOut("GameUtils._httpData", GameUtils._httpData)
    DebugOut("requestMode", requestMode)
    DebugOut("GameUtils._httpDataType", GameUtils._httpDataType)
  end
  ext.http.requestBasic({
    url,
    param = requestParam,
    mode = requestMode,
    header = header,
    method = httpMethod,
    body = GameUtils._httpData,
    contentType = GameUtils._httpDataType,
    callback = function(statusCode, responseContent, errstr)
      DebugOut("---------------NOW CALL BACK HTTP------------")
      if type(responseContent) == "table" then
        DebugOutPutTable(responseContent, "responseContent")
      end
      if isNeedLoading then
        local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
        GameWaiting:HideLoadingScreen()
      end
      DebugOut("NOW STATUS CODE::" .. statusCode)
      if errstr ~= nil or statusCode ~= 200 then
        responseErrFunc(statusCode, responseContent)
        return
      else
        responseFunc(responseContent)
      end
    end
  })
  GameUtils._httpData = nil
  GameUtils._httpDataType = nil
  GameUtils._httpServer = nil
  GameUtils._httpHeader = nil
end
function GameUtils:SetHTTPServer(server_ip)
  GameUtils._httpServer = server_ip
end
function GameUtils:SetHTTPHeader(header)
  GameUtils._httpHeader = header
end
function GameUtils.httpRequestFailedCallback(status_code, content)
  local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
  local serverName = " "
  if GameUtils:GetActiveServerInfo() then
    serverName = serverName .. GameUtils:GetActiveServerInfo().name or GameUtils:GetActiveServerInfo().id or ""
  end
  local errorText = GameLoader:GetGameText("LC_MENU_CONNECT_ERROR") .. serverName
  local GameSetting = LuaObjectManager:GetLuaObject("GameSetting")
  GameSetting:showContactUsDialogForNetError(GameLoader:GetGameText("LC_MENU_ERROR_TITLE"), errorText)
end
function GameUtils:Tap4funAccountRegister(tap4fun_account, successCallback)
  local data = {
    passport = tap4fun_account.passport,
    password = ext.ENC1(tap4fun_account.password)
  }
  GameUtils:SetHTTPPostData(ext.json.generate(data), nil)
  GameUtils:HTTP_SendRequest("gamers/register", nil, successCallback, true, GameUtils.httpRequestFailedCallback, "POST")
end
function GameUtils:Tap4funModifyPassword(tap4fun_account, newPassword, successCallback)
  DebugOut("GameUtils:Tap4funModifyPassword")
  assert(tap4fun_account)
  assert(newPassword)
  local httpheader = {
    AccessToken = "A6E56CD1-B178-8B82-E6E0-02DCF13D7A25"
  }
  GameUtils._httpData = "passport=" .. tap4fun_account.passport .. "&old_password=" .. ext.ENC1(tap4fun_account.password) .. "&new_password=" .. ext.ENC1(newPassword)
  GameUtils:SetHTTPHeader(httpheader)
  GameUtils:SetHTTPServer("https://ucenter.pf.tap4fun.com/")
  GameUtils:HTTP_SendBaseRequest("users/outside_update_password?" .. GameUtils._httpData, nil, successCallback, true, GameUtils.httpRequestFailedCallback, "GET", "notencrypt")
end
function GameUtils:Tap4funAccountValidate(tap4fun_account, successCallback)
  local data = {
    passport = tap4fun_account.passport,
    password = ext.ENC1(tap4fun_account.password),
    acc_type = GameUtils.AccountType.mail
  }
  GameUtils:SetHTTPPostData(ext.json.generate(data), nil)
  GameUtils:HTTP_SendRequest("gamers/validate", nil, successCallback, true, GameUtils.httpRequestFailedCallback, "POST")
end
function GameUtils:QihooAccountValidate(qihoo_account, successCallback)
  local data = {
    passport = qihoo_account.passport,
    password = qihoo_account.password,
    acc_type = GameUtils.AccountType.qihoo
  }
  GameUtils:SetHTTPPostData(ext.json.generate(data), nil)
  GameUtils:HTTP_SendRequest("gamers/validate", nil, successCallback, true, GameUtils.httpRequestFailedCallback, "POST")
end
function GameUtils:FacebookAccountValidate(facebook_account, successCallback, failedCallback)
  local data = {
    passport = facebook_account.passport,
    password = facebook_account.password,
    acc_type = GameUtils.AccountType.facebook
  }
  if nil == failedCallback then
    failedCallback = GameUtils.httpRequestFailedCallback
  end
  GameUtils:SetHTTPPostData(ext.json.generate(data), nil)
  GameUtils:HTTP_SendRequest("gamers/validate", nil, successCallback, true, failedCallback, "POST")
end
function GameUtils:PlatformExtAccountValidate(Ext_account_info_json, successCallback)
  local data = ext.json.parse(Ext_account_info_json)
  data.acc_type = tonumber(IPlatformExt.getConfigValue("AccType"))
  GameUtils:SetHTTPPostData(ext.json.generate(data), nil)
  GameUtils:HTTP_SendRequest("gamers/validate", nil, successCallback, true, GameUtils.httpRequestFailedCallback, "POST")
end
function GameUtils:GetLogSeverLogicID()
  local LoginInfo = self:GetLoginInfo()
  return LoginInfo.ServerInfo.logic_id
end
function GameUtils:Tap4funAccountBind(tap4fun_account, BindPlayerName, successCallback, failedCallback)
  assert(tap4fun_account)
  local device_info = {}
  device_info.udid = ext.GetIOSOpenUdid()
  device_info.mac_addr = ext.GetIOSMacAddress()
  device_info.open_udid = ext.GetIOSOpenUdid()
  device_info.game_id = GameUtils:GetLogSeverLogicID()
  local bind_data = {
    gamer = {
      passport = tap4fun_account.passport,
      password = ext.ENC1(tap4fun_account.password),
      acc_type = GameUtils.AccountType.mail
    },
    device = device_info
  }
  bind_data.role = BindPlayerName
  DebugOutPutTable(bind_data, "bindData")
  bind_data = ext.json.generate(bind_data)
  GameUtils:SetHTTPPostData(bind_data, nil)
  if nil == failedCallback then
    failedCallback = GameUtils.httpRequestFailedCallback
  end
  GameUtils:HTTP_SendRequest("gamers/bind_role", nil, successCallback, true, failedCallback, "POST")
end
function GameUtils:FacebookAccountBind(loginType, facebook_account, BindPlayerName, successCallback)
  assert(facebook_account)
  local device_info = {}
  device_info.udid = ext.GetIOSOpenUdid()
  device_info.mac_addr = ext.GetIOSMacAddress()
  device_info.open_udid = ext.GetIOSOpenUdid()
  device_info.game_id = GameUtils:GetLogSeverLogicID()
  local AccountType
  if loginType == GameUtils.AccountType.facebook then
    AccountType = GameUtils.AccountType.facebook
  elseif loginType == GameUtils.AccountType.tango then
    AccountType = GameUtils.AccountType.tango
  end
  local bind_data = {
    gamer = {
      passport = facebook_account.passport,
      password = facebook_account.password,
      acc_type = AccountType
    },
    device = device_info
  }
  bind_data.role = BindPlayerName
  DebugOutPutTable(bind_data, "bindData")
  bind_data = ext.json.generate(bind_data)
  GameUtils:SetHTTPPostData(bind_data, nil)
  GameUtils:HTTP_SendRequest("gamers/bind_role", nil, successCallback, true, GameUtils.httpRequestFailedCallback, "POST")
end
function GameUtils:UpdateServerList(SuccessCallback, AccountTable)
  local function successCallback(content)
    if ext.addFlurryEvent then
      ext.addFlurryEvent("FetchLastLoginListResultSuccessed", {FetchLastLoginListResult = "Successed"})
    end
    if SuccessCallback then
      SuccessCallback(content)
    end
  end
  local httpRequestInfo = GameLoader:GetGameText("LC_ALERT_HTTP_FAILED")
  local function failedCallback(statusCode)
    local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
    local serverName = " "
    if GameUtils:GetActiveServerInfoHook() then
      serverName = serverName .. GameUtils:GetActiveServerInfoHook().name or GameUtils:GetActiveServerInfoHook().id or ""
    end
    local extra_error = "Error:1_" .. 5 .. "_" .. statusCode
    local errorText = GameLoader:GetGameText("LC_ALERT_HTTP_FAILED") .. serverName .. extra_error
    local GameSetting = LuaObjectManager:GetLuaObject("GameSetting")
    GameSetting:showContactUsDialogForNetError("ERROR", errorText, function()
      GameUtils:UpdateServerList(SuccessCallback, tap4fun_account)
    end)
    if ext.addFlurryEvent then
      ext.addFlurryEvent("FetchLastLoginListResultFailed", {FetchLastLoginListResult = "Failed"})
    end
  end
  local httpdata = {}
  httpdata.passports = {}
  if AccountTable then
    httpdata.passports = AccountTable
  end
  DebugOutPutTable(httpdata, "httpdata")
  httpdata = ext.json.generate(httpdata)
  DebugOut(httpdata)
  GameUtils:SetHTTPPostData(httpdata, nil)
  GameUtils:HTTP_SendRequest("gamers/udid_v2", nil, successCallback, false, failedCallback, "POST")
  if ext.addFlurryEvent then
    ext.addFlurryEvent("FetchLastLoginListStarted", {FetchLastLoginListStarted = "Started"})
  end
end
function GameUtils:RequestAccountPlayerTable(AccountInfo, SuccessCallback, FailedCallback)
  if nil == AccountInfo then
    AccountInfo = {passort = "", password = ""}
  end
  assert(AccountInfo)
  local DataPacket = {}
  DataPacket.passport = AccountInfo.passport
  if IPlatformExt.getConfigValue("UseExtLogin") == "True" then
    local accInfoStr = GameUtils.IPlatformExtLoginInfo_json or GameUtils.IPlatformExtLastLoginInfo
    if accInfoStr then
      local accInfo = {}
      accInfo = ext.json.parse(accInfoStr)
      if accInfo then
        DataPacket.password = accInfo.password
        if IPlatformExt.getConfigValue("PlatformName") == "taptap" then
          DataPacket.passport = accInfo.passport
        end
      end
    end
    DataPacket.acc_type = tonumber(IPlatformExt.getConfigValue("AccType"))
  elseif GameUtils:IsFacebookAccount(AccountInfo) then
    DataPacket.password = AccountInfo.password
    DataPacket.acc_type = GameUtils.AccountType.facebook
  elseif GameUtils:IsLoginTangoAccount() then
    DataPacket.password = AccountInfo.password
    DataPacket.acc_type = GameUtils.AccountType.tango
  elseif AccountInfo.accType ~= GameUtils.AccountType.guest and GameUtils:IsMailAccount(AccountInfo) then
    DataPacket.password = ext.ENC1(AccountInfo.password)
    DataPacket.acc_type = GameUtils.AccountType.mail
  elseif GameUtils:IsQihooApp() then
    GameUtils:printByAndroid("GameUtils:IsQihooAccount(AccountInfo)")
    DataPacket.acc_type = GameUtils.AccountType.qihoo
    DataPacket.password = GameUtils.qihoo_token
    GameUtils:printByAndroid("DataPacket.passport: " .. DataPacket.passport .. "/ DataPacket.acc_type: " .. DataPacket.acc_type)
  else
    DataPacket.passport = ""
    DataPacket.password = ext.ENC1("")
    DataPacket.acc_type = GameUtils.AccountType.guest
  end
  DebugOutPutTable(DataPacket, "AccountData")
  DataPacket = ext.json.generate(DataPacket)
  GameUtils:SetHTTPPostData(DataPacket, nil)
  GameUtils:HTTP_SendRequest("gamers/passport_v2", nil, SuccessCallback, true, FailedCallback, "POST")
end
function GameUtils:GetAccountLocalData(AccountPassport, accType)
  if GameSettingData.PassportTable then
    local TargetAccount
    for _, AccountInfo in ipairs(GameSettingData.PassportTable) do
      if AccountInfo.passport == AccountPassport then
        if accType then
          local tmp = AccountInfo.accType or GameUtils.AccountType.mail
          if tmp == accType then
            TargetAccount = AccountInfo
            break
          end
        else
          TargetAccount = AccountInfo
          break
        end
      end
    end
    return TargetAccount
  end
  return nil
end
function GameUtils:AddAccountLocalData(AccountLocalData)
  if not GameSettingData.PassportTable then
    GameSettingData.PassportTable = {}
  end
  if IPlatformExt.getConfigValue("UseExtLogin") == "True" then
    GameSettingData.PassportTable = {}
    table.insert(GameSettingData.PassportTable, AccountLocalData)
    GameUtils:SaveSettingData()
    return
  end
  for _, AccountInfo in ipairs(GameSettingData.PassportTable) do
    if AccountInfo.passport == AccountLocalData.passport then
      AccountInfo.password = AccountLocalData.password
      GameUtils:SaveSettingData()
      return
    end
  end
  if GameUtils:IsQihooApp() then
    GameUtils:printByAndroid("\229\176\134qihoo\232\180\166\229\143\183\230\183\187\229\138\160\229\136\176GameSettingData.PassportTable[1]")
    GameSettingData.PassportTable[1] = AccountLocalData
    GameUtils:SaveSettingData()
  else
    table.insert(GameSettingData.PassportTable, AccountLocalData)
    DebugOutPutTable(GameSettingData.PassportTable, "AccountLocalTable")
    GameUtils:SaveSettingData()
  end
end
function GameUtils:RemoveAccountLocalData(passport)
  if GameSettingData.PassportTable then
    for IndexData, AccountInfo in ipairs(GameSettingData.PassportTable) do
      if AccountInfo.passport == passport then
        table.remove(GameSettingData.PassportTable, IndexData)
        break
      end
    end
    if GameSettingData.LastLogin and GameSettingData.LastLogin.AccountInfo and GameSettingData.LastLogin.AccountInfo.passport == passport then
      GameSettingData.LastLogin = nil
    end
    self:SaveSettingData()
  end
end
function GameUtils:SetServerListData(content)
  DebugTable(content)
  GameUtils.ServerAndAccountInfo = content
end
function GameUtils:GetServerInfoWithIP(server_ip)
  for _, v in ipairs(GameUtils.ServerAndAccountInfo.can_use_servers) do
    if v.ip == server_ip then
      return v
    end
  end
  return nil
end
function GameUtils:WriteUserName(text)
  if GameGlobalData:GetUserInfo() then
    text = string.gsub(text, "<player>", GameUtils:GetUserDisplayName(GameGlobalData:GetUserInfo().name))
    text = string.gsub(text, "<v_player>", GameUtils:GetUserDisplayName(GameUtils:GetAdjutantName()))
  end
  return text
end
function GameUtils:GetServerInfoWithID(server_id)
  for _, v in ipairs(GameUtils.ServerAndAccountInfo.server_list) do
    if v.logic_id == server_id then
      return v
    end
  end
  return nil
end
function GameUtils:GetActiveServerInfo()
  return self.LoginInfo.ServerInfo
end
function GameUtils:GetActiveServerInfoHook()
  if self.LoginInfo then
    return self.LoginInfo.ServerInfo
  end
  return nil
end
function GameUtils:SetLoginInfo(LoginInfo)
  if LoginInfo and LoginInfo.RegistAppId == nil then
    LoginInfo.RegistAppId = ""
  elseif LoginInfo and LoginInfo.isCreateActor == nil then
    LoginInfo.isCreateActor = 1
  end
  self.LoginInfo = LoginInfo
end
function GameUtils:GetLoginInfo()
  return self.LoginInfo
end
function GameUtils:CheckFirstEnter()
  local firstenter = true
  firstenter = firstenter and #self.ServerAndAccountInfo.passports_last == 0
  firstenter = firstenter and #self.ServerAndAccountInfo.passports == 0
  firstenter = firstenter and #self.ServerAndAccountInfo.udid_roles == 0
  return firstenter
end
function GameUtils.GetServerList()
  return GameUtils.ServerAndAccountInfo.can_use_servers
end
function GameUtils.numberAddCommaWithBackslash(numToConvert, backslash)
  local num = tonumber(numToConvert)
  if num and type(num) == "number" then
    local formatted = tostring(num)
    while true do
      if not backslash then
        formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", "%1,%2")
      else
        formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", "%1,%2")
      end
      if k == 0 then
        break
      end
    end
    return formatted
  else
    return numToConvert
  end
end
function GameUtils.numberAddComma(numToConvert)
  return GameUtils.numberAddCommaWithBackslash(numToConvert, false)
end
function GameUtils.numberConversion(num)
  local convertedNum
  if num >= 1000000000000 then
    convertedNum = string.format("%3dMM", num / 1000000000000)
  elseif num >= 100000000 then
    convertedNum = string.format("%3dM", num / 1000000)
  elseif num >= 10000000 and num < 100000000 then
    convertedNum = string.format("%.1fM", num / 1000000)
  elseif num >= 1000000 and num < 10000000 then
    convertedNum = string.format("%.1fM", num / 1000000)
  elseif num >= 100000 and num < 1000000 then
    convertedNum = string.format("%3dK", num / 1000)
  elseif num >= 10000 and num < 100000 then
    convertedNum = string.format("%.1fk", num / 1000)
  else
    convertedNum = string.format("%d", num)
  end
  if num > 0 and num < 1 then
    convertedNum = string.format("%.2f", num)
  end
  return convertedNum
end
function GameUtils.numberConversionEnglish(num)
  local convertedNum
  if num >= 1000000000000 then
    convertedNum = string.format("%.1fT", num / 1000000000000)
  elseif num >= 100000000000 then
    convertedNum = string.format("%3dB", num / 1000000000)
  elseif num >= 1000000000 then
    convertedNum = string.format("%.1fB", num / 1000000000)
  elseif num >= 100000000 then
    convertedNum = string.format("%3dM", num / 1000000)
  elseif num >= 10000000 and num < 100000000 then
    convertedNum = string.format("%.1fM", num / 1000000)
  elseif num >= 1000000 and num < 10000000 then
    convertedNum = string.format("%.1fM", num / 1000000)
  elseif num >= 100000 and num < 1000000 then
    convertedNum = string.format("%3dK", num / 1000)
  elseif num >= 10000 and num < 100000 then
    convertedNum = string.format("%.1fk", num / 1000)
  else
    convertedNum = string.format("%d", num)
  end
  return convertedNum
end
function GameUtils.numberConversion2(num, isNoLimited)
  DebugOut("numberConversion2", num)
  if isNoLimited then
    convertedNum = string.format("%.0f", num)
  elseif num >= 1.0E20 then
    local countM = 0
    while num >= 1.0E20 do
      countM = countM + 1
      num = num / 1000000
    end
    convertedNum = string.format("%.0f", num)
    while countM > 0 do
      countM = countM - 1
      convertedNum = convertedNum .. "M"
    end
  else
    convertedNum = string.format("%.0f", num)
  end
  return convertedNum
end
function GameUtils.numberConversion3(num, isNoLimited)
  local convertedNum
  if num >= 1000000000000 then
    convertedNum = string.format("%3dMM", num / 1000000000000)
  elseif num >= 100000000 then
    convertedNum = string.format("%3dM", num / 1000000)
  elseif num >= 10000000 and num < 100000000 then
    convertedNum = string.format("%.1fM", num / 1000000)
  else
    convertedNum = string.format("%d", num)
  end
  return convertedNum
end
function GameUtils.numberConversionFloat(num)
  local convertedNum
  if num >= 100000000 then
    convertedNum = string.format("%3dM", num / 1000000)
  elseif num >= 10000000 and num < 100000000 then
    convertedNum = string.format("%.1fM", num / 1000000)
  elseif num >= 1000000 and num < 10000000 then
    convertedNum = string.format("%.1fM", num / 1000000)
  elseif num >= 100000 and num < 1000000 then
    convertedNum = string.format("%3dK", num / 1000)
  elseif num >= 10000 and num < 100000 then
    convertedNum = string.format("%.1fk", num / 1000)
  elseif num > math.floor(num) then
    convertedNum = string.format("%.1f", num)
  else
    convertedNum = string.format("%d", num)
  end
  return convertedNum
end
function GameUtils:Warning(str)
  print(" Warning: " .. str)
end
function GameUtils:Error(str)
  print(" Error: " .. str)
end
function GameUtils:printTab(n)
  for i = 1, n do
    io.write("\t")
  end
end
function GameUtils:printValue(v, depth)
  if type(v) == "string" then
    io.write(string.format("%q", v))
  elseif type(v) == "number" then
    io.write(v)
  elseif type(v) == "boolean" then
    io.write(v and "true" or "false")
  elseif type(v) == "table" then
    GameUtils:printTable(v, depth)
  elseif type(v) == "userdata" then
    io.write("userdata")
  elseif type(v) == "function" then
    io.write("function")
  else
    self:Warning("invalid type " .. type(v))
  end
end
function GameUtils:printTable(t, depth)
  if t == nil then
    print("printTable: nil table")
    return
  end
  local depth = depth or 1
  if type(t) ~= "table" or type(depth) ~= "number" then
    self:Warning("error depth; ignore")
    return
  end
  if depth > 9 then
    self:Warning("too many depth; ignore")
    return
  end
  io.write("{\n")
  for k, v in pairs(t) do
    GameUtils:printTab(depth)
    io.write("[")
    GameUtils:printValue(k, depth + 1)
    io.write("] = ")
    GameUtils:printValue(v, depth + 1)
    io.write(",\n")
  end
  GameUtils:printTab(depth - 1)
  io.write("}\n")
end
function GameUtils:SaveTable(file, t, depth)
  if t == nil then
    print("printTable: nil table")
    return
  end
  local depth = depth or 1
  if depth > 9 then
    self:Warning("too many depth; ignore")
    return
  end
  file:write("{\n")
  for k, v in pairs(t) do
    GameUtils:SaveTab(file, depth)
    file:write("[")
    GameUtils:SaveValue(file, k, depth + 1)
    file:write("] = ")
    GameUtils:SaveValue(file, v, depth + 1)
    file:write(",\n")
  end
  GameUtils:SaveTab(file, depth - 1)
  file:write("}\n")
end
function GameUtils:SaveValue(file, v, depth)
  if type(v) == "string" then
    file:write(string.format("%q", v))
  elseif type(v) == "number" then
    file:write(v)
  elseif type(v) == "boolean" then
    file:write(v and "true" or "false")
  elseif type(v) == "table" then
    GameUtils:SaveTable(file, v, depth)
  elseif type(v) == "userdata" then
    file:write("userdata")
  elseif type(v) == "function" then
    file:write("function")
  else
    self:Warning("invalid type " .. type(v))
  end
end
function GameUtils:SaveTab(file, n)
  for i = 1, n do
    file:write("\t")
  end
end
function GameUtils:outputTable(t, name)
  io.write(name .. " = ")
  GameUtils:printTable(t)
end
function GameUtils:formatValue(v, out)
  if type(v) == "string" then
    out = out .. string.format("%q", v)
  elseif type(v) == "number" then
    out = out .. v
  elseif type(v) == "boolean" then
    out = out .. (v and "true" or "false")
  elseif type(v) == "table" then
    out = GameUtils:formatTable(v, out)
  else
    error("Wrong value type for data table!")
  end
  return out
end
function GameUtils:ShowTips(content)
  local GameTip = LuaObjectManager:GetLuaObject("GameTip")
  GameTip:Show(content)
end
function GameUtils:formatTable(t, out)
  out = out .. "{\n"
  for k, v in pairs(t) do
    out = out .. "["
    out = GameUtils:formatValue(k, out)
    out = out .. "] = "
    out = GameUtils:formatValue(v, out)
    out = out .. ",\n"
  end
  out = out .. " }\n"
  return out
end
function GameUtils:formatSaveString(t, name)
  local out = name .. " = "
  out = GameUtils:formatTable(t, out)
  return out
end
function GameUtils:CombineBattleID(actId, battleID)
  return actId * 1000000 + battleID
end
function GameUtils:ResolveBattleID(combinedID)
  local actID = math.floor(combinedID / 1000000)
  local battleID = combinedID - actID * 1000000
  return actID, battleID
end
function GameUtils:CheckEventType(battleID)
  local event_type = battleID % 1000
  event_type = math.floor(event_type / 100)
  return event_type
end
function GameUtils.DeviceLangToText(str)
  if ext.SNSdkType == "kakao" then
    return "kr"
  end
  if string.find(str, "en") == 1 then
    return "en"
  elseif string.find(str, "zh_Hans") == 1 then
    return "cn"
  elseif string.find(str, "zh_Hant") == 1 then
    return "zh"
  elseif string.find(str, "ja") == 1 then
    return "jp"
  elseif string.find(str, "de") == 1 then
    return "ger"
  elseif string.find(str, "fr") == 1 then
    return "fr"
  elseif string.find(str, "ko") == 1 then
    return "kr"
  elseif string.find(str, "it") == 1 then
    return "it"
  elseif string.find(str, "pt") == 1 then
    return "po"
  elseif string.find(str, "es") == 1 then
    return "sp"
  elseif string.find(str, "ru") == 1 then
    return "ru"
  elseif string.find(str, "nl") == 1 then
    return "nl"
  else
    return "en"
  end
end
function GameUtils:formatNumber(num)
  if num > 1000000000 then
    num = math.floor(num / 1000000000)
    return "" .. num .. "B"
  elseif num > 1000000 then
    num = math.floor(num / 1000000)
    return "" .. num .. "M"
  elseif num > 10000 then
    num = math.floor(num / 1000)
    return "" .. num .. "K"
  else
    return "" .. num
  end
end
function GameUtils:formatTimeStringToNBit(timevalue)
  local checkarray = {
    [1] = {
      sc = 2592000,
      ss = GameUtils:GetTimeChar("M")
    },
    [2] = {
      sc = 86400,
      ss = GameUtils:GetTimeChar("d")
    },
    [3] = {
      sc = 3600,
      ss = GameUtils:GetTimeChar("h")
    },
    [4] = {
      sc = 60,
      ss = GameUtils:GetTimeChar("m")
    },
    [5] = {
      sc = 1,
      ss = GameUtils:GetTimeChar("s")
    }
  }
  local valuetable = {}
  local valueindex = -1
  local n = 0
  if timevalue >= checkarray[1].sc then
    n = 1
  elseif timevalue >= checkarray[2].sc then
    n = 2
  elseif timevalue >= checkarray[3].sc then
    n = 2
  elseif timevalue >= checkarray[4].sc then
    n = 2
  else
    n = 1
  end
  for i = 1, #checkarray do
    if timevalue > checkarray[i].sc then
      local count = math.floor(timevalue / checkarray[i].sc)
      local _str = tostring(count) .. checkarray[i].ss
      table.insert(valuetable, _str)
      if #valuetable == n then
        break
      end
      timevalue = timevalue % checkarray[i].sc
    end
  end
  local timeString = ""
  for i = 1, #valuetable do
    timeString = timeString .. valuetable[i]
  end
  return timeString
end
function GameUtils:GetUserDisplayName(name_full)
  local server_suffix = "." .. GameUtils:GetActiveServerInfo().tag
  local index_suffix = string.find(name_full, server_suffix)
  if index_suffix then
    local name_display = string.sub(name_full, 1, index_suffix - 1)
    return name_display
  else
    return name_full
  end
end
function GameUtils:CutOutUsernameByLastDot(name_full)
  local totoalName = ""
  startpos, endpos = string.find(name_full, "[%.]")
  while startpos do
    local name_preffix = string.sub(name_full, 1, startpos - 1)
    if totoalName ~= "" then
      totoalName = totoalName .. "."
    end
    totoalName = totoalName .. name_preffix
    name_full = string.sub(name_full, startpos + 1, string.len(name_full))
    startpos, endpos = string.find(name_full, "[%.]")
  end
  if totoalName == "" then
    totoalName = name_full
  end
  return totoalName
end
function GameUtils:GetUserServerName(name_full)
  local index = string.find(name_full, "%.")
  if index then
    local serverName = string.sub(name_full, index + 1, string.len(name_full))
    return serverName
  else
    return nil
  end
end
function GameUtils:GetUserFullName(name_user)
  local server_suffix = "." .. GameUtils:GetActiveServerInfo().tag
  local index_suffix = string.find(name_user, server_suffix)
  if index_suffix then
    return name_user
  else
    local name_full = name_user .. server_suffix
    return name_full
  end
end
function GameUtils:SaveSettingData()
  if ext.SaveRawData then
    ext.SaveRawData("SETTING.raw", GameUtils:formatSaveString(GameSettingData, "GameSettingData"))
  else
    ext.SaveGameData("SETTING.tfl", GameUtils:formatSaveString(GameSettingData, "GameSettingData"))
  end
end
function GameUtils:LoadSettingData()
  if ext.IsFileExist then
    if ext.IsFileExist("SETTING.raw") and ext.LoadRawData then
      loadstring(ext.LoadRawData("SETTING.raw"))()
    else
      ext.dofile("SETTING.tfl")
      if ext.SaveRawData then
        ext.SaveRawData("SETTING.raw", GameUtils:formatSaveString(GameSettingData, "GameSettingData"))
      end
    end
  else
    ext.dofile("SETTING.tfl")
  end
end
function GameUtils:CheckUpdateSettingData()
  local isUpdated = false
  if GameSettingData == nil then
    GameUtils:LoadSettingData()
    if GameSettingData == nil then
      GameSettingData = {}
      GameSettingData.EnableMusic = true
      GameSettingData.EnableSound = true
      GameSettingData.EnablePayRemind = true
      GameSettingData.FirstEnterGame = true
      GameSettingData.EnableBuildingName = true
      GameSettingData.EnableChatEffect = true
      isUpdated = true
    end
  end
  if GameSettingData and GameSettingData.EnablePayRemind == nil then
    GameSettingData.EnablePayRemind = true
    isUpdated = true
  end
  if GameSettingData.LastLogin and GameSettingData.LastLogin.ServerInfo and GameSettingData.LastLogin.ServerInfo.server_version == nil then
    GameSettingData.LastLogin.ServerInfo.server_version = 1
    isUpdated = true
  end
  if GameSettingData.Save_Lang == nil then
    GameSettingData.Save_Lang = GameUtils.DeviceLangToText(ext.GetDeviceLanguage())
    GameSettingData.RECORD_VERSION = 1
    isUpdated = true
  end
  if GameSettingData.m_lastSectionShowEnterDialog == nil then
    GameSettingData.m_lastSectionShowEnterDialog = -10
    GameSettingData.RECORD_VERSION = 1
    isUpdated = true
  end
  if isUpdated then
    GameUtils:SaveSettingData()
  end
  if IPlatformExt.getConfigValue("PlatformName") == "taptap" then
    local sucfunc = function(jsoninfo)
      local newjson = {
        passport = jsoninfo.access_token,
        password = jsoninfo.openid
      }
      local strnewjson = ext.json.generate(newjson)
      GameUtils.IPlatformExtLoginInfo_json = strnewjson
      GameUtils.IPlatformExtLastLoginInfo = strnewjson
      GameUtils:PlatformExtAccountValidate(strnewjson, GameAccountSelector.PlatformExtAccountValidateCallback_Standard)
      GameSettingData.wechat_refrshtoken = jsoninfo.refresh_token
    end
    if GameSettingData.wechat_refrshtoken and #GameSettingData.wechat_refrshtoken > 0 then
      local sucfunc = function(jsoninfo)
        local newjson = {
          passport = jsoninfo.access_token,
          password = jsoninfo.openid
        }
        local strnewjson = ext.json.generate(newjson)
        GameUtils.IPlatformExtLoginInfo_json = strnewjson
        GameUtils.IPlatformExtLastLoginInfo = strnewjson
      end
      GameUtils:wechat_getToken_by_refresh(GameSettingData.wechat_refrshtoken, sucfunc, function()
      end)
    end
  end
end
function GameUtils._RestartGameCallback()
  if GameUtils.clearFontObj then
    GameUtils.clearFontObj:clearFonts()
  end
  ext.RestartGame()
  return nil
end
function GameUtils:RestartGame(delayTime, flash_obj)
  GameSettingData.LastLoginSuccess = false
  GameUtils:SaveSettingData()
  GameUtils.clearFontObj = flash_obj
  delayTime = delayTime or 200
  GameTimer:Add(GameUtils._RestartGameCallback, delayTime)
end
function GameUtils:GetPlayerSexByAvatra(avatar)
  if avatar == "male" then
    return 1
  end
  return 0
end
function GameUtils:GetPlayerAvatar(playerSex, fleetLevel)
  local sex = playerSex or GameGlobalData:GetUserInfo().sex
  local userinfo = GameGlobalData:GetUserInfo()
  local avatar = ""
  if fleetLevel and fleetLevel >= 6 then
    if 1 == sex then
      avatar = "head300"
    else
      avatar = "head301"
    end
    if GameDataAccessHelper:IsHeadResNeedDownload(avatar) and GameDataAccessHelper:CheckFleetHasAvataImage(avatar) then
      DebugOut(avatar)
      return avatar
    end
  end
  if 1 == sex then
    return "male"
  else
    return "female"
  end
end
function GameUtils:GetPlayerAvatarWithSex(sex, fleetLevel)
  if fleetLevel and fleetLevel >= 6 then
    local avatar = ""
    if 1 == sex then
      avatar = "head300"
    else
      avatar = "head301"
    end
    if GameDataAccessHelper:IsHeadResNeedDownload(avatar) and GameDataAccessHelper:CheckFleetHasAvataImage(avatar) then
      return avatar
    end
  end
  if 1 == sex then
    return "male"
  else
    return "female"
  end
end
function GameUtils:GetAdjutantName()
  local sex = GameGlobalData:GetUserInfo().sex
  if 1 == sex then
    return GameLoader:GetGameText("LC_NPC_NPC_F")
  else
    return GameLoader:GetGameText("LC_NPC_NPC_M")
  end
end
function GameUtils:GetAdjutantAvatar()
  local sex = GameGlobalData:GetUserInfo().sex
  if 1 == sex then
    return "head10"
  else
    return "head11"
  end
end
function GameUtils:GetUserVoiceKeyAndSecret()
  local locale = ext.GetDeviceLanguage()
  local key = -1
  local secret = -1
  if locale == "zh_Hans" then
    key = "gIjCQ0Fgk9z7XilcW01qQ"
    secret = "oXCgnY9jmbgQSLoJrdfbx863SmHSxroYDVJa4zjE"
  elseif locale == "fr" then
    key = "Ol24IVOigSIfv3GshZZrVw"
    secret = "t4jbNH4pdn6amIcF27WayZM2iu93ghLQdukEVX2XguY"
  elseif locale == "zh_Hant" then
    key = "mxlvDhw7x5zKFWpZjArwXw"
    secret = "TPUTwnmwLO4dR4MzUNpDm7sRZcMPobnXphPqhXAO8"
  elseif locale == "ja" then
    key = "o8AI6vNKDzyf0LGjmELdnA"
    secret = "mHUh1ShTHilq9XPCA9v8CrMIOssUqQ4Zhrwqjq7Ac"
  elseif locale == "es" then
    key = "iBbE21qwCVN838q4qj1w"
    secret = "MHjZMwAQJeDvNUemOJ3jcuP3S7Iw094bPXtsHKoAY"
  elseif locale == "it" then
    key = "XbvkcxFrv2AKppJWISEc3A"
    secret = "DWau4uHgD9AVZFFmaBuiYufOqNCrlcXtli4UQOReGo"
  elseif locale == "nl" then
    key = "T4ANcCGGgDvdUV8lVo0NA"
    secret = "dIlF1xO4l3RXA96jg5I0YM52FtodaTtGuzrvZhr08KU"
  elseif locale == "de" then
    key = "VngwJI4ubxWKu4cv9GOG2w"
    secret = "cL1Wa3FGsFtnh7ODhqcA3K9bx9cCylCueP9tuABU"
  elseif locale == "pt" then
    key = "tm7ZP2cdSKuswt7CEd97jw"
    secret = "bTLcTSyE5YWoW2AZEoFA8wUp7J1T1Ys6Bi8DgYZpe8"
  elseif locale == "ko" then
    key = "wW22rANdoUU7VG4GVZ0Pg"
    secret = "FF79ZgIGaa1f9CzXxhPJTwrEk4CV2pKAuZ0YXlzXE"
  elseif locale == "ru" then
    key = "vpDUyjXQIbbmLXXph7Fkxg"
    secret = "aCZnFDqQOiKZ0QpEseWdEYILl1yub83NpzdsY7aTiI"
  else
    key = "sT7K93hMFj8cWrehCINRA"
    secret = "cEy7MweT4E4kdcGRiIhx4QBgpy5i3FtsLbVGEin4lhs"
  end
  return key, secret
end
function GameUtils:PlayMusic(music_path)
  DebugOut("play music = ", music_path)
  if GameSettingData.EnableMusic == nil then
    GameSettingData.EnableMusic = true
    GameUtils:SaveSettingData()
  end
  local indexDir = string.find(music_path, "sound/")
  if not indexDir then
    music_path = "sound/" .. music_path
  end
  if GameSettingData.EnableMusic and self.ActiveMusic ~= music_path then
    self.ActiveMusic = music_path
    ext.audio.playBackgroundMusic(music_path)
  end
end
function GameUtils:StopMusic()
  ext.audio.stopBackgroundMusic()
end
function GameUtils:PlaySound(sound_path)
  DebugOut("PlaySound = ", sound_path)
  if GameSettingData.EnableSound == nil then
    GameSettingData.EnableSound = true
    GameUtils:SaveSettingData()
  end
  if GameSettingData.EnableSound then
    local indexDir = string.find(sound_path, "sound/")
    if not indexDir then
      sound_path = "sound/" .. sound_path
    end
    ext.audio.playEffect(sound_path)
  end
end
function GameUtils:PlayCG()
  if AutoUpdate.isAndroidDevice then
    GameUtils:PlayMovie("cut_scene.mp4", true)
  else
    GameUtils:PlayMovie("cut_scene.mov", true)
  end
end
function GameUtils:PlayMovie(movie_path, isCanSkip)
  if isCanSkip then
    isCanSkip = true
  else
    isCanSkip = false
  end
  local indexDir = string.find(movie_path, "video/")
  if not indexDir then
    movie_path = "video/" .. movie_path
  end
  ext.video.playMovie(movie_path, isCanSkip)
end
function GameUtils:IsMovieFinished()
  return ext.video.isMovieFinished()
end
function GameUtils:GetActiveMusic()
  return self.ActiveMusic
end
function GameUtils:SetBattleSpeed(battleSpeed)
  GameSettingData.BattleSpeed = battleSpeed
  GameUtils:SaveSettingData()
end
function GameUtils:GetBattleSpeed()
  if not GameSettingData.BattleSpeed then
    GameSettingData.BattleSpeed = 2
    GameUtils:SaveSettingData()
  end
  return GameSettingData.BattleSpeed
end
function GameUtils:CreditCostConfirm(info, callback, forceConfirm, cancelCallback)
  if GameSettingData.EnablePayRemind == nil then
    GameSettingData.EnablePayRemind = true
    GameUtils:SaveSettingData()
  end
  if GameSettingData.EnablePayRemind or forceConfirm == true then
    local GameUIMessageDialog = LuaObjectManager:GetLuaObject("GameUIMessageDialog")
    GameUIMessageDialog:SetStyle(GameUIMessageDialog.DialogStyle.YesNo)
    GameUIMessageDialog:SetYesButton(callback, nil)
    GameUIMessageDialog:SetNoButton(cancelCallback, nil)
    local infoTitle = GameLoader:GetGameText("LC_MENU_TITLE_VERIFY")
    GameUIMessageDialog:Display(infoTitle, info)
    if not forceConfirm then
      GameUIMessageDialog:ShowPayAction()
    end
  else
    callback()
  end
end
function GameUtils:ShowMaskLayer(posX, posY, ButtonPos, text, style)
  local GameUIMaskLayer = LuaObjectManager:GetLuaObject("GameUIMaskLayer")
  GameUIMaskLayer:Reload()
  GameUIMaskLayer:SetMaskStyle(style)
  if style == GameUIMaskLayer.MaskStyle.mid then
    GameUIMaskLayer:Display(GameUIMaskLayer:GetScreenWidth() / 2, GameUIMaskLayer:GetScreenHight() / 2, ButtonPos, text)
  else
    GameUIMaskLayer:Display(posX, posY, ButtonPos, text)
  end
end
function GameUtils:GetTutorialHelp(...)
  local GameUIMaskLayer = LuaObjectManager:GetLuaObject("GameUIMaskLayer")
  return GameUIMaskLayer:GetIsShow()
end
function GameUtils:HideTutorialHelp(...)
  local GameUIMaskLayer = LuaObjectManager:GetLuaObject("GameUIMaskLayer")
  GameUIMaskLayer:OnFSCommand("helptutorial")
end
function GameUtils:MaskLayerMidTutorial(text)
  local GameUIMaskLayer = LuaObjectManager:GetLuaObject("GameUIMaskLayer")
  DebugOut("width = " .. ext.SCREEN_WIDTH / 2 .. " hight = " .. ext.SCREEN_HEIGHT / 2)
  GameUtils:ShowMaskLayer("", "", GameUIMaskLayer.ButtonPos.right, text, GameUIMaskLayer.MaskStyle.mid)
end
function GameUtils:GetTutorialName(...)
  local GameUIMaskLayer = LuaObjectManager:GetLuaObject("GameUIMaskLayer")
  return GameUIMaskLayer:GetCurrentTutorial()
end
function GameUtils:GetScreenWidth(...)
  if ext.isRetina and ext.isRetina() and not ext.is16x9() and GameUtils:isIOSBundle() then
    DebugOut("1111111")
    return ext.SCREEN_WIDTH / 2
  else
    DebugOut("2222222")
    return ext.SCREEN_WIDTH
  end
end
function GameUtils:GetScreenHight(...)
  if ext.isRetina and ext.isRetina() and not ext.is16x9() and GameUtils:isIOSBundle() then
    return ext.SCREEN_HEIGHT / 2
  else
    return ext.SCREEN_HEIGHT
  end
end
function GameUtils:CensorWordsFilter(srcText)
  do return srcText end
  local censorWords = GameDataAccessHelper:GetCensorWords()
  local allCensorWordsPositions = {}
  for i, v in pairs(censorWords) do
    local startPos, endPos
    local allPositions = {}
    startPos, endPos = string.find(srcText, v.word, 1, true)
    while startPos ~= nil do
      table.insert(allPositions, {startPos = startPos, endPos = endPos})
      startPos = startPos + 1
      startPos, endPos = string.find(srcText, v.word, startPos, true)
    end
    if #allPositions > 0 then
      allCensorWordsPositions[i] = allPositions
    end
  end
  local textLen = string.len(srcText)
  local filteredText = srcText
  for _, v in pairs(allCensorWordsPositions) do
    for _, w in pairs(v) do
      local censorWordLen = w.endPos - w.startPos + 1
      filteredText = string.sub(filteredText, 1, w.startPos - 1) .. string.rep("*", censorWordLen) .. string.sub(filteredText, w.endPos + 1, textLen)
    end
  end
  return filteredText
end
function GameUtils:GetCensorWordsFromText(srcText)
  do return {} end
  local censorWords = GameDataAccessHelper:GetCensorWords()
  local censorWordsInSrtText = {}
  for i, v in pairs(censorWords) do
    local startPos, endPos
    startPos, endPos = string.find(srcText, v.word, 1, true)
    if startPos ~= nil then
      table.insert(censorWordsInSrtText, v.word)
    end
  end
  return censorWordsInSrtText
end
function GameUtils:isValidMailFormat(mailText)
  local stateTable = {
    [1] = {
      jumpTable = {
        {
          charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
          nextState = 2
        }
      },
      isEndState = false
    },
    [2] = {
      jumpTable = {
        {
          charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
          nextState = 2
        },
        {charSet = ".-_", nextState = 1},
        {charSet = "@", nextState = 3}
      },
      isEndState = false
    },
    [3] = {
      jumpTable = {
        {
          charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
          nextState = 4
        }
      },
      isEndState = false
    },
    [4] = {
      jumpTable = {
        {
          charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
          nextState = 4
        },
        {charSet = "-_", nextState = 3},
        {charSet = ".", nextState = 5}
      },
      isEndState = false
    },
    [5] = {
      jumpTable = {
        {
          charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
          nextState = 6
        }
      },
      isEndState = false
    },
    [6] = {
      jumpTable = {
        {
          charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
          nextState = 7
        },
        {charSet = "-_", nextState = 3},
        {charSet = ".", nextState = 5}
      },
      isEndState = false
    },
    [7] = {
      jumpTable = {
        {
          charSet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890",
          nextState = 7
        },
        {charSet = "-_", nextState = 3},
        {charSet = ".", nextState = 5}
      },
      isEndState = true
    }
  }
  local char = string.sub(mailText, 1, 1)
  local mailTextLen = string.len(mailText)
  local curState = 1
  for i = 1, mailTextLen do
    local curChar = string.sub(mailText, i, i)
    local curStateJumpTable = stateTable[curState].jumpTable
    local curCharValid = false
    for _, v in ipairs(curStateJumpTable) do
      local pos1, pos2 = string.find(v.charSet, curChar, 1, true)
      if pos1 ~= nil and pos1 == pos2 then
        curState = v.nextState
        curCharValid = true
        break
      end
    end
    if not curCharValid then
      return false
    end
  end
  return stateTable[curState].isEndState
end
function GameUtils:CheckIsContainsIllegalChar(strText)
  DebugOut("CheckIsContainsIllegalChar", strText)
  local len = string.len(strText)
  local isContains = false
  for i = 1, len do
    local curChar = string.byte(string.sub(strText, i, i))
    DebugOut(i, "curChar: ", string.sub(strText, i, i), curChar)
    if curChar < 0 or curChar > 127 then
      isContains = true
    end
  end
  return isContains
end
function GameUtils:GetDeviceIDFA()
  local idfa
  idfa = ext.GetIDFA()
  idfa = idfa or ""
  return idfa
end
function GameUtils.onFBLoginSuccess(success, fbID, token, name)
  DebugOut("GameUtils.onFBLoginSuccess()")
  DebugOut(success)
  DebugOut(fbID)
  DebugOut(token)
  DebugOut(name)
  if success then
    GameUtils.curFacebookInfo.success = 1
  else
    GameUtils.curFacebookInfo.success = 0
  end
  GameUtils.curFacebookInfo.fbID = fbID
  GameUtils.curFacebookInfo.token = token
  GameUtils.curFacebookInfo.name = name
  if success then
    Facebook.mError = nil
    Facebook.mUserId = fbID
    Facebook.mToken = token
    Facebook.mUserName = name
    Facebook:SaveFacebookInfo(fbID, name)
    Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.SUCCESS
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  end
end
function GameUtils:tryToLoginFB()
  self:clearFBLoginInfo()
  ext.socialShare.SignInFacebook(0)
end
function GameUtils:clearFBLoginInfo()
  GameUtils.curFacebookInfo.success = -1
  GameUtils.curFacebookInfo.fbID = ""
  GameUtils.curFacebookInfo.token = ""
  GameUtils.curFacebookInfo.name = ""
end
function GameUtils:hasFBLogined()
  if GameSettingData.PassportTable == nil or #GameSettingData.PassportTable == 0 then
    return false
  end
  for _, AccountInfo in ipairs(GameSettingData.PassportTable) do
    if self:IsFacebookAccount(AccountInfo) then
      return true
    end
  end
  return false
end
function GameUtils:getCurFacebookAccDisplayName()
  for _, AccountInfo in ipairs(GameSettingData.PassportTable) do
    if self:IsFacebookAccount(AccountInfo) then
      return AccountInfo.displayName
    end
  end
  return ""
end
function GameUtils:IsInMatrix(fleet_id)
  local fleets_matrix = GameGlobalData:GetData("matrix").cells
  for i, fleet in pairs(fleets_matrix) do
    if fleet.fleet_identity == fleet_id then
      return true
    end
  end
  return false
end
function GameUtils:IsModuleUnlock(moduleName)
  local modules_status = GameGlobalData:GetData("modules_status")
  if modules_status ~= nil then
    for i, v in ipairs(modules_status.modules) do
      if v.name == moduleName then
        return v.status
      end
    end
  end
  return false
end
function GameUtils:GetBindingStatus(bindingName)
  local buildings = GameGlobalData:GetData("buildings")
  if buildings ~= nil then
    for i, v in ipairs(buildings) do
      if v.name == bindingName then
        return v.status
      end
    end
  end
end
function GameUtils:GetBindingPre(bindingName)
  local buildings = GameGlobalData:GetData("buildings")
  table.sort(buildings.buildings, function(buildingLhs, buildingRhs)
    return buildingLhs.require_user_level < buildingRhs.require_user_level
  end)
  DebugTable(buildings.buildings)
  for i, building in ipairs(buildings.buildings) do
    if bindingName == building.name and 1 ~= i then
      return buildings.buildings[i - 1]
    end
  end
  return nil
end
GameUtils.AccountType = {
  guest = 0,
  mail = 1,
  facebook = 2,
  tango = 3,
  qihoo = 4,
  uc = 5,
  bd = 6
}
function GameUtils:IsFacebookAccount(accountInfo)
  if accountInfo ~= nil and accountInfo.accType ~= nil and accountInfo.accType == GameUtils.AccountType.facebook then
    return true
  else
    return false
  end
end
function GameUtils:IsMailAccount(accountInfo)
  if accountInfo ~= nil and not GameUtils:IsFacebookAccount(accountInfo) and not GameUtils:IsLoginTangoAccount() and not GameUtils:IsQihooAccount(accountInfo) then
    if accountInfo.accType and accountInfo.accType ~= GameUtils.AccountType.mail then
      return false
    end
    return true
  else
    return false
  end
end
function GameUtils:IsQihooAccount(accountInfo)
  if accountInfo ~= nil and accountInfo.accType == GameUtils.AccountType.qihoo then
    return true
  else
    return false
  end
end
function GameUtils:GetSaveLang()
  local locale = GameSettingData.Save_Lang
  if nil == locale then
    locale = GameUtils.DeviceLangToText(ext.GetDeviceLanguage())
  end
  return locale
end
function GameUtils:GetIsCNBundleType()
  local bundleIdentifier = ext.GetBundleIdentifier()
  if bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_CN or bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_LOCAL or bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_PLATFORM_QIHOO then
    return true
  end
  return false
end
function GameUtils:GetFlagFrameName(flagID)
  if type(flagID) ~= "number" then
    return "flag_unknown"
  elseif flagID == 0 then
    return "flag_unknown"
  elseif flagID < 10 then
    return "flag_0" .. flagID
  elseif (self:GetSaveLang() == "cn" or self:GetIsCNBundleType() == true) and (flagID == 18 or flagID == 34 or flagID == 39) then
    return "flag_38"
  else
    return "flag_" .. flagID
  end
end
function GameUtils:IsTestGateWay()
  local all = {}
  all["54.201.12.25:80"] = true
  all["54.201.12.25:8080"] = true
  all["54.201.12.25"] = true
  all["a.portal-platform.tap4fun.com/gl/url_get/dev/dev1/"] = true
  return all[AutoUpdate.destIpAddrPool[1]]
end
function GameUtils:IsTutorialScene()
  if immanentversion == 2 then
    return not TutorialQuestManager.QuestTutorialCityHall:IsFinished() and not TutorialQuestManager.QuestTutorialCityHall:IsActive()
  end
  return false
end
function GameUtils:IsMycardAPP()
  local bundleIdentifier = ext.GetBundleIdentifier()
  local IsMycardAPP = bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_MYCARD
  return IsMycardAPP
end
function GameUtils:IsTangoAPP()
  local bundleIdentifier = ext.GetBundleIdentifier()
  local isTangoApp = bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_TANGO or bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_TANGO
  return isTangoApp
end
function GameUtils:IsLoginTangoAccount()
  local GameAccountSelector = LuaObjectManager:GetLuaObject("GameAccountSelector")
  return GameUtils:IsTangoAPP() and GameAccountSelector.ishaveTangAccount
end
function GameUtils:TangoLogin()
  local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
  local GameAccountSelector = LuaObjectManager:GetLuaObject("GameAccountSelector")
  local function successcallback()
    GameWaiting:HideLoadingScreen()
    local data = {
      passport = GameUtils.m_myProfile.tangoID,
      password = GameUtils.m_myProfile.token,
      acc_type = GameUtils.AccountType.tango
    }
    GameUtils:SetHTTPPostData(ext.json.generate(data), nil)
    GameUtils:HTTP_SendRequest("gamers/validate", nil, GameAccountSelector.TangoAccountValiddataCallback, true, GameUtils.httpRequestFailedCallback, "POST")
  end
  local function failedCallback(str)
    GameWaiting:HideLoadingScreen()
    GameAccountSelector:JustShowTangoAccout()
    if #GameAccountSelector.LoginTable == 0 then
      local LoginInfo = {}
      local ServerInfo = GameUtils:GetServerInfoWithID(GameUtils.ServerAndAccountInfo.recommand_id)
      assert(ServerInfo)
      LoginInfo.ServerInfo = ServerInfo
      GameUtils:SetLoginInfo(LoginInfo)
      DelayLoad()
      NetMessageMgr:InitNet()
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateLoading)
    elseif not GameUtils:GetLoginInfo() then
      GameUtils:SetLoginInfo(LuaUtils:table_rcopy(GameAccountSelector.LoginTable[1]))
      DelayLoad()
      GameAccountSelector:UpdateLoginInfo()
    end
  end
  GameWaiting:ShowLoadingScreen()
  GameUtils:TryTangoLogin(successcallback, failedCallback)
end
function GameUtils:TryTangoLogin(succCallback, failedCallback)
  assert(succCallback)
  if self.m_myProfile then
    succCallback()
    return
  end
  ext.socialNetwork.login(function(errStr)
    if errStr then
      local first = string.sub(errStr, 1, 1)
      if first then
        GameUtils.IsNotInstallTango = tonumber(first) == 1
      end
      if failedCallback then
        failedCallback(errStr)
      end
      return
    end
    ext.socialNetwork.getMyProfile(function(errStr, myProfile)
      if errStr then
        if failedCallback then
          failedCallback(errStr)
        end
        return
      end
      GameUtils.m_myProfile = myProfile
      succCallback()
    end)
  end)
end
function GameUtils:IsQihooApp()
  local bundleIdentifier = ext.GetBundleIdentifier()
  local isQihooApp = bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_PLATFORM_QIHOO
  return isQihooApp
end
function GameUtils:QihooLogin()
  GameUtils:printByAndroid("----------GameUtils:QihooLogin( )-------------")
  local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
  local GameAccountSelector = LuaObjectManager:GetLuaObject("GameAccountSelector")
  if GameUtils.qihoo_token then
    local QihooAccountInfo = {}
    QihooAccountInfo.passport = GameUtils.qihoo_token
    QihooAccountInfo.password = GameUtils.qihoo_token
    GameWaiting:ShowLoadingScreen()
    GameUtils:QihooAccountValidate(QihooAccountInfo, GameAccountSelector.QihooAccountValidateCallback)
  end
end
function loginEnd(token)
  GameUtils:printByAndroid("Qihoo login end : " .. token)
  local GameAccountSelector = LuaObjectManager:GetLuaObject("GameAccountSelector")
  local v = {}
  v = ext.json.parse(token)
  GameUtils.qihoo_token = v.qihoo_token
  GameUtils:printByAndroid("Lua loginEnd token=" .. GameUtils.qihoo_token)
  if GameUtils.qihoo_token ~= "-1" then
    GameUtils:QihooLogin()
  end
end
GameUtils.IPlatformExtLoginInfo_json = nil
GameUtils.IPlatformExtLastLoginInfo = nil
function GameUtils.IPlatformExtLogin_Standard_GateWay()
  if IPlatformExt.getConfigValue("PlatformName") == "taptap" and GameUtils.IPlatformExtLoginInfo_json then
    GameUtils.PlatfromExtLoginEnd_GateWay_Standard(GameUtils.IPlatformExtLoginInfo_json)
    return
  end
  IPlatformExt.RegCallBackFunc(1, GameUtils.PlatfromExtLoginEnd_GateWay_Standard)
  IPlatformExt.RegCallBackFunc(4, GameUtils.PlatfromExtLogoutEnd_Standard)
  IPlatformExt.Login()
end
function GameUtils:wechat_getToken_by_refresh(strRefreshToken, succallback, failcallback)
  local strurl = "https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=<APPID>&grant_type=refresh_token&refresh_token=<REFRESH_TOKEN>"
  strurl = strurl.gsub(strurl, "<APPID>", "wx6a8bbe94b1ee3fae")
  strurl = strurl.gsub(strurl, "<REFRESH_TOKEN>", strRefreshToken)
  local header = {
    ["User-Agent"] = "Tap4fun client"
  }
  DebugOut("xxpp refresh", strurl)
  ext.http.requestBasic({
    strurl,
    param = "",
    mode = "notencrypt",
    header = header,
    method = "get",
    callback = function(statusCode, content, errstr)
      if statusCode == 200 then
        DebugOut(content)
        local accInfo = ext.json.parse(content)
        if accInfo.errcode then
          GameUtils:printByAndroid("xxpp failed refresh " .. accInfo.errcode)
          DebugOut("must here")
          failcallback()
        else
          succallback(accInfo)
        end
      else
        failcallback()
      end
    end
  })
end
function GameUtils:wechat_getToken_by_code(strcode, succallback, failcallback)
  local strurl = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=<APPID>&secret=<SECRET>&code=<CODE>&grant_type=authorization_code"
  strurl = strurl.gsub(strurl, "<APPID>", "wx6a8bbe94b1ee3fae")
  strurl = strurl.gsub(strurl, "<SECRET>", "074767b46a218708d89aa90396ca42d9")
  strurl = strurl.gsub(strurl, "<CODE>", strcode)
  DebugOut("xxpp code", strurl)
  local header = {
    ["User-Agent"] = "Tap4fun client"
  }
  ext.http.requestBasic({
    strurl,
    param = "",
    mode = "notencrypt",
    header = header,
    method = "get",
    callback = function(statusCode, content, errstr)
      if statusCode == 200 then
        DebugOut(content)
        local accInfo = ext.json.parse(content)
        if accInfo.errcode then
          GameUtils:printByAndroid("xxpp failed code " .. accInfo.errcode)
          failcallback()
        else
          GameUtils:wechat_getToken_by_refresh(accInfo.refresh_token, succallback, failcallback)
        end
      else
        failcallback()
      end
    end
  })
end
local _func_Standard_loginServer = function(LoginEndInfo_json)
  GameUtils:printByAndroid("func_Standard_loginServer LoginEndInfo_json " .. LoginEndInfo_json)
  local taptap_from_java = false
  if IPlatformExt.getConfigValue("PlatformName") == "taptap" and not string.find(LoginEndInfo_json, "{") then
    taptap_from_java = true
  end
  if taptap_from_java then
    local sucfunc = function(jsoninfo)
      local newjson = {
        passport = jsoninfo.access_token,
        password = jsoninfo.openid
      }
      local strnewjson = ext.json.generate(newjson)
      DebugOut("xxpp openid ", jsoninfo.openid)
      GameUtils.IPlatformExtLoginInfo_json = strnewjson
      GameUtils.IPlatformExtLastLoginInfo = strnewjson
      local GameAccountSelector = LuaObjectManager:GetLuaObject("GameAccountSelector")
      GameUtils:PlatformExtAccountValidate(strnewjson, GameAccountSelector.PlatformExtAccountValidateCallback_Standard)
      GameSettingData.wechat_refrshtoken = jsoninfo.refresh_token
      GameUtils:SaveSettingData()
    end
    local failfunc = function()
      GameSettingData.wechat_refrshtoken = nil
      GameUtils:SaveSettingData()
    end
    GameUtils:wechat_getToken_by_code(LoginEndInfo_json, sucfunc, failfunc)
  else
    GameUtils.IPlatformExtLoginInfo_json = LoginEndInfo_json
    GameUtils.IPlatformExtLastLoginInfo = LoginEndInfo_json
    local GameAccountSelector = LuaObjectManager:GetLuaObject("GameAccountSelector")
    GameUtils:PlatformExtAccountValidate(LoginEndInfo_json, GameAccountSelector.PlatformExtAccountValidateCallback_Standard)
  end
end
function GameUtils.IPlatformExtLogin_Standard_Server()
  local GameAccountSelector = LuaObjectManager:GetLuaObject("GameAccountSelector")
  local function func_Standard_loginServer(LoginEndInfo_json)
    if string.len(LoginEndInfo_json) < 1 then
      return
    end
    GameUtils:SetLoginInfo(nil)
    _func_Standard_loginServer(LoginEndInfo_json)
  end
  IPlatformExt.RegCallBackFunc(1, func_Standard_loginServer)
  IPlatformExt.RegCallBackFunc(4, GameUtils.PlatfromExtLogoutEnd_Standard)
  if not GameUtils.IPlatformExtLoginInfo_json or IPlatformExt.getConfigValue("ForceDoubleLogin") == "True" then
    IPlatformExt.Login()
  else
    GameAccountSelector:EnterGame()
  end
end
function GameUtils.PlatfromExtLoginEnd_GateWay_Standard(LoginEndInfo_json)
  GameUtils:printByAndroid("----------PlatfromExtLoginEnd_Standard_GateWay-------------")
  GameUtils:printByAndroid("PlatfromExtLoginEnd_GateWay_Standard LoginEndInfo_json " .. LoginEndInfo_json)
  if string.len(LoginEndInfo_json) < 1 then
    if IPlatformExt.getConfigValue("PlatformName") == "taptap" then
    else
      GameStateManager.GameStateAccountSelect.TryUpdateServer()
    end
    return
  end
  _func_Standard_loginServer(LoginEndInfo_json)
end
GameUtils.PlatfromExtLogout_Standard_clearFontObj = nil
function GameUtils.PlatfromExtLogout_Standard(flash_obj)
  GameUtils:printByAndroid("PlatfromExtLogout_Standard")
  GameUtils.PlatfromExtLogout_Standard_clearFontObj = flash_obj
  IPlatformExt.Logout()
end
function GameUtils.PlatfromExtLogoutEnd_Standard()
  GameUtils:printByAndroid("PlatfromExtLogoutEnd_Standard")
  GameSettingData.PassportTable = {}
  GameSettingData.LastLogin = nil
  GameUtils:SaveSettingData()
  GameUtils:RestartGame(nil, GameUtils.PlatfromExtLogout_Standard_clearFontObj)
end
function GameUtils:SafeRecordLoginInfo()
  local GameInfo = {}
  GameInfo.Type = "Login"
  GameInfo.PlayerID = GameGlobalData:GetUserInfo().player_id
  GameInfo.PlayerName = GameGlobalData:GetUserInfo().name
  GameInfo.PlayerLevel = GameGlobalData:GetData("levelinfo").level
  GameInfo.ServerID = GameUtils:GetActiveServerInfo().id
  GameInfo.ServerName = GameUtils:GetActiveServerInfo().name
  DebugOut("SafeRecordLoginInfo")
  DebugTable(GameInfo)
  GameUtils:SafeRecordGameInfo(GameInfo)
end
function GameUtils:SafeRecordGameInfo(GameInfoTable)
  if IPlatformExt.RecordGameInfo then
    IPlatformExt.RecordGameInfo(ext.json.generate(GameInfoTable))
  end
end
function GameUtils:DebugOutTableInAndroid(content, count)
  if not content then
    return
  end
  if type(content) ~= "table" then
    return
  end
  count = count or 2
  if not type(count) == "number" then
    count = 2
  end
  for k, v in pairs(content) do
    local label = ""
    for i = 1, count do
      label = label .. ".."
    end
    if type(v) == "table" then
      GameUtils:printByAndroid(label .. " [ " .. k .. " ]=")
      GameUtils:DebugOutTableInAndroid(v, count + 2)
    else
      GameUtils:printByAndroid(label .. " [ " .. tostring(k) .. " ]" .. "= [ " .. tostring(v) .. " ] ")
    end
  end
end
function GameUtils:printByAndroid(...)
  local t = {
    ...
  }
  for k, v in pairs(t) do
    t[k] = tostring(v)
  end
  local content = table.concat(t, ",")
  DebugOut(content)
  if AutoUpdate.isAndroidDevice then
    ext.__debugLog(content)
  end
end
function GameUtils:getProductListReqNum()
  local bundleIdentifier = ext.GetBundleIdentifier()
  if bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_WORLD then
    return 200
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_CN then
    return 201
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_TANGO then
    return 202
  elseif bundleIdentifier == "com.tap4fun.galaxyempire2_android_huawei" then
    return 116
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID then
    return 100
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_DELUXE then
    return 100
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_LOCAL then
    return 101
  elseif bundleIdentifier == "com.tap4fun.galaxyempire2_android_taptap" then
    return 115
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_TANGO then
    return 102
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_MYCARD then
    return 110
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_AMAZON then
    return 103
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_PLATFORM_QIHOO then
    return 111
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_GLOBAL then
    return 100
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_SPACELANCER then
    return 100
  end
  return 0
end
function GameUtils:isIOSBundle()
  local bundleIdentifier = ext.GetBundleIdentifier()
  if bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_WORLD then
    return true
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_CN then
    return true
  end
  return false
end
function GameUtils:EscapeHtmlStr(str)
  str = string.gsub(str, "&", "&amp;")
  str = string.gsub(str, "<", "&lt;")
  str = string.gsub(str, ">", "&gt;")
  return str
end
function GameUtils:TrimHtmlStr(str)
  DebugOut("before str = ", str)
  str = string.gsub(str, "<font[^>]*>", "")
  str = string.gsub(str, "</font>", "")
  DebugOut("after str = ", str)
  return str
end
function GameUtils:combineUrlParamTable(t)
  local r = {}
  for k, v in pairs(t) do
    v = ext.ENC3(v)
    table.insert(r, tostring(k) .. "=" .. tostring(v))
  end
  return LuaUtils:string_combine(r, "&")
end
GameUtils.mTransCacheMap = nil
function GameUtils:Google_Translate(text, cb)
  local targetLocale = GameUtils:ConvertLocaleToGoogleCode()
  if GameUtils.mTransCacheMap and GameUtils.mTransCacheMap[targetLocale] and GameUtils.mTransCacheMap[targetLocale][text] then
    local function timerCall()
      DebugOut("Translate use cache data.")
      cb(GameUtils.mTransCacheMap[targetLocale][text], nil)
    end
    GameTimer:Add(timerCall, 1)
    return
  end
  local params = {
    key = "AIzaSyCTmj7inPubcaudTxSfJpkX8SHyNhYpUjw",
    q = text,
    target = targetLocale
  }
  local header = {}
  ext.http.requestBasic({
    "https://www.googleapis.com/language/translate/v2",
    param = "?" .. self:combineUrlParamTable(params),
    mode = "notencrypt",
    header = header,
    method = "get",
    callback = function(statusCode, content, errstr)
      if statusCode == 200 then
        local r = ""
        if content.data and type(content.data) == "table" and content.data.translations and type(content.data.translations) == "table" and #content.data.translations > 0 then
          for _, v in ipairs(content.data.translations) do
            r = r .. v.translatedText
          end
        end
        print("Google Translator::::::-------------------------------------->", r)
        if nil == GameUtils.mTransCacheMap then
          GameUtils.mTransCacheMap = {}
        end
        if nil == GameUtils.mTransCacheMap[targetLocale] then
          GameUtils.mTransCacheMap[targetLocale] = {}
        end
        GameUtils.mTransCacheMap[targetLocale][text] = r
        cb(r, nil)
      else
        cb(nil, errstr)
      end
    end
  })
end
function GameUtils:ConvertLocaleToGoogleCode()
  local locale = GameSettingData.Save_Lang
  if nil == locale then
    locale = GameUtils.DeviceLangToText(ext.GetDeviceLanguage())
  end
  if locale == "cn" then
    return "zh-CN"
  elseif locale == "en" then
    return "en"
  elseif locale == "ru" then
    return "ru"
  elseif locale == "po" then
    return "pt-BR"
  elseif locale == "kr" then
    return "ko"
  elseif locale == "jp" then
    return "ja"
  elseif locale == "zh" then
    return "zh-TW"
  elseif locale == "ger" then
    return "de"
  elseif locale == "fr" then
    return "fr"
  elseif locale == "sp" then
    return "es"
  elseif locale == "it" then
    return "it"
  elseif locale == "nl" then
    return "nl"
  elseif locale == "tr" then
    return "tr"
  elseif locale == "ido" then
    return "id"
  else
    return locale
  end
end
function GameUtils:CheckSpaceCharFromString(content)
  local startpos
  startpos, _ = string.find(content, " ")
  if startpos then
    return true
  else
    return false
  end
end
function GameUtils:isAccountCharaterValid(content)
  local textLen = string.len(content)
  local curState = 1
  local isValid = true
  for i = 1, textLen do
    local curChar = string.sub(content, i, i)
    local startpos
    startpos, _ = string.find(curChar, "^[%w_%.@%+%-]+$")
    if startpos then
    else
      isValid = false
      break
    end
  end
  DebugOut("isAccountCharaterValid", content, isValid)
  return isValid
end
function GameUtils:GetChannelStr(msg)
  local channelStr = ""
  if msg.channel == "global_chat_channel" then
    if msg.receiver ~= "" then
      channelStr = "<font color='#458B74'> " .. "[" .. GameLoader:GetGameText("LC_MENU_WHISPER_CHAT_ABB") .. "]" .. "</font>"
    else
      channelStr = "<font color='#FFD700'> " .. "[" .. GameLoader:GetGameText("LC_MENU_WORLD_CHAT_ABB") .. "]" .. "</font>"
    end
  elseif msg.channel == "tc_chat_channel" then
    channelStr = "<font color='#EE0000'> " .. "[" .. GameLoader:GetGameText("LC_MENU_BATTLE_CHAT_ABB") .. "]" .. "</font>"
  else
    channelStr = "<font color='#00CDCD'> " .. "[" .. GameLoader:GetGameText("LC_MENU_ALLIANCE_CHAT_ABB") .. "]" .. "</font>"
  end
  return channelStr
end
function GameUtils:BindAccount(origin_type, origin_passport, origin_password, bind_type, bind_passport, bind_password, successCallback, failedCallback)
  local orgPassword = origin_password
  if origin_type == GameUtils.AccountType.mail then
    orgPassword = ext.ENC1(origin_password)
  end
  local bindPassword = bind_password
  if bind_type == GameUtils.AccountType.mail then
    bindPassword = ext.ENC1(bind_password)
  end
  local data = {
    origin_type = origin_type,
    origin_passport = origin_passport,
    origin_password = orgPassword,
    bind_type = bind_type,
    bind_passport = bind_passport,
    bind_password = bindPassword,
    udid = ext.GetIOSOpenUdid(),
    game_id = GameUtils:GetLogSeverLogicID()
  }
  GameUtils:SetHTTPPostData(ext.json.generate(data), nil)
  GameUtils:HTTP_SendRequest("gamers/multi_bind", nil, successCallback, false, failedCallback, "POST")
end
function GameUtils:IsChinese()
  local isChinese = false
  if ext.GetBundleIdentifier() == "com.tap4fun.galaxyempire2.chinese" then
    isChinese = true
  elseif ext.GetBundleIdentifier() == "com.tap4fun.galaxyempire2_android.platform.BD" then
    isChinese = true
  elseif ext.GetBundleIdentifier() == "com.tap4fun.galaxyempire2_android.platform.qihoo360" then
    isChinese = true
  elseif ext.GetBundleIdentifier() == "com.tap4fun.galaxyempire2_android.platform.uc" then
    isChinese = true
  elseif ext.GetBundleIdentifier() == "com.tap4fun.galaxyempire2_android_local" then
    isChinese = true
  elseif ext.GetBundleIdentifier() == "com.tap4fun.galaxyempire2_android_taptap" then
    isChinese = true
  end
  return isChinese
end
function GameUtils:IsSimplifiedChinese()
  if GameSettingData and GameSettingData.Save_Lang and GameSettingData.Save_Lang == "cn" then
    return true
  else
    return false
  end
end
function GameUtils:RequestServerList(AccountInfo, SuccessCallback, FailedCallback)
  local DataPacket = {}
  DataPacket.passport = AccountInfo.passport
  DataPacket.password = AccountInfo.password or ""
  if IPlatformExt.getConfigValue("UseExtLogin") == "True" then
    local accInfoStr = GameUtils.IPlatformExtLoginInfo_json or GameUtils.IPlatformExtLastLoginInfo
    if accInfoStr then
      local accInfo = {}
      accInfo = ext.json.parse(accInfoStr)
      if accInfo then
        DataPacket.password = accInfo.password
        if IPlatformExt.getConfigValue("PlatformName") == "taptap" then
          DataPacket.passport = accInfo.passport
        end
      end
    end
    DataPacket.acc_type = tonumber(IPlatformExt.getConfigValue("AccType"))
  elseif GameUtils:IsQihooApp() then
    GameUtils:printByAndroid("GameUtils:IsQihooAccount(AccountInfo)")
    DataPacket.acc_type = GameUtils.AccountType.qihoo
    DataPacket.password = GameUtils.qihoo_token
  elseif AccountInfo.accType == GameUtils.AccountType.guest then
    DataPacket.passport = ""
    DataPacket.acc_type = GameUtils.AccountType.guest
  else
    DataPacket.acc_type = AccountInfo.accType or GameUtils.AccountType.mail
  end
  if DataPacket.acc_type == GameUtils.AccountType.mail or DataPacket.acc_type == GameUtils.AccountType.guest then
    DataPacket.password = ext.ENC1(DataPacket.password)
  end
  DebugOutPutTable(DataPacket, "RequestServerList")
  DataPacket = ext.json.generate(DataPacket)
  GameUtils:SetHTTPPostData(DataPacket, nil)
  local function successCallback(content)
    if ext.addFlurryEvent then
      ext.addFlurryEvent("FetchServerListV2ResultSuccessed", {FetchServerListV2Result = "Successed"})
    end
    if g_SaveNewFteData then
      ext.sendNewFteData("FTE_FetchServerListV2ResultSuccessed")
    end
    if SuccessCallback then
      SuccessCallback(content)
    end
  end
  local function failedCallback(content)
    if ext.addFlurryEvent then
      ext.addFlurryEvent("FetchServerListV2ResultFailed", {FetchServerListV2Result = "Failed"})
    end
    local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
    local serverName = " "
    if GameUtils:GetActiveServerInfo() then
      serverName = serverName .. GameUtils:GetActiveServerInfo().name or GameUtils:GetActiveServerInfo().id or ""
    end
    local errorText = GameLoader:GetGameText("LC_ALERT_HTTP_FAILED") .. serverName
    GameUIGlobalScreen:ShowMessageBox(1, "ERROR", errorText)
    if FailedCallback then
      FailedCallback(content)
    end
  end
  GameUtils:HTTP_SendRequest("gamers/servers_v2", nil, successCallback, true, failedCallback, "POST")
  if g_SaveNewFteData then
    ext.sendNewFteData("FTE_FetchServerListV2Started")
  end
  if ext.addFlurryEvent then
    ext.addFlurryEvent("FetchServerListV2Started", {FetchServerListV2Started = "Started"})
  end
end
function GameUtils:MakeGameitem(itemType, itemID, itemNum, itemLevel)
  local gameItem = {}
  gameItem.item_type = itemType
  local GameHelper = LuaObjectManager:GetLuaObject("GameHelper")
  if GameHelper:IsResource(itemType) then
    gameItem.number = itemNum
    gameItem.no = 1
  else
    gameItem.number = itemID
    gameItem.no = itemNum
  end
  gameItem.level = itemLevel
  return gameItem
end
function GameUtils:Translate(text, cb)
  GameUtils.mTranslation:translate("auto", self:ConvertLocaleToGoogleCode(), text, cb)
end
local CommanderRanks = {
  [1] = "rank_E",
  [2] = "rank_D",
  [3] = "rank_C",
  [4] = "rank_B",
  [5] = "rank_A",
  [6] = "rank_S1",
  [7] = "rank_S2",
  [8] = "rank_S3",
  [9] = "rank_S4",
  [10] = "rank_S5",
  [11] = "rank_S6",
  [98] = "rank_SS",
  [99] = "rank_SSS"
}
function GameUtils:GetFleetRankFrameInFairArena(rank_id, callback, id, formationType, poolType, isPool)
  DebugOut("GetFleetRankFrameInFairArena = " .. rank_id)
  local rankimage = GameDataAccessHelper:GetFleetRankImageFrame(rank_id)
  local frame_rank = "rank"
  local fullFileName = DynamicResDownloader:GetFullName("LAZY_LOAD_DOWN_" .. rankimage .. ".png", DynamicResDownloader.resType.RANK_PIC)
  local localPath = "data2/" .. fullFileName
  if rank_id > 5 then
    if DynamicResDownloader:IfResExsit(localPath) then
      ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
      frame_rank = rankimage
    else
      frame_rank = "rank"
      local extInfo = {}
      extInfo.rank_id = rankimage
      extInfo.id = id
      extInfo.formationType = formationType
      extInfo.poolType = poolType
      extInfo.isPool = isPool
      DynamicResDownloader:AddDynamicRes(fullFileName, DynamicResDownloader.resType.RANK_PIC, extInfo, callback)
    end
  else
    frame_rank = rankimage
  end
  DebugOut("frame_rank = " .. frame_rank)
  return frame_rank
end
function GameUtils:GetFleetRankFrame(rank_id, callback, id)
  DebugOut("rank_id = " .. rank_id)
  local rankimage = GameDataAccessHelper:GetFleetRankImageFrame(rank_id)
  local frame_rank = "rank"
  local fullFileName = DynamicResDownloader:GetFullName("LAZY_LOAD_DOWN_" .. rankimage .. ".png", DynamicResDownloader.resType.RANK_PIC)
  local localPath = "data2/" .. fullFileName
  if rank_id > 5 then
    if DynamicResDownloader:IfResExsit(localPath) then
      ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
      frame_rank = rankimage
    else
      frame_rank = "rank"
      local extInfo = {}
      extInfo.rank_id = rankimage
      extInfo.id = id
      DynamicResDownloader:AddDynamicRes(fullFileName, DynamicResDownloader.resType.RANK_PIC, extInfo, callback)
    end
  else
    frame_rank = rankimage
  end
  DebugOut("frame_rank = " .. frame_rank)
  return frame_rank
end
function GameUtils:GetPlayerRankingInWdc(rankImag, extInfo, callback)
  local frame_ranking = "rank1_0"
  local fullFileName = DynamicResDownloader:GetFullName("LAZY_LOAD_DOWN_glc_" .. rankImag .. ".png", DynamicResDownloader.resType.RANKING_PIC)
  local localPath = "data2/" .. fullFileName
  if DynamicResDownloader:IfResExsit(localPath) then
    ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
    frame_ranking = rankImag
  else
    frame_ranking = "rank1_0"
    DynamicResDownloader:AddDynamicRes(fullFileName, DynamicResDownloader.resType.RANKING_PIC, extInfo, callback)
  end
  DebugOut("frame_ranking = " .. frame_ranking)
  return frame_ranking
end
function GameUtils:GetPlayerRankInWdc()
  local wdcPlayerInfo = GameGlobalData:GetData("wdcPlayerInfo")
  DebugOut("GetPlayerRankInWdc = ")
  DebugTable(wdcPlayerInfo)
  local rankName = ""
  if wdcPlayerInfo.player_info.using_rank ~= 0 then
    rankName = "[" .. GameLoader:GetGameText("LC_MENU_LEAGUE_GRADENAME_" .. wdcPlayerInfo.player_info.using_rank) .. "]"
  end
  local GameHelper = LuaObjectManager:GetLuaObject("GameHelper")
  local rank = GameHelper:GetFoatColor("CDFFFF", rankName)
  if wdcPlayerInfo.player_info.using_rank == 36 then
    if wdcPlayerInfo.player_info.using_ranking == 1 then
      rank = GameHelper:GetFoatColor("FFCC33", rankName)
    elseif wdcPlayerInfo.player_info.using_ranking > 1 and wdcPlayerInfo.player_info.using_ranking < 101 then
      rank = GameHelper:GetFoatColor("9966FF", rankName)
    end
  end
  return rank
end
function GameUtils:GetPlayerRank(rank, ranking)
  DebugOut("GetPlayerRank = " .. rank .. " " .. ranking)
  local rankText = ""
  if rank == 0 then
    return rankText
  end
  local rankName = "[" .. GameLoader:GetGameText("LC_MENU_LEAGUE_GRADENAME_" .. rank) .. "]"
  local GameHelper = LuaObjectManager:GetLuaObject("GameHelper")
  rankText = GameHelper:GetFoatColor("CDFFFF", rankName)
  if rank == 36 then
    if ranking == 1 then
      rankText = GameHelper:GetFoatColor("FFCC33", rankName)
    elseif ranking > 1 and ranking < 101 then
      rankText = GameHelper:GetFoatColor("9966FF", rankName)
    end
  end
  return rankText
end
GameUtils.AppDownLoadURL = {
  ["com.tap4fun.galaxyempire2"] = "https://itunes.apple.com/us/app/galaxy-legend/id599877646?ls=1&mt=8",
  ["com.tap4fun.galaxyempire2.chinese"] = "https://itunes.apple.com/us/app/yin-he-chuan-shuo-zhong-wen-ban/id687617647?ls=1&mt=8",
  ["com.tap4fun.galaxyempire2_android"] = "market://details?id=com.tap4fun.galaxyempire2_android",
  ["com.ts.galaxyempire2_android_global"] = "market://details?id=com.ts.galaxyempire2_android_global",
  ["com.tap4fun.galaxyempire2_android_mycard"] = "market://details?id=com.tap4fun.galaxyempire2_android",
  ["com.tap4fun.galaxyempire2_android_mobogenie"] = "market://details?id=com.tap4fun.galaxyempire2_android",
  ["com.tap4fun.galaxyempire2_android_local"] = "http://yh.t4f.cn/yh.apk",
  ["com.tap4fun.galaxyempire2_android_amazon"] = "market://details?id=com.tap4fun.galaxyempire2_android",
  ["com.tap4fun.galaxyempire2_android.platform.qihoo360"] = "http://yh.t4f.cn/yh.apk",
  ["com.tap4fun.galaxyempire2_android.platform.uc"] = "http://yh.t4f.cn/yh.apk",
  ["com.tap4fun.galaxyempire2_android_cafe"] = "market://details?id=com.tap4fun.galaxyempire2_android",
  ["com.ts.spacelancer"] = "market://details?id=com.ts.spacelancer"
}
GameUtils.IOSWorld = {
  ["com.tap4fun.galaxyempire2"] = true
}
GameUtils.IOSChinese = {
  ["com.tap4fun.galaxyempire2.chinese"] = true
}
GameUtils.AndroidWorld = {
  ["com.tap4fun.galaxyempire2_android"] = true,
  ["com.tap4fun.galaxyempire2_android_cafe"] = true,
  ["com.tap4fun.galaxyempire2_android_amazon"] = true,
  ["com.ts.galaxyempire2_android_global"] = true,
  ["com.tap4fun.galaxyempire2_android_mycard"] = true,
  ["com.tap4fun.galaxyempire2_android_mobogenie"] = true,
  ["com.ts.spacelancer"] = true
}
GameUtils.AndroidChinese = {
  ["com.tap4fun.galaxyempire2_android_local"] = true,
  ["com.tap4fun.galaxyempire2_android.platform.qihoo360"] = true,
  ["com.tap4fun.galaxyempire2_android.platform.uc"] = true,
  ["com.tap4fun.galaxyempire2_android.platform.BD"] = true,
  ["com.tap4fun.galaxyempire2_android_taptap"] = true
}
GameUtils.WorldPack = {
  ["com.tap4fun.galaxyempire2"] = true,
  ["com.tap4fun.galaxyempire2_android"] = true,
  ["com.tap4fun.galaxyempire2_android_cafe"] = true,
  ["com.tap4fun.galaxyempire2_android_amazon"] = true,
  ["com.ts.galaxyempire2_android_global"] = true,
  ["com.tap4fun.galaxyempire2_android_mycard"] = true,
  ["com.tap4fun.galaxyempire2_android_mobogenie"] = true
}
function GameUtils:IsSpaceLancer()
  local localAppid = ext.GetBundleIdentifier()
  return localAppid == "com.ts.spacelancer"
end
function GameUtils:CanLoginByAppid(registAppid, localAppid)
  if GameUtils.IOSWorld[registAppid] == true and GameUtils.IOSWorld[localAppid] == true then
    return true
  end
  if GameUtils.IOSChinese[registAppid] == true and GameUtils.IOSChinese[localAppid] == true then
    return true
  end
  if GameUtils.AndroidWorld[registAppid] == true and GameUtils.AndroidWorld[localAppid] == true then
    return true
  end
  if GameUtils.AndroidChinese[registAppid] == true and GameUtils.AndroidChinese[localAppid] == true then
    return true
  end
  return false
end
function GameUtils:ShowErrorLoginInfo(registAppid, localAppid)
  local GameUIMessageDialog = LuaObjectManager:GetLuaObject("GameUIMessageDialog")
  local isAndroidReg = string.find(registAppid, "android")
  local isAndroidLoc = string.find(localAppid, "android")
  if isAndroidReg == isAndroidLoc then
    local function callback()
      ext.http.openURL(GameUtils.AppDownLoadURL[registAppid])
    end
    local text_title = GameLoader:GetGameText("LC_MENU_TITLE_VERIFY")
    GameUIMessageDialog:SetStyle(GameUIMessageDialog.DialogStyle.Caption)
    GameUIMessageDialog:SetLeftTextButton(GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_CANCEL"), nil, {})
    GameUIMessageDialog:SetRightTextButton(GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_CONFIRM"), callback, {})
    GameUIMessageDialog:Display(text_title, GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_MSG"))
  else
    local function callback()
      if GameUtils.WorldPack[registAppid] then
        ext.http.openURL("http://download.gl.tap4fun.com/")
      else
        ext.http.openURL("http://yh.t4f.cn/")
      end
    end
    local text_title = GameLoader:GetGameText("LC_MENU_TITLE_VERIFY")
    GameUIMessageDialog:SetStyle(GameUIMessageDialog.DialogStyle.Caption)
    GameUIMessageDialog:SetLeftTextButton(GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_CANCEL"), nil, {})
    GameUIMessageDialog:SetRightTextButton(GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_CONFIRM"), callback, {})
    GameUIMessageDialog:Display(text_title, GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_MSG"))
  end
end
function GameUtils:ShowVersonError(localAppid)
  local GameUIMessageDialog = LuaObjectManager:GetLuaObject("GameUIMessageDialog")
  local function callback()
    ext.http.openURL(GameUtils.AppDownLoadURL[localAppid])
  end
  local text_title = GameLoader:GetGameText("LC_MENU_TITLE_VERIFY")
  GameUIMessageDialog:SetStyle(GameUIMessageDialog.DialogStyle.Caption)
  GameUIMessageDialog:SetLeftTextButton(GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_CANCEL"), nil, {})
  GameUIMessageDialog:SetRightTextButton(GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_CONFIRM"), callback, {})
  GameUIMessageDialog:Display(text_title, GameLoader:GetGameText("LC_MENU_GET_RIGHT_VERSION_INFO_1"))
end
function GameUtils:GetNeedSpeed()
  local localAppid = ext.GetBundleIdentifier()
  local speedList = {
    [AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_CN] = true,
    [AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_LOCAL] = true,
    [AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_PLATFORM_QIHOO] = true
  }
  local code = "UN"
  code = string.lower(ext.GetDeviceLanguage())
  if speedList[localAppid] then
    return true
  elseif localAppid == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID and (code == "pt" or code == "pt_br") then
    return true
  elseif localAppid == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_SPACELANCER and (code == "pt" or code == "pt_br") then
    return true
  elseif localAppid == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_GLOBAL and (code == "pt" or code == "pt_br") then
    return true
  end
  return false
end
function GameUtils:GetLeftNumFromOSVersion(ver)
  if ver == nil or ver == "" or string.sub(ver, 1, 1) == "." then
    return nil
  end
  local vers = LuaUtils:string_split(ver, ".")
  if #vers == 0 then
    return nil
  end
  if type(tonumber(vers[1])) ~= "number" then
    return nil
  else
    return tonumber(vers[1])
  end
end
CountryCodeMapFlag = {
  UN = "flag_unknown",
  RU = "flag_01",
  US = "flag_02",
  DE = "flag_03",
  FR = "flag_04",
  KR = "flag_06",
  VN = "flag_07",
  GB = "flag_08",
  MX = "flag_10",
  CA = "flag_11",
  ID = "flag_15",
  IN = "flag_16",
  TW = "flag_18",
  MY = "flag_19",
  JP = "flag_21",
  CO = "flag_27",
  ES = "flag_28",
  AU = "flag_33",
  HK = "flag_34",
  CN = "flag_38",
  MO = "flag_39"
}
function GameUtils:GetFlagByCountryCode()
  local code = "UN"
  if AutoUpdate.isAndroidDevice then
    code = ext.GetDeviceCountry()
  else
    code = ext.GetCountryCode()
  end
  DebugOut("GameUtils:GetFlagByCountryCode:", code)
  GameUtils:printByAndroid("GameUtils:GetFlagByCountryCode:" .. code)
  local flag = CountryCodeMapFlag[code]
  if GameUtils:IsChinese() and (code == "TW" or code == "CN" or code == "HK" or code == "MO") then
    flag = CountryCodeMapFlag.CN
  end
  if flag == nil then
    flag = "flag_unknown"
  end
  return flag
end
function GameUtils:SyncServerInfo(callback)
  local loginInfo = GameUtils:GetLoginInfo()
  local AccountInfo
  AccountInfo = loginInfo.AccountInfo
  local function servercallback(content)
    for k, v in ipairs(content.servers) do
      if v.server.logic_id == loginInfo.ServerInfo.logic_id then
        loginInfo.ServerInfo = v.server
        if GameSettingData.LastLogin == nil then
          GameSettingData.LastLogin = {}
        end
        GameSettingData.LastLogin.ServerInfo = loginInfo.ServerInfo
        GameSettingData.LastLogin.LastLoginSuccess = false
        GameUtils:SaveSettingData()
        break
      end
    end
    if callback then
      callback()
    end
  end
  GameUtils:RequestServerList(AccountInfo, servercallback, nil)
end
function GameUtils:SavePhoneInfo()
  local versionCode = -1
  if ext.GetVersionCode then
    versionCode = ext.GetVersionCode()
  end
  if ext.GetDeviceInfo then
    ret1, ret2 = ext.GetDeviceInfo()
  end
  local google_aid = ""
  if LuaUtils:string_startswith(ret2, "3") then
    google_aid = string.sub(ret2, 2)
  end
  local param = {}
  param.version_code = tostring(versionCode)
  param.phone_info = {}
  local item = {}
  item.str_key = "is_simulator"
  item.str_value = ext.GetIsSimulator and ext.GetIsSimulator() or "-1"
  param.phone_info[#param.phone_info + 1] = item
  local item2 = {}
  item2.str_key = "idfa"
  item2.str_value = ext.GetIDFA and ext.GetIDFA() or ""
  param.phone_info[#param.phone_info + 1] = item2
  local item3 = {}
  item3.str_key = "google_aid"
  item3.str_value = google_aid
  param.phone_info[#param.phone_info + 1] = item3
  local item4 = {}
  item4.str_key = "android_id"
  item4.str_value = ext.GetAndroidId and ext.GetAndroidId() or ""
  param.phone_info[#param.phone_info + 1] = item4
  local item5 = {}
  item5.str_key = "device_id"
  item5.str_value = ext.GetDeviceID and ext.GetDeviceID() or ""
  param.phone_info[#param.phone_info + 1] = item5
  local item6 = {}
  item6.str_key = "mac_address"
  item6.str_value = ext.GetIOSMacAddress and ext.GetIOSMacAddress() or ""
  param.phone_info[#param.phone_info + 1] = item6
  local item7 = {}
  item7.str_key = "latitude"
  item7.str_value = ext.GetLatitude and ext.GetLatitude() or "9999"
  param.phone_info[#param.phone_info + 1] = item7
  local item8 = {}
  item8.str_key = "longitude"
  item8.str_value = ext.GetLongitude and ext.GetLongitude() or "9999"
  param.phone_info[#param.phone_info + 1] = item8
  local item9 = {}
  item9.str_key = "altitude"
  item9.str_value = ext.GetAltitude and ext.GetAltitude() or "9999"
  param.phone_info[#param.phone_info + 1] = item9
  local item10 = {}
  item10.str_key = "network_type"
  item10.str_value = ext.GetNetworkType and ext.GetNetworkType() or "wifi"
  param.phone_info[#param.phone_info + 1] = item10
  local item11 = {}
  item11.str_key = "third_part_device_id"
  item11.str_value = ext.GetThirdPartDeviceId and ext.GetThirdPartDeviceId() or ""
  param.phone_info[#param.phone_info + 1] = item11
  local item12 = {}
  item12.str_key = "app_version"
  item12.str_value = ext.GetAppVersion and ext.GetAppVersion() or ""
  NetMessageMgr:SendMsg(NetAPIList.version_info_req.Code, param, nil, false, nil)
end
function GameUtils:URLIsHTTPS(url)
  if url then
    if string.find(url, "portal-platform") then
      return true
    else
      return false
    end
  else
    return false
  end
end
GameUtils.Tongdui_records = {}
function GameUtils:RecordForTongdui(code, content, callback, iswaiting, failedcallback)
  for i = #GameUtils.Tongdui_records, 1, -1 do
    if GameUtils.Tongdui_records[i].code == code then
      table.remove(GameUtils.Tongdui_records, i)
    end
  end
  local t = {
    code = code,
    content = content,
    callback = callback,
    iswaiting = iswaiting,
    failedcallback = failedcallback
  }
  table.insert(GameUtils.Tongdui_records, t)
end
function GameUtils:RecordForTongdui_onuser_cancel(code, cacelcallback)
  local oldinfo
  for k, v in pairs(GameUtils.Tongdui_records) do
    if v.code == code then
      oldinfo = v
      break
    end
  end
  assert(oldinfo, "must have info " .. code)
  oldinfo.user_cancelcallback = cacelcallback
end
function GameUtils.NtfTongdui(content)
  local oldAPI = content.api
  assert(oldAPI)
  local oldinfo
  for k, v in pairs(GameUtils.Tongdui_records) do
    if v.code == oldAPI then
      oldinfo = v
      break
    end
  end
  assert(oldinfo, "must have info " .. oldAPI .. LuaUtils:serializeTable(GameUtils.Tongdui_records))
  local GameHelper = LuaObjectManager:GetLuaObject("GameHelper")
  local itemName = GameHelper:GetAwardNameText(content.item.item_type, content.item.number)
  local itemIcon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(content.item)
  local str = string.gsub(GameLoader:GetGameText("LC_MENU_LACK_OF_RESOURCES"), "<name1>", itemName)
  local infoText = string.gsub(str, "<name2>", content.credit)
  local function _confirm_exchange_callback(msgType, content)
    if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.confirm_exchange_req.Code then
      local GameUICollect = LuaObjectManager:GetLuaObject("GameUICollect")
      if content.code == 135 and not GameUICollect:CheckTutorialCollect(content.code) then
        local GameVip = LuaObjectManager:GetLuaObject("GameVip")
        GameVip:CheckIsNeedShowVip(content.code)
      elseif content.code == 0 then
        NetMessageMgr:SendMsg(oldinfo.code, oldinfo.content, oldinfo.callback, oldinfo.iswaiting, oldinfo.failedcallback)
      elseif oldAPI == NetAPIList.buy_scratch_card_req.Code then
        local GameVip = LuaObjectManager:GetLuaObject("GameVip")
        GameVip:CheckIsNeedShowVip(content.code)
      end
      return true
    end
    return false
  end
  local oldv = NetMessageMgr:RemoveMsg(oldAPI)
  local function _onCreditconfirm1()
    local function _newBuy()
      local param = {
        api = oldAPI,
        item = {
          content.item
        }
      }
      NetMessageMgr:SendMsg(NetAPIList.confirm_exchange_req.Code, param, _confirm_exchange_callback, true, nil)
    end
    local tongduitxt = GameUtils:TryGetText("LC_MENU_TONGDUI_TIP1", "<item1>not, <number>credit")
    tongduitxt = string.gsub(tongduitxt, "<item1>", itemName)
    tongduitxt = string.gsub(tongduitxt, "<number>", content.credit)
    GameUtils:CreditCostConfirm(tongduitxt, _newBuy, false, oldinfo.user_cancelcallback)
  end
  local ItemBox = LuaObjectManager:GetLuaObject("ItemBox")
  local itemNum = content.item.number
  if content.item.item_type == "item" then
    itemNum = content.item.no
  end
  ItemBox:ShowCreditconfirm1(infoText, itemIcon, itemNum, nil, nil, content.credit, _onCreditconfirm1)
end
GameUtils.multi_Tongdui_records = {}
function GameUtils:RecordForMultiTongdui(code, content, callback, iswaiting, failedcallback)
  for i = #GameUtils.multi_Tongdui_records, 1, -1 do
    if GameUtils.multi_Tongdui_records[i].code == code then
      table.remove(GameUtils.multi_Tongdui_records, i)
    end
  end
  local t = {
    code = code,
    content = content,
    callback = callback,
    iswaiting = iswaiting,
    failedcallback = failedcallback
  }
  table.insert(GameUtils.multi_Tongdui_records, t)
end
function GameUtils.NtfMultiTongdui(content)
  local oldAPI = content.api
  assert(oldAPI)
  local oldinfo
  for k, v in pairs(GameUtils.multi_Tongdui_records) do
    if v.code == oldAPI then
      oldinfo = v
      break
    end
  end
  assert(oldinfo, "must have info " .. oldAPI .. LuaUtils:serializeTable(GameUtils.multi_Tongdui_records))
  local GameHelper = LuaObjectManager:GetLuaObject("GameHelper")
  local itemName = GameHelper:GetAwardNameText(content.exchange[1].item.item_type, content.exchange[1].item.number)
  local itemIcon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(content.exchange[1].item)
  local itemName2 = GameHelper:GetAwardNameText(content.exchange[2].item.item_type, content.exchange[2].item.number)
  local itemIcon2 = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(content.exchange[2].item)
  local allcredit = content.exchange[1].credit + content.exchange[2].credit
  local infoText = GameUtils:TryGetText("LC_MENU_BUY_ITEM2_TIP", "<item1>/<item2> not, need <number> credit")
  local infoText = string.gsub(infoText, "<item1>", itemName)
  local infoText = string.gsub(infoText, "<item2>", itemName2)
  local infoText = string.gsub(infoText, "<number>", allcredit)
  local function _confirm_exchange_callback(msgType, content)
    if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.confirm_exchange_req.Code then
      local GameUICollect = LuaObjectManager:GetLuaObject("GameUICollect")
      if content.code == 135 and not GameUICollect:CheckTutorialCollect(content.code) then
        local GameVip = LuaObjectManager:GetLuaObject("GameVip")
        GameVip:CheckIsNeedShowVip(content.code)
      elseif content.code == 0 then
        NetMessageMgr:SendMsg(oldinfo.code, oldinfo.content, oldinfo.callback, oldinfo.iswaiting, oldinfo.failedcallback)
      elseif oldAPI == NetAPIList.buy_scratch_card_req.Code then
        local GameVip = LuaObjectManager:GetLuaObject("GameVip")
        GameVip:CheckIsNeedShowVip(content.code)
      end
      return true
    end
    return false
  end
  local oldv = NetMessageMgr:RemoveMsg(oldAPI)
  local function _onCreditconfirm1()
    local function _newBuy()
      local param = {
        api = oldAPI,
        item = {
          content.exchange[1].item,
          content.exchange[2].item
        }
      }
      NetMessageMgr:SendMsg(NetAPIList.confirm_exchange_req.Code, param, _confirm_exchange_callback, true, nil)
    end
    local tongduitxt = GameUtils:TryGetText("LC_MENU_TONGDUI_TIP2", "<item1>/<item2> not, <number>credit")
    tongduitxt = string.gsub(tongduitxt, "<item1>", itemName)
    tongduitxt = string.gsub(tongduitxt, "<item2>", itemName2)
    tongduitxt = string.gsub(tongduitxt, "<number>", allcredit)
    GameUtils:CreditCostConfirm(tongduitxt, _newBuy, false, oldinfo.user_cancelcallback)
  end
  local ItemBox = LuaObjectManager:GetLuaObject("ItemBox")
  local itemNum = content.exchange[1].item.number
  if content.exchange[1].item.item_type == "item" then
    itemNum = content.exchange[1].item.no
  end
  local itemNum2 = content.exchange[2].item.number
  if content.exchange[2].item.item_type == "item" then
    itemNum = content.exchange[2].item.no
  end
  ItemBox:ShowCreditconfirm1(infoText, itemIcon, itemNum, itemIcon2, itemNum2, allcredit, _onCreditconfirm1)
end
function GameUtils:LogFirebaseEvent(eventName, eventParam)
  if ext.LogFirebaseEvent then
    ext.LogFirebaseEvent(eventName, eventParam)
  end
end
function GameUtils:TryGetText(strkey, default)
  assert(strkey)
  local str = GameLoader:GetGameText(strkey)
  if not str or #str == 0 then
    return default or strkey
  end
  return str
end
function GameUtils:ReqReDownloadRes()
  local callback = function(msgType, content)
    if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.redownload_res_req.Code then
      return true
    elseif msgType == NetAPIList.redownload_res_ack.Code then
      for k, v in ipairs(content.res_list) do
        GameUtils:AddDownLoadRes(v.str_key, v.str_value)
      end
      return true
    end
    return false
  end
  NetMessageMgr:SendMsg(NetAPIList.redownload_res_req.Code, nil, callback, false, nil)
end
function GameUtils:AddDownLoadRes(resType, resName)
  if resType == "avatar" then
    GameDataAccessHelper:CheckFleetHasAvataImage(resName)
  elseif resType == "fleet" then
    GameDataAccessHelper:CheckHasShipImage(resName)
  elseif resType == "item" then
    local fullFileName = DynamicResDownloader:GetFullName(resName, DynamicResDownloader.resType.PIC)
    local localPath = "data2/" .. fullFileName
    if DynamicResDownloader:IfResExsit(localPath) then
      ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
    else
      DynamicResDownloader:AddDynamicRes(resName, DynamicResDownloader.resType.PIC, nil, nil)
    end
  else
    local fullFileName = DynamicResDownloader:GetFullName(resName, DynamicResDownloader.resType.WELCOME_PIC)
    local localPath = "data2/" .. fullFileName
    if not ext.crc32.crc32(localPath) or ext.crc32.crc32(localPath) == "" then
      DynamicResDownloader:AddDynamicRes(resName, DynamicResDownloader.resType.WELCOME_PIC, nil, nil)
    end
  end
end
function GameUtils:GetAttrName(attr_id)
  return GameLoader:GetGameText("LC_MENU_Equip_param_" .. ((attr_id < 19 or attr_id > 22) and attr_id or attr_id + 2))
end
function GameUtils:GetAttrValue(attr_id, attr_value)
  if attr_id == 19 or attr_id == 20 or attr_id == 21 or attr_id == 22 or attr_id == 37 then
    local ret = attr_value / 1000 * 100
    ret = self:keepTwoDecimalPlaces(ret)
    return string.format("%0.2f", ret) .. "%"
  else
    return attr_value
  end
end
function GameUtils:keepTwoDecimalPlaces(decimal)
  decimal = decimal * 100
  decimal = decimal % 1 >= 0.499 and math.ceil(decimal) or math.floor(decimal)
  return decimal * 0.01
end
function GameUtils:GetCommonIcon_dataExtra(strpic, extInfo, callback)
  local fullFileName = strpic
  local localPath = "data2/LAZY_LOAD_dynamic_" .. fullFileName
  if DynamicResDownloader:IfResExsit(localPath) then
    ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
  else
    local extInfo = {}
    extInfo.localPath = "data2/LAZY_LOAD_dynamic_" .. strpic
    DynamicResDownloader:AddDynamicRes(strpic, DynamicResDownloader.resType.PIC, extInfo, callback)
    print("xxpp commonicon1", extInfo.localPath)
    return "empty"
  end
end
function GameUtils:GetCommonIcon_textureup(strpic, extInfo, callback)
  local fullFileName = strpic
  local localPath = "data2/LAZY_LOAD_dynamic_" .. fullFileName
  local isok, str = AutoUpdateInBackground:IsHeroFileUpdatedToServer(localPath, callback, extInfo)
  print("xxpp commonicon4", localPath, isok, str or "nil")
  if isok then
  else
    return "empty"
  end
end
function GameUtils:OnFSCommand(cmd, arg, uilua)
  if cmd == "CommonIcon" then
    do
      local mcpath, frame, picname, isextpng = unpack(LuaUtils:string_split(arg, "|"))
      DebugOut("GameUtils:OnFSCommand", mcpath, frame, picname, isextpng)
      local function func(extInfo)
        local flash_obj = uilua:GetFlashObject()
        if flash_obj then
          flash_obj:InvokeASCallback("_root", "SetCommonIconsDownloaded", extInfo.mcpath, extInfo.frame)
        end
        print("xxpp commonicon2", frame)
      end
      local defaultframe
      if isextpng then
        defaultframe = GameUtils:GetCommonIcon_dataExtra(picname, nil, func)
      else
        local extInfo = {mcpath = mcpath, frame = frame}
        defaultframe = GameUtils:GetCommonIcon_textureup(picname, extInfo, func)
      end
      if defaultframe then
        local flash_obj = uilua:GetFlashObject()
        if flash_obj then
          flash_obj:InvokeASCallback("_root", "SetCommonIconsDownloaded", mcpath, defaultframe)
        end
        print("xxpp commonicon3", defaultframe)
      end
      return true
    end
  end
end
