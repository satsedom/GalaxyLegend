local enhance = GameData.heros.enhance
table.insert(enhance, {
  ID = 1,
  LEVEL = 1,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 2,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 3,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 4,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 5,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 6,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 7,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 8,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 9,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 10,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 11,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 12,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 13,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 14,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 15,
  vessels = 6
})
table.insert(enhance, {
  ID = 1,
  LEVEL = 16,
  vessels = 6
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 2,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 3,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 4,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 5,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 6,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 7,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 8,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 9,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 10,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 11,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 12,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 13,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 14,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 15,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 16,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 17,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 18,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 19,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 20,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 21,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 22,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 1,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 2,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 3,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 4,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 5,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 6,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 7,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 8,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 9,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 10,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 11,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 12,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 13,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 14,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 15,
  vessels = 6
})
table.insert(enhance, {
  ID = 102,
  LEVEL = 16,
  vessels = 6
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 103,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 104,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 105,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 106,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 111,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 112,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 113,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 114,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 115,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 116,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 117,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 118,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 119,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 120,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 121,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 122,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 123,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 124,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 125,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 126,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 127,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 128,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 129,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 130,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 131,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 132,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 133,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 134,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 135,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 136,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 137,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 138,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 139,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 140,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 141,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 142,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 143,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 144,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 145,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 146,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 147,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 148,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 149,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 150,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 151,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 152,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 153,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 154,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 155,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 156,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 157,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 158,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 159,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 160,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 161,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 162,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 163,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 164,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 165,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 166,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 167,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 168,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 169,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 170,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 171,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 172,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 173,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 174,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 175,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 176,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 177,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 178,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 179,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 180,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 181,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 182,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 183,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 184,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 185,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 186,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 187,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 188,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 189,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 190,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 191,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 192,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 193,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 194,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 195,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 196,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 197,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 198,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 199,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 200,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 202,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 203,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 205,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 206,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 207,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 208,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 209,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 210,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 211,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 212,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 213,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 214,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 215,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 301,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 302,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 303,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 304,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 305,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 306,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 307,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 308,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 309,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 310,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 311,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 312,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 313,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 314,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 315,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 316,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 317,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 318,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 319,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 320,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 321,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 322,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 323,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 324,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 325,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 326,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 327,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 328,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 329,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 330,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 331,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 332,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 333,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 334,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 335,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 336,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 337,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 338,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 339,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 340,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 341,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 342,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 343,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 344,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 345,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 346,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 347,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 348,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 349,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 350,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 1,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 2,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 3,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 4,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 5,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 6,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 7,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 8,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 9,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 10,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 11,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 12,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 13,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 14,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 15,
  vessels = 6
})
table.insert(enhance, {
  ID = 351,
  LEVEL = 16,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 1,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 2,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 3,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 4,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 5,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 6,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 7,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 8,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 9,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 10,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 11,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 12,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 13,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 14,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 15,
  vessels = 6
})
table.insert(enhance, {
  ID = 352,
  LEVEL = 16,
  vessels = 6
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 353,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 354,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 355,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 356,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 357,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 358,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 359,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 360,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 361,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 362,
  LEVEL = 16,
  vessels = 2
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 363,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 1,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 2,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 3,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 4,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 5,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 6,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 7,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 8,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 9,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 10,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 11,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 12,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 13,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 14,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 15,
  vessels = 6
})
table.insert(enhance, {
  ID = 364,
  LEVEL = 16,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 1,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 2,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 3,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 4,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 5,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 6,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 7,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 8,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 9,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 10,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 11,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 12,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 13,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 14,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 15,
  vessels = 6
})
table.insert(enhance, {
  ID = 365,
  LEVEL = 16,
  vessels = 6
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 366,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 1,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 2,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 3,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 4,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 5,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 6,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 7,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 8,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 9,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 10,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 11,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 12,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 13,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 14,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 15,
  vessels = 3
})
table.insert(enhance, {
  ID = 367,
  LEVEL = 16,
  vessels = 3
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 1,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 2,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 3,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 4,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 5,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 6,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 7,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 8,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 9,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 10,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 11,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 12,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 13,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 14,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 15,
  vessels = 4
})
table.insert(enhance, {
  ID = 368,
  LEVEL = 16,
  vessels = 4
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 1,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 2,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 3,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 4,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 5,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 6,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 7,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 8,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 9,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 10,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 11,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 12,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 13,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 14,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 15,
  vessels = 5
})
table.insert(enhance, {
  ID = 369,
  LEVEL = 16,
  vessels = 5
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 1,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 2,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 3,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 4,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 5,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 6,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 7,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 8,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 9,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 10,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 11,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 12,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 13,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 14,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 15,
  vessels = 1
})
table.insert(enhance, {
  ID = 370,
  LEVEL = 16,
  vessels = 1
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 1,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 2,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 3,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 4,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 5,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 6,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 7,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 8,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 9,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 10,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 11,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 12,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 13,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 14,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 15,
  vessels = 2
})
table.insert(enhance, {
  ID = 371,
  LEVEL = 16,
  vessels = 2
})
