local GameStateTouchEffect = GameStateManager.GameStateTouchEffect
GameStateTouchEffect.ObjectStack = {}
function GameStateTouchEffect:AddObject(luaobject)
  if #self.ObjectStack == 0 then
    table.insert(self.ObjectStack, luaobject)
  end
  GameStateBase.AddObject(self, luaobject)
  DebugOut("GameStateTouchEffect:AddObject", #self.ObjectStack)
end
function GameStateTouchEffect:OnTouchPressed(x, y)
  GameStateBase.OnTouchPressed(self, x, y)
  return false
end
function GameStateTouchEffect:OnTouchReleased(x, y)
  GameStateBase.OnTouchReleased(self, x, y)
  return false
end
function GameStateTouchEffect:OnTouchMoved(x, y)
  GameStateBase.OnTouchMoved(self, x, y)
  return false
end
