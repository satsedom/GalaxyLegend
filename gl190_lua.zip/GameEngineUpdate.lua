print("----------------Lua world is Run--------------!")
local require = require
if AutoUpdate.destIpAddrPool[1] == "a.portal-platform.tap4fun.com/gl/url_get/dev/dev1/" or string.find(AutoUpdate.destIpAddrPool[1], "54.201.12.25") then
  AutoUpdate.isTestGW = true
end
if AutoUpdate.isTestGW then
  do
    local printByAndroid = function(...)
      local t = {
        ...
      }
      for k, v in pairs(t) do
        t[k] = tostring(v)
      end
      local content = table.concat(t, ",")
      if AutoUpdate.isAndroidDevice then
        ext.__debugLog(content)
      end
    end
    local function _loadLuaFiles()
      local file = io.open(ext.GetDocPath() .. "luatest/files.lua", "r")
      if file then
        local str = file:read("*a")
        file:close()
        loadstring(str)()
        for v, _ in pairs(g_luafiles) do
          print("xxpp lua udid ", v)
          printByAndroid("xxpp lua udid ", v)
        end
      end
    end
    _loadLuaFiles()
    if g_luafiles then
      do
        local luafiles_to_replace = g_luafiles[ext.GetIOSOpenUdid()] or {}
        if luafiles_to_replace then
          do
            local g_require = require
            function require(fname, ...)
              if not luafiles_to_replace[fname] then
                g_require(fname)
                return
              end
              local _, _, fpath = string.find(fname, "/(.*)%.tfl")
              if not fpath then
                print("xxpp lua2 ", fname)
                printByAndroid("xxpp lua2 ", fname)
                g_require(fname)
                return
              end
              fpath = string.format("%sluatest/%s.lua", ext.GetDocPath(), fpath)
              file = io.open(fpath, "r")
              if not file then
                print("xxpp lua3 ", fname)
                printByAndroid("xxpp lua3 ", fname)
                g_require(fname)
                return
              end
              local str = file:read("*a")
              file:close()
              print("xxpp lua ok ", fname)
              printByAndroid("xxpp lua ok ", fname)
              loadstring(str)()
            end
          end
        end
      end
    end
    ext.http.requestDownload({
      "http://172.20.133.3:8000/files.lua",
      method = "GET",
      localpath = "luatest/" .. "files.lua",
      callback = function(statusCode, content, errstr)
        _loadLuaFiles()
        if g_luafiles then
          local luafiles_to_replace = g_luafiles[ext.GetIOSOpenUdid()] or {}
          for v, _ in pairs(luafiles_to_replace) do
            local _, _, fpath = string.find(v, "/(.*)%.tfl")
            if fpath then
              ext.http.requestDownload({
                "http://172.20.133.3:8000/" .. fpath .. ".lua",
                method = "GET",
                localpath = "luatest/" .. fpath .. ".lua",
                callback = function(statusCode, content, errstr)
                  print("xxpp download ", v)
                  printByAndroid("xxpp download ", v)
                end
              })
            else
              print("xxpp luaerr 1 ", v)
              printByAndroid("xxpp luaerr 1 ", v)
            end
          end
        end
      end
    })
  end
else
  function print(...)
  end
end
require("data1/GL_lua_class.tfl")
require("data1/DebugConfig.tfl")
require("data1/FlurryInterface.tfl")
require("data1/GlobalConfig.tfl")
require("data1/AutoUpdateInBackground.tfl")
require("data1/BattleEffectManager.tfl")
require("data1/LuaUtils.tfl")
require("data1/GameUtils.tfl")
require("data1/GameTimer.tfl")
require("data1/GameCheat.tfl")
require("data1/DeviceAutoConfig.tfl")
require("data1/Emoji.tfl")
require("data1/Translation.tfl")
require("data1/FacebookGraphStorySharer.tfl")
require("data1/EventLogInterface.tfl")
require("data1/AlertDataList.tfl")
require("data1/TutorialQuestManager.tfl")
require("data1/LuaObject.tfl")
require("data1/Facebook.tfl")
require("data1/GameStateBase.tfl")
require("data1/RegisterAllLuaObject.tfl")
require("data1/GameStateManager.tfl")
require("data1/GameGlobalData.tfl")
require("data1/GameTextEdit.tfl")
require("data1/NetMessageMgr.tfl")
require("data1/GameNotice.tfl")
require("data1/GameObjectMainPlanet.tfl")
require("data1/GameSectionSelect.tfl")
require("data1/GameObjectFormationBackground.tfl")
require("data1/GameObjectDragger.tfl")
require("data1/GameAndroidBackManager.tfl")
require("data1/GameStateLoading.tfl")
require("data1/GameStateMainPlanet.tfl")
require("data1/GameStateCampaignSelection.tfl")
require("data1/GameStateFormation.tfl")
require("data1/GameStateBattlePlay.tfl")
require("data1/GameStateRecruit.tfl")
require("data1/GameStateFactory.tfl")
require("data1/GameStateAlliance.tfl")
require("data1/GameStateFleetInfo.tfl")
require("data1/GameStateEquipEnhance.tfl")
require("data1/GameStateAffairInfo.tfl")
require("data1/GameStateConfrontation.tfl")
require("data1/GameStateKrypton.tfl")
require("data1/GameStateTrade.tfl")
require("data1/GameStateStore.tfl")
require("data1/GameStateInstance.tfl")
require("data1/GameStateTouchEffect.tfl")
require("data1/GameStateLargeMap.tfl")
require("data1/GameStateColonization.tfl")
require("data1/GameStateWD.tfl")
require("data1/GameStateBattleMap.tfl")
require("data1/GameStatePlayerMatrix.tfl")
require("data1/GameStateMineMap.tfl")
require("data1/GameStateGacha.tfl")
require("data1/GameStateToprank.tfl")
require("data1/GameStateArcane.tfl")
require("data1/GameStateAccountSelect.tfl")
require("data1/GameStateGlobal.tfl")
require("data1/GameStateItem.tfl")
require("data1/GameStateWorldBoss.tfl")
require("data1/GameStateConsortium.tfl")
require("data1/GameStateDaily.tfl")
require("data1/GameStateDebug.tfl")
require("data1/GameStateStarCraft.tfl")
require("data1/GameStateLab.tfl")
require("data1/GameStateWorldChampion.tfl")
require("data1/GameStateHeroHandbook.tfl")
require("data1/GameStateWVE.tfl")
require("data1/GameStateTacticsCenter.tfl")
require("data1/GameStateDice.tfl")
require("data1/GameStateMiningWorld.tfl")
require("data1/GameStateScratchGacha.tfl")
require("data1/GameObjectBattleMapBG.tfl")
require("data1/GameObjectBattleMap.tfl")
require("data1/GameUIBarRight.tfl")
require("data1/GameUIBarMiddle.tfl")
require("data1/GameUIBarLeft.tfl")
require("data1/NewsTip.tfl")
require("data1/GameUIBuilding.tfl")
require("data1/GameUIBuildingInfo.tfl")
require("data1/GameUITechnology.tfl")
require("data1/GameUICollect.tfl")
require("data1/GameUIMessageDialog.tfl")
require("data1/GameUIRecruitMain.tfl")
require("data1/GameUIRecruitTopbar.tfl")
require("data1/GameUIRecruitWarpgate.tfl")
require("data1/GameObjectBattleReplay.tfl")
require("data1/GameObjectBattleBG.tfl")
require("data1/GameUIAffairHall.tfl")
require("data1/GameUIFactory.tfl")
require("data1/GameUIUnalliance.tfl")
require("data1/GameUIAllianceInfo.tfl")
require("data1/GameUIUserAlliance.tfl")
require("data1/GameUIAllianceList.tfl")
require("data1/GameUIPlayerView.tfl")
require("data1/GameUIAchievement.tfl")
require("data1/GameUIPrestige.tfl")
require("data1/GameUISection.tfl")
require("data1/GameStateSetting.tfl")
require("data1/GameObjectTutorialCutscene.tfl")
require("data1/GameUIGlobalScreen.tfl")
require("data1/GameUICommonDialog.tfl")
require("data1/GameUIChat.tfl")
require("data1/GameUIFriend.tfl")
require("data1/GameObjectAdventure.tfl")
require("data1/GameObjectClimbTower.tfl")
require("data1/GameUIArena.tfl")
require("data1/GameUIOfflineReward.tfl")
require("data1/GameUITap4funAccount.tfl")
require("data1/GameObjectShakeScreen.tfl")
require("data1/GameStateArena.tfl")
require("data1/GameFleetInfoBag.tfl")
require("data1/GameFleetInfoBackground.tfl")
require("data1/GameFleetNewEnhance.tfl")
require("data1/GameFleetInfoTabBar.tfl")
require("data1/GameObjectLevelUp.tfl")
require("data1/GameUIEvent.tfl")
require("data1/GameObjectGacha.tfl")
require("data1/GameObjectToprank.tfl")
require("data1/GameObjectArcaneMap.tfl")
require("data1/GameObjectArcaneEnhance.tfl")
require("data1/GameObjectWelcome.tfl")
require("data1/GameUIHalfPortrait.tfl")
require("data1/GameMail.tfl")
require("data1/GameTip.tfl")
require("data1/ItemBox.tfl")
require("data1/GameSetting.tfl")
require("data1/DynamicResDownloader.tfl")
require("data1/GameGoodsList.tfl")
require("data1/GameGoodsBuyBox.tfl")
require("data1/masterAchievementTips.tfl")
require("data1/GameUISectionFinish.tfl")
require("data1/GameTradeTabBar.tfl")
require("data1/GameItemBag.tfl")
require("data1/GameUIEnemyInfo.tfl")
require("data1/GameUIArcaneEnemyInfo.tfl")
require("data1/GameUIBattleResult.tfl")
require("data1/GameUIKrypton.tfl")
require("data1/GameHelper.tfl")
require("data1/GameRush.tfl")
require("data1/GameCommonBackground.tfl")
require("data1/GameDebugBox.tfl")
require("data1/GameUIColonial.tfl")
require("data1/GameUISlaveSelect.tfl")
require("data1/GameUIColonialMenu.tfl")
require("data1/GameUICommonEvent.tfl")
require("data1/GameCommonGoodsList.tfl")
require("data1/GameCommonBuyBox.tfl")
require("data1/GameWDAttkBox.tfl")
require("data1/GameUIWDPlanetSelect.tfl")
require("data1/GameUIWDDefence.tfl")
require("data1/GameUIWDInBattle.tfl")
require("data1/GameUIWDEnemyScene.tfl")
require("data1/GameUIWDStuff.tfl")
require("data1/GameUIWebView.tfl")
require("data1/GameUIRechargePush.tfl")
require("data1/GameVip.tfl")
require("data1/GameObjectAwardCenter.tfl")
require("data1/GameNews.tfl")
require("data1/Webview.tfl")
require("data1/GameNewMenuItem.tfl")
require("data1/GameQuestMenu.tfl")
require("data1/GameUIPrestigeRankUp.tfl")
require("data1/GameObjectPlayerMatrix.tfl")
require("data1/GameUIPlayerDetailInfo.tfl")
require("data1/GameObjectMineMap.tfl")
require("data1/GameUILab.tfl")
require("data1/GameObjectBuyBack.tfl")
require("data1/GameObjectAllianceDonation.tfl")
require("data1/GameObjectCosmicExpedition.tfl")
require("data1/GameAccountSelector.tfl")
require("data1/GameUIActivity.tfl")
require("data1/GameUIActivityNew.tfl")
require("data1/GameWaiting.tfl")
require("data1/GameObjectWorldBoss.tfl")
require("data1/GameObjectFakeBattle.tfl")
require("data1/NetMessageHandler.tfl")
require("data1/DebugCommand.tfl")
require("data1/GameUIRebuildFleet.tfl")
require("data1/GamePushNotification.tfl")
require("data1/GameUISevenBenefit.tfl")
require("data1/GameUIStarCraftMap.tfl")
require("data1/GameUIFleetGrowUp.tfl")
require("data1/GameUIWorldChampion.tfl")
require("data1/GameUIHeroHandbook.tfl")
require("data1/GameUIAdjutant.tfl")
require("data1/GameObjectTacticsCenter.tfl")
require("data1/AchievementPlatformMap.tfl")
require("data1/IPlatformExtSupport.tfl")
require("data1/GameUIConsortium.tfl")
require("data1/WVEGameManeger.tfl")
require("data1/WVEGameTutorial.tfl")
require("data1/GameUIPlayerInfo.tfl")
require("data1/GameUIGlobalChatBar.tfl")
require("data1/GameVipDetailInfoPanel.tfl")
require("data1/ProductIdentifyList.tfl")
require("data1/GameUISupplyDialog.tfl")
require("data1/RefineDataManager.tfl")
require("data1/InterstellarAdventure.tfl")
require("data1/GameStateInterstellar.tfl")
require("data1/FacebookPopUI.tfl")
require("data1/FacebookStoryAwardUI.tfl")
require("data1/GameUIMaskLayer.tfl")
require("data1/GameUIFirstCharge.tfl")
require("data1/GameUIStarCraftEnter.tfl")
require("data1/GameUIRecruitMainNew.tfl")
require("data1/GameUIHeroUnion.tfl")
require("data1/GameStateFairArena.tfl")
require("data1/GameUIFairArenaMain.tfl")
require("data1/GameUIFairArenaEnter.tfl")
require("data1/GameUIFairArenaRank.tfl")
require("data1/GameUIFairArenaFormation.tfl")
require("data1/GameUIScratchGacha.tfl")
require("data1/GameTouchEffect.tfl")
require("data1/GameUILargeMap.tfl")
require("data1/GameUIDice.tfl")
if AutoUpdate.isDeveloper then
  require("data1/TestBattle.tfl")
end
require("data1/extGetUserInfo.tfl")
require("data1/TutorialAdjutantManager.tfl")
require("data1/GameUIActivityEvent.tfl")
require("data1/GameUIMaster.tfl")
require("data1/GameUIStopNotice.tfl")
require("data1/GameUIMiningWorld.tfl")
require("data1/GameUIMiningWars.tfl")
require("data1/GameArtifact.tfl")
require("data1/GameStateStarSystem.tfl")
require("data1/GameUIStarSystemPort.tfl")
require("data1/GameUIStarSystemStore.tfl")
require("data1/GameUIStarSystemRecycle.tfl")
require("data1/GameUIStarSystemGacha.tfl")
require("data1/GameUIStarSystemMedalEquip.tfl")
require("data1/GameHeroUnlockTip.tfl")
ext.dofile("data1/EngineDefault.tfl")
if ext.SaveGameData then
  ext.SaveGameData(".nomedia", "nomedia = {}")
end
immanentversionSpeed = nil
immanentversion170 = nil
immanentversion175 = nil
function DelayLoad()
  DebugOut("DelayLoad: ...")
  local LoginInfo = GameUtils:GetLoginInfo()
  DebugTable(LoginInfo)
  if LoginInfo and LoginInfo.ServerInfo and LoginInfo.ServerInfo.server_version then
    immanentversion = LoginInfo.ServerInfo.server_version
    immanentversionSpeed = LoginInfo.ServerInfo.server_version
    if immanentversionSpeed == 3 then
      immanentversion = 1
    end
  else
    immanentversion = 1
  end
  DebugOut("immanentversion: " .. immanentversion)
  if immanentversion == 1 then
    ext.dofile("data1/V1GameData.tfl")
    ext.dofile("data1/V1fakeBattleResult1.tfl")
    ext.dofile("data1/V1fakeBattleResult2.tfl")
    ext.dofile("data1/V1fakeBattleResult3.tfl")
    ext.dofile("data1/V1fakeBattleResult4.tfl")
    ext.dofile("data1/V1fakeBattleResult0.tfl")
    ext.dofile("data1/V1ACTInfo.tfl")
    ext.dofile("data1/GameDataAccessHelper.tfl")
    ext.dofile("data1/FleetDataAccessHelper.tfl")
    LuaObjectManager:setTrackingState(false)
    GameStateManager:setTrackingState(false)
  elseif immanentversion == 2 then
    ext.dofile("data1/V2GameData.tfl")
    ext.dofile("data1/V2fakeBattleResult1.tfl")
    ext.dofile("data1/V2fakeBattleResult2.tfl")
    ext.dofile("data1/V2fakeBattleResult3.tfl")
    ext.dofile("data1/V2fakeBattleResult4.tfl")
    ext.dofile("data1/V2fakeBattleResult0.tfl")
    ext.dofile("data1/V2ACTInfo.tfl")
    ext.dofile("data1/GameDataAccessHelper.tfl")
    ext.dofile("data1/FleetDataAccessHelper.tfl")
    LuaObjectManager:setTrackingState(true)
    GameStateManager:setTrackingState(true)
  else
    assert(false)
  end
  local GameStateMainPlanet = GameStateManager.GameStateMainPlanet
  GameStateMainPlanet.FirstShowSign = false
  LuaObjectManager:LoadFlashFileName("GameObjectTutorialCutscene", "tutorial_V1.tfs", "tutorial_V1.tfs")
end
GameTimer:Init()
NetMessageMgr:InitMsgHandle()
GameStateManager:Init()
FacebookGraphStorySharer:OnInitGame()
LuaObjectManager:OnInitGame()
BattleEffectManager:Init()
GameNotice:Init()
Facebook:Reset()
ProductIdentifyList:InitProduct()
ProductIdentifyList:SetProductList()
local GameSetting = LuaObjectManager:GetLuaObject("GameSetting")
GameSetting:CheckStopRecordFlurryEvent()
GameUtils:RequestTranslateInfo()
function OnFlashObjectDestroy(instName)
  LuaObjectManager:OnFlashObjectDestroy(instName)
end
function OnNetFailed(codeId)
  NetMessageMgr:OnConnectFailed(codeId)
end
function OnConnectToServer()
  NetMessageMgr:OnConnectToServer()
end
function OnTryingReconnect()
  NetMessageMgr:OnTryingReconnect()
end
function Update(dt)
  NetMessageMgr:Update(dt)
  GameStateManager:Update(dt)
  GameTimer:Update(dt)
  AutoUpdateInBackground:Update(dt)
  DynamicResDownloader:Update(dt)
  Facebook:Update()
end
function Render()
  GameStateManager:Render()
  if DebugConfig.isDebugBattllePlayLoad then
    GameStateManager.GameStateDebug:SwitchTimeEnd()
  end
end
function OnPause()
  DebugOut("OnPause")
  ext.socket.closeConnection()
  GameGlobalData.onPauseTime = os.time()
  GameGlobalData.isLogin = false
  GameGlobalData.forRequestActivityInfo = true
  AutoUpdateInBackground:SaveBGFileList()
  AutoUpdateInBackground:SaveHRFileList()
end
function OnResume()
  DebugOut("OnResume")
  if GameGlobalData.onPauseTime then
    local timeoff = os.time() - GameGlobalData.onPauseTime
    if timeoff > 1800 then
      local GameUIMessageDialog = LuaObjectManager:GetLuaObject("GameUIMessageDialog")
      local text_title = GameLoader:GetGameText("LC_MENU_TITLE_VERIFY")
      GameUIMessageDialog:SetStyle(GameUIMessageDialog.DialogStyle.OK)
      GameUIMessageDialog:SetOkButton(function()
        GameUtils:RestartGame(1)
      end)
      GameUIMessageDialog:Display(text_title, GameLoader:GetGameText("LC_MENU_LOGIN_UNLOGIN_ALERT"))
      return
    end
  end
  ext.socket.reconnectToServer()
  AutoUpdateInBackground:SaveBGFileList()
  AutoUpdateInBackground:SaveHRFileList()
  GameStateManager:NotificationGameResume()
end
function OnTouchPressed(x, y)
  DebugOut("GameEngineUpdate:OnTouchPressed")
  GameStateManager:OnTouchPressed(x, y)
end
function OnTouchMoved(x, y)
  GameStateManager:OnTouchMoved(x, y)
end
function OnTouchReleased(x, y)
  GameStateManager:OnTouchReleased(x, y)
end
function OnMultiTouchBegin(x1, y1, x2, y2)
  GameStateManager:OnMultiTouchBegin(x1, y1, x2, y2)
end
function OnMultiTouchMove(x1, y1, x2, y2)
  GameStateManager:OnMultiTouchMove(x1, y1, x2, y2)
end
function OnMultiTouchEnd(x1, y1, x2, y2)
  GameStateManager:OnMultiTouchEnd(x1, y1, x2, y2)
end
function OnBackKeyPressed()
  return GameAndroidBackManager:BackPressed()
end
function RegisterAndroidGCmID(ReId)
  GameStateManager.GameStateMainPlanet.RegisterAndroidGCmID = ReId
end
function RecordLuaException(exceptionStack)
  if AutoUpdate.isTestGW then
    ext.showAlert(exceptionStack, 0)
  end
end
