local Monsters = GameData.ChapterMonsterAct6.Monsters
Monsters[601001] = {
  ID = 601001,
  durability = 27898,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601002] = {
  ID = 601002,
  durability = 22380,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601003] = {
  ID = 601003,
  durability = 3980,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601004] = {
  ID = 601004,
  durability = 11338,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601005] = {
  ID = 601005,
  durability = 11340,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601006] = {
  ID = 601006,
  durability = 27898,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601007] = {
  ID = 601007,
  durability = 22377,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601008] = {
  ID = 601008,
  durability = 3979,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601009] = {
  ID = 601009,
  durability = 11339,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601010] = {
  ID = 601010,
  durability = 11339,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601011] = {
  ID = 601011,
  durability = 27897,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[601012] = {
  ID = 601012,
  durability = 22378,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601013] = {
  ID = 601013,
  durability = 3979,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601014] = {
  ID = 601014,
  durability = 11339,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[601015] = {
  ID = 601015,
  durability = 11338,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601016] = {
  ID = 601016,
  durability = 41695,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[601017] = {
  ID = 601017,
  durability = 22380,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601018] = {
  ID = 601018,
  durability = 3980,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601019] = {
  ID = 601019,
  durability = 11339,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601020] = {
  ID = 601020,
  durability = 11338,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601021] = {
  ID = 601021,
  durability = 27898,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601022] = {
  ID = 601022,
  durability = 22377,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601023] = {
  ID = 601023,
  durability = 3979,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601024] = {
  ID = 601024,
  durability = 11338,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601025] = {
  ID = 601025,
  durability = 11339,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601026] = {
  ID = 601026,
  durability = 27897,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601027] = {
  ID = 601027,
  durability = 22377,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601028] = {
  ID = 601028,
  durability = 3979,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601029] = {
  ID = 601029,
  durability = 11339,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601030] = {
  ID = 601030,
  durability = 11339,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601031] = {
  ID = 601031,
  durability = 29433,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601032] = {
  ID = 601032,
  durability = 23607,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601033] = {
  ID = 601033,
  durability = 4184,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601034] = {
  ID = 601034,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[601035] = {
  ID = 601035,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601036] = {
  ID = 601036,
  durability = 44001,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[601037] = {
  ID = 601037,
  durability = 23607,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[601038] = {
  ID = 601038,
  durability = 4184,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601039] = {
  ID = 601039,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[601040] = {
  ID = 601040,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602001] = {
  ID = 602001,
  durability = 29433,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602002] = {
  ID = 602002,
  durability = 23607,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602003] = {
  ID = 602003,
  durability = 4184,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602004] = {
  ID = 602004,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602005] = {
  ID = 602005,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602006] = {
  ID = 602006,
  durability = 29433,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602007] = {
  ID = 602007,
  durability = 23607,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602008] = {
  ID = 602008,
  durability = 4184,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602009] = {
  ID = 602009,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602010] = {
  ID = 602010,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602011] = {
  ID = 602011,
  durability = 29436,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602012] = {
  ID = 602012,
  durability = 23607,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602013] = {
  ID = 602013,
  durability = 4184,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602014] = {
  ID = 602014,
  durability = 11954,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602015] = {
  ID = 602015,
  durability = 11954,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602016] = {
  ID = 602016,
  durability = 44004,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[602017] = {
  ID = 602017,
  durability = 23607,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[602018] = {
  ID = 602018,
  durability = 4184,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602019] = {
  ID = 602019,
  durability = 11954,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602020] = {
  ID = 602020,
  durability = 11954,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[602021] = {
  ID = 602021,
  durability = 29434,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602022] = {
  ID = 602022,
  durability = 23608,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602023] = {
  ID = 602023,
  durability = 4184,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602024] = {
  ID = 602024,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602025] = {
  ID = 602025,
  durability = 11953,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602026] = {
  ID = 602026,
  durability = 29433,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602027] = {
  ID = 602027,
  durability = 23607,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602028] = {
  ID = 602028,
  durability = 4184,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602029] = {
  ID = 602029,
  durability = 11954,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602030] = {
  ID = 602030,
  durability = 11954,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602031] = {
  ID = 602031,
  durability = 30970,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602032] = {
  ID = 602032,
  durability = 24837,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602033] = {
  ID = 602033,
  durability = 4389,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602034] = {
  ID = 602034,
  durability = 12568,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602035] = {
  ID = 602035,
  durability = 12568,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602036] = {
  ID = 602036,
  durability = 46305,
  Avatar = "head15",
  Ship = "ship39"
}
Monsters[602037] = {
  ID = 602037,
  durability = 24835,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602038] = {
  ID = 602038,
  durability = 4389,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602039] = {
  ID = 602039,
  durability = 12568,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[602040] = {
  ID = 602040,
  durability = 12567,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[603001] = {
  ID = 603001,
  durability = 19724,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603002] = {
  ID = 603002,
  durability = 15021,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603003] = {
  ID = 603003,
  durability = 4389,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[603004] = {
  ID = 603004,
  durability = 6434,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603005] = {
  ID = 603005,
  durability = 8478,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603006] = {
  ID = 603006,
  durability = 19724,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603007] = {
  ID = 603007,
  durability = 15021,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603008] = {
  ID = 603008,
  durability = 4389,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603009] = {
  ID = 603009,
  durability = 6434,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603010] = {
  ID = 603010,
  durability = 8479,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603011] = {
  ID = 603011,
  durability = 19723,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603012] = {
  ID = 603012,
  durability = 15021,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603013] = {
  ID = 603013,
  durability = 4389,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603014] = {
  ID = 603014,
  durability = 6434,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603015] = {
  ID = 603015,
  durability = 8478,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603016] = {
  ID = 603016,
  durability = 29436,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[603017] = {
  ID = 603017,
  durability = 15021,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603018] = {
  ID = 603018,
  durability = 4389,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603019] = {
  ID = 603019,
  durability = 6433,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603020] = {
  ID = 603020,
  durability = 8478,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603021] = {
  ID = 603021,
  durability = 19724,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603022] = {
  ID = 603022,
  durability = 15021,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603023] = {
  ID = 603023,
  durability = 4389,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[603024] = {
  ID = 603024,
  durability = 6434,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603025] = {
  ID = 603025,
  durability = 8479,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603026] = {
  ID = 603026,
  durability = 19724,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[603027] = {
  ID = 603027,
  durability = 15021,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603028] = {
  ID = 603028,
  durability = 4389,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603029] = {
  ID = 603029,
  durability = 6434,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603030] = {
  ID = 603030,
  durability = 8479,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603031] = {
  ID = 603031,
  durability = 21671,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603032] = {
  ID = 603032,
  durability = 16496,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603033] = {
  ID = 603033,
  durability = 4799,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603034] = {
  ID = 603034,
  durability = 7048,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603035] = {
  ID = 603035,
  durability = 9298,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603036] = {
  ID = 603036,
  durability = 32353,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[603037] = {
  ID = 603037,
  durability = 16495,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603038] = {
  ID = 603038,
  durability = 4799,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603039] = {
  ID = 603039,
  durability = 7048,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[603040] = {
  ID = 603040,
  durability = 9298,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604001] = {
  ID = 604001,
  durability = 20545,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604002] = {
  ID = 604002,
  durability = 15597,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604003] = {
  ID = 604003,
  durability = 4798,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604004] = {
  ID = 604004,
  durability = 7048,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604005] = {
  ID = 604005,
  durability = 9298,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604006] = {
  ID = 604006,
  durability = 20545,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[604007] = {
  ID = 604007,
  durability = 15596,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604008] = {
  ID = 604008,
  durability = 4798,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604009] = {
  ID = 604009,
  durability = 7048,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[604010] = {
  ID = 604010,
  durability = 9297,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604011] = {
  ID = 604011,
  durability = 20544,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604012] = {
  ID = 604012,
  durability = 15596,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604013] = {
  ID = 604013,
  durability = 4798,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604014] = {
  ID = 604014,
  durability = 7048,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604015] = {
  ID = 604015,
  durability = 9298,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604016] = {
  ID = 604016,
  durability = 30668,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[604017] = {
  ID = 604017,
  durability = 15596,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604018] = {
  ID = 604018,
  durability = 4799,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604019] = {
  ID = 604019,
  durability = 7048,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604020] = {
  ID = 604020,
  durability = 9297,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604021] = {
  ID = 604021,
  durability = 20545,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604022] = {
  ID = 604022,
  durability = 15596,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604023] = {
  ID = 604023,
  durability = 4799,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604024] = {
  ID = 604024,
  durability = 7048,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604025] = {
  ID = 604025,
  durability = 9298,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604026] = {
  ID = 604026,
  durability = 20545,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604027] = {
  ID = 604027,
  durability = 15595,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604028] = {
  ID = 604028,
  durability = 4798,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604029] = {
  ID = 604029,
  durability = 7048,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[604030] = {
  ID = 604030,
  durability = 9298,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604031] = {
  ID = 604031,
  durability = 22388,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604032] = {
  ID = 604032,
  durability = 16989,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[604033] = {
  ID = 604033,
  durability = 5208,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604034] = {
  ID = 604034,
  durability = 7662,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604035] = {
  ID = 604035,
  durability = 10117,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604036] = {
  ID = 604036,
  durability = 33433,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[604037] = {
  ID = 604037,
  durability = 16989,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604038] = {
  ID = 604038,
  durability = 5208,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604039] = {
  ID = 604039,
  durability = 7662,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[604040] = {
  ID = 604040,
  durability = 10117,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605001] = {
  ID = 605001,
  durability = 22389,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605002] = {
  ID = 605002,
  durability = 16989,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605003] = {
  ID = 605003,
  durability = 5208,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605004] = {
  ID = 605004,
  durability = 7662,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605005] = {
  ID = 605005,
  durability = 10116,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605006] = {
  ID = 605006,
  durability = 22388,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605007] = {
  ID = 605007,
  durability = 16989,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605008] = {
  ID = 605008,
  durability = 5208,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605009] = {
  ID = 605009,
  durability = 7663,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605010] = {
  ID = 605010,
  durability = 10116,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605011] = {
  ID = 605011,
  durability = 22389,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605012] = {
  ID = 605012,
  durability = 16989,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[605013] = {
  ID = 605013,
  durability = 5208,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605014] = {
  ID = 605014,
  durability = 7662,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605015] = {
  ID = 605015,
  durability = 10117,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[605016] = {
  ID = 605016,
  durability = 33434,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[605017] = {
  ID = 605017,
  durability = 16989,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605018] = {
  ID = 605018,
  durability = 5208,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605019] = {
  ID = 605019,
  durability = 7663,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605020] = {
  ID = 605020,
  durability = 10117,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605021] = {
  ID = 605021,
  durability = 22388,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605022] = {
  ID = 605022,
  durability = 16989,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605023] = {
  ID = 605023,
  durability = 5208,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605024] = {
  ID = 605024,
  durability = 7662,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605025] = {
  ID = 605025,
  durability = 10117,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605026] = {
  ID = 605026,
  durability = 22387,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605027] = {
  ID = 605027,
  durability = 16989,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605028] = {
  ID = 605028,
  durability = 5208,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605029] = {
  ID = 605029,
  durability = 7662,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605030] = {
  ID = 605030,
  durability = 10117,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605031] = {
  ID = 605031,
  durability = 24231,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605032] = {
  ID = 605032,
  durability = 18381,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605033] = {
  ID = 605033,
  durability = 5618,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605034] = {
  ID = 605034,
  durability = 8277,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605035] = {
  ID = 605035,
  durability = 10936,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[605036] = {
  ID = 605036,
  durability = 36196,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[605037] = {
  ID = 605037,
  durability = 18382,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605038] = {
  ID = 605038,
  durability = 5618,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[605039] = {
  ID = 605039,
  durability = 8277,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[605040] = {
  ID = 605040,
  durability = 10936,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606001] = {
  ID = 606001,
  durability = 24231,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606002] = {
  ID = 606002,
  durability = 18382,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606003] = {
  ID = 606003,
  durability = 5618,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606004] = {
  ID = 606004,
  durability = 8277,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606005] = {
  ID = 606005,
  durability = 10936,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606006] = {
  ID = 606006,
  durability = 24231,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606007] = {
  ID = 606007,
  durability = 18381,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606008] = {
  ID = 606008,
  durability = 5618,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606009] = {
  ID = 606009,
  durability = 8277,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606010] = {
  ID = 606010,
  durability = 10936,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606011] = {
  ID = 606011,
  durability = 24231,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606012] = {
  ID = 606012,
  durability = 18381,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606013] = {
  ID = 606013,
  durability = 5618,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606014] = {
  ID = 606014,
  durability = 8277,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606015] = {
  ID = 606015,
  durability = 10936,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606016] = {
  ID = 606016,
  durability = 36196,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[606017] = {
  ID = 606017,
  durability = 18381,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606018] = {
  ID = 606018,
  durability = 5618,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[606019] = {
  ID = 606019,
  durability = 8277,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606020] = {
  ID = 606020,
  durability = 10936,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606021] = {
  ID = 606021,
  durability = 24232,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[606022] = {
  ID = 606022,
  durability = 18381,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606023] = {
  ID = 606023,
  durability = 5618,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606024] = {
  ID = 606024,
  durability = 8277,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606025] = {
  ID = 606025,
  durability = 10936,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606026] = {
  ID = 606026,
  durability = 24232,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606027] = {
  ID = 606027,
  durability = 18382,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606028] = {
  ID = 606028,
  durability = 5618,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606029] = {
  ID = 606029,
  durability = 8277,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606030] = {
  ID = 606030,
  durability = 10936,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606031] = {
  ID = 606031,
  durability = 26075,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606032] = {
  ID = 606032,
  durability = 19773,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606033] = {
  ID = 606033,
  durability = 6027,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606034] = {
  ID = 606034,
  durability = 8891,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606035] = {
  ID = 606035,
  durability = 11755,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606036] = {
  ID = 606036,
  durability = 38964,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[606037] = {
  ID = 606037,
  durability = 19774,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606038] = {
  ID = 606038,
  durability = 6027,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606039] = {
  ID = 606039,
  durability = 8891,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[606040] = {
  ID = 606040,
  durability = 11755,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607001] = {
  ID = 607001,
  durability = 26075,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[607002] = {
  ID = 607002,
  durability = 19775,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607003] = {
  ID = 607003,
  durability = 6028,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607004] = {
  ID = 607004,
  durability = 8891,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[607005] = {
  ID = 607005,
  durability = 11755,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607006] = {
  ID = 607006,
  durability = 26075,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607007] = {
  ID = 607007,
  durability = 19774,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607008] = {
  ID = 607008,
  durability = 6027,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607009] = {
  ID = 607009,
  durability = 8892,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607010] = {
  ID = 607010,
  durability = 11755,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607011] = {
  ID = 607011,
  durability = 26076,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607012] = {
  ID = 607012,
  durability = 19775,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607013] = {
  ID = 607013,
  durability = 6027,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607014] = {
  ID = 607014,
  durability = 8892,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607015] = {
  ID = 607015,
  durability = 11756,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607016] = {
  ID = 607016,
  durability = 38962,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[607017] = {
  ID = 607017,
  durability = 19773,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607018] = {
  ID = 607018,
  durability = 6028,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607019] = {
  ID = 607019,
  durability = 8891,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607020] = {
  ID = 607020,
  durability = 11755,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607021] = {
  ID = 607021,
  durability = 26076,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607022] = {
  ID = 607022,
  durability = 19773,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607023] = {
  ID = 607023,
  durability = 6028,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607024] = {
  ID = 607024,
  durability = 8892,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[607025] = {
  ID = 607025,
  durability = 11755,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607026] = {
  ID = 607026,
  durability = 26075,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607027] = {
  ID = 607027,
  durability = 19775,
  Avatar = "head23",
  Ship = "ship37"
}
Monsters[607028] = {
  ID = 607028,
  durability = 6027,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607029] = {
  ID = 607029,
  durability = 8892,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607030] = {
  ID = 607030,
  durability = 11756,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607031] = {
  ID = 607031,
  durability = 27917,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607032] = {
  ID = 607032,
  durability = 21166,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607033] = {
  ID = 607033,
  durability = 6437,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607034] = {
  ID = 607034,
  durability = 9506,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607035] = {
  ID = 607035,
  durability = 12574,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607036] = {
  ID = 607036,
  durability = 41727,
  Avatar = "head17",
  Ship = "ship39"
}
Monsters[607037] = {
  ID = 607037,
  durability = 21167,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607038] = {
  ID = 607038,
  durability = 6437,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607039] = {
  ID = 607039,
  durability = 9506,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[607040] = {
  ID = 607040,
  durability = 12574,
  Avatar = "head23",
  Ship = "ship39"
}
Monsters[608001] = {
  ID = 608001,
  durability = 27919,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608002] = {
  ID = 608002,
  durability = 21167,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608003] = {
  ID = 608003,
  durability = 6437,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608004] = {
  ID = 608004,
  durability = 9506,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608005] = {
  ID = 608005,
  durability = 12574,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608006] = {
  ID = 608006,
  durability = 27918,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608007] = {
  ID = 608007,
  durability = 21167,
  Avatar = "head26",
  Ship = "ship37"
}
Monsters[608008] = {
  ID = 608008,
  durability = 6437,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608009] = {
  ID = 608009,
  durability = 9506,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608010] = {
  ID = 608010,
  durability = 12575,
  Avatar = "head26",
  Ship = "ship37"
}
Monsters[608011] = {
  ID = 608011,
  durability = 27919,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608012] = {
  ID = 608012,
  durability = 21167,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608013] = {
  ID = 608013,
  durability = 6437,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608014] = {
  ID = 608014,
  durability = 9506,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608015] = {
  ID = 608015,
  durability = 12575,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608016] = {
  ID = 608016,
  durability = 41727,
  Avatar = "head39",
  Ship = "ship39"
}
Monsters[608017] = {
  ID = 608017,
  durability = 21167,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608018] = {
  ID = 608018,
  durability = 6437,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608019] = {
  ID = 608019,
  durability = 9505,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608020] = {
  ID = 608020,
  durability = 12575,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608021] = {
  ID = 608021,
  durability = 27917,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608022] = {
  ID = 608022,
  durability = 21167,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608023] = {
  ID = 608023,
  durability = 6437,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608024] = {
  ID = 608024,
  durability = 9506,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608025] = {
  ID = 608025,
  durability = 12574,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608026] = {
  ID = 608026,
  durability = 27919,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608027] = {
  ID = 608027,
  durability = 21167,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608028] = {
  ID = 608028,
  durability = 6437,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608029] = {
  ID = 608029,
  durability = 9505,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608030] = {
  ID = 608030,
  durability = 12574,
  Avatar = "head26",
  Ship = "ship37"
}
Monsters[608031] = {
  ID = 608031,
  durability = 29761,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608032] = {
  ID = 608032,
  durability = 22559,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608033] = {
  ID = 608033,
  durability = 6847,
  Avatar = "head26",
  Ship = "ship37"
}
Monsters[608034] = {
  ID = 608034,
  durability = 10120,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608035] = {
  ID = 608035,
  durability = 13394,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608036] = {
  ID = 608036,
  durability = 44492,
  Avatar = "head4",
  Ship = "ship39"
}
Monsters[608037] = {
  ID = 608037,
  durability = 22560,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608038] = {
  ID = 608038,
  durability = 6847,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608039] = {
  ID = 608039,
  durability = 10120,
  Avatar = "head26",
  Ship = "ship39"
}
Monsters[608040] = {
  ID = 608040,
  durability = 13394,
  Avatar = "head26",
  Ship = "ship39"
}
