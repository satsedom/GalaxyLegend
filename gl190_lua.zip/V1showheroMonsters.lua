local Monsters = GameData.showhero.Monsters
Monsters[100000000] = {
  ID = 100000000,
  vessels = 1,
  durability = 250000,
  Avatar = "mystery",
  Ship = "ship24"
}
Monsters[100000001] = {
  ID = 100000001,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000002] = {
  ID = 100000002,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000003] = {
  ID = 100000003,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000004] = {
  ID = 100000004,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000005] = {
  ID = 100000005,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000006] = {
  ID = 100000006,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000007] = {
  ID = 100000007,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000008] = {
  ID = 100000008,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000009] = {
  ID = 100000009,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000010] = {
  ID = 100000010,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000011] = {
  ID = 100000011,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
Monsters[100000012] = {
  ID = 100000012,
  vessels = 3,
  durability = 2000,
  Avatar = "head13",
  Ship = "ship16"
}
