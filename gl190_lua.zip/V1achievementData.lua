local Data = GameData.achievement.Data
Data[1] = {
  ID = 1,
  Level = 1,
  Title = "ACHIEVEMENT_TITLE_1",
  Desc = "ACHIEVEMENT_DESC_1",
  SType = "Commander"
}
Data[2] = {
  ID = 2,
  Level = 2,
  Title = "ACHIEVEMENT_TITLE_2",
  Desc = "ACHIEVEMENT_DESC_2",
  SType = "Krypton"
}
Data[3] = {
  ID = 3,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_3",
  Desc = "ACHIEVEMENT_DESC_3",
  SType = "Commander"
}
Data[4] = {
  ID = 4,
  Level = 1,
  Title = "ACHIEVEMENT_TITLE_4",
  Desc = "ACHIEVEMENT_DESC_4",
  SType = "Commander"
}
Data[5] = {
  ID = 5,
  Level = 2,
  Title = "ACHIEVEMENT_TITLE_5",
  Desc = "ACHIEVEMENT_DESC_5",
  SType = "Commander"
}
Data[6] = {
  ID = 6,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
Data[7] = {
  ID = 7,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
Data[8] = {
  ID = 8,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
Data[9] = {
  ID = 9,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
Data[10] = {
  ID = 10,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
Data[11] = {
  ID = 11,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
Data[12] = {
  ID = 12,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
Data[13] = {
  ID = 13,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
Data[14] = {
  ID = 14,
  Level = 3,
  Title = "ACHIEVEMENT_TITLE_6",
  Desc = "ACHIEVEMENT_DESC_6",
  SType = "Commander"
}
