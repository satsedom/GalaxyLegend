local Monsters = GameData.ChapterMonsterTutorial.Monsters
Monsters[10001] = {
  ID = 10001,
  durability = 199,
  Avatar = "head13",
  Ship = "ship2"
}
Monsters[10002] = {
  ID = 10002,
  durability = 218,
  Avatar = "head13",
  Ship = "ship2"
}
Monsters[10003] = {
  ID = 10003,
  durability = 238,
  Avatar = "head13",
  Ship = "ship2"
}
Monsters[10004] = {
  ID = 10004,
  durability = 223,
  Avatar = "head13",
  Ship = "ship2"
}
Monsters[10005] = {
  ID = 10005,
  durability = 259,
  Avatar = "head13",
  Ship = "ship2"
}
Monsters[10006] = {
  ID = 10006,
  durability = 241,
  Avatar = "head13",
  Ship = "ship2"
}
