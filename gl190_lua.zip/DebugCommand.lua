DebugCommand = {
  dinfo = {},
  stopAll = false
}
function DebugCommand:t_tostring(maxdepth, _indent)
  local str = {}
  maxdepth = maxdepth or 4
  _indent = _indent or "--"
  local function internal(self, str, indent)
    if #indent >= maxdepth then
      table.insert(str, indent .. " ,too many depth\n")
      return
    end
    for k, v in pairs(self) do
      if type(v) == "table" then
        table.insert(str, indent .. tostring(k) .. ":\n")
        internal(v, str, indent .. indent)
      else
        table.insert(str, indent .. tostring(k) .. ": " .. tostring(v) .. "\n")
      end
    end
  end
  internal(self, str, _indent)
  return table.concat(str, "")
end
function DebugCommand.DebugPoint(id, ...)
  if DebugCommand.stopAll then
    return
  end
  local tinfo = DebugCommand.dinfo[id]
  if tinfo == nil then
    return
  end
  if tinfo.cnt > 0 then
    tinfo.cnt = tinfo.cnt - 1
    if tinfo.cnt == 0 then
      DebugCommand.dinfo[id] = nil
    end
  end
  local result, str = pcall(tinfo.func, ...)
  if not result then
    local stack = tostring(str) .. debug.traceback()
    print("xxpp " .. stack)
    ext.doDebug("20\002" .. stack)
    return
  end
  if not str then
    return
  end
  print("xxpp " .. string.gsub(str, "\n", [[

xxpp ]]))
  ext.doDebug("20\002" .. str)
end
function DebugCommand_DebugRealTime(strcmd)
  if strcmd == nil then
    return
  end
  local acmd = LuaUtils:string_split(strcmd, "&")
  local id = acmd[1]
  local strfunc = acmd[3]
  local cnt = tonumber(acmd[2])
  DebugCommand.dinfo[id] = {
    cnt = cnt,
    func = loadstring(strfunc)()
  }
  DebugCommand.stopAll = false
  print("xxpp DebugRealTime" .. strcmd)
end
function DebugCommand:excute(command_string)
  if not GameUtils:IsTestGateWay() then
    return
  end
  command_string = "DebugCommand." .. command_string
  local callback = loadstring(command_string)
  callback()
end
function DebugCommand.output(value_string)
  value_string = "return " .. value_string
  local eval_func = loadstring(value_string)
  GameUtils:printValue(eval_func())
end
function DebugCommand._CheckOfflineReward()
  local data_offline = GameGlobalData:GetData("offline_info")
  local GameUIBarLeft = LuaObjectManager:GetLuaObject("GameUIBarLeft")
  GameUIBarLeft:ShowOfflineRewardIcon()
end
function DebugCommand._EnterSection(area_id, section_id)
  area_id = tonumber(area_id)
  section_id = tonumber(section_id)
  local GameStateBattleMap = GameStateManager.GameStateBattleMap
  GameStateBattleMap:EnterSection(area_id, section_id, nil)
end
function DebugCommand._ProcessEvent(combined_id)
  local GameUIEvent = LuaObjectManager:GetLuaObject("GameUIEvent")
  GameUIEvent:Show(combined_id)
end
function DebugCommand.CheckPrestigeRankUp()
  local GameUIPrestigeRankUp = LuaObjectManager:GetLuaObject("GameUIPrestigeRankUp")
  GameUIPrestigeRankUp:CheckNeedDisplay()
end
function DebugCommand.alliance()
  local GameStateAlliance = GameStateManager.GameStateAlliance
  GameStateManager:SetCurrentGameState(GameStateAlliance)
end
function DebugCommand.arena()
  GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
end
function DebugCommand.CheckPlayerMatrix()
  local GameStatePlayerMatrix = GameStateManager.GameStatePlayerMatrix
  GameStateManager:SetCurrentGameState(GameStatePlayerMatrix)
end
function DebugCommand.UnlockCommand(item_name)
  if item_name == "formation" then
    item_name = "hire"
  end
  local find = false
  local modules_status = GameGlobalData:GetData("modules_status")
  for _, v in ipairs(modules_status.modules) do
    if v.name == item_name then
      v.status = true
      find = true
      break
    end
  end
  if find then
    local GameUIBarRight = LuaObjectManager:GetLuaObject("GameUIBarRight")
    GameUIBarRight:FormatRightMenu()
    local GameTip = LuaObjectManager:GetLuaObject("GameTip")
    GameTip:Show("unlock " .. item_name .. " success !")
  else
    local GameTip = LuaObjectManager:GetLuaObject("GameTip")
    GameTip:Show("not find item - " .. item_name .. " !")
  end
end
function DebugCommand.Mine(cmd, arg)
  local GameStateMineMap = GameStateManager.GameStateMineMap
  GameStateManager:SetCurrentGameState(GameStateMineMap)
end
function DebugCommand.AutoPVENetCallback(msgtype, content)
  if msgtype == NetAPIList.common_ack.Code and (content.api == NetAPIList.battle_result_req.Code or content.api == NetAPIList.battle_result_req.Code or content.api == NetAPIList.user_map_status_req.Code) then
    if content.code ~= 0 then
      local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  end
  if msgtype == NetAPIList.event_loot_ack.Code then
    DebugCommand:CheckAutoPVEStatus()
    return true
  end
  if msgtype == NetAPIList.battle_result_ack.Code then
    for _, commander_data in ipairs(content.fleets) do
      if commander_data.damage < 70 then
        DebugOut("send repair msg !")
        local net_packet = {onserver = 1}
        NetMessageMgr:SendMsg(NetAPIList.fleet_repair_all_req.Code, net_packet, DebugCommand.AutoPVENetCallback, true, nil)
        break
      end
    end
    if 0 < content.result.accomplish_level then
      DebugCommand:CheckAutoPVEStatus()
    else
      local GameTip = LuaObjectManager:GetLuaObject("GameTip")
      GameTip:Show("battle failed !")
    end
    return true
  end
  if msgtype == NetAPIList.user_map_status_ack.Code then
    local event_count = #content.status
    for i = 1, event_count do
      local battle_data = content.status[1]
      table.remove(content.status, 1)
      local battle_type = math.floor(battle_data.battle_id % 1000 * 0.01)
      if battle_type == 1 or battle_type == 0 then
        table.insert(content.status, battle_data)
      end
    end
    table.sort(content.status, function(a, b)
      return a.battle_id % 100 < b.battle_id % 100
    end)
    DebugOutPutTable(content.status, "sort_status")
    local progress = GameGlobalData:GetData("progress")
    progress.finish_count = content.finish_count
    local request_content = {
      battle_id = content.status[progress.finish_count + 1].battle_id,
      action = 1
    }
    DebugOutPutTable(content.status[progress.finish_count + 1], "battle_data")
    NetMessageMgr:SendMsg(NetAPIList.pve_battle_req.Code, request_content, DebugCommand.AutoPVENetCallback, true, nil)
    return true
  end
  return false
end
function DebugCommand:CheckAutoPVEStatus()
  local pve_progress = GameGlobalData:GetData("progress")
  if pve_progress.act > self.AutoPVEInfo.area then
    return
  end
  if pve_progress.act == self.AutoPVEInfo.area and pve_progress.chapter > self.AutoPVEInfo.section then
    return
  end
  if pve_progress.act == self.AutoPVEInfo.area and pve_progress.chapter == self.AutoPVEInfo.section and (pve_progress.all_count < self.AutoPVEInfo.battle or pve_progress.finish_count >= self.AutoPVEInfo.battle) then
    return
  end
  local pve_supply = GameGlobalData:GetData("battle_supply")
  if pve_supply.current < 10 then
    NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {cmd = "supply()"}, nil, nil)
  end
  local function netRequestCall()
    local content = {
      chapter_id = pve_progress.act * 1000 + pve_progress.chapter
    }
    NetMessageMgr:SendMsg(NetAPIList.pve_map_status_req.Code, content, DebugCommand.AutoPVENetCallback, true, netRequestCall)
  end
  netRequestCall()
end
function DebugCommand.autopve(area, section, battle)
  DebugCommand.AutoPVEInfo = {}
  DebugCommand.AutoPVEInfo.area = tonumber(area)
  DebugCommand.AutoPVEInfo.section = tonumber(section)
  DebugCommand.AutoPVEInfo.battle = tonumber(battle)
  local level_info = GameGlobalData:GetData("levelinfo")
  if level_info.level < 35 then
    NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {cmd = "level(70)"}, nil, nil)
  end
  DebugCommand:CheckAutoPVEStatus()
end
function DebugCommand.SeePVEPlay(content, callback)
  local GameTip = LuaObjectManager:GetLuaObject("GameTip")
  GameTip:Show("Battle Replay!" .. DebugCommand.SeePVEInfo.result_area .. " " .. DebugCommand.SeePVEInfo.result_section .. " " .. DebugCommand.SeePVEInfo.result_battle)
  local GameStateBattlePlay = GameStateManager.GameStateBattlePlay
  GameStateBattlePlay:RegisterOverCallback(callback, nil)
  GameStateManager.GameStateBattlePlay:InitBattle(GameStateBattlePlay.MODE_PLAY, content.report, DebugCommand.SeePVEInfo.result_area, DebugCommand.SeePVEInfo.result_section * 1000 + DebugCommand.SeePVEInfo.result_battle)
  GameStateManager:SetCurrentGameState(GameStateManager.GameStateBattlePlay)
end
function DebugCommand.SeePVENetCallback(msgtype, content)
  if msgtype == NetAPIList.common_ack.Code and (content.api == NetAPIList.event_loot_req.Code or content.api == NetAPIList.battle_result_req.Code or content.api == NetAPIList.user_map_status_req.Code) then
    if content.code ~= 0 then
      local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  end
  if msgtype == NetAPIList.event_loot_ack.Code then
    DebugCommand:CheckSeePVEStatus()
    return true
  end
  if msgtype == NetAPIList.battle_result_ack.Code then
    for _, commander_data in ipairs(content.fleets) do
      if commander_data.damage < 70 then
        DebugOut("send repair msg !")
        local net_packet = {onserver = 1}
        NetMessageMgr:SendMsg(NetAPIList.fleet_repair_all_req.Code, net_packet, DebugCommand.SeePVENetCallback, true, nil)
        break
      end
    end
    if 0 < content.result.accomplish_level then
      local callback = function()
        GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
        DebugCommand.CheckSeePVEStatus()
      end
      DebugCommand.SeePVEPlay(content, callback)
    else
      local callback = function()
        GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
        local GameTip = LuaObjectManager:GetLuaObject("GameTip")
        GameTip:Show("battle failed !")
      end
      DebugCommand.SeePVEPlay(content, callback)
    end
    return true
  end
  if msgtype == NetAPIList.user_map_status_ack.Code then
    local event_count = #content.status
    for i = 1, event_count do
      local battle_data = content.status[1]
      table.remove(content.status, 1)
      local battle_type = math.floor(battle_data.battle_id % 1000 * 0.01)
      if battle_type == 1 or battle_type == 0 then
        table.insert(content.status, battle_data)
      end
    end
    table.sort(content.status, function(a, b)
      return a.battle_id % 100 < b.battle_id % 100
    end)
    DebugOutPutTable(content.status, "sort_status")
    DebugOut("ReadyPlayBattle " .. DebugCommand.SeePVEInfo.area .. " " .. DebugCommand.SeePVEInfo.section .. " " .. DebugCommand.SeePVEInfo.battle)
    local request_content = {
      battle_id = content.status[DebugCommand.SeePVEInfo.battle_index].battle_id,
      action = 1
    }
    DebugOutPutTable(content.status[DebugCommand.SeePVEInfo.battle_index], "battle_data")
    NetMessageMgr:SendMsg(NetAPIList.pve_battle_req.Code, request_content, DebugCommand.SeePVENetCallback, true, nil)
    DebugCommand.SeePVEInfo.result_battle = DebugCommand.SeePVEInfo.battle
    DebugCommand.SeePVEInfo.result_section = DebugCommand.SeePVEInfo.section
    DebugCommand.SeePVEInfo.result_area = DebugCommand.SeePVEInfo.area
    local GameStateBattleMap = GameStateManager.GameStateBattleMap
    GameStateBattleMap.m_currentAreaID = DebugCommand.SeePVEInfo.result_area
    GameStateBattleMap.m_currentSectionID = DebugCommand.SeePVEInfo.result_section
    DebugCommand.SeePVEInfo.battle_index = DebugCommand.SeePVEInfo.battle_index + 1
    if not content.status[DebugCommand.SeePVEInfo.battle_index] then
      DebugCommand.SeePVEInfo.battle = 1
      DebugCommand.SeePVEInfo.battle_index = 1
      DebugCommand.SeePVEInfo.section = DebugCommand.SeePVEInfo.section + 1
      if DebugCommand.SeePVEInfo.section > 8 then
        DebugCommand.SeePVEInfo.section = 1
        DebugCommand.SeePVEInfo.area = DebugCommand.SeePVEInfo.area + 1
      end
    else
      DebugCommand.SeePVEInfo.battle = content.status[DebugCommand.SeePVEInfo.battle_index].battle_id % 100
    end
    return true
  end
  return false
end
function DebugCommand:CheckSeePVEStatus()
  if DebugCommand.SeePVEInfo.area > DebugCommand.SeePVEInfo.end_area then
    return
  end
  local pve_supply = GameGlobalData:GetData("battle_supply")
  if pve_supply.current < 10 then
    NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {cmd = "supply()"}, nil, nil)
  end
  local netRequestCall = function()
    local content = {
      chapter_id = DebugCommand.SeePVEInfo.area * 1000 + DebugCommand.SeePVEInfo.section
    }
    NetMessageMgr:SendMsg(NetAPIList.pve_map_status_req.Code, content, DebugCommand.SeePVENetCallback, true, netRequestCall)
  end
  netRequestCall()
end
function DebugCommand.seepve(area, section, battle)
  DebugCommand.SeePVEInfo = {}
  DebugCommand.SeePVEInfo.area = tonumber(area)
  DebugCommand.SeePVEInfo.section = tonumber(section)
  DebugCommand.SeePVEInfo.battle = tonumber(battle)
  DebugCommand.SeePVEInfo.battle_index = tonumber(battle)
  DebugCommand.SeePVEInfo.end_area = 9
  DebugCommand.SeePVEInfo.end_section = 8
  DebugCommand.SeePVEInfo.end_battle = 99
  local level_info = GameGlobalData:GetData("levelinfo")
  if level_info.level < 35 then
    NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {cmd = "level(90)"}, nil, nil)
  end
  DebugCommand:CheckSeePVEStatus()
end
function DebugCommand.bestfleet()
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "add_fleet(209)"
  }, nil, nil)
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "add_fleet(210)"
  }, nil, nil)
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "add_fleet(211)"
  }, nil, nil)
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "add_fleet(212)"
  }, nil, nil)
end
function DebugCommand.prestige()
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "increase_prestige(1000000000)"
  }, nil, nil)
end
function DebugCommand.recruit()
  GameStateManager:SetCurrentGameState(GameStateManager.GameStateRecruit)
end
function DebugCommand.gacha()
  GameStateManager:SetCurrentGameState(GameStateManager.GameStateGacha)
end
function DebugCommand.toprank()
  local GameStateToprank = GameStateManager.GameStateToprank
  GameStateManager:SetCurrentGameState(GameStateToprank)
end
function DebugCommand.TechLab()
  local GameUITechnology = LuaObjectManager:GetLuaObject("GameUITechnology")
  GameStateManager:GetCurrentGameState():AddObject(GameUITechnology)
end
function DebugCommand.refresh_time(timeType, leftTimeValue)
  local refreshTime = GameGlobalData:GetRefreshTime(timeType)
  if refreshTime then
    refreshTime.next_time = tonumber(leftTimeValue)
    GameGlobalData:RefreshData(timeType)
  end
end
function DebugCommand.arcane()
  local GameStateArcane = GameStateManager.GameStateArcane
  GameStateManager:SetCurrentGameState(GameStateArcane)
end
function DebugCommand.gateway(gateway_addr)
  local url = "http://" .. gateway_addr .. "/"
  if GameUtils:URLIsHTTPS(gateway_addr) then
    url = "https://" .. gateway_addr .. "/"
  end
  GameUtils.HTTP_SERVER = url
  local function successCallback(content)
    GameSettingData.Gateway = gateway_addr
    GameUtils:SaveSettingData()
    GameUtils:RestartGame(200, nil)
  end
  GameUtils:UpdateServerList(successCallback)
end
function DebugCommand.worldboss()
  local GameStateWorldBoss = GameStateManager.GameStateWorldBoss
  GameStateManager:SetCurrentGameState(GameStateWorldBoss)
end
function DebugCommand.androidback()
  GameAndroidBackManager:BackPressed()
end
function DebugCommand.fps()
  DebugConfig.isDebugFPS = not DebugConfig.isDebugFPS
end
function DebugCommand.free()
  collectgarbage("collect")
end
local NetCallbackClaimAward = function(msgType, content)
  if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.laba_award_req.Code then
    if content.code ~= 0 then
      local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    else
      NetMessageMgr:SendMsg(NetAPIList.laba_info_req.Code, nil, NetCallbackGachaInfo, true, nil)
    end
    return true
  end
  return false
end
local NetCallbackRollItems = function(msgType, content)
  if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.laba_req.Code then
    if content.code ~= 0 then
      local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    else
      NetMessageMgr:SendMsg(NetAPIList.laba_info_req.Code, nil, NetCallbackGachaInfo, true, nil)
    end
    return true
  end
  return false
end
function DebugCommand.loadbattle()
  local GameTip = LuaObjectManager:GetLuaObject("GameTip")
  GameTip:Show("loadbattle")
  local GameObjectBattleReplay = LuaObjectManager:GetLuaObject("GameObjectBattleReplay")
  GameObjectBattleReplay:LoadFlashObject()
end
function DebugCommand.freebattle()
  local GameTip = LuaObjectManager:GetLuaObject("GameTip")
  GameTip:Show("freebattle")
  local GameObjectBattleReplay = LuaObjectManager:GetLuaObject("GameObjectBattleReplay")
  GameObjectBattleReplay:UnloadFlashObject()
  collectgarbage("collect")
end
function NetCallbackGachaInfo(msgType, content)
  if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.laba_info_req.Code then
    if content.code ~= 0 then
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  end
  if msgType == NetAPIList.laba_ntf.Code then
    if content.rate ~= 0 then
      NetMessageMgr:SendMsg(NetAPIList.laba_award_req.Code, nil, NetCallbackClaimAward, true, nil)
    else
      NetMessageMgr:SendMsg(NetAPIList.laba_req.Code, nil, NetCallbackRollItems, true, nil)
    end
    return true
  end
  return false
end
function DebugCommand.autoslot()
  NetMessageMgr:SendMsg(NetAPIList.laba_info_req.Code, nil, NetCallbackGachaInfo, true, nil)
end
local GenerateBattle = function(skillID)
  if not GameData.Spell.Keys[skillID] then
    return nil
  end
  local range = GameData.Spell.Keys[skillID].range_type
  local attackResponsStates = {
    "miss",
    "intercept",
    "shield",
    "hit"
  }
  local fleetPos = {
    {5},
    {
      5,
      2,
      8
    },
    {
      5,
      4,
      6
    },
    {
      5,
      2,
      8,
      4,
      6
    },
    {
      5,
      2,
      8,
      4,
      6
    }
  }
  local battleResult = {}
  battleResult.player1 = "\229\187\150\229\164\167\229\130\187.vbb.s991"
  battleResult.player2_avatar = "male"
  battleResult.player2 = "battle"
  battleResult.player1_avatar = "male"
  battleResult.reuslt = 1
  battleResult.player1_identity = 1
  battleResult.player1_pos = 5
  battleResult.player2_identity = 1
  battleResult.player2_pos = 5
  battleResult.player1_fleets = {
    [1] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 5
    },
    [2] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 2
    },
    [3] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 8
    },
    [4] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 4
    },
    [5] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 6
    }
  }
  battleResult.player2_fleets = {
    [1] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 5
    },
    [2] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 2
    },
    [3] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 8
    },
    [4] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 4
    },
    [5] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 1000000,
      cur_accumulator = 0,
      max_durability = 1000000,
      identity = 1,
      pos = 6
    }
  }
  battleResult.rounds = {}
  local roundIndex = 1
  for _, attackState in pairs(attackResponsStates) do
    do
      local round = {}
      round.attacks = {}
      round.buff = {}
      round.player1_action = true
      round.dot = {}
      round.pos = 5
      round.round_cnt = roundIndex
      round.sp_attacks = {}
      for _, pos in pairs(fleetPos[range]) do
        local spAtt = {}
        spAtt.durability = 999995
        spAtt.def_pos = pos
        spAtt.sp_id = skillID
        if attackState == "shield" then
          spAtt.shield = 999995
        else
          spAtt.shield = 0
        end
        spAtt.buff_effect = 0
        spAtt.acc = 0
        if attackState == "intercept" then
          spAtt.intercept = true
        else
          spAtt.intercept = false
        end
        spAtt.self_cast = false
        if attackState == "shield" then
          spAtt.shield_damage = 999995
        else
          spAtt.shield_damage = 0
        end
        spAtt.acc_change = 0
        if attackState == "miss" then
          spAtt.hit = false
        else
          spAtt.hit = true
        end
        spAtt.dur_damage = 5
        spAtt.round_cnt = 0
        spAtt.atk_pos = 5
        spAtt.crit = false
        table.insert(round.sp_attacks, spAtt)
      end
      table.insert(battleResult.rounds, round)
      roundIndex = roundIndex + 1
    end
    local round = {}
    round.attacks = {}
    round.buff = {}
    round.player1_action = false
    round.dot = {}
    round.pos = 5
    round.round_cnt = roundIndex
    round.sp_attacks = {}
    for _, pos in pairs(fleetPos[range]) do
      local spAtt = {}
      spAtt.durability = 999995
      spAtt.def_pos = pos
      spAtt.sp_id = skillID
      if attackState == "shield" then
        spAtt.shield = 999995
      else
        spAtt.shield = 0
      end
      spAtt.buff_effect = 0
      spAtt.acc = 0
      if attackState == "intercept" then
        spAtt.intercept = true
      else
        spAtt.intercept = false
      end
      spAtt.self_cast = false
      if attackState == "shield" then
        spAtt.shield_damage = 999995
      else
        spAtt.shield_damage = 0
      end
      spAtt.acc_change = 0
      if attackState == "miss" then
        spAtt.hit = false
      else
        spAtt.hit = true
      end
      spAtt.dur_damage = 5
      spAtt.round_cnt = 0
      spAtt.atk_pos = 5
      spAtt.crit = false
      table.insert(round.sp_attacks, spAtt)
    end
    table.insert(battleResult.rounds, round)
    roundIndex = roundIndex + 1
  end
  return battleResult
end
function DebugCommand.testbattle(battle)
  if type(battle) == "nil" then
    print("testbattle nil")
    local GameStateBattleMap = GameStateManager.GameStateBattleMap
    GameStateBattleMap.m_currentAreaID = 60
    GameStateManager.GameStateBattlePlay:InitBattle(GameStateManager.GameStateBattlePlay.MODE_PLAY, TestBattleData, 60, 0)
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateBattlePlay)
    local callback = function()
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
    end
    GameStateManager.GameStateBattlePlay:RegisterOverCallback(callback, nil)
  elseif type(battle) == "string" then
    print("testbattle " .. battle)
    local skills = GameData.Spell.Keys
    for i, v in pairs(skills) do
      if i >= 10000 and v.EFFECT == battle then
        battle = i
        break
      end
    end
    if type(battle) == "number" then
      local battleResult = GenerateBattle(battle)
      if battleResult then
        GameStateManager.GameStateBattlePlay:InitBattle(GameStateManager.GameStateBattlePlay.MODE_PLAY, battleResult, 60, 0)
        GameStateManager:SetCurrentGameState(GameStateManager.GameStateBattlePlay)
      end
    end
  elseif type(battle) == "number" then
    print("testbattle " .. battle)
    local battleResult = GenerateBattle(battle)
    if battleResult then
      GameStateManager.GameStateBattlePlay:InitBattle(GameStateManager.GameStateBattlePlay.MODE_PLAY, battleResult, 60, 0)
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateBattlePlay)
    end
  end
end
function DebugCommand.showwdmenu(menutype)
  local GameUIWDStuff = LuaObjectManager:GetLuaObject("GameUIWDStuff")
  GameUIWDStuff:Show(menutype)
end
function DebugCommand.enter_star_craft()
  local GameUIWDStuff = LuaObjectManager:GetLuaObject("GameUIStarCraftMap")
  GameStateManager:SetCurrentGameState(GameStateManager.GameStateStarCraft)
end
function DebugCommand.debugstory()
  local GameUICommonDialog = LuaObjectManager:GetLuaObject("GameUICommonDialog")
  local function callback()
    GameUICommonDialog:ForcePlayStory({100040, 100041})
  end
  GameUICommonDialog:ForcePlayStory({51226, 51227}, callback)
end
function DebugCommand.resetres()
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "update(money, 0)"
  }, nil, nil)
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "update(credit, 0)"
  }, nil, nil)
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "update(technique, 0)"
  }, nil, nil)
  NetMessageMgr:SendMsg(NetAPIList.gm_cmd_req.Code, {
    cmd = "update(prestige, 0)"
  }, nil, nil)
end
function DebugCommand:dodebug(debug_cmd)
  local params = string.gsub(debug_cmd, " +", "\002")
  local retstr = ext.doDebug and ext.doDebug(params) or ""
  if #retstr > 1 then
    print("[debug] ret " .. retstr)
  end
end
function DebugCommand.DbgVariable(t, strkey)
  local oldmeta = getmetatable(t)
  if oldmeta and oldmeta.__dbgkey then
    oldmeta.__dbgkey[strkey] = true
    oldmeta[strkey] = rawget(t, strkey)
    rawset(t, strkey, nil)
    return
  end
  local newmeta = {
    __dbgkey = {}
  }
  newmeta.__dbgkey[strkey] = true
  function newmeta.__newindex(t, k, v)
    if newmeta.__dbgkey[k] then
      newmeta[k] = v
      print("[DbgVariable]", k, tostring(v), debug.traceback())
    else
      if oldmeta then
        if oldmeta.__newindex then
          oldmeta.__newindex(t, k, v)
          return
        elseif oldmeta[k] then
          oldmeta[k] = v
          return
        end
      end
      rawset(t, k, v)
    end
  end
  function newmeta.__index(t, k)
    if newmeta.__dbgkey[k] then
      return newmeta[k]
    elseif oldmeta then
      if oldmeta.__index then
        return oldmeta.__index(t, k)
      else
        return oldmeta[k]
      end
    end
  end
  setmetatable(t, newmeta)
  newmeta[strkey] = rawget(t, strkey)
  rawset(t, strkey, nil)
end
function DebugCommand.Update()
  if not AutoUpdate.isTestGW then
    return
  end
  DebugCommand.DebugPoint("mainupdate")
  DebugCommand:dodebug("1")
end
if AutoUpdate.isTestGW then
  DebugCommand:dodebug("0")
end
