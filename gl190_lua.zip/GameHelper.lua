local GameHelper = LuaObjectManager:GetLuaObject("GameHelper")
local GameUIChat = LuaObjectManager:GetLuaObject("GameUIChat")
local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
local GameTip = LuaObjectManager:GetLuaObject("GameTip")
local GameUIKrypton = LuaObjectManager:GetLuaObject("GameUIKrypton")
local GameUICollect = LuaObjectManager:GetLuaObject("GameUICollect")
local GameUIAffairHall = LuaObjectManager:GetLuaObject("GameUIAffairHall")
local GameUITechnology = LuaObjectManager:GetLuaObject("GameUITechnology")
local GameFleetEnhance = LuaObjectManager:GetLuaObject("GameFleetEnhance")
local GameUIPrestigeRankUp = LuaObjectManager:GetLuaObject("GameUIPrestigeRankUp")
local GameStateConfrontation = GameStateManager.GameStateConfrontation
local GameStateKrypton = GameStateManager.GameStateKrypton
local GameStateBattleMap = GameStateManager.GameStateBattleMap
local GameStateEquipEnhance = GameStateManager.GameStateEquipEnhance
local GameUIUserAlliance = LuaObjectManager:GetLuaObject("GameUIUserAlliance")
local GameUIActivityNew = LuaObjectManager:GetLuaObject("GameUIActivityNew")
local QuestTutorialStarCharge = TutorialQuestManager.QuestTutorialStarCharge
local GameStateLab = GameStateManager.GameStateLab
local GameStateStore = GameStateManager.GameStateStore
local GameStateRecruit = GameStateManager.GameStateRecruit
local GameStateDaily = GameStateManager.GameStateDaily
local GameObjectMainPlanet = LuaObjectManager:GetLuaObject("GameObjectMainPlanet")
local GameUIArena = LuaObjectManager:GetLuaObject("GameUIArena")
local showDaily = false
local GameUIHalfPortrait = LuaObjectManager:GetLuaObject("GameUIHalfPortrait")
local HalfPortraitResource = require("data1/Half_Portrait_Resource.tfl")
local ItemBox = LuaObjectManager:GetLuaObject("ItemBox")
local GameItemBag = LuaObjectManager:GetLuaObject("GameItemBag")
local QuestTutorialEquip = TutorialQuestManager.QuestTutorialEquip
local QuestTutorialPrestige = TutorialQuestManager.QuestTutorialPrestige
local GameUIMessageDialog = LuaObjectManager:GetLuaObject("GameUIMessageDialog")
local GameStateScratchGacha = GameStateManager.GameStateScratchGacha
local GameUILab = LuaObjectManager:GetLuaObject("GameUILab")
require("FleetMatrix.tfl")
GameHelper.achievement = nil
GameHelper.daily = nil
GameHelper.currentTab = -1
GameHelper.todayList = nil
GameHelper.TabName = {
  affairs = 1,
  fleets = 2,
  exp = 3,
  alliance = 4,
  ["function"] = 5
}
GameHelper.EBattleResultType = {
  TYPE_BATTLE = 1,
  TYPE_CHALLENGE = 2,
  TYPE_COLONIAL = 3
}
GameHelper.BattleResultType = {
  [1] = {
    [2] = "battle_lose",
    [1] = "battle_win"
  },
  [2] = {
    [2] = "challenge_lose",
    [1] = "challenge_win"
  },
  [3] = {
    [2] = "colonial_lose",
    [1] = "colonial_win"
  }
}
GameHelper.executer = {
  action = nil,
  category = 0,
  subCategory = 0
}
GameHelper.localRewardData = {}
GameHelper.currenrRewardKey = nil
GameHelper.titleQuestId = -1
GameHelper.currentDay = nil
GameHelper.HalfPortraitTable = {}
GameHelper.HalfPortraitHeroResourceTable = {}
GameHelper.forcePrestige = nil
function GameHelper.GetTodayCallback(msgType, content)
  if msgType == NetAPIList.today_act_task_ack.Code then
    DebugOutPutTable(content, "today quest")
    GameHelper.todayText = content.task.id
    GameHelper.todayTextLocal = GameHelper.todayText
    if content.task.reward_number == -1 then
      GameHelper.RefreshAll(true)
      GameHelper:GetFlashObject():InvokeASCallback("_root", "ShowQuestCenter")
      return true
    end
    showDaily = true
    if showDaily then
      GameHelper.todayList = {}
      GameHelper.todayList.word = content.word
      GameHelper.todayList.background = content.background
      GameHelper.todayList.task = content.task
      for k, v in pairs(GameHelper.todayList.task.task_content) do
        v.enable = v.action ~= "total_online_time"
      end
      if content.background ~= "undefined" then
        GameStateDaily:GetTexture(content.background, function(extInfo)
          if GameHelper:GetFlashObject() then
            GameHelper:GetFlashObject():ReplaceTexture("LAZY_LOAD_TODAY_PIC_0.png", extInfo.FileName)
          end
        end)
      end
      if content.word ~= "undefined" then
        GameStateDaily:GetTexture(content.word, function(extInfo)
          if GameHelper:GetFlashObject() then
            GameHelper:GetFlashObject():ReplaceTexture("LAZY_LOAD_TODAY_QuestBAR_PIC.png", extInfo.FileName)
          end
        end)
      end
      GameHelper:GetFlashObject():InvokeASCallback("_root", "SetToday", GameLoader:GetGameText(content.task.task_name), content.title_font, content.banner_font)
    end
    GameHelper.RefreshAll(true)
    GameHelper:GetFlashObject():InvokeASCallback("_root", "ShowQuestCenter")
    return true
  end
  return false
end
function GameHelper:GetDayState(day)
  if day.max_task_count == 0 then
    day.state = 1
    return
  end
  if day.current_task_count == day.max_task_count then
    day.state = 2
    return
  end
  if 0 <= day.today then
    day.state = 1
    return
  end
  if day.can_redo == false then
    day.state = 4
    return
  end
  day.state = 3
end
function GameHelper:isTodayLived()
  local levelInfo = GameGlobalData:GetData("levelinfo")
  if levelInfo.level < 22 then
    return false
  end
  if not showDaily then
    return false
  end
  if GameHelper.todayList.task.is_finished and not GameHelper.todayList.task.is_get_reward then
    self:GetFlashObject():InvokeASCallback("_root", "SetTodayCount", 1)
    return true
  end
  local count = 0
  for k, v in pairs(GameHelper:GetTodaySubQuestList()) do
    if not v.is_get_reward and v.is_finished then
      count = count + 1
    end
  end
  if self:GetFlashObject() then
    self:GetFlashObject():InvokeASCallback("_root", "SetTodayCount", count)
  end
  return count > 0
end
function GameHelper:RequestToday()
  NetMessageMgr:SendMsg(NetAPIList.today_act_task_req.Code, nil, GameHelper.GetTodayCallback, true, nil)
  if GameHelper.daily == nil then
    NetMessageMgr:SendMsg(NetAPIList.enter_monthly_req.Code, nil, GameHelper.GetDailyCallback, true, nil)
  end
  if GameHelper.achievement == nil then
    NetMessageMgr:SendMsg(NetAPIList.achievement_list_req.Code, nil, GameHelper.GetAchievementCallBack, true, nil)
  end
  NetMessageMgr:SendMsg(NetAPIList.view_award_req.Code, nil, GameHelper.GetRewardDaily, true, nil)
end
function GameHelper:OnInitGame()
end
function GameHelper:Init()
  self.executer.action = nil
  self:LoadFlashObject()
  local flash_obj = self:GetFlashObject()
  local levelInfo = GameGlobalData:GetData("levelinfo")
  if flash_obj then
    flash_obj:InvokeASCallback("_root", "initFlashObject", levelInfo.level)
    flash_obj:InvokeASCallback("_root", "setDisplayText", GameLoader:GetGameText("LC_MENU_NEW_DAILY_UNFINISH_CHAR"), GameLoader:GetGameText("LC_MENU_NEW_DAILY_FINISH_CHAR"), GameLoader:GetGameText("LC_MENU_NEW_DAILY_CLOSED_CHAR"), GameLoader:GetGameText("LC_MENU_EXECUTE_CHAR"), GameLoader:GetGameText("LC_MENU_NEW_DAILY_REMEDY_BUTTON"), GameLoader:GetGameText("LC_MENU_NEW_DAILY_CAN_REMEDY_CHAR"), GameLoader:GetGameText("LC_MENU_NEW_DAILY_CLOSED_CHAR"), GameLoader:GetGameText("LC_MENU_FACEBOOK_REWARDS_CREDIT"), GameLoader:GetGameText("LC_MENU_FACEBOOK_REWARDS_HISTORY"), GameLoader:GetGameText("LC_MENU_CELESTIAL_PORTAL_REACHED"))
  end
  GameGlobalData:RegisterDataChangeCallback("levelinfo", GameHelper.RefreshAll)
  GameGlobalData:RegisterDataChangeCallback("task_statistic", GameHelper.RefreshAll)
end
function GameHelper:OnAddToGameState()
  if GameUtils:GetTutorialHelp() then
    local GameUIMaskLayer = LuaObjectManager:GetLuaObject("GameUIMaskLayer")
    GameUtils:MaskLayerMidTutorial(GameLoader:GetGameText("LC_MENU_ASSISTANT_INFO_21"))
  end
  self:Init()
  self:DownloadQuestList()
  if GameHelper.forcePrestige then
    GameHelper.EnterPage = 4
    GameHelper:GetFlashObject():InvokeASCallback("_root", "setDailyTab", GameHelper.EnterPage)
    GameHelper.EnterPage = nil
  end
end
function GameHelper:SetEnterPage(index)
  self.EnterPage = index
end
function GameHelper:OnEraseFromGameState()
  showDaily = false
  GameHelper.todayList = nil
  GameHelper.daily = nil
  GameHelper.achievement = nil
  self:Clear()
  self:UnloadFlashObject()
end
function GameHelper:Clear()
  self:GetFlashObject():InvokeASCallback("_root", "clearListBox")
  GameGlobalData:RemoveDataChangeCallback("levelinfo", GameHelper.RefreshAll)
  GameGlobalData:RemoveDataChangeCallback("task_statistic", GameHelper.RefreshAll)
end
function GameHelper:Update(dt)
  self:GetFlashObject():InvokeASCallback("_root", "UpdateQuestList")
  self:GetFlashObject():Update(dt)
end
function GameHelper.GetDayDetailCallback(msgType, content)
  if msgType == NetAPIList.view_each_task_ack.Code then
    GameHelper.cost = content.cost
    GameHelper.touchDailyContent = content.task.task_content
    local day = GameHelper.daily.each_day[GameHelper.currentDay]
    DebugOutPutTable(day, "send day")
    local can_redo = day.can_redo
    local not_redo_all = false
    table.sort(GameHelper.touchDailyContent, GameHelper.sortTodaySubQuestList)
    local isUnLockAll = true
    for k, v in ipairs(GameHelper.touchDailyContent) do
      if immanentversion170 == 4 or immanentversion170 == 5 then
        v.name = GameLoader:GetGameText("LC_QUEST170_TODAY_QUEST_" .. v.action)
        v.info = GameLoader:GetGameText("LC_QUEST170_TODAY_QUEST_DESC_" .. v.action)
      else
        v.name = GameLoader:GetGameText("LC_QUEST_TODAY_QUEST_" .. v.action)
        v.info = GameLoader:GetGameText("LC_QUEST_TODAY_QUEST_DESC_" .. v.action)
      end
      v.enable = v.action ~= "total_online_time"
      local reward = v.rewards[1]
      local extInfo = {}
      extInfo.id = v.id
      v.icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(reward, extInfo, function(extInfo)
        DebugOut("extInfo:" .. extInfo.id .. ":=>item_" .. extInfo.item_id)
        if GameHelper:GetFlashObject() then
          GameHelper:GetFlashObject():InvokeASCallback("_root", "updateDailyFrame", extInfo.id, "item_" .. extInfo.item_id)
        end
      end)
      if not v.is_enabled then
        isUnLockAll = false
      end
      if v.is_enabled and not v.is_finished then
        not_redo_all = true
      end
      v.number = GameHelper:GetAwardCount(reward.item_type, reward.number, reward.no)
    end
    can_redo = can_redo and not_redo_all and isUnLockAll
    local reward = content.task.rewards[1]
    local icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(reward, nil, function(extInfo)
      if GameHelper:GetFlashObject() then
        GameHelper:GetFlashObject():InvokeASCallback("_root", "updateDailyFrame", 0, "item_" .. extInfo.item_id)
      end
    end)
    local number = GameHelper:GetAwardCount(reward.item_type, reward.number, reward.no)
    local allTitle = GameLoader:GetGameText("LC_MENU_NEW_DAILY_FINISH_QUEST_CHAR")
    local allInfo = GameLoader:GetGameText("LC_MENU_NEW_DAILY_INFO_1")
    DebugOutPutTable(content.cost, "day cost")
    DebugOutPutTable(GameHelper.touchDailyContent, "day detail")
    if GameHelper:GetFlashObject() then
      if GameHelper.updateDetail then
        GameHelper:GetFlashObject():InvokeASCallback("_root", "UpdateSelectDay", content.task.id, icon, number, allTitle, allInfo, GameHelper.touchDailyContent, day, content.cost, can_redo and day.today < 0)
      else
        GameHelper:GetFlashObject():InvokeASCallback("_root", "SetSelectDay", content.task.id, icon, number, allTitle, allInfo, GameHelper.touchDailyContent, day, content.cost, can_redo and day.today < 0)
      end
    end
    return true
  end
  return false
end
function GameHelper.GetDailyCallback(msgType, content)
  if msgType == NetAPIList.enter_monthly_ack.Code or msgType == NetAPIList.other_monthly_ack.Code then
    DebugOutPutTable(content, "daily day")
    if not GameHelper.daily then
      GameHelper.daily = {}
    else
      GameHelper.daily.each_key = {}
      GameHelper.daily.each_day = content.each_day
    end
    GameHelper.daily.each_key = {}
    GameHelper.daily.each_day = content.each_day
    local each_day = GameHelper.daily.each_day
    for k, v in ipairs(each_day) do
      GameHelper.daily.each_key[k] = v.id
    end
    local todays = LuaUtils:string_split(GameHelper.todayTextLocal, "-")
    local now_year = tonumber(todays[1])
    local now_month = tonumber(todays[2])
    local now_day = tonumber(todays[3])
    local background = "undefined"
    local activity = 1
    local flashObj = GameHelper:GetFlashObject()
    local isTitle = true
    local downloadImgCall = {}
    for k, v in ipairs(GameHelper.daily.each_key) do
      local day = each_day[k]
      local pRet = LuaUtils:string_split(day.id, "-")
      if day.is_today then
        day.today = 0
      else
        local ret_year = tonumber(pRet[1])
        local ret_month = tonumber(pRet[2])
        local ret_day = tonumber(pRet[3])
        if ret_year * 10000 + ret_month * 100 + ret_day > now_year * 10000 + now_month * 100 + now_day then
          day.today = 1
        else
          day.today = -1
        end
      end
      day.tag = pRet[3]
      if day.tag == "01" then
        day.tag = GameLoader:GetGameText("LC_MENU_NEW_DAILY_MONTH_" .. tostring(tonumber(pRet[2])))
        if isTitle then
          isTitle = false
          flashObj:InvokeASCallback("_root", "setMonthTitle", day.tag)
        end
      end
      GameHelper:GetDayState(day)
      if background ~= day.background then
        background = day.background
        if background ~= "undefined" then
          local img = {}
          img.path = day.background
          img.activity = activity
          table.insert(downloadImgCall, img)
          activity = activity + 1
        end
      end
      if day.background ~= "undefined" then
        day.activity = activity - 1
      end
    end
    if content.current then
      GameHelper.daily.current = content.current
    end
    if content.max then
      GameHelper.daily.max = content.max
    end
    local levelInfo = GameGlobalData:GetData("levelinfo")
    if GameHelper.EnterPage then
      if levelinfo.level < 22 then
        GameHelper.EnterPage = 3
      end
      GameHelper:GetFlashObject():InvokeASCallback("_root", "setDailyTab", GameHelper.EnterPage)
      GameHelper.EnterPage = nil
      GameHelper:GetFlashObject():unlockInput()
    end
    GameHelper:UpdateDaily()
    for k, v in pairs(downloadImgCall) do
      GameStateDaily:GetTexture(v.path, function(extInfo)
        if GameHelper:GetFlashObject() then
          GameHelper:GetFlashObject():ReplaceTexture("LAZY_LOAD_EVENTDAY_PIC_" .. extInfo.arg.activity .. ".png", extInfo.FileName)
          GameHelper:GetFlashObject():InvokeASCallback("_root", "enabledDayPic", extInfo.arg.activity)
          DebugOut("day.background==>" .. extInfo.arg.activity .. "File:" .. extInfo.FileName)
        end
      end, {
        activity = v.activity
      })
    end
    downloadImgCall = {}
    return true
  end
  return false
end
function GameHelper.GetAchievementCallBack(msgtype, content)
  if msgtype == NetAPIList.common_ack.Code and content.api == NetAPIList.achievement_list_req.Code then
    if content.code ~= 0 then
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  elseif msgtype == NetAPIList.achievement_list_ack.Code then
    GameHelper:GenerateAchievementData(content)
    GameHelper:InitAchievement()
    GameHelper:SetCupInfo()
    GameHelper:RefreshAchievement()
    local levelInfo = GameGlobalData:GetData("levelinfo")
    if levelInfo.level < 22 and not GameHelper.forcePrestige then
      GameHelper.EnterPage = 3
    end
    if GameHelper.EnterPage == 3 then
      GameHelper:GetFlashObject():InvokeASCallback("_root", "setDailyTab", GameHelper.EnterPage)
      GameHelper.EnterPage = nil
      GameHelper:GetFlashObject():unlockInput()
    end
    return true
  end
  return false
end
function GameHelper.UpdatePriceCallback(msgType, content)
  if msgType == NetAPIList.view_each_task_ack.Code then
    GameHelper.cost = content.cost
    if GameHelper:GetFlashObject() then
      GameHelper:GetFlashObject():InvokeASCallback("_root", "updateCost", GameHelper.cost.once_cost)
    end
    local today = GameHelper.daily.each_day[GameHelper.currentDay]
    today.current_task_count = 0
    local isFinishedAll = true
    local updateCall = true
    for k, v in pairs(content.task.task_content) do
      if v.is_finished then
        today.current_task_count = today.current_task_count + 1
      else
        if v.is_enabled then
          updateCall = false
        end
        isFinishedAll = false
      end
    end
    if isFinishedAll then
      if GameHelper:GetFlashObject() then
        GameHelper:GetFlashObject():InvokeASCallback("_root", "increaseDailyProcess")
      end
      GameHelper.daily.current = GameHelper.daily.current + 1
    end
    if updateCall then
      GameHelper:UpdateFinishAll()
    end
    if GameHelper:GetFlashObject() then
      GameHelper:GetFlashObject():InvokeASCallback("_root", "SetTodayQuestFinish", GameHelper.currentDay, today.current_task_count, GameHelper.currentRedo)
    end
    GameHelper.currentRedo = 0
    return true
  end
  return false
end
function GameHelper.GetRedocallback(msgType, content)
  if msgType == NetAPIList.redo_task_ack.Code then
    if content.code == 1 then
      local today_id = GameHelper.daily.each_key[GameHelper.currentDay]
      NetMessageMgr:SendMsg(NetAPIList.view_each_task_req.Code, {id = today_id}, GameHelper.UpdatePriceCallback, true, nil)
    elseif content.code == 0 then
      GameTip:Show(GameLoader:GetGameText("LC_MENU_NOT_ENOUGH_CREDIT"))
    end
    return true
  end
  return false
end
function GameHelper.GetRewardDaily(msgType, content)
  if msgType == NetAPIList.view_award_ack.Code then
    DebugOutPutTable(content, "reward daily")
    GameHelper.dailyAward = content.award
    GameHelper.updateRewardDaily()
    return true
  end
  return false
end
function GameHelper.updateRewardDaily()
  local hasReward = false
  table.sort(GameHelper.dailyAward, function(v1, v2)
    if v1.is_receive and v2.is_receive then
      return v1.count < v2.count
    end
    if not v1.is_receive and v2.is_receive then
      return true
    end
    if not v1.is_receive and not v2.is_receive then
      return v1.count < v2.count
    end
    return false
  end)
  for k, v in ipairs(GameHelper.dailyAward) do
    v.is_finished = false
    if immanentversion170 == 4 or immanentversion170 == 5 then
      v.rewardTitle = string.format(GameLoader:GetGameText("LC_QUEST170_TODAY_QUEST_REWARD"), v.count)
    else
      v.rewardTitle = string.format(GameLoader:GetGameText("LC_QUEST_TODAY_QUEST_REWARD"), v.count)
    end
    v.is_finished = v.count <= GameHelper.daily.current
    if v.is_finished and not v.is_receive then
      hasReward = true
    end
    for kk, kv in ipairs(v.rewards) do
      local extInfo = {}
      extInfo.rewardId = k
      extInfo.rewardIndex = kk
      kv.icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(kv, extInfo, function(extInfo)
        if GameHelper:GetFlashObject() then
          GameHelper:GetFlashObject():InvokeASCallback("_root", "updateRewardFrame", extInfo.rewardId, extInfo.rewardIndex, "item_" .. extInfo.item_id)
        end
      end)
      kv.count = GameHelper:GetAwardCount(kv.item_type, kv.number, kv.no)
      kv.name = GameHelper:GetAwardTypeText(kv.item_type, kv.number)
    end
  end
  GameHelper:GetFlashObject():InvokeASCallback("_root", "initRewardList", GameHelper.dailyAward, hasReward, GameHelper.forcePrestige)
end
function GameHelper:UpdateDaily(...)
  local flashObj = GameHelper:GetFlashObject()
  if flashObj then
    flashObj:InvokeASCallback("_root", "UpdateDaily", GameHelper.daily.each_day, GameHelper.daily.current, GameHelper.daily.max)
  end
end
function GameHelper:UpdateFinishAll()
  NetMessageMgr:SendMsg(NetAPIList.view_award_req.Code, nil, GameHelper.GetRewardDaily, true, nil)
  GameHelper.updateDetail = true
  local today_id = GameHelper.daily.each_key[GameHelper.currentDay]
  NetMessageMgr:SendMsg(NetAPIList.view_each_task_req.Code, {id = today_id}, GameHelper.GetDayDetailCallback, true, nil)
end
function GameHelper:GenerateAchievementData(content)
  GameHelper.achievement = {}
  GameHelper.achievement.cup = {}
  GameHelper.achievement.list = {}
  for k, v in ipairs(content.achievement_list or {}) do
    local item = {}
    item = LuaUtils:table_copy(v)
    item.title = GameLoader:GetGameText("LC_ACHIEVEMENT_title_" .. tostring(v.id))
    item.desc = GameLoader:GetGameText("LC_ACHIEVEMENT_desc_" .. tostring(v.id))
    item.btnText = GameLoader:GetGameText("LC_MENU_NEW_SPACE_GOTO_BUTTON")
    if item.number >= 100000 then
      item.number = GameUtils.numberConversion(item.number)
    end
    if 100000 <= item.finish_count then
      item.finish_count = GameUtils.numberConversion(item.finish_count)
    end
    item.rewardsList = {}
    if GameHelper.achievement.cup["level_" .. v.level] == nil then
      GameHelper.achievement.cup["level_" .. v.level] = {}
      GameHelper.achievement.cup["level_" .. v.level].total = 0
      GameHelper.achievement.cup["level_" .. v.level].complete = 0
    end
    GameHelper.achievement.cup["level_" .. v.level].total = GameHelper.achievement.cup["level_" .. v.level].total + 1
    if 0 < v.is_finished then
      GameHelper.achievement.cup["level_" .. v.level].complete = GameHelper.achievement.cup["level_" .. v.level].complete + 1
      item.btnText = GameLoader:GetGameText("LC_MENU_CAPTION_RECEIVE")
    end
    if v.is_finished == 0 then
      item.order = v.weight
    elseif v.is_finished == 1 then
      item.order = v.weight - 1000
    elseif v.is_finished == 2 then
      item.order = v.weight + 1000
    end
    for k1, v1 in ipairs(v.rewards or {}) do
      local tmp = {}
      tmp.count = GameHelper:GetAwardCount(v1.item_type, v1.number, v1.no)
      tmp.displayCount = GameUtils.numberConversion(math.floor(tmp.count))
      tmp.frame = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(v1)
      tmp.model = v1
      item.rewardsList[#item.rewardsList + 1] = tmp
    end
    if v.can_show then
      GameHelper.achievement.list[#GameHelper.achievement.list + 1] = item
    end
  end
  GameHelper:SortAchievemnet()
end
function GameHelper:InitAchievement()
  if GameHelper.achievement and self:GetFlashObject() then
    self:GetFlashObject():InvokeASCallback("_root", "InitAchievement", #GameHelper.achievement.list)
  end
end
function GameHelper:SetCupInfo()
  if GameHelper.achievement and self:GetFlashObject() then
    self:GetFlashObject():InvokeASCallback("_root", "SetAchievementCup", GameHelper.achievement.cup)
  end
end
function GameHelper:OnAchievementItem(itemIndex)
  if GameHelper.achievement.list[itemIndex] and self:GetFlashObject() then
    self:GetFlashObject():InvokeASCallback("_root", "UpdateAchievementItem", itemIndex, GameHelper.achievement.list[itemIndex])
  end
end
function GameHelper:GoToAchievement(id)
  local gotoType = ""
  for k, v in pairs(GameHelper.achievement.list) do
    if v.id == id then
      gotoType = v.classify
      break
    end
  end
  if gotoType == "maintask" then
    GameQuestMenu.tabTag = 1
    GameQuestMenu:ShowQuestMenu()
  elseif gotoType == "arena" then
    if GameUtils:IsModuleUnlock("arena") then
      GameUIArena.mCurrentArenaType = GameUIArena.ARENA_TYPE.normalArena
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
    end
  elseif gotoType == "vip" then
    if not GameGlobalData:FTPVersion() then
      GameVip:showVip(false)
    end
  elseif gotoType == "tech" then
    if GameUtils:IsModuleUnlock("tech") then
      GameUITechnology:EnterTechnology()
    end
  elseif gotoType == "krypton" then
    if GameUtils:IsModuleUnlock("krypton") then
      GameStateKrypton:EnterKrypton(GameStateKrypton.KRYPTON)
    end
  elseif gotoType == "activity" then
    GameStateManager:GetCurrentGameState():AddObject(GameUIActivityNew)
  elseif gotoType == "tc" then
    if GameUtils:IsModuleUnlock("tc") and GameGlobalData.starCraftData.open then
      local GameUIStarCraftEnter = LuaObjectManager:GetLuaObject("GameUIStarCraftEnter")
      GameUIStarCraftEnter:Show()
    else
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
    end
  elseif gotoType == "mining" then
    if GameUtils:IsModuleUnlock("mining") then
      local GameStateMineMap = GameStateManager.GameStateMineMap
      GameStateManager:SetCurrentGameState(GameStateMineMap)
    end
  elseif gotoType == "colonial" then
    if GameUtils:IsModuleUnlock("colonial") then
      GameStateManager:GetCurrentGameState():EraseObject(self)
      local gs = GameStateManager.GameStateColonization
      gs.lastState = GameStateManager:GetCurrentGameState()
      GameStateManager:SetCurrentGameState(gs)
    end
  elseif gotoType == "dicoslab" then
    if GameUtils:IsModuleUnlock("dicoslab") then
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateLab)
    end
  elseif gotoType == "fleets" then
    if GameUtils:IsModuleUnlock("fleets") then
      local GameStateEquipEnhance = GameStateManager.GameStateEquipEnhance
      GameStateEquipEnhance:EnterEquipEnhance(-1)
    end
  elseif gotoType == "hire" then
    if GameUtils:IsModuleUnlock("hire") then
      local GameStatePlayerMatrix = GameStateManager.GameStatePlayerMatrix
      GameStateManager:SetCurrentGameState(GameStatePlayerMatrix)
    end
  elseif gotoType == "remodel" then
    if GameUtils:IsModuleUnlock("remodel") then
      local GameUIFactory = LuaObjectManager:GetLuaObject("GameUIFactory")
      GameStateManager:GetCurrentGameState():AddObject(GameUIFactory)
      GameUIFactory.EnterRebuild = true
    end
  elseif gotoType == "infinite_cosmos" then
    if GameUtils:IsModuleUnlock("infinite_cosmos") then
      local instanceActivityList = GameUIActivityNew:getInstanceData()
      if instanceActivityList then
        GameObjectClimbTower:gotoInstanceSelectScreen(instanceActivityList)
      else
        GameUIActivityNew:RequestActivity(true, GameUILab.gotoInstanceLater)
      end
    end
  elseif gotoType == "wdc" then
    if GameUtils:IsModuleUnlock("arena") then
      if GameUIArena.advancedArenaEnterData == nil then
        NetMessageMgr:SendMsg(NetAPIList.enter_champion_req.Code, nil, function(msgType, content)
          if msgType == NetAPIList.enter_champion_ack.Code then
            GameUIArena.advancedArenaEnterData = content.world_champion
            if GameUIArena.advancedArenaEnterData.states ~= 1 then
              GameUIArena.mCurrentArenaType = GameUIArena.ARENA_TYPE.normalArena
              GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
            elseif GameUIArena.advancedArenaEnterData.states == 1 then
              GameUIArena.mCurrentArenaType = GameUIArena.ARENA_TYPE.wdc
              GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
            end
            return true
          end
          return false
        end, true)
      elseif GameUIArena.advancedArenaEnterData.states ~= 1 then
        GameUIArena.mCurrentArenaType = GameUIArena.ARENA_TYPE.normalArena
        GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
      elseif GameUIArena.advancedArenaEnterData.states == 1 then
        GameUIArena.mCurrentArenaType = GameUIArena.ARENA_TYPE.wdc
        GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
      end
    end
  elseif gotoType == "wd" then
    if GameUtils:IsModuleUnlock("wd") then
      if not GameStateMainPlanet.WDActive then
        local QuestTutorialWD = TutorialQuestManager.QuestTutorialWD
        self:GetFlashObject():InvokeASCallback("_root", "HideTutorialWorld")
        self:GetFlashObject():InvokeASCallback("_root", "CloseWDEntrency")
      end
      local GameUIWDPlanetSelect = LuaObjectManager:GetLuaObject("GameUIWDPlanetSelect")
      GameUIWDPlanetSelect.EnterEventDirectly = true
      local gs = GameStateManager.GameStateWD
      DebugOut("1-1-1-1-1-1-1")
      if not GameObjectMainPlanet.fetchNtfForWD then
        local playerList = {}
        local requestParam = {notifies = playerList}
        NetMessageMgr:SendMsg(NetAPIList.alliance_notifies_req.Code, requestParam, GameObjectMainPlanet.fetchNtfForWDCallback, true, nil)
        if not GameStateManager.GameStateWD.AllDataFetched() and GameStateManager.GameStateWD.HaveAlliance() then
          DebugOut("wait here 1")
          GameObjectMainPlanet.waitFetchNtfForWD = true
          GameWaiting:ShowLoadingScreen()
        end
      end
      if GameStateManager.GameStateWD.wdList ~= nil and GameObjectMainPlanet.fetchNtfForWD and (GameStateManager.GameStateWD.HaveAlliance() and GameStateManager.GameStateWD.AllDataFetched() or not GameStateManager.GameStateWD.HaveAlliance()) then
        if GameStateManager.GameStateWD.WDBaseInfo.State == GameStateManager.GameStateWD.WDState.BATTLE and not GameStateManager.GameStateWD.OpponentDataFetched() then
          GameObjectMainPlanet.waitFetchNtfForWD = true
          GameWaiting:ShowLoadingScreen()
        else
          gs.lastState = GameStateManager:GetCurrentGameState()
          GameStateManager:SetCurrentGameState(gs)
          DebugOut("1-1-1-1-1-1-2")
        end
      end
    end
  elseif gotoType == "wc" then
    if GameUtils:IsModuleUnlock("wc") then
      GameUIWorldChampion:RequestEnterWC()
    end
  elseif gotoType == "centalsystem" then
    if GameUtils:IsModuleUnlock("centalsystem") then
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateTacticsCenter)
    end
  elseif gotoType == "shop" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateStore)
  elseif gotoType == "alliance" and GameUtils:IsModuleUnlock("alliance") then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateAlliance)
  end
end
function GameHelper:ReqAchievementReward(id)
  local param = {}
  param.id = id
  NetMessageMgr:SendMsg(NetAPIList.achievement_reward_receive_req.Code, param, GameHelper.GetAchievementRewardCallBack, true, nil)
end
function GameHelper.GetAchievementRewardCallBack(msgtype, content)
  if msgtype == NetAPIList.common_ack.Code and content.api == NetAPIList.achievement_reward_receive_req.Code then
    if content.code ~= 0 then
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  elseif msgtype == NetAPIList.achievement_reward_receive_ack.Code then
    for k, v in pairs(GameHelper.achievement.list or {}) do
      if v.id == content.id then
        v.is_finished = 2
        v.order = v.weight + 1000
      end
    end
    for k, v in ipairs(content.achievement_list or {}) do
      local item = {}
      item = LuaUtils:table_copy(v)
      item.title = GameLoader:GetGameText("LC_ACHIEVEMENT_title_" .. tostring(v.id))
      item.desc = GameLoader:GetGameText("LC_ACHIEVEMENT_desc_" .. tostring(v.id))
      item.btnText = GameLoader:GetGameText("LC_MENU_NEW_SPACE_GOTO_BUTTON")
      if item.number >= 100000 then
        item.number = GameUtils.numberConversion(item.number)
      end
      if 100000 <= item.finish_count then
        item.finish_count = GameUtils.numberConversion(item.finish_count)
      end
      item.rewardsList = {}
      if GameHelper.achievement.cup["level_" .. v.level] == nil then
        GameHelper.achievement.cup["level_" .. v.level] = {}
        GameHelper.achievement.cup["level_" .. v.level].total = 0
        GameHelper.achievement.cup["level_" .. v.level].complete = 0
      end
      GameHelper.achievement.cup["level_" .. v.level].total = GameHelper.achievement.cup["level_" .. v.level].total + 1
      if 0 < v.is_finished then
        GameHelper.achievement.cup["level_" .. v.level].complete = GameHelper.achievement.cup["level_" .. v.level].complete + 1
        item.btnText = GameLoader:GetGameText("LC_MENU_CAPTION_RECEIVE")
      end
      if v.is_finished == 0 then
        item.order = v.weight
      elseif v.is_finished == 1 then
        item.order = v.weight - 1000
      elseif v.is_finished == 2 then
        item.order = v.weight + 1000
      end
      for k1, v1 in ipairs(v.rewards or {}) do
        local tmp = {}
        tmp.count = GameHelper:GetAwardCount(v1.item_type, v1.number, v1.no)
        tmp.displayCount = GameUtils.numberConversion(math.floor(tmp.count))
        tmp.frame = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(v1)
        tmp.model = v1
        item.rewardsList[#item.rewardsList + 1] = tmp
      end
      if v.can_show then
        GameHelper.achievement.list[#GameHelper.achievement.list + 1] = item
      end
    end
    GameHelper:SortAchievemnet()
    GameHelper:RefreshAchievement()
    if GameHelper:GetFlashObject() then
      GameHelper:GetFlashObject():InvokeASCallback("_root", "RefreshAchievementList", #GameHelper.achievement.list)
    end
    return true
  end
  return false
end
function GameHelper:SortAchievemnet()
  if GameHelper.achievement and GameHelper.achievement.list then
    table.sort(GameHelper.achievement.list, function(a, b)
      return a.order < b.order
    end)
  end
end
function GameHelper:OnFSCommand(cmd, arg)
  if cmd == "TapDaily" then
    GameHelper.currentDay = tonumber(arg)
    local id = GameHelper.daily.each_key[tonumber(arg)]
    DebugOut("TapDaily:" .. arg .. ":" .. id)
    GameHelper.updateDetail = false
    NetMessageMgr:SendMsg(NetAPIList.view_each_task_req.Code, {id = id}, GameHelper.GetDayDetailCallback, true, nil)
  end
  if cmd == "TapBuqian" then
    local str = GameLoader:GetGameText("LC_MENU_COST_CREDIT_ALERT_CHAR")
    local cost = GameHelper.cost.each_cost
    if arg == "0" then
      cost = GameHelper.cost.once_cost
    end
    local infoText = string.format(str, cost)
    GameHelper.currentRedo = tonumber(arg)
    GameUtils:CreditCostConfirm(infoText, function()
      local today_id = GameHelper.daily.each_key[GameHelper.currentDay]
      DebugOut("buqian:" .. today_id .. "=>" .. GameHelper.currentRedo)
      NetMessageMgr:SendMsg(NetAPIList.redo_task_req.Code, {
        id = today_id,
        sub_id = GameHelper.currentRedo
      }, GameHelper.GetRedocallback, true, nil)
    end, true, nil)
  end
  if cmd == "TapAward" then
    do
      local pData = LuaUtils:string_split(arg, "\001")
      local id = tonumber(pData[1])
      local count = tonumber(pData[2])
      NetMessageMgr:SendMsg(NetAPIList.get_award_req.Code, {id = id, count = count}, function(msgType, content)
        if msgType == NetAPIList.get_award_ack.Code then
          for i, v in ipairs(GameHelper.dailyAward) do
            if v.count == count then
              v.is_receive = true
              GameHelper.updateRewardDaily()
              break
            end
          end
          return true
        end
        return false
      end, true, nil)
    end
  end
  if cmd == "TapExecute" then
    local id = tonumber(arg)
    local day
    for k, v in pairs(GameHelper.touchDailyContent) do
      if v.id == id then
        day = v
        break
      end
    end
    if day == nil then
      return
    end
    self.executer.action = day.action
    if self.executer.action then
      self:GotoExecSubQuest(self.executer)
      self.executer.action = nil
    end
  end
  if cmd == "TapTab" then
    local index = tonumber(arg)
    if index ~= 4 then
      GameHelper.forcePrestige = nil
    end
    self:GetFlashObject():InvokeASCallback("_root", "SetBtnHelpIsShow", false)
    if index == 1 then
    elseif index == 4 then
      if GameItemBag.EquipTutorialAgain then
        AddFlurryEvent("TutorialItem_SelectFleet", {}, 2)
      end
      if QuestTutorialEquip:IsActive() and not QuestTutorialEquip:IsFinished() then
        AddFlurryEvent("FirstClickFleets", {}, 1)
        AddFlurryEvent("TutorialSelectFleets", {}, 2)
      elseif QuestTutorialPrestige:IsActive() and not QuestTutorialPrestige:IsFinished() then
        AddFlurryEvent("SecondClickFleets", {}, 1)
      end
      self:Show()
      self:GetFlashObject():InvokeASCallback("_root", "SetBtnHelpIsShow", true)
    elseif GameHelper.daily == nil then
      NetMessageMgr:SendMsg(NetAPIList.enter_monthly_req.Code, nil, GameHelper.GetDailyCallback, true, nil)
    end
  end
  if cmd == "SwitchDaily" then
    local index = tonumber(arg)
    DebugOut("today now text:" .. GameHelper.todayText)
    local todays = LuaUtils:string_split(GameHelper.todayText, "-")
    local year = tonumber(todays[1])
    local month = tonumber(todays[2])
    if index < 0 then
      month = month - 1
      if month == 0 then
        year = year - 1
        month = 12
      end
      GameHelper.todayText = year .. "-" .. month .. "-1"
      NetMessageMgr:SendMsg(NetAPIList.other_monthly_req.Code, {
        id = GameHelper.todayText
      }, GameHelper.GetDailyCallback, true, nil)
    elseif index == 0 then
      NetMessageMgr:SendMsg(NetAPIList.enter_monthly_req.Code, nil, GameHelper.GetDailyCallback, true, nil)
      GameHelper.todayText = GameHelper.todayTextLocal
    else
      month = month + 1
      if month == 13 then
        year = year + 1
        month = 1
      end
      GameHelper.todayText = year .. "-" .. month .. "-1"
      NetMessageMgr:SendMsg(NetAPIList.other_monthly_req.Code, {
        id = GameHelper.todayText
      }, GameHelper.GetDailyCallback, true, nil)
    end
  end
  if cmd == "closeQuestCenter" and self.executer.action then
    self:GotoExecSubQuest(self.executer)
    self.executer.action = nil
  end
  if cmd == "close_state" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
  end
  if cmd == "tabChanged" then
    GameHelper:TabChanged(tonumber(arg))
  end
  if cmd == "onItemEnter" then
    GameHelper:RefreshItem(tonumber(arg))
  end
  if cmd == "beginPress" then
  elseif cmd == "endPress" then
  end
  if cmd == "getAllReward" then
    if self.currentTab == 0 then
      GameHelper.rewardAll = true
      NetMessageMgr:SendMsg(NetAPIList.get_today_award_req.Code, {
        id = GameHelper.todayList.task.id,
        sub_id = 0
      }, GameHelper.GetTodayQuestRewardCallback, true, nil)
    else
      local name = self:GetTabName(self.currentTab)
      local get_task_reward_req_param = {
        task_id = GameHelper.questList[name].id
      }
      NetMessageMgr:SendMsg(NetAPIList.get_task_reward_req.Code, get_task_reward_req_param, GameHelper.GetQuestRewardCallback, true, nil)
    end
  end
  if cmd == "showRewardDetail" then
    do
      local item_type = ""
      local item_id
      if self.currentTab == 0 and self.todayList then
        item_type = self.todayList.task.rewards[1].item_type
        if not self:IsResource(item_type) then
          item_id = self.todayList.task.rewards[1].number
        end
      else
        local name = self:GetTabName(self.currentTab)
        item_type = self.questList[name].rewards[1].item_type
        if not self:IsResource(item_type) then
          item_id = self.questList[name].rewards[1].number
        end
      end
      DebugOut("item_id", item_id, "item_type: ", item_type)
      if item_id and item_id ~= 0 and not self:IsResource(item_type) then
        local function callback(msgType, content)
          DebugOut("item_id in callback", item_id, "index: ")
          DebugOut("msgType:", msgType)
          DebugTable(content)
          if msgType == NetAPIList.get_reward_detail_ack.Code then
            if GameHelper.localRewardData then
              GameHelper.localRewardData[item_id] = content.details
              DebugOut("message:", item_id)
              DebugTable(content.details)
              GameHelper:showRewardDetail()
            end
            return true
          else
            return false
          end
        end
        if not self:isLocalRewardDataExist(item_id) then
          NetMessageMgr:SendMsg(NetAPIList.get_reward_detail_req.Code, {itemId = item_id}, callback, true, nil)
        else
          GameHelper:showRewardDetail()
        end
      end
    end
  end
  if cmd == "showItemDetail" then
    local item_id
    local item_type = ""
    if self.currentTab == 0 and self.todayList then
      item_type = self.todayList.task.rewards[1].item_type
      if not self:IsResource(item_type) then
        item_id = self.todayList.task.rewards[1].number
      end
    else
      local name = self:GetTabName(self.currentTab)
      item_type = self.questList[name].rewards[1].item_type
      if not self:IsResource(item_type) then
        item_id = self.questList[name].rewards[1].number
      end
    end
    local index = tonumber(arg)
    DebugOut("item_id", item_id, "index: ", index)
    DebugTable(GameHelper.localRewardData)
    local item = GameHelper.localRewardData[item_id][index]
    self:showItemDetil(item, item.item_type)
  end
  if cmd == "questListButtonReleased" then
    self:ExecuteSubQuest(tonumber(arg))
  end
  if cmd == "update_achievement_item" then
    self:OnAchievementItem(tonumber(arg))
  elseif cmd == "TouchHeadBtn" then
    local isGoto, id = unpack(LuaUtils:string_split(arg, ":"))
    if isGoto == "true" then
      GameHelper:GoToAchievement(tonumber(id))
    else
      GameHelper:ReqAchievementReward(tonumber(id))
    end
  elseif cmd == "ShowDetail" then
    local index, ind = unpack(LuaUtils:string_split(arg, ":"))
    local item = GameHelper.achievement.list[tonumber(index)]
    if item and item.rewardsList[tonumber(ind)] then
      local it = item.rewardsList[tonumber(ind)].model
      if it.item_type == "item" then
        it.cnt = 1
        ItemBox:showItemBox("Item", it, tonumber(it.number), 320, 480, 200, 200, "", nil, "", nil)
      elseif it.item_type == "fleet" then
        local fleetID = it.number
        ItemBox:ShowCommanderDetail2(fleetID, nil, nil)
      end
    end
  end
  if cmd == "update_prestige_item" then
    self:UpdatePrestigeItem(tonumber(arg))
    return
  elseif cmd == "select_ranking" then
    self:UpdateActivePrestigeInfo(tonumber(arg))
    return
  elseif cmd == "receive_award" then
    self:ObtainAward(tonumber(arg))
    return
  elseif cmd == "btn_help" then
    local text_title = ""
    local info = GameLoader:GetGameText("LC_MENU_PRESTIGE_HELP")
    GameUIMessageDialog:SetStyle(GameUIMessageDialog.DialogStyle.HELP)
    GameUIMessageDialog:Display(text_title, info)
  elseif cmd == "MenuItemReleased" then
    if immanentversion == 1 then
      local index_item = tonumber(arg)
      local data_prestige = self:GetPrestigeInfo(index_item)
      local prestige_name = GameDataAccessHelper:GetMilitaryRankName(data_prestige.prestige_level)
      local award_data, awardDetail = GameDataAccessHelper:GenerateMilitaryRankAwardInfo(data_prestige.prestige_level)
      DebugOutPutTable(awardDetail, "awardDetail")
      local daily_award = GameDataAccessHelper:GenerateMilitaryRankDailyAwardInfo(data_prestige.prestige_level)
      local firstAwardDetail = awardDetail[1]
      local prestige_info_param = prestige_name
      if firstAwardDetail[1] == "skill" then
        local skill = firstAwardDetail[2]
        local skillName = GameDataAccessHelper:GetSkillNameText(skill)
        local skillDesc = GameDataAccessHelper:GetSkillDesc(skill)
        local skillRangeType = "TYPE_" .. GameDataAccessHelper:GetSkillRangeType(skill)
        local skillRangetypeName = GameLoader:GetGameText("LC_MENU_SKILL_RANGE_TYPE_" .. GameDataAccessHelper:GetSkillRangeType(skill))
        prestige_info_param = prestige_info_param .. "\002" .. "skill\001" .. skill .. "\001" .. skillName .. "\001" .. skillDesc .. "\001" .. skillRangeType .. "\001" .. skillRangetypeName .. "\001"
      elseif firstAwardDetail[1] == "recruit_count_up" then
        local recruit_count = firstAwardDetail[2]
        local recruit_count_name = GameLoader:GetGameText("LC_MENU_RECRUIT_COUNT_NAME")
        local recruit_count_desc = GameLoader:GetGameText("LC_MENU_RECRUIT_COUNT_DESC_" .. recruit_count)
        prestige_info_param = prestige_info_param .. "\002" .. "recruit_count_up\001" .. recruit_count .. "\001" .. recruit_count_name .. "\001" .. recruit_count_desc .. "\001"
      elseif firstAwardDetail[1] == "unlock_formation" then
        local unlock_formation = firstAwardDetail[2]
        local unlock_formation_name = GameLoader:GetGameText("LC_MENU_UNLOCK_FORMATION_NAME")
        local unlock_formation_desc = GameLoader:GetGameText("LC_MENU_UNLOCK_FORMATION_DESC")
        prestige_info_param = prestige_info_param .. "\002" .. "unlock_formation\001" .. unlock_formation .. "\001" .. unlock_formation_name .. "\001" .. unlock_formation_desc .. "\001"
      else
        prestige_info_param = prestige_info_param .. "\002empty"
      end
      prestige_info_param = prestige_info_param .. "\002" .. daily_award
      ItemBox:ShowPrestigeInfo(prestige_info_param)
    elseif immanentversion == 2 then
    end
  end
end
function GameHelper:isLocalRewardDataExist(key)
  if GameHelper.localRewardData[key] ~= nil then
    return true
  else
    return false
  end
end
function GameHelper:showItemDetil(item_, item_type)
  local item = item_
  if item_type == "krypton" then
    if item.level == 0 then
      item.level = 1
    end
    local detail = GameUIKrypton:TryQueryKryptonDetail(item.number, item.level, function(msgType, content)
      local ret = GameUIKrypton.QueryKryptonDetailCallBack(msgType, content)
      if ret then
        local tmp = GameGlobalData:GetKryptonDetail(item.number, item.level)
        if tmp == nil then
          return false
        end
        ItemBox:SetKryptonBox(tmp, item.number)
        local operationTable = {}
        operationTable.btnUnloadVisible = false
        operationTable.btnUpgradeVisible = false
        operationTable.btnUseVisible = false
        operationTable.btnDecomposeVisible = false
        ItemBox:ShowKryptonBox(320, 1080, operationTable)
      end
      return ret
    end)
    if detail == nil then
    else
      ItemBox:SetKryptonBox(detail, item.number)
      local operationTable = {}
      operationTable.btnUnloadVisible = false
      operationTable.btnUpgradeVisible = false
      operationTable.btnUseVisible = false
      operationTable.btnDecomposeVisible = false
      ItemBox:ShowKryptonBox(320, 1080, operationTable)
    end
  end
  if item_type == "fleet" then
    local GameUIFirstCharge = LuaObjectManager:GetLuaObject("GameUIFirstCharge")
    GameUIFirstCharge:ShowCommanderInfo(tonumber(item.number))
  end
  if item_type == "item" then
    item.cnt = 1
    ItemBox:showItemBox("ChoosableItem", item, tonumber(item.number), 320, 1080, 200, 200, "", nil, "", nil)
  end
end
function GameHelper:showRewardDetail()
  if self:GetFlashObject() then
    local item_id
    local item_type = ""
    if self.currentTab == 0 and self.todayList then
      item_type = self.todayList.task.rewards[1].item_type
      if not self:IsResource(item_type) then
        item_id = self.todayList.task.rewards[1].number
      end
    else
      local name = self:GetTabName(self.currentTab)
      item_type = self.questList[name].rewards[1].item_type
      if not self:IsResource(item_type) then
        item_id = self.questList[name].rewards[1].number
      end
    end
    local param = {}
    DebugOut("hellotp", item_id)
    DebugTable(GameHelper.localRewardData[item_id])
    if item_id and not self:IsResource(item_type) and self.localRewardData[item_id] then
      for k, v in ipairs(self.localRewardData[item_id]) do
        local localparam = {}
        localparam.icon = self:GetAwardTypeIconFrameNameSupportDynamic(v)
        localparam.item_num = self:GetAwardCountWithX(v.item_type, v.number, v.no)
        table.insert(param, localparam)
      end
      DebugOut("fortp:")
      DebugTable(param)
      self:GetFlashObject():InvokeASCallback("_root", "showRewardDetail", param)
    end
  end
end
function GameHelper:ExecuteSubQuest(key)
  self.currentSubQuestKey = key
  local currentSubQuestList
  if self.currentTab == 0 then
    currentSubQuestList = GameHelper:GetTodaySubQuestList()
  else
    currentSubQuestList = GameHelper:GetCurrentSubQuestList()
  end
  local subQuest
  for k, v in pairs(currentSubQuestList) do
    if v.id == key then
      subQuest = v
    end
  end
  if subQuest then
    DebugOut("subQuest: ", subQuest.is_get_reward, subQuest.is_finished)
    if not subQuest.is_get_reward and subQuest.is_finished then
      local get_sub_task_reward_req_param = {
        task_id = subQuest.id
      }
      if self.currentTab == 0 then
        GameHelper.rewardAll = false
        NetMessageMgr:SendMsg(NetAPIList.get_today_award_req.Code, {
          id = GameHelper.todayList.task.id,
          sub_id = tonumber(key)
        }, GameHelper.GetTodayQuestRewardCallback, true, nil)
      else
        NetMessageMgr:SendMsg(NetAPIList.get_task_reward_req.Code, get_sub_task_reward_req_param, GameHelper.GetSubQuestRewardCallback, true, nil)
      end
    elseif not subQuest.is_finished then
      self:GetFlashObject():InvokeASCallback("_root", "HideQuestCenter", "true")
      self.executer.action = subQuest.action
      self.executer.category = subQuest.category
      self.executer.subCategory = subQuest.subCategory
    end
  end
end
function GameHelper:OnAddOther()
  self:GetFlashObject():InvokeASCallback("_root", "hideScreen", true)
end
function GameHelper:OnEraseOther()
  if showDaily then
    GameHelper.daily = nil
  end
  self:OnAddToGameState()
  self:GetFlashObject():InvokeASCallback("_root", "hideScreen", false)
end
function GameHelper:GotoExecSubQuest(executer)
  DebugOutPutTable(executer, "GotoExecSubQuest: ")
  local action = executer.action
  if action == "collection" then
    if GameGlobalData:BuildingCanEnter(GameUICollect.buildingName) then
      GameUICollect:ShowCollect()
    else
      local GameUIBuilding = LuaObjectManager:GetLuaObject("GameUIBuilding")
      GameUIBuilding:DisplayUpgradeDialog(GameUICollect.buildingName)
    end
  elseif action == "affairs_hall" then
    GameStateManager.GameStateAffairInfo:RequestInfo()
  elseif action == "mainplan" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
  elseif action == "warp_Gate" then
    GameStateRecruit:SetTabtype("warpgate")
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateRecruit)
  elseif action == "recruit" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateRecruit)
  elseif action == "krypton" then
    GameStateKrypton:EnterKrypton(GameStateKrypton.LAB)
  elseif action == "tech_lab" then
    GameUITechnology:EnterTechnology()
  elseif action == "enhance" then
    GameStateEquipEnhance:EnterEquipEnhance(GameFleetEnhance.TAB_ENHANCE)
  elseif action == "ace_combat" then
    GameStateConfrontation:EnterConfrontation()
  elseif action == "championship" then
    GameUIArena:SetArenaType(GameUIArena.ARENA_TYPE.normalArena)
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
  elseif action == "champion_get_reward" then
    GameUIArena:SetArenaType(GameUIArena.ARENA_TYPE.normalArena)
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
  elseif action == "battle_select" then
    local progress = GameGlobalData:GetData("progress")
    GameStateBattleMap:EnterSection(progress.act, progress.chapter, nil)
  elseif action == "function" then
  elseif action == "alliance" then
    GameStateManager.GameStateAlliance:Activate()
  elseif action == "mining" or action == "mining_attack" then
    local GameStateMineMap = GameStateManager.GameStateMineMap
    GameStateManager:SetCurrentGameState(GameStateMineMap)
  elseif action == "donate" or action == "explore" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateAlliance)
    GameUIUserAlliance:SelectTab("function")
  elseif action == "chat" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
    GameStateManager:GetCurrentGameState():AddObject(GameUIChat)
    GameUIChat:SelectChannel("alliance")
  elseif action == "colony_action" then
    local gs = GameStateManager.GameStateColonization
    gs.lastState = GameStateManager:GetCurrentGameState()
    GameStateManager:SetCurrentGameState(gs)
  elseif action == "world_boss" then
    GameStateLab.mCurSubState = STATE_LAB_SUB_STATE.SUBSTATE_NORMAL
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateLab)
  elseif action == "player_ac" then
    GameStateLab.mCurSubState = STATE_LAB_SUB_STATE.SUBSTATE_NORMAL
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateLab)
  elseif action == "laba_use" then
    GameStateLab.mCurSubState = STATE_LAB_SUB_STATE.SUBSTATE_NORMAL
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateLab)
  elseif action == "read_activity" then
    GameStateManager:GetCurrentGameState():AddObject(GameUIActivityNew)
  elseif action == "buy_daily_gift" then
    GameStateManager:SetCurrentGameState(GameStateStore)
  elseif action == "remodel" then
    local GameUIFactory = LuaObjectManager:GetLuaObject("GameUIFactory")
    GameStateManager:GetCurrentGameState():AddObject(GameUIFactory)
    GameUIFactory.EnterRebuild = true
  elseif action == "daily_monthly_card" then
    local GameVip = LuaObjectManager:GetLuaObject("GameVip")
    GameVip:showVip(false, nil, 3)
  elseif action == "infinite_cosmos" then
    GameStateLab.mCurSubState = STATE_LAB_SUB_STATE.SUBSTATE_NORMAL
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateLab)
  elseif action == "chaos_quasar" then
    GameStateLab.mCurSubState = STATE_LAB_SUB_STATE.SUBSTATE_NORMAL
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateLab)
  elseif action == "pay" then
    local GameVip = LuaObjectManager:GetLuaObject("GameVip")
    GameVip:showVip(false)
  elseif action == "combo_gacha" then
    GameStateManager:GetCurrentGameState():AddObject(GameUIActivityNew)
  elseif action == "special_store_buy" then
    LuaObjectManager:GetLuaObject("GameGoodsList"):SetEnterStoreType(2)
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateStore)
  elseif action == "tactical_refine" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateTacticsCenter)
  elseif action == "join_crusade" then
    GameStateLab.mCurSubState = STATE_LAB_SUB_STATE.SUBSTATE_NORMAL
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateLab)
  elseif action == "join_crusade_times" then
    GameStateLab.mCurSubState = STATE_LAB_SUB_STATE.SUBSTATE_NORMAL
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateLab)
  elseif action == "tc_score" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
    GameObjectMainPlanet:BuildingClicked("territorial_entry")
  elseif action == "try_champion" then
    GameUIArena:SetArenaType(GameUIArena.ARENA_TYPE.normalArena)
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
  elseif action == "wd_score" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
    GameObjectMainPlanet:BuildingClicked("world_domination")
  elseif action == "total_online_time" then
  elseif action == "normal_store_buy" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateStore)
  elseif action == "global_chat" then
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
    GameStateManager:GetCurrentGameState():AddObject(GameUIChat)
    GameUIChat:SelectChannel("world")
  elseif action == "glc" then
    GameUIArena:SetArenaType(GameUIArena.ARENA_TYPE.wdc)
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateArena)
  elseif action == "occupy_succ" then
    local item = GameUILab:GetLibsItemByName("starwar")
    if item and item.count_down > 0 then
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateMiningWorld)
      local GameUIMiningWorld = LuaObjectManager:GetLuaObject("GameUIMiningWorld")
      GameUIMiningWorld.enterDir = 1
      GameUIMiningWorld:Show()
    else
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
    end
  end
end
function GameHelper:GetTabName(index)
  for k, v in pairs(self.TabName) do
    if v == index then
      return k
    end
  end
  return nil
end
function GameHelper:DownloadQuestList()
  NetMessageMgr:SendMsg(NetAPIList.task_list_req.Code, nil, GameHelper.DownloadQuestListCallback, true, nil)
end
function GameHelper:TabChanged(index)
  if self.currentTab == index then
    return
  end
  self.currentTab = index
  if index == 0 then
    self:RefreshToday()
  else
    self:RefreshTab(index)
  end
end
function GameHelper:GetTodaySubQuestList(...)
  if self.todayList == nil then
    return {}
  end
  currentSubQuestList = LuaUtils:table_values(self.todayList.task.task_content)
  table.sort(currentSubQuestList, GameHelper.sortTodaySubQuestList)
  return currentSubQuestList
end
function GameHelper:GetCurrentSubQuestList(tabIndex)
  if self.questList == nil then
    return {}
  end
  local tab = tabIndex or self.currentTab
  if tab == -1 then
    tab = 1
  end
  local name = self:GetTabName(tab)
  local currentSubQuestList = self.questList[name].task_content
  local player_level = GameGlobalData:GetData("levelinfo").level
  currentSubQuestList = LuaUtils:table_values(LuaUtils:table_filter(currentSubQuestList, function(k, v)
    return player_level >= v.player_level
  end))
  local questHasReward = self.questList[name].is_get_reward
  local questHasFinished = self.questList[name].is_finished
  currentSubQuestList = LuaUtils:table_values(currentSubQuestList)
  DebugOutPutTable(currentSubQuestList, "currentSubQuestList")
  table.sort(currentSubQuestList, GameHelper.sortSubQuestList)
  return currentSubQuestList, name
end
function GameHelper.sortTodaySubQuestList(v1, v2)
  if v1 and v2 then
    if v1.is_enabled and not v2.is_enabled then
      return true
    elseif v1.is_enabled and v2.is_enabled then
      if not v1.is_get_reward and v2.is_get_reward then
        return true
      elseif not v1.is_get_reward and not v2.is_get_reward then
        if v1.is_finished and v2.is_finished then
          return v1.id < v2.id
        elseif not v1.is_finished and v2.is_finished then
          return false
        elseif v1.is_finished and not v2.is_finished then
          return true
        else
          return v1.id < v2.id
        end
      elseif v1.is_get_reward and not v2.is_get_reward then
        return false
      else
        return v1.id < v2.id
      end
    elseif not v1.is_enabled and v2.is_enabled then
      return false
    else
      return v1.id < v2.id
    end
  end
  return false
end
function GameHelper.sortSubQuestList(v1, v2)
  if v1 and v2 then
    if v1.is_finished and not v1.is_get_reward and (not v2.is_finished or v2.is_get_reward) then
      return true
    elseif not v1.is_finished and v2.is_get_reward then
      return true
    end
  end
  return false
end
function GameHelper:RefreshItem(key)
  local currentSubQuestList
  if self.currentTab == 0 then
    currentSubQuestList = GameHelper:GetTodaySubQuestList()
  else
    currentSubQuestList = GameHelper:GetCurrentSubQuestList()
  end
  if key == GameHelper.titleQuestId then
    if self.currentTab == 0 and self.todayList then
      local questCanFinish = not self.todayList.task.is_get_reward and self.todayList.task.is_finished
      DebugOut("\230\137\147\229\141\176 today quest can finish: ", questCanFinish)
      local finishedCount = 0
      for k, v in ipairs(currentSubQuestList) do
        if v.is_finished then
          finishedCount = finishedCount + 1
        end
      end
      local icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(self.todayList.task.rewards[1], nil, function(extInfo)
        if GameHelper:GetFlashObject() then
          GameHelper:GetFlashObject():InvokeASCallback("_root", "updateTitleFrame", -1, "item_" .. extInfo.item_id)
        end
      end)
      local isFinish = self.todayList.task.is_finished
      local rewardNumberSubFinishNeed = self.todayList.task.reward_number
      local claimedText = GameLoader:GetGameText("LC_MENU_CLAIMED_BUTTON")
      DebugOut("TEST_TP:")
      DebugTable(self.todayList.task.rewards[1])
      self:GetFlashObject():InvokeASCallback("_root", "isForDay", true)
      self:GetFlashObject():InvokeASCallback("_root", "setTitleItem", GameHelper.titleQuestId, GameLoader:GetGameText("LC_MENU_NEW_DAILY_EVENT_INFO"), finishedCount, #currentSubQuestList, icon, questCanFinish, GameLoader:GetGameText("LC_MENU_DAILY_TASK_REWARDS_BUTTON"), GameLoader:GetGameText("LC_MENU_TARGET_CHAR"), GameLoader:GetGameText("LC_MENU_DAILY_TASK_OPERATION_BUTTON"), GameLoader:GetGameText("LC_MENU_GET_CHAR"), isFinish, rewardNumberSubFinishNeed, claimedText)
    else
      local name = self:GetTabName(self.currentTab)
      if self.questList and self.questList[name] then
        local questCanFinish = not self.questList[name].is_get_reward and self.questList[name].is_finished
        DebugOut("\230\137\147\229\141\176 questCanFinish", name, questCanFinish)
        DebugTable(self.questList)
        local finishedCount = 0
        for k, v in ipairs(currentSubQuestList) do
          if v.is_finished then
            finishedCount = finishedCount + 1
          end
        end
        local icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(self.questList[name].rewards[1], nil, function(extInfo)
          if GameHelper:GetFlashObject() then
            GameHelper:GetFlashObject():InvokeASCallback("_root", "updateTitleFrame", -1, "item_" .. extInfo.item_id)
          end
        end)
        local isFinish = self.questList[name].is_finished
        self:GetFlashObject():InvokeASCallback("_root", "isForDay", false)
        local rewardNumberSubFinishNeed = self.questList[name].reward_number
        local claimedText = GameLoader:GetGameText("LC_MENU_CLAIMED_BUTTON")
        self:GetFlashObject():InvokeASCallback("_root", "setTitleItem", GameHelper.titleQuestId, GameLoader:GetGameText("LC_QUEST_QUEST_INFO_" .. string.upper(name)), finishedCount, #currentSubQuestList, icon, questCanFinish, GameLoader:GetGameText("LC_MENU_DAILY_TASK_REWARDS_BUTTON"), GameLoader:GetGameText("LC_MENU_TARGET_CHAR"), GameLoader:GetGameText("LC_MENU_DAILY_TASK_OPERATION_BUTTON"), GameLoader:GetGameText("LC_MENU_GET_CHAR"), isFinish, rewardNumberSubFinishNeed, claimedText)
      end
    end
    return
  end
  if not currentSubQuestList then
    return
  end
  local subQuest
  for k, v in ipairs(currentSubQuestList) do
    if v.id == key then
      subQuest = v
    end
  end
  DebugOut("refresh item:" .. key)
  DebugOutPutTable(currentSubQuestList, "refresh")
  if subQuest then
    local stateText = GameLoader:GetGameText("LC_MENU_EXECUTE_CHAR")
    if subQuest.is_finished then
      stateText = GameLoader:GetGameText("LC_MENU_GET_CHAR")
    end
    local rewardFrame = 1
    local number = GameHelper:GetAwardCount(subQuest.rewards[1].item_type, subQuest.rewards[1].number, subQuest.rewards[1].no)
    local rewardCountText = GameUtils.numberConversion(number)
    local icon = GameHelper:GetAwardTypeIconFrameNameSupportDynamic(subQuest.rewards[1], {id = key}, function(extInfo)
      if GameHelper:GetFlashObject() then
        GameHelper:GetFlashObject():InvokeASCallback("_root", "updateTitleFrame", extInfo.id, "item_" .. extInfo.item_id)
      end
    end)
    if subQuest.finish_count > subQuest.number then
      subQuest.finish_count = subQuest.number
    end
    local player_level = GameGlobalData:GetData("levelinfo").level
    local unlockLV = 0
    if player_level < subQuest.player_level then
      unlockLV = subQuest.player_level
    end
    if self.currentTab == 0 then
      self:GetFlashObject():InvokeASCallback("_root", "setSubItem", key, subQuest.is_enabled, subQuest.is_get_reward, subQuest.is_finished, GameLoader:GetGameText("LC_QUEST_TODAY_QUEST_" .. subQuest.action), subQuest.finish_count .. "/" .. subQuest.number, rewardFrame, stateText, icon, rewardCountText, GameLoader:GetGameText("LC_QUEST_TODAY_QUEST_DESC_" .. subQuest.action), unlockLV, subQuest.enable, GameLoader:GetGameText("LC_MENU_Level"))
    else
      self:GetFlashObject():InvokeASCallback("_root", "setSubItem", key, subQuest.is_enabled, subQuest.is_get_reward, subQuest.is_finished, GameLoader:GetGameText("LC_QUEST_SUB_QUEST_" .. subQuest.id), subQuest.finish_count .. "/" .. subQuest.number, rewardFrame, stateText, icon, rewardCountText, GameLoader:GetGameText("LC_QUEST_SUB_QUEST_DESC_" .. subQuest.id), unlockLV, true, GameLoader:GetGameText("LC_MENU_Level"))
    end
  end
end
function GameHelper:RefreshToday()
  local currentSubQuestList = GameHelper:GetTodaySubQuestList()
  self:GetFlashObject():InvokeASCallback("_root", "clearListBox")
  self:GetFlashObject():InvokeASCallback("_root", "InitQuestList")
  self:GetFlashObject():InvokeASCallback("_root", "AddItemId", GameHelper.titleQuestId)
  for k, v in ipairs(currentSubQuestList) do
    self:GetFlashObject():InvokeASCallback("_root", "AddItemId", v.id)
  end
  if #currentSubQuestList > 4 then
    self:GetFlashObject():InvokeASCallback("_root", "showRichangArrow", true)
  else
    self:GetFlashObject():InvokeASCallback("_root", "showRichangArrow", false)
  end
end
function GameHelper:RefreshTab(index)
  local currentSubQuestList = GameHelper:GetCurrentSubQuestList(index)
  self:GetFlashObject():InvokeASCallback("_root", "clearListBox")
  self:GetFlashObject():InvokeASCallback("_root", "InitQuestList")
  self:GetFlashObject():InvokeASCallback("_root", "AddItemId", GameHelper.titleQuestId)
  for k, v in ipairs(currentSubQuestList) do
    self:GetFlashObject():InvokeASCallback("_root", "AddItemId", v.id)
  end
  if #currentSubQuestList > 4 then
    self:GetFlashObject():InvokeASCallback("_root", "showRichangArrow", true)
  else
    self:GetFlashObject():InvokeASCallback("_root", "showRichangArrow", false)
  end
end
function GameHelper.RefreshAll(forceRefresh)
  if not GameHelper:GetFlashObject() then
    return
  end
  forceRefresh = forceRefresh or false
  if forceRefresh or GameStateManager:GetCurrentGameState():IsObjectInState(GameHelper) then
    GameHelper:RefreshTodayTab()
    GameHelper:RefreshNews()
    GameHelper:RefreshAchievement()
    DebugOut("SetCurrentTab:" .. GameHelper.currentTab)
    local levelInfo = GameGlobalData:GetData("levelinfo")
    GameHelper:GetFlashObject():InvokeASCallback("_root", "setTabSelect", GameHelper.currentTab, levelInfo.level)
    if GameHelper.currentTab == 0 then
      GameHelper:RefreshToday()
    else
      GameHelper:RefreshQuestList()
    end
  end
end
function GameHelper:RefreshTodayTab()
  if showDaily and self.currentTab == -1 then
    self.currentTab = 0
  end
  GameHelper:GetFlashObject():InvokeASCallback("_root", "SetTabState", 1, self:isTodayLived())
end
function GameHelper:RefreshAchievement()
  local isNew = false
  if GameHelper.achievement then
    for k, v in pairs(GameHelper.achievement.list or {}) do
      if v.is_finished == 1 then
        isNew = true
        break
      end
    end
  end
  GameHelper:GetFlashObject():InvokeASCallback("_root", "SetTabState", 3, isNew)
end
function GameHelper:RefreshNews()
  local newCount = {}
  local visible = {}
  local isNew = false
  for k, v in pairs(self.TabName) do
    newCount[v] = 0
    visible[v] = 0
  end
  if self.questList and type(self.questList) == "table" then
    for k, v in pairs(self.questList) do
      local index = self.TabName[k]
      if not v.is_get_reward and v.is_finished then
        newCount[index] = newCount[index] + 1
      end
      for tk, tv in pairs(GameHelper:GetCurrentSubQuestList(index)) do
        if not tv.is_get_reward and tv.is_finished then
          newCount[index] = newCount[index] + 1
          isNew = true
        end
      end
    end
  end
  if self.questList and type(self.questList) == "table" then
    for k, v in pairs(self.questList) do
      local index = self.TabName[k]
      local tempList = GameHelper:GetCurrentSubQuestList(index)
      if not LuaUtils:table_empty(tempList) then
        visible[index] = 1
      end
    end
  end
  if self.currentTab == -1 then
    for k, v in ipairs(visible) do
      if v == 1 then
        self.currentTab = k
        GameHelper:GetFlashObject():InvokeASCallback("_root", "setTab", self.currentTab)
        break
      end
    end
  end
  local news = table.concat(newCount, "\001")
  local visibles = table.concat(visible, "\001")
  self:GetFlashObject():InvokeASCallback("_root", "refreshNews", visibles, news)
  if isNew then
    GameHelper:GetFlashObject():InvokeASCallback("_root", "SetTabState", 1, true)
  end
end
function GameHelper:RefreshQuestList()
  local currentSubQuestList = GameHelper:GetCurrentSubQuestList()
  self:GetFlashObject():InvokeASCallback("_root", "clearListBox")
  self:GetFlashObject():InvokeASCallback("_root", "InitQuestList")
  self:GetFlashObject():InvokeASCallback("_root", "AddItemId", GameHelper.titleQuestId)
  for k, v in ipairs(currentSubQuestList) do
    self:GetFlashObject():InvokeASCallback("_root", "AddItemId", v.id)
  end
  if #currentSubQuestList > 4 then
    self:GetFlashObject():InvokeASCallback("_root", "showRichangArrow", true)
  else
    self:GetFlashObject():InvokeASCallback("_root", "showRichangArrow", false)
  end
end
function GameHelper:GetAwardTypeTextAndIcon(key, number)
  local typeText = "UnknownAward"
  local icon = key
  if key == "money" then
    typeText = GameLoader:GetGameText("LC_MENU_MONEY_CHAR")
  elseif key == "vip_exp" then
    typeText = GameLoader:GetGameText("LC_MENU_VIP_EXP_CHAR")
  elseif key == "laba_supply" then
    typeText = GameLoader:GetGameText("LC_MENU_DEXTER_COIN")
  elseif key == "technique" then
    typeText = GameLoader:GetGameText("LC_MENU_TECHNIQUE_CHAR")
  elseif key == "exp" then
    typeText = GameLoader:GetGameText("LC_MENU_EXP_CHAR")
  elseif key == "credit" then
    typeText = GameLoader:GetGameText("LC_MENU_LOOT_CREDIT")
  elseif key == "crystal" then
    typeText = GameLoader:GetGameText("LC_MENU_LOOT_CRYSTAL")
  elseif key == "prestige" then
    typeText = GameLoader:GetGameText("LC_MENU_PRESTIGE_CHAR")
  elseif key == "ac_supply" then
    typeText = GameLoader:GetGameText("LC_MENU_AC_SUPPLY_CHAR")
  elseif key == "wd_supply" then
    typeText = GameLoader:GetGameText("LC_MENU_WD_SUPPLY_CHAR")
  elseif key == "brick" then
    typeText = GameLoader:GetGameText("LC_MENU_BRICK_CHAR")
  elseif key == "lepton" then
    typeText = GameLoader:GetGameText("LC_MENU_LOOT_LEPTON")
  elseif key == "item" or key == "equip" then
    if key == "equip" then
      typeText = GameLoader:GetGameText("LC_ITEM_EQUIP_TYPE_SLOT" .. GameDataAccessHelper:GetEquipSlot(number))
    else
      typeText = GameLoader:GetGameText("LC_ITEM_ITEM_CHAR")
    end
    icon = "item_" .. number
  elseif key == "crusade_repair" then
    typeText = GameLoader:GetGameText("LC_MENU_TBC_REPAIR_ENERGY")
  else
    typeText = GameLoader:GetGameText("LC_ITEM_ITEM_NAME_" .. key)
  end
  return typeText, icon
end
function GameHelper:GetAwardText(key, number, no)
  if GameHelper:IsResource(key) then
    return GameHelper:GetAwardTypeText(key, -1) .. "x" .. number
  else
    return GameHelper:GetAwardTypeText(key, number) .. "x" .. no
  end
end
function GameHelper:GetItemText(key, number, no)
  if GameHelper:IsResource(key) then
    return number .. " " .. GameHelper:GetAwardTypeText(key, -1)
  else
    return no .. " " .. GameHelper:GetAwardTypeText(key, number)
  end
end
function GameHelper:GetAwardCount(key, number, no)
  if GameHelper:IsResource(key) then
    return number
  else
    return no
  end
end
function GameHelper:GetAwardCountWithX(key, number, no)
  if GameHelper:IsResource(key) then
    return "" .. number
  else
    return "x " .. no
  end
end
function GameHelper:GetAwardNameText(key, number)
  if GameHelper:IsResource(key) then
    return GameHelper:GetAwardTypeText(key, -1)
  else
    return GameHelper:GetAwardTypeText(key, number)
  end
end
function GameHelper:getAwardNameTextAndCount(key, number, no)
  if GameHelper:IsResource(key) then
    return GameHelper:GetAwardTypeText(key, -1), number
  else
    return GameHelper:GetAwardTypeText(key, number), no
  end
end
function GameHelper:IsScratchGachaResource(key)
  if key == "space_pattern1" or key == "space_pattern2" or key == "space_pattern3" then
    return true
  else
    return false
  end
end
function GameHelper:IsResource(key)
  if key == "money" or key == "vip_exp" or key == "mine_digg_licence_one" or key == "mine_fight_licence_one" or key == "technique" or key == "exp" or key == "medal_resource" or key == "credit" or key == "crystal" or key == "prestige" or key == "quark" or key == "pve_supply" or key == "battle_supply" or key == "pvp_supply" or key == "lepton" or key == "kenergy" or key == "laba_supply" or key == "ac_supply" or key == "wd_supply" or key == "brick" or key == "silver" or key == "wdc_supply" or key == "crusade_repair" or key == "art_point" or key == "space_pattern1" or key == "space_pattern2" or key == "space_pattern3" then
    return true
  else
    return false
  end
end
function GameHelper:GetAwardTypeText(key, number)
  local typeText = "UnknownAward"
  if key == "money" then
    typeText = GameLoader:GetGameText("LC_MENU_MONEY_CHAR")
  elseif key == "vip_exp" then
    typeText = GameLoader:GetGameText("LC_MENU_VIP_EXP_CHAR")
  elseif key == "mine_digg_licence_one" then
    typeText = GameLoader:GetGameText("LC_MENU_MINE_CHANCE_EVENT")
  elseif key == "brick" then
    typeText = GameLoader:GetGameText("LC_MENU_BRICK_CHAR")
  elseif key == "mine_fight_licence_one" then
    typeText = GameLoader:GetGameText("LC_MENU_PLUNDER_CHANCE_EVENT")
  elseif key == "technique" then
    typeText = GameLoader:GetGameText("LC_MENU_TECHNIQUE_CHAR")
  elseif key == "exp" then
    typeText = GameLoader:GetGameText("LC_MENU_EXP_CHAR")
  elseif key == "credit" then
    typeText = GameLoader:GetGameText("LC_MENU_LOOT_CREDIT")
  elseif key == "medal_resource" then
    typeText = GameLoader:GetGameText("LC_MENU_NAME_MEDAL_RESOURCE")
  elseif key == "crystal" then
    typeText = GameLoader:GetGameText("LC_MENU_LOOT_CRYSTAL")
  elseif key == "prestige" then
    typeText = GameLoader:GetGameText("LC_MENU_PRESTIGE_CHAR")
  elseif key == "quark" then
    typeText = GameLoader:GetGameText("LC_MENU_QUARK_CHAR")
  elseif key == "pve_supply" or key == "battle_supply" then
    typeText = GameLoader:GetGameText("LC_MENU_SUPPLY_CHAR")
  elseif key == "pvp_supply" then
    typeText = GameLoader:GetGameText("LC_MENU_SUPPLY_CHAR")
  elseif key == "wd_supply" then
    typeText = GameLoader:GetGameText("LC_MENU_WD_SUPPLY_CHAR")
  elseif key == "lepton" then
    typeText = GameLoader:GetGameText("LC_MENU_LOOT_LEPTON")
  elseif key == "kenergy" then
    typeText = GameLoader:GetGameText("LC_MENU_krypton_energy")
  elseif key == "laba_supply" then
    typeText = GameLoader:GetGameText("LC_MENU_DEXTER_COIN")
  elseif key == "ac_supply" then
    typeText = GameLoader:GetGameText("LC_MENU_AC_SUPPLY_CHAR")
  elseif key == "crusade_repair" then
    typeText = GameLoader:GetGameText("LC_MENU_TBC_REPAIR_ENERGY")
  elseif key == "fleet" then
    typeText = GameLoader:GetGameText("LC_NPC_" .. GameDataAccessHelper:GetCommanderName(number))
  elseif key == "equip" then
    typeText = GameLoader:GetGameText("LC_ITEM_EQUIP_TYPE_SLOT" .. GameDataAccessHelper:GetEquipSlot(number))
  elseif key == "silver" or tonumber(number) == 99000004 then
    typeText = GameLoader:GetGameText("LC_MENU_GLC_STORE_MONEY")
  elseif key == "art_point" then
    typeText = GameLoader:GetGameText("LC_MENU_ARTIFACT_RESOURCE")
  elseif key == "medal_item" then
    typeText = GameLoader:GetGameText("LC_MENU_MEDAL_ITEM_NAME_" .. number)
  elseif key == "medal" then
    local id = math.ceil(number / 100000 - 1) * 100000 + number % 10
    DebugOut("GetMedal_Name:LC_MENU_MEDAL_NAME_" .. id)
    typeText = GameLoader:GetGameText("LC_MENU_MEDAL_NAME_" .. id)
  else
    typeText = GameLoader:GetGameText("LC_ITEM_ITEM_NAME_" .. number)
  end
  return typeText
end
function GameHelper:GetAwardTypeIconFrameNameSupportDynamic(gameItem, extInfo, downLoadCallBack)
  local frame = "temp"
  if DynamicResDownloader:IsDynamicStuffByGameItem(gameItem) then
    local fullFileName = DynamicResDownloader:GetFullName(gameItem.number .. ".png", DynamicResDownloader.resType.PIC)
    local localPath = "data2/" .. fullFileName
    DebugWD("localPath = ", localPath)
    if DynamicResDownloader:IfResExsit(localPath) then
      ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
      frame = "item_" .. gameItem.number
    else
      frame = "temp"
      self:AddDownloadPathForGameItem(gameItem.number, extInfo, downLoadCallBack)
    end
  elseif self:IsScratchGachaResource(gameItem.item_type) then
    if GameStateScratchGacha.act_id * 10 + 7 == GameSettingData.ScratchPreActivity then
      frame = gameItem.item_type
    else
      frame = "temp"
      DynamicResDownloader:AddDynamicRes(gameItem.item_type .. ".png", DynamicResDownloader.resType.PIC, extInfo, downLoadCallBack)
    end
  elseif gameItem.item_type == "fleet" then
    frame = GameDataAccessHelper:GetFleetAvatar(gameItem.number, 0)
  else
    frame = GameHelper:GetAwardTypeIconFrameName(gameItem.item_type, gameItem.number, gameItem.no)
  end
  return frame
end
function GameHelper:AddDownloadPathForGameItem(itemID, extInfo, callBack)
  local resName = itemID .. ".png"
  local aExtInfo = extInfo or {}
  aExtInfo.item_id = itemID
  aExtInfo.localPath = "data2/LAZY_LOAD_dynamic_" .. resName
  DynamicResDownloader:AddDynamicRes(resName, DynamicResDownloader.resType.PIC, aExtInfo, callBack)
end
function GameHelper:GetBackgroundImgDynamic(itemId, localImg, downloadImg, downCallback)
  local localPath = "data2/" .. DynamicResDownloader:GetFullName(downloadImg, DynamicResDownloader.resType.FESTIVAL_BANNER)
  DebugOut("localPath : " .. localPath)
  if DynamicResDownloader:IfResExsit(localPath) then
    ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
  else
    local downloadInfo = {}
    downloadInfo.itemId = itemId
    downloadInfo.localImg = localImg
    downloadInfo.localPath = downloadImg
    DynamicResDownloader:AddDynamicRes(downloadImg, DynamicResDownloader.resType.FESTIVAL_BANNER, downloadInfo, downCallback)
  end
end
function GameHelper:GetFoatColor(color, text)
  if not color then
    return text
  end
  local color_new = "#" .. color
  local cl = string.gsub("<font color='#'>", "#", color_new)
  return cl .. text .. "</font>"
end
function GameHelper:GetGameItemDownloadPng(key, number)
  if key == "equip" or key == "item" or key == "krypton" then
    return id .. ".png"
  elseif key == "medal" then
    local id = math.ceil(number / 100000 - 1) * 100000 + number % 10
    return id .. ".png"
  elseif key == "medal_item" then
    return number .. ".png"
  elseif key == "medal_new_icon" then
    local id = math.ceil(number / 100000 - 1) * 100000 + number % 10
    return id .. "_bg.png"
  else
    assert(false, key .. number)
  end
end
function GameHelper:GetAwardTypeIconFrameName(key, number, no)
  local iconText = "temp"
  if key == "money" then
    iconText = "money"
  elseif key == "vip_exp" then
    iconText = "vip_exp"
  elseif key == "brick" then
    iconText = "brick"
  elseif key == "technique" then
    iconText = "technique"
  elseif key == "exp" then
    iconText = "exp"
  elseif key == "credit" then
    iconText = "credit"
  elseif key == "crystal" then
    iconText = "crystal"
  elseif key == "prestige" then
    iconText = "prestige"
  elseif key == "quark" then
    iconText = "quark"
  elseif key == "pve_supply" or key == "battle_supply" then
    iconText = "pve_supply"
  elseif key == "wd_supply" then
    iconText = "wd_supply"
  elseif key == "lepton" then
    iconText = "lepton"
  elseif key == "kenergy" then
    iconText = "kenergy"
  elseif key == "laba_supply" then
    iconText = "laba_supply"
  elseif key == "ac_supply" then
    iconText = "ac_supply"
  elseif key == "silver" then
    iconText = "silver"
  elseif key == "art_point" then
    iconText = "art_point"
  elseif key == "medal_resource" then
    iconText = "medal_resource"
  elseif key == "equip" or key == "item" or key == "krypton" then
    iconText = "item_" .. number
  elseif key == "medal" then
    local id = math.ceil(number / 100000 - 1) * 100000 + number % 10
    iconText = "medal_" .. id
  elseif key == "medal_new_icon" then
    local id = math.ceil(number / 100000 - 1) * 100000 + number % 10
    iconText = "medal_" .. id .. "_bg"
  elseif key == "medal_item" then
    iconText = "medal_item_" .. number
  end
  return iconText
end
function GameHelper:GetMedalIconFrameAndPic(type)
  local id = math.ceil(type / 100000 - 1) * 100000 + type % 10
  DebugOut("GetMedalIconFrame", type, id)
  return "medal_" .. id, id .. ".png"
end
function GameHelper:GetMedalIconFrameAndPicNew(type)
  local id = math.ceil(type / 100000 - 1) * 100000 + type % 10
  DebugOut("GetMedalIconFrame", type, id)
  return "medal_" .. id .. "_bg", id .. "_bg.png"
end
function GameHelper:GetCommonIconFrame(game_item, callBack)
  local frame = ""
  if DynamicResDownloader:IsDynamicStuffByGameItem(game_item) then
    local fullFileName = DynamicResDownloader:GetFullName(game_item.number .. ".png", DynamicResDownloader.resType.PIC)
    local localPath = "data2/" .. fullFileName
    DebugWD("localPath = ", localPath)
    if DynamicResDownloader:IfResExsit(localPath) then
      DebugOut("DynamicResDownloader:IfResExsit(localPath)) then")
      ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
      frame = "item_" .. game_item.number
    else
      DebugOut("DynamicResDownloader:IfResExsit(localPath)) then not")
      frame = "temp"
      GameHelper:AddDownloadPathForOfficer(game_item.number, callBack)
    end
  elseif game_item.item_type == "fleet" then
    frame = GameDataAccessHelper:GetFleetAvatar(game_item.number, 0)
  else
    frame = GameHelper:GetAwardTypeIconFrameName(game_item.item_type, game_item.number, game_item.no)
  end
  return frame
end
function GameHelper:AddDownloadPathForOfficer(itemID, callBack)
  local resName = itemID .. ".png"
  local extInfo = {}
  extInfo.item_id = itemID
  extInfo.localPath = "data2/LAZY_LOAD_dynamic_" .. resName
  DynamicResDownloader:AddDynamicRes(resName, DynamicResDownloader.resType.PIC, extInfo, callBack)
end
function GameHelper:GetRewardInfo(typeText, key, numberText, no)
  local info = GameLoader:GetGameText("LC_MENU_REWARD_INFO")
  info = string.gsub(info, "%[EVENT%]", GameLoader:GetGameText("LC_MENU_PRESTIGE_DAILY_REWARDS_TITLE"))
  local name, count = GameHelper:getAwardNameTextAndCount(key, numberText, no)
  info = string.gsub(info, "%[NUMBER%]", tostring(count))
  info = string.gsub(info, "%[TYPE%]", name)
  return info
end
function GameHelper:GetRewardInfoNew(typeText, numberText)
  local info = string.gsub(GameLoader:GetGameText("LC_MENU_REWARD_INFO"), "%[TYPE%]", typeText)
  info = string.gsub(info, "%[EVENT%]", GameLoader:GetGameText("LC_MENU_PRESTIGE_DAILY_REWARDS_TITLE"))
  info = string.gsub(info, "%[NUMBER%]", numberText)
  return info
end
function GameHelper:GetRewardInfoAndEvent(typeText, numberText, eventText)
  local info = string.gsub(GameLoader:GetGameText("LC_MENU_REWARD_INFO"), "%[TYPE%]", typeText)
  info = string.gsub(info, "%[EVENT%]", eventText)
  info = string.gsub(info, "%[NUMBER%]", numberText)
  return info
end
function GameHelper.DownloadQuestListCallback(msgType, content)
  if msgType == NetAPIList.task_list_ack.Code then
    GameHelper.questList = {}
    local temp = content.task_list
    for k, v in pairs(temp) do
      GameHelper.questList[v.task_name] = v
    end
    DebugOutPutTable(content.task_list, "content.task_list=")
    GameHelper.currentTab = -1
    GameHelper:RequestToday()
    return true
  end
  return false
end
function GameHelper:ShowGetReward(quest)
  local rewards = quest.rewards
  local typeText = GameLoader:GetGameText("LC_MENU_" .. string.upper(rewards[1].item_type) .. "_CHAR")
  local numberText = rewards[1].number
  ItemBox:ShowRewardBox(rewards)
end
function GameHelper.GetQuestRewardCallback(msgType, content)
  if msgType == NetAPIList.common_ack.Code then
    if content.api == NetAPIList.get_task_reward_req.Code then
      if content.code == 0 then
        local name = GameHelper:GetTabName(GameHelper.currentTab)
        GameHelper.questList[name].is_get_reward = true
        GameHelper.RefreshAll()
        GameHelper:ShowGetReward(GameHelper.questList[name], true)
      else
        GameUIGlobalScreen:ShowAlert("error", content.code, nil)
      end
    end
    return true
  end
  return false
end
function GameHelper.GetTodayQuestRewardCallback(msgType, content)
  if msgType == NetAPIList.get_today_award_ack.Code then
    if content.code == 2 then
      if GameHelper.rewardAll then
        GameHelper.todayList.task.is_get_reward = true
      else
        local subQuest
        for tk, tv in pairs(GameHelper.todayList.task.task_content) do
          if tv.id == GameHelper.currentSubQuestKey then
            subQuest = tv
            break
          end
        end
        subQuest.is_get_reward = true
      end
      GameHelper.RefreshAll()
    end
    return true
  end
  return false
end
function GameHelper.GetSubQuestRewardCallback(msgType, content)
  if msgType == NetAPIList.common_ack.Code then
    if content.api == NetAPIList.get_task_reward_req.Code then
      if content.code == 0 then
        local subQuest
        for k, v in pairs(GameHelper.questList) do
          for tk, tv in pairs(v.task_content) do
            if tv.id == GameHelper.currentSubQuestKey then
              subQuest = GameHelper.questList[k].task_content[tk]
              break
            end
          end
        end
        subQuest.is_get_reward = true
        GameHelper.RefreshAll()
        GameHelper:ShowGetReward(subQuest, false)
      else
        GameUIGlobalScreen:ShowAlert("error", content.code, nil)
      end
    end
    return true
  end
  return false
end
function GameHelper:StartUpABattle(battleReport, awards, battleResultType, battleFinishCallback)
  local GameUIBattleResult = LuaObjectManager:GetLuaObject("GameUIBattleResult")
  local GameStateBattlePlay = GameStateManager.GameStateBattlePlay
  DebugOut("battleResultType = ", battleResultType)
  GameUIBattleResult:LoadFlashObject()
  local result = 1
  if battleReport.player1 == GameGlobalData:GetUserInfo().name then
    if battleReport.result == 1 then
      result = 1
    else
      result = 2
    end
  elseif battleReport.player2 == GameGlobalData:GetUserInfo().name then
    if battleReport.result == 2 then
      result = 1
    else
      result = 2
    end
  end
  local windowType = GameHelper.BattleResultType[battleResultType][result]
  DebugOut("windowType = ", windowType)
  local awardDataTable = {}
  if result == 1 then
    local index = 1
    GameUIBattleResult:UpdateAwardItem3("challenge_win", 2, -1, 0, 0)
    for indexAward, dataAward in ipairs(awards) do
      DebugOut("dataAward = ")
      DebugTable(dataAward)
      GameUIBattleResult:UpdateAwardItem3("challenge_win", 2, -1, 0, 0)
      if dataAward.no ~= 0 then
        GameUIBattleResult:UpdateAwardItem3("challenge_win", index, dataAward.item_type, dataAward.no, dataAward.number)
        index = index + 1
      end
    end
  end
  GameUIBattleResult:SetFightReport(battleReport, nil, nil)
  local lastGameState = GameStateManager:GetCurrentGameState()
  GameStateBattlePlay:InitBattle(GameStateBattlePlay.MODE_HISTORY, battleReport)
  GameStateBattlePlay:RegisterOverCallback(function()
    GameStateManager:SetCurrentGameState(lastGameState)
    if battleFinishCallback then
      battleFinishCallback()
    end
    GameUIBattleResult:LoadFlashObject()
    GameUIBattleResult:AnimationMoveIn(windowType, false)
    lastGameState:AddObject(GameUIBattleResult)
  end)
  GameStateManager:SetCurrentGameState(GameStateBattlePlay)
end
if AutoUpdate.isAndroidDevice then
  function GameHelper.OnAndroidBack()
    GameHelper:GetFlashObject():InvokeASCallback("_root", "closeWindow")
  end
end
function GameHelper:DownloadResIfNeed(typeId, callback)
  DebugOut("DownloadResIfNeed " .. tostring(typeId))
  local isNeedDownload = false
  if DynamicResDownloader:IsDynamicStuff(typeId, DynamicResDownloader.resType.PIC) then
    local fullFileName = DynamicResDownloader:GetFullName(tostring(typeId) .. ".png", DynamicResDownloader.resType.PIC)
    local localPath = "data2/" .. fullFileName
    DebugOut("localPath = ", localPath)
    if DynamicResDownloader:IfResExsit(localPath) then
      DebugOut("DynamicResDownloader:IfResExsit(localPath)) then")
      ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
    else
      DebugOut("DynamicResDownloader:IfResExsit(localPath)) then not")
      GameHelper:AddDownloadPathForOfficer(typeId, callback)
      isNeedDownload = true
    end
  end
  return isNeedDownload
end
function GameHelper:GetFleetsForce()
  local fleets = GameGlobalData:GetData("fleetinfo").fleets
  local InMatrix = GameGlobalData:GetData("matrix").cells
  local newForce = 0
  for i, fleet in pairs(fleets) do
    if GameUtils:IsInMatrix(fleet.identity) then
      newForce = newForce + fleet.force
    end
  end
  DebugOut("newForce:" .. newForce)
  return newForce
end
function GameHelper:IsHaveFleetById(id)
  local fleets = GameGlobalData:GetData("fleetinfo").fleets
  for i, fleet in ipairs(fleets) do
    if id == fleet.identity then
      return true
    end
  end
  return false
end
function GameHelper:GetCurrentMatrixFleetAvatarAndRank(cur_index)
  local curMatrix = FleetMatrix.matrixs[cur_index].cells
  DebugOut("curMatrix = ")
  DebugTable(curMatrix)
  local curMatrixAvatar = {}
  if curMatrix and #curMatrix > 0 then
    for k, v in pairs(curMatrix) do
      if 0 < v.fleet_identity then
        local avatarT = {}
        DebugOut("fleet_identity = " .. v.fleet_identity)
        local fleetDetail = GameGlobalData:GetFleetInfo(v.fleet_identity)
        DebugTable(fleetDetail)
        local leaderlist = GameGlobalData:GetData("leaderlist")
        local fleetID = v.fleet_identity
        if v.fleet_identity == 1 and leaderlist then
          avatarT.fleetAvatar = GameDataAccessHelper:GetFleetAvatar(leaderlist.leader_ids[cur_index])
          fleetID = leaderlist.leader_ids[cur_index]
        else
          avatarT.fleetAvatar = GameDataAccessHelper:GetFleetAvatar(v.fleet_identity)
        end
        avatarT.rankid = GameDataAccessHelper:GetCommanderColorFrame(fleetID, fleetDetail.level)
        table.insert(curMatrixAvatar, avatarT)
      end
    end
  end
  DebugOut("curMatrixAvatar = ")
  DebugTable(curMatrixAvatar)
  return curMatrixAvatar
end
function GameHelper.OnHalfPortraitResDowanloaded(extInfo)
  GameUIHalfPortrait:PreLoadRes(extInfo.src .. ".png")
end
function GameHelper:CheckHalfPortraitImg(image)
  local fullFileName = DynamicResDownloader:GetFullName(image, DynamicResDownloader.resType.HALFPORTRAIT)
  local localPath = "data2/" .. fullFileName .. ".tga"
  GameUtils:printByAndroid("GameUIHalfPortrait:CheckHalfPortraitImg:" .. localPath .. "," .. ext.crc32.crc32(localPath))
  if DynamicResDownloader:IfResExsit(localPath) then
    ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
    return true
  elseif ext.crc32.crc32(localPath) ~= "" then
    ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
    return true
  else
    local extInfo = {}
    extInfo.src = image
    DynamicResDownloader:AddDynamicRes(image .. ".tga", DynamicResDownloader.resType.HALFPORTRAIT, extInfo, GameHelper.OnHalfPortraitResDowanloaded)
    DebugOut("GameHelper:CheckHalfPortraitImg", localPath, "not Loaded")
    return false
  end
end
function GameHelper:CheckHalfPortraitImgGroup(Group)
  local retValue = true
  local imageGroup = HalfPortraitResource.classify[Group]
  DebugOut("GameHelper:CheckHalfPortraitImgGroup", Group)
  DebugTable(imageGroup)
  for k, v in ipairs(imageGroup) do
    retValue = self:CheckHalfPortraitImg(v) and retValue
  end
  return retValue
end
function GameHelper:CheckHalfPortraitResourceLoaded(HalfPortraitType)
  if GameHelper.HalfPortraitTable[HalfPortraitType] == true then
    return true
  end
  local isAllLoaded = false
  if HalfPortraitType == 1 then
    isAllLoaded = self:CheckHalfPortraitImgGroup(1)
  elseif HalfPortraitType == 2 then
    isAllLoaded = self:CheckHalfPortraitImgGroup(2)
  elseif HalfPortraitType == 3 then
    isAllLoaded = self:CheckHalfPortraitImgGroup(4)
  elseif HalfPortraitType == 4 then
    local isLoaded1 = self:CheckHalfPortraitImgGroup(3)
    local isLoaded2 = self:CheckHalfPortraitImgGroup(5)
    local isLoaded3 = self:CheckHalfPortraitImgGroup(7)
    isAllLoaded = isLoaded1 and isLoaded2 and isLoaded3
  elseif HalfPortraitType == 6 then
    isAllLoaded = self:CheckHalfPortraitImgGroup(5)
  elseif HalfPortraitType == 7 then
    local isLoaded1 = self:CheckHalfPortraitImgGroup(5)
    local isLoaded2 = self:CheckHalfPortraitImgGroup(7)
    isAllLoaded = isLoaded1 and isLoaded2
  end
  local idLoaded = self:CheckHalfPortraitImgGroup(8)
  isAllLoaded = isAllLoaded and idLoaded
  GameHelper.HalfPortraitTable[HalfPortraitType] = isAllLoaded
  DebugOut("GameHelper:CheckHalfPortraitResourceLoaded", HalfPortraitType, isAllLoaded)
  return isAllLoaded
end
function GameHelper:CheckHalfPortraitAvataAndShip(fleetAbility)
  if GameHelper.HalfPortraitHeroResourceTable[fleetAbility.ID] == true then
    return true
  end
  local avata = self:GetHalfPortratiAvatImage(fleetAbility.AVATAR)
  local isShipLoaded = self:CheckHalfPortraitImg("LAZY_LOAD_DOWN_halfProtrait_" .. fleetAbility.SHIP)
  local isHeadLoaded = self:CheckHalfPortraitImg(avata)
  GameHelper.HalfPortraitHeroResourceTable[fleetAbility.ID] = isShipLoaded and isHeadLoaded
  return isShipLoaded and isHeadLoaded
end
function GameHelper:GetHalfPortratiAvatImage(avata)
  if avata == "head102" then
    return "LAZY_LOAD_DOWN_avater_fire_102"
  elseif avata == "head21" then
    return "LAZY_LOAD_DOWN_avata_256_256_headDuoDuo"
  else
    return "LAZY_LOAD_DOWN_avata_256_256_" .. avata
  end
end
function GameHelper:PreLoadHalfPortraitRes(HalfPortraitType, fleetAbility)
  GameUIHalfPortrait:PreLoadRes(self:GetHalfPortratiAvatImage(fleetAbility.AVATAR) .. ".png")
  GameUIHalfPortrait:PreLoadRes("LAZY_LOAD_DOWN_halfProtrait_" .. fleetAbility.SHIP .. ".png")
  if HalfPortraitType == 1 then
    isAllLoaded = self:PreLoadHalfPortraitGroupRes(1)
  elseif HalfPortraitType == 2 then
    isAllLoaded = self:PreLoadHalfPortraitGroupRes(2)
  elseif HalfPortraitType == 3 then
    isAllLoaded = self:PreLoadHalfPortraitGroupRes(4)
  elseif HalfPortraitType == 4 then
    local isLoaded1 = self:PreLoadHalfPortraitGroupRes(3)
    local isLoaded2 = self:PreLoadHalfPortraitGroupRes(5)
    local isLoaded3 = self:PreLoadHalfPortraitGroupRes(7)
    isAllLoaded = isLoaded1 and isLoaded2 and isLoaded3
  elseif HalfPortraitType == 6 then
    isAllLoaded = self:PreLoadHalfPortraitGroupRes(5)
  elseif HalfPortraitType == 7 then
    local isLoaded1 = self:PreLoadHalfPortraitGroupRes(5)
    local isLoaded2 = self:PreLoadHalfPortraitGroupRes(7)
    isAllLoaded = isLoaded1 and isLoaded2
  end
end
function GameHelper:PreLoadHalfPortraitGroupRes(groupId)
  local imageGroup = HalfPortraitResource.classify[groupId]
  for k, v in ipairs(imageGroup) do
    GameUIHalfPortrait:PreLoadRes(v .. ".png")
  end
end
local GameFleetInfoTabBar = LuaObjectManager:GetLuaObject("GameFleetInfoTabBar")
GameHelper.PrestigeStatus = {}
GameHelper.PrestigeStatus.Unfinished = "unfinished"
GameHelper.PrestigeStatus.Wait = "wait"
GameHelper.PrestigeStatus.Received = "received"
local QuestTutorialPrestige = TutorialQuestManager.QuestTutorialPrestige
local GameUICommonDialog = LuaObjectManager:GetLuaObject("GameUICommonDialog")
local QuestTutorialEnhance_second = TutorialQuestManager.QuestTutorialEnhance_second
GameHelper._PrestigeData = {}
function GameHelper:Show()
  DebugOut("GameHelper:Show")
  if not self:GetFlashObject() then
    self:LoadFlashObject()
  end
  self:GetFlashObject():InvokeASCallback("_root", "setLocalText", "LC_MENU_NEXT_RANK", GameLoader:GetGameText("LC_MENU_NEXT_RANK"))
  self:GetFlashObject():InvokeASCallback("_root", "setLocalText", "LC_MENU_CONTENT_NEED_PRESTIGE", GameLoader:GetGameText("LC_MENU_CONTENT_NEED_PRESTIGE"))
  GameHelper:ReqPrestigeInfo()
end
function GameHelper:ReqPrestigeInfo()
  local function netFailedCallback()
    NetMessageMgr:SendMsg(NetAPIList.prestige_info_req.Code, nil, self._NetCallbackProc, true, netFailedCallback)
  end
  NetMessageMgr:SendMsg(NetAPIList.prestige_info_req.Code, nil, self._NetCallbackProc, true, netFailedCallback)
end
function GameHelper._NetCallbackProc(msgtype, content)
  if msgtype == NetAPIList.prestige_info_ack.Code then
    DebugTable(content)
    GameHelper.PrestigeData = content
    GameHelper:ProcessPrestigeData(content)
    GameHelper:InitPrestigeList()
    return true
  end
  if msgtype == NetAPIList.prestige_obtain_award_ack.Code then
    if content.code ~= 0 then
    end
    local data_prestige = GameHelper:GetPrestigeInfo(GameHelper._ObtainLevel)
    data_prestige.obtained = true
    GameHelper:UpdatePrestigeItem(data_prestige.prestige_level)
    return true
  end
  if msgtype == 0 and content.api == NetAPIList.prestige_get_req.Code then
    GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    if GameStateManager:GetCurrentGameState():IsObjectInState(GameHelper) then
      GameHelper:ReqPrestigeInfo()
    end
    return true
  end
  return false
end
function GameHelper:SetPrestigeTutorialFinish()
  QuestTutorialPrestige:SetFinish(true)
end
function GameHelper:RankUpPrstige(arg)
end
function GameHelper:InitPrestigeList()
  self:GetFlashObject():InvokeASCallback("_root", "lua2fs_updatePrestigeList", #self._PrestigeData.prestige_infos)
  if self._PrestigeData.cur_level < self._PrestigeData.max_level then
    self:GetFlashObject():InvokeASCallback("_root", "setActivePrestigeRank", self._PrestigeData.cur_level + 1)
  end
end
function GameHelper:ProcessPrestigeData(prestiges_data)
  self._PrestigeData = prestiges_data
  prestiges_data.cur_level = 0
  prestiges_data.max_level = 0
  for _, rank_info in ipairs(prestiges_data.prestige_infos) do
    if rank_info.obtained and rank_info.prestige_level > prestiges_data.cur_level then
      prestiges_data.cur_level = rank_info.prestige_level
    end
    if rank_info.prestige_level > prestiges_data.max_level then
      prestiges_data.max_level = rank_info.prestige_level
    end
  end
end
function GameHelper:UpdatePrestigeItem(index_item)
  local data_prestige = self:GetPrestigeInfo(index_item)
  local prev_prestige_data = self:GetPrestigeInfo(index_item - 1)
  local award_data = GameDataAccessHelper:GenerateMilitaryRankAwardInfo(data_prestige.prestige_level)
  local canNextLevelTxt = GameLoader:GetGameText("LC_MENU_PRESTIGE_UPGRADE_CHAR")
  local visible = false
  DebugOut("award_data - ", award_data)
  local prestige_item_param = ""
  prestige_item_param = prestige_item_param .. tostring(data_prestige.prestige_level)
  prestige_item_param = prestige_item_param .. "," .. GameDataAccessHelper:GetMilitaryRankName(data_prestige.prestige_level)
  prestige_item_param = prestige_item_param .. "," .. self:CheckPrestigeStatus(data_prestige)
  prestige_item_param = prestige_item_param .. "," .. tostring(self._PrestigeData.prestige)
  prestige_item_param = prestige_item_param .. "," .. tostring(data_prestige.prestige_require)
  prestige_item_param = prestige_item_param .. "," .. tostring(GameUtils.numberConversion(self._PrestigeData.prestige))
  prestige_item_param = prestige_item_param .. "," .. tostring(GameUtils.numberConversion(data_prestige.prestige_require))
  prestige_item_param = prestige_item_param .. "," .. award_data
  local daily_award = GameDataAccessHelper:GenerateMilitaryRankDailyAwardInfo(data_prestige.prestige_level)
  local title = GameLoader:GetGameText("LC_MENU_PRESTIGE_DAILY_REWARDS_TITLE")
  DebugOut("daily_award - ", daily_award, data_prestige.prestige_level)
  self:GetFlashObject():InvokeASCallback("_root", "UpdatePrestigeItem", index_item, prestige_item_param, canNextLevelTxt, QuestTutorialPrestige:IsActive(), tonumber(immanentversion), daily_award, title)
end
function GameHelper:ObtainAward(level)
  if immanentversion == 1 then
    self._ObtainLevel = level
    local packet = {prestige_level = level}
    NetMessageMgr:SendMsg(NetAPIList.prestige_obtain_award_req.Code, packet, self._NetCallbackProc, true, nil)
  end
end
function GameHelper:GetPrestigeInfo(level)
  for _, v in ipairs(self._PrestigeData.prestige_infos) do
    if v.prestige_level == level then
      return v
    end
  end
  return nil
end
function GameHelper:CheckPrestigeStatus(prestige_info)
  local prestige_status = "unfinished"
  if self._PrestigeData.cur_level == prestige_info.prestige_level - 1 then
    prestige_status = "active"
  elseif prestige_info.prestige_require < self._PrestigeData.prestige then
    if prestige_info.obtained then
      prestige_status = "received"
    else
      prestige_status = "unreceived"
    end
  end
  return prestige_status
end
