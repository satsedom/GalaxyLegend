local flag = GameData.alliance.flag
table.insert(flag, {
  SORT_NUMBER = 1,
  FLAG_CN = 38,
  FLAG_WORLD = 1
})
table.insert(flag, {
  SORT_NUMBER = 2,
  FLAG_CN = 34,
  FLAG_WORLD = 2
})
table.insert(flag, {
  SORT_NUMBER = 3,
  FLAG_CN = 18,
  FLAG_WORLD = 3
})
table.insert(flag, {
  SORT_NUMBER = 4,
  FLAG_CN = 39,
  FLAG_WORLD = 4
})
table.insert(flag, {
  SORT_NUMBER = 5,
  FLAG_CN = 1,
  FLAG_WORLD = 38
})
table.insert(flag, {
  SORT_NUMBER = 6,
  FLAG_CN = 2,
  FLAG_WORLD = 5
})
table.insert(flag, {
  SORT_NUMBER = 7,
  FLAG_CN = 3,
  FLAG_WORLD = 6
})
table.insert(flag, {
  SORT_NUMBER = 8,
  FLAG_CN = 4,
  FLAG_WORLD = 7
})
table.insert(flag, {
  SORT_NUMBER = 9,
  FLAG_CN = 5,
  FLAG_WORLD = 8
})
table.insert(flag, {
  SORT_NUMBER = 10,
  FLAG_CN = 6,
  FLAG_WORLD = 9
})
table.insert(flag, {
  SORT_NUMBER = 11,
  FLAG_CN = 7,
  FLAG_WORLD = 10
})
table.insert(flag, {
  SORT_NUMBER = 12,
  FLAG_CN = 8,
  FLAG_WORLD = 11
})
table.insert(flag, {
  SORT_NUMBER = 13,
  FLAG_CN = 9,
  FLAG_WORLD = 12
})
table.insert(flag, {
  SORT_NUMBER = 14,
  FLAG_CN = 10,
  FLAG_WORLD = 13
})
table.insert(flag, {
  SORT_NUMBER = 15,
  FLAG_CN = 11,
  FLAG_WORLD = 14
})
table.insert(flag, {
  SORT_NUMBER = 16,
  FLAG_CN = 12,
  FLAG_WORLD = 15
})
table.insert(flag, {
  SORT_NUMBER = 17,
  FLAG_CN = 13,
  FLAG_WORLD = 16
})
table.insert(flag, {
  SORT_NUMBER = 18,
  FLAG_CN = 14,
  FLAG_WORLD = 17
})
table.insert(flag, {
  SORT_NUMBER = 19,
  FLAG_CN = 15,
  FLAG_WORLD = 18
})
table.insert(flag, {
  SORT_NUMBER = 20,
  FLAG_CN = 16,
  FLAG_WORLD = 19
})
table.insert(flag, {
  SORT_NUMBER = 21,
  FLAG_CN = 17,
  FLAG_WORLD = 20
})
table.insert(flag, {
  SORT_NUMBER = 22,
  FLAG_CN = 19,
  FLAG_WORLD = 21
})
table.insert(flag, {
  SORT_NUMBER = 23,
  FLAG_CN = 20,
  FLAG_WORLD = 22
})
table.insert(flag, {
  SORT_NUMBER = 24,
  FLAG_CN = 21,
  FLAG_WORLD = 23
})
table.insert(flag, {
  SORT_NUMBER = 25,
  FLAG_CN = 22,
  FLAG_WORLD = 24
})
table.insert(flag, {
  SORT_NUMBER = 26,
  FLAG_CN = 23,
  FLAG_WORLD = 25
})
table.insert(flag, {
  SORT_NUMBER = 27,
  FLAG_CN = 24,
  FLAG_WORLD = 26
})
table.insert(flag, {
  SORT_NUMBER = 28,
  FLAG_CN = 25,
  FLAG_WORLD = 27
})
table.insert(flag, {
  SORT_NUMBER = 29,
  FLAG_CN = 26,
  FLAG_WORLD = 28
})
table.insert(flag, {
  SORT_NUMBER = 30,
  FLAG_CN = 27,
  FLAG_WORLD = 29
})
table.insert(flag, {
  SORT_NUMBER = 31,
  FLAG_CN = 28,
  FLAG_WORLD = 30
})
table.insert(flag, {
  SORT_NUMBER = 32,
  FLAG_CN = 29,
  FLAG_WORLD = 31
})
table.insert(flag, {
  SORT_NUMBER = 33,
  FLAG_CN = 30,
  FLAG_WORLD = 32
})
table.insert(flag, {
  SORT_NUMBER = 34,
  FLAG_CN = 31,
  FLAG_WORLD = 33
})
table.insert(flag, {
  SORT_NUMBER = 35,
  FLAG_CN = 32,
  FLAG_WORLD = 34
})
table.insert(flag, {
  SORT_NUMBER = 36,
  FLAG_CN = 33,
  FLAG_WORLD = 35
})
table.insert(flag, {
  SORT_NUMBER = 37,
  FLAG_CN = 35,
  FLAG_WORLD = 36
})
table.insert(flag, {
  SORT_NUMBER = 38,
  FLAG_CN = 36,
  FLAG_WORLD = 37
})
table.insert(flag, {
  SORT_NUMBER = 39,
  FLAG_CN = 37,
  FLAG_WORLD = 39
})
