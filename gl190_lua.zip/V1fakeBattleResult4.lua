local fakeBattleResult4 = {
  player1 = "vddfv. vbb.s991",
  player1_identity = 102,
  player1_pos = 2,
  player2_identity = 6000408,
  player2_pos = 8,
  player2_avatar = "head13",
  player2 = "battle",
  player1_avatar = "female",
  result = 1,
  rounds = {
    [1] = {
      attacks = {},
      sp_attacks = {
        [1] = {
          durability = 0,
          def_pos = 1,
          sp_id = 401,
          shield = 0,
          buff_effect = 0,
          acc = 75,
          intercept = false,
          self_cast = false,
          shield_damage = 0,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 20298,
          round_cnt = 0,
          atk_pos = 2,
          crit = true
        },
        [2] = {
          durability = 0,
          def_pos = 2,
          sp_id = 401,
          shield = 0,
          buff_effect = 0,
          acc = 75,
          intercept = false,
          self_cast = false,
          shield_damage = 0,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 9708,
          round_cnt = 0,
          atk_pos = 2,
          crit = false
        },
        [3] = {
          durability = 0,
          def_pos = 3,
          sp_id = 401,
          shield = 0,
          buff_effect = 0,
          acc = 75,
          intercept = false,
          self_cast = false,
          shield_damage = 0,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 8556,
          round_cnt = 0,
          atk_pos = 2,
          crit = false
        },
        [4] = {
          durability = 0,
          def_pos = 4,
          sp_id = 401,
          shield = 0,
          buff_effect = 0,
          acc = 75,
          intercept = false,
          self_cast = false,
          shield_damage = 0,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 9190,
          round_cnt = 0,
          atk_pos = 2,
          crit = false
        },
        [5] = {
          durability = 40000,
          def_pos = 5,
          sp_id = 401,
          shield = 35788,
          buff_effect = 202,
          acc = 75,
          intercept = true,
          self_cast = false,
          shield_damage = 4212,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 0,
          round_cnt = 2,
          atk_pos = 2,
          crit = false
        },
        [6] = {
          durability = 0,
          def_pos = 6,
          sp_id = 401,
          shield = 0,
          buff_effect = 0,
          acc = 75,
          intercept = false,
          self_cast = false,
          shield_damage = 0,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 11809,
          round_cnt = 0,
          atk_pos = 2,
          crit = false
        },
        [7] = {
          durability = 0,
          def_pos = 7,
          sp_id = 401,
          shield = 0,
          buff_effect = 0,
          acc = 75,
          intercept = false,
          self_cast = false,
          shield_damage = 0,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 11465,
          round_cnt = 0,
          atk_pos = 2,
          crit = false
        },
        [8] = {
          durability = 0,
          def_pos = 8,
          sp_id = 401,
          shield = 0,
          buff_effect = 0,
          acc = 75,
          intercept = false,
          self_cast = false,
          shield_damage = 0,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 9948,
          round_cnt = 0,
          atk_pos = 2,
          crit = false
        },
        [9] = {
          durability = 0,
          def_pos = 9,
          sp_id = 401,
          shield = 0,
          buff_effect = 0,
          acc = 75,
          intercept = false,
          self_cast = false,
          shield_damage = 0,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 11546,
          round_cnt = 0,
          atk_pos = 2,
          crit = false
        }
      },
      buff = {
        [1] = {
          buff_step = 3,
          side = "p2",
          param = 0,
          buff_effect = 202,
          pos = 5,
          round_cnt = 2
        }
      },
      player1_action = true,
      dot = {},
      pos = 2,
      round_cnt = 1
    },
    [2] = {
      attacks = {},
      sp_attacks = {
        [1] = {
          durability = 40000,
          def_pos = 5,
          sp_id = 403,
          shield = 34265,
          buff_effect = 0,
          acc = 100,
          intercept = true,
          self_cast = false,
          shield_damage = 1523,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 0,
          round_cnt = 0,
          atk_pos = 4,
          crit = false
        }
      },
      buff = {},
      player1_action = true,
      dot = {},
      pos = 4,
      round_cnt = 2
    },
    [3] = {
      attacks = {},
      sp_attacks = {
        [1] = {
          durability = 40000,
          def_pos = 5,
          sp_id = 403,
          shield = 32629,
          buff_effect = 0,
          acc = 125,
          intercept = true,
          self_cast = false,
          shield_damage = 1636,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 0,
          round_cnt = 0,
          atk_pos = 6,
          crit = false
        }
      },
      buff = {},
      player1_action = true,
      dot = {},
      pos = 6,
      round_cnt = 3
    },
    [4] = {
      attacks = {},
      sp_attacks = {
        [1] = {
          durability = 40000,
          def_pos = 5,
          sp_id = 404,
          shield = 27001,
          buff_effect = 0,
          acc = 150,
          intercept = false,
          self_cast = false,
          shield_damage = 5628,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 0,
          round_cnt = 0,
          atk_pos = 7,
          crit = true
        }
      },
      buff = {},
      player1_action = true,
      dot = {},
      pos = 7,
      round_cnt = 4
    },
    [5] = {
      attacks = {},
      sp_attacks = {
        [1] = {
          durability = 40000,
          def_pos = 5,
          sp_id = 404,
          shield = 24887,
          buff_effect = 0,
          acc = 175,
          intercept = true,
          self_cast = false,
          shield_damage = 2114,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 0,
          round_cnt = 0,
          atk_pos = 9,
          crit = false
        }
      },
      buff = {},
      player1_action = true,
      dot = {},
      pos = 9,
      round_cnt = 5
    },
    [6] = {
      attacks = {
        [1] = {
          attack_type = 1,
          atk_effect = "gammaBlaster",
          def_pos = 5,
          shield = 18090,
          atk_acc_change = 25,
          acc = 200,
          intercept = false,
          atk_acc = 25,
          shield_damage = 6797,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 0,
          durability = 40000,
          atk_pos = 2,
          crit = true
        }
      },
      sp_attacks = {},
      buff = {},
      player1_action = true,
      dot = {},
      pos = 2,
      round_cnt = 6
    },
    [7] = {
      attacks = {},
      sp_attacks = {
        [1] = {
          durability = 0,
          def_pos = 2,
          sp_id = 402,
          shield = 0,
          buff_effect = 0,
          acc = 50,
          intercept = true,
          self_cast = false,
          shield_damage = 10000,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 20266,
          round_cnt = 0,
          atk_pos = 5,
          crit = true
        },
        [2] = {
          durability = 0,
          def_pos = 4,
          sp_id = 402,
          shield = 0,
          buff_effect = 0,
          acc = 25,
          intercept = true,
          self_cast = false,
          shield_damage = 6000,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 37698,
          round_cnt = 0,
          atk_pos = 5,
          crit = true
        },
        [3] = {
          durability = 0,
          def_pos = 6,
          sp_id = 402,
          shield = 0,
          buff_effect = 0,
          acc = 25,
          intercept = true,
          self_cast = false,
          shield_damage = 6000,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 29436,
          round_cnt = 0,
          atk_pos = 5,
          crit = false
        },
        [4] = {
          durability = 0,
          def_pos = 7,
          sp_id = 402,
          shield = 0,
          buff_effect = 0,
          acc = 25,
          intercept = false,
          self_cast = false,
          shield_damage = 6000,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 90653,
          round_cnt = 0,
          atk_pos = 5,
          crit = true
        },
        [5] = {
          durability = 0,
          def_pos = 9,
          sp_id = 402,
          shield = 0,
          buff_effect = 0,
          acc = 25,
          intercept = false,
          self_cast = false,
          shield_damage = 6000,
          acc_change = 25,
          atk_acc_change = -100,
          atk_acc = 0,
          hit = true,
          dur_damage = 85063,
          round_cnt = 0,
          atk_pos = 5,
          crit = true
        }
      },
      buff = {
        [1] = {
          buff_step = 3,
          side = "p2",
          param = 0,
          buff_effect = 202,
          pos = 5,
          round_cnt = 1
        }
      },
      player1_action = false,
      dot = {},
      pos = 5,
      round_cnt = 7
    }
  },
  player1_fleets = {
    [1] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 240,
      cur_accumulator = 50,
      max_durability = 240,
      identity = 1,
      pos = 5
    },
    [2] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 122,
      cur_accumulator = 50,
      max_durability = 122,
      identity = 4,
      pos = 8
    },
    [3] = {
      max_shield = 10000,
      shield = 10000,
      cur_durability = 10000,
      cur_accumulator = 100,
      max_durability = 10000,
      identity = 102,
      pos = 2
    },
    [4] = {
      max_shield = 6000,
      shield = 6000,
      cur_durability = 2000,
      cur_accumulator = 100,
      max_durability = 2000,
      identity = 103,
      pos = 4
    },
    [5] = {
      max_shield = 6000,
      shield = 6000,
      cur_durability = 2000,
      cur_accumulator = 100,
      max_durability = 2000,
      identity = 104,
      pos = 6
    },
    [6] = {
      max_shield = 6000,
      shield = 6000,
      cur_durability = 2000,
      cur_accumulator = 100,
      max_durability = 2000,
      identity = 105,
      pos = 7
    },
    [7] = {
      max_shield = 6000,
      shield = 6000,
      cur_durability = 2000,
      cur_accumulator = 100,
      max_durability = 2000,
      identity = 106,
      pos = 9
    }
  },
  player2_fleets = {
    [1] = {
      max_shield = 40000,
      shield = 40000,
      cur_durability = 40000,
      cur_accumulator = 50,
      max_durability = 40000,
      identity = 6000401,
      pos = 5
    },
    [2] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 6000,
      cur_accumulator = 50,
      max_durability = 6000,
      identity = 6000402,
      pos = 1
    },
    [3] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 6000,
      cur_accumulator = 50,
      max_durability = 6000,
      identity = 6000403,
      pos = 2
    },
    [4] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 6000,
      cur_accumulator = 50,
      max_durability = 6000,
      identity = 6000404,
      pos = 3
    },
    [5] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 6000,
      cur_accumulator = 50,
      max_durability = 6000,
      identity = 6000405,
      pos = 4
    },
    [6] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 6000,
      cur_accumulator = 50,
      max_durability = 6000,
      identity = 6000406,
      pos = 6
    },
    [7] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 6000,
      cur_accumulator = 50,
      max_durability = 6000,
      identity = 6000407,
      pos = 7
    },
    [8] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 6000,
      cur_accumulator = 50,
      max_durability = 6000,
      identity = 6000408,
      pos = 8
    },
    [9] = {
      max_shield = 0,
      shield = 0,
      cur_durability = 6000,
      cur_accumulator = 50,
      max_durability = 6000,
      identity = 6000409,
      pos = 9
    }
  }
}
local fakeBattleAnim4 = {
  [1] = {
    round_index = 1,
    round_step = 2,
    attack_round_index = -1,
    dialog_id = {1100037},
    befor_dialog_anim = {
      {
        "ShowShipAppear",
        true,
        2
      },
      {
        "ShowShipAppear",
        true,
        4
      },
      {
        "ShowShipAppear",
        true,
        6
      },
      {
        "ShowShipAppear",
        true,
        7
      },
      {
        "ShowShipAppear",
        true,
        9
      }
    },
    hide_anim_in_dialog = true,
    after_dialog_anim = nil
  },
  [2] = {
    round_index = 2,
    round_step = 2,
    attack_round_index = -1,
    dialog_id = {
      1100038,
      1100039,
      1100040,
      11000401,
      1100041,
      1100042,
      1100043
    },
    befor_dialog_anim = nil,
    hide_anim_in_dialog = true,
    after_dialog_anim = {
      {
        "SetShipDisappearInFakeBattle",
        true,
        5
      },
      {
        "SetShipDisappearInFakeBattle",
        true,
        8
      }
    }
  },
  [3] = {
    round_index = 9,
    round_step = 2,
    attack_round_index = -1,
    dialog_id = {1100041},
    befor_dialog_anim = nil,
    hide_anim_in_dialog = true,
    after_dialog_anim = nil
  }
}
local fakeBattleCommand4 = {
  {
    "HideShipInFakeBattle",
    true,
    2
  },
  {
    "HideShipInFakeBattle",
    true,
    4
  },
  {
    "HideShipInFakeBattle",
    true,
    6
  },
  {
    "HideShipInFakeBattle",
    true,
    7
  },
  {
    "HideShipInFakeBattle",
    true,
    9
  },
  {
    "SetPlayer1Avatar",
    "LC_NPC_NPC_1",
    "head17"
  }
}
GameData.fakeBattleAnim4 = fakeBattleAnim4
GameData.fakeBattleResult4 = fakeBattleResult4
GameData.fakeBattleCommand4 = fakeBattleCommand4
