local ItemBox = LuaObjectManager:GetLuaObject("ItemBox")
local GameStateItem = GameStateManager.GameStateItem
function GameStateItem:OnFocusGain(previousState)
end
function GameStateItem:OnFocusLost(newState)
end
function GameStateItem:GetPreState()
end
