local GameTouchEffect = LuaObjectManager:GetLuaObject("GameTouchEffect")
local m_activeTag = {}
local touchItem = {}
local m_removeItem = {}
function GameTouchEffect:OnInitGame()
end
function GameTouchEffect:OnAddToGameState()
  DebugOut("GameTouchEffect:OnAddToGameState")
  self:LoadFlashObject()
end
function GameTouchEffect:OnEraseFromGameState()
  self:UnloadFlashObject()
  collectgarbage("collect")
end
function GameTouchEffect:OnFSCommand(cmd, arg)
end
function GameTouchEffect:Update(dt)
  local flashObj = GameTouchEffect:GetFlashObject()
  if flashObj then
    flashObj:Update(dt)
    flashObj:InvokeASCallback("_root", "OnUpdate")
  end
end
