EInterstellarSpaceState = {
  SPACE_STATE_FOCUS = 2,
  SPACE_STATE_FINISH = 3,
  SPACE_STATE_LOCKED = 1
}
EInterstellarAdventureState = {ADVENTURE_STATE_IDLE = 1, ADVENTURE_STATE_DOING = 2}
