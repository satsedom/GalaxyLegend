local matrix = {
  _TYPE = "module",
  _NAME = "matrix",
  _VERSION = "0.2.11.20120416"
}
local matrix_meta = {}
function matrix:new(rows, columns, value)
  if type(rows) == "table" then
    if type(rows[1]) ~= "table" then
      return setmetatable({
        {
          rows[1]
        },
        {
          rows[2]
        },
        {
          rows[3]
        }
      }, matrix_meta)
    end
    return setmetatable(rows, matrix_meta)
  end
  local mtx = {}
  local value = value or 0
  if columns == "I" then
    for i = 1, rows do
      mtx[i] = {}
      for j = 1, rows do
        if i == j then
          mtx[i][j] = 1
        else
          mtx[i][j] = 0
        end
      end
    end
  else
    for i = 1, rows do
      mtx[i] = {}
      for j = 1, columns do
        mtx[i][j] = value
      end
    end
  end
  return setmetatable(mtx, matrix_meta)
end
setmetatable(matrix, {
  __call = function(...)
    return matrix.new(...)
  end
})
function matrix.add(m1, m2)
  local mtx = {}
  for i = 1, #m1 do
    local m3i = {}
    mtx[i] = m3i
    for j = 1, #m1[1] do
      m3i[j] = m1[i][j] + m2[i][j]
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.sub(m1, m2)
  local mtx = {}
  for i = 1, #m1 do
    local m3i = {}
    mtx[i] = m3i
    for j = 1, #m1[1] do
      m3i[j] = m1[i][j] - m2[i][j]
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.mul(m1, m2)
  local mtx = {}
  for i = 1, #m1 do
    mtx[i] = {}
    for j = 1, #m2[1] do
      local num = m1[i][1] * m2[1][j]
      for n = 2, #m1[1] do
        num = num + m1[i][n] * m2[n][j]
      end
      mtx[i][j] = num
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.div(m1, m2)
  local rank
  m2, rank = matrix.invert(m2)
  if not m2 then
    return m2, rank
  end
  return matrix.mul(m1, m2)
end
function matrix.mulnum(m1, num)
  local mtx = {}
  for i = 1, #m1 do
    mtx[i] = {}
    for j = 1, #m1[1] do
      mtx[i][j] = m1[i][j] * num
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.divnum(m1, num)
  local mtx = {}
  for i = 1, #m1 do
    local mtxi = {}
    mtx[i] = mtxi
    for j = 1, #m1[1] do
      mtxi[j] = m1[i][j] / num
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.pow(m1, num)
  assert(num == math.floor(num), "exponent not an integer")
  if num == 0 then
    return matrix:new(#m1, "I")
  end
  if num < 0 then
    local rank
    m1, rank = matrix.invert(m1)
    if not m1 then
      return m1, rank
    end
    num = -num
  end
  local mtx = matrix.copy(m1)
  for i = 2, num do
    mtx = matrix.mul(mtx, m1)
  end
  return mtx
end
local number_norm2 = function(x)
  return x * x
end
function matrix.det(m1)
  assert(#m1 == #m1[1], "matrix not square")
  local size = #m1
  if size == 1 then
    return m1[1][1]
  end
  if size == 2 then
    return m1[1][1] * m1[2][2] - m1[2][1] * m1[1][2]
  end
  if size == 3 then
    return m1[1][1] * m1[2][2] * m1[3][3] + m1[1][2] * m1[2][3] * m1[3][1] + m1[1][3] * m1[2][1] * m1[3][2] - m1[1][3] * m1[2][2] * m1[3][1] - m1[1][1] * m1[2][3] * m1[3][2] - m1[1][2] * m1[2][1] * m1[3][3]
  end
  local e = m1[1][1]
  local zero = type(e) == "table" and e.zero or 0
  local norm2 = type(e) == "table" and e.norm2 or number_norm2
  local mtx = matrix.copy(m1)
  local det = 1
  for j = 1, #mtx[1] do
    local rows = #mtx
    local subdet, xrow
    for i = 1, rows do
      local e = mtx[i][j]
      if not subdet then
        if e ~= zero then
          subdet, xrow = e, i
        end
      elseif e ~= zero and math.abs(norm2(e) - 1) < math.abs(norm2(subdet) - 1) then
        subdet, xrow = e, i
      end
    end
    if subdet then
      if xrow ~= rows then
        mtx[rows], mtx[xrow] = mtx[xrow], mtx[rows]
        det = -det
      end
      for i = 1, rows - 1 do
        if mtx[i][j] ~= zero then
          local factor = mtx[i][j] / subdet
          for n = j + 1, #mtx[1] do
            mtx[i][n] = mtx[i][n] - factor * mtx[rows][n]
          end
        end
      end
      if math.fmod(rows, 2) == 0 then
        det = -det
      end
      det = det * subdet
      table.remove(mtx)
    else
      return det * 0
    end
  end
  return det
end
local pivotOk = function(mtx, i, j, norm2)
  local iMin
  local normMin = math.huge
  for _i = i, #mtx do
    local e = mtx[_i][j]
    local norm = math.abs(norm2(e))
    if norm > 0 and normMin > norm then
      iMin = _i
      normMin = norm
    end
  end
  if iMin then
    if iMin ~= i then
      mtx[i], mtx[iMin] = mtx[iMin], mtx[i]
    end
    return true
  end
  return false
end
local copy = function(x)
  return type(x) == "table" and x.copy(x) or x
end
function matrix.dogauss(mtx)
  local e = mtx[1][1]
  local zero = type(e) == "table" and e.zero or 0
  local one = type(e) == "table" and e.one or 1
  local norm2 = type(e) == "table" and e.norm2 or number_norm2
  local rows, columns = #mtx, #mtx[1]
  for j = 1, rows do
    if pivotOk(mtx, j, j, norm2) then
      for i = j + 1, rows do
        if mtx[i][j] ~= zero then
          local factor = mtx[i][j] / mtx[j][j]
          mtx[i][j] = copy(zero)
          for _j = j + 1, columns do
            mtx[i][_j] = mtx[i][_j] - factor * mtx[j][_j]
          end
        end
      end
    else
      return false, j - 1
    end
  end
  for j = rows, 1, -1 do
    local div = mtx[j][j]
    for _j = j + 1, columns do
      mtx[j][_j] = mtx[j][_j] / div
    end
    for i = j - 1, 1, -1 do
      if mtx[i][j] ~= zero then
        local factor = mtx[i][j]
        for _j = j + 1, columns do
          mtx[i][_j] = mtx[i][_j] - factor * mtx[j][_j]
        end
        mtx[i][j] = copy(zero)
      end
    end
    mtx[j][j] = copy(one)
  end
  return true
end
function matrix.invert(m1)
  assert(#m1 == #m1[1], "matrix not square")
  local mtx = matrix.copy(m1)
  local ident = setmetatable({}, matrix_meta)
  local e = m1[1][1]
  local zero = type(e) == "table" and e.zero or 0
  local one = type(e) == "table" and e.one or 1
  for i = 1, #m1 do
    local identi = {}
    ident[i] = identi
    for j = 1, #m1 do
      identi[j] = copy(i == j and one or zero)
    end
  end
  mtx = matrix.concath(mtx, ident)
  local done, rank = matrix.dogauss(mtx)
  if done then
    return matrix.subm(mtx, 1, #mtx[1] / 2 + 1, #mtx, #mtx[1])
  else
    return nil, rank
  end
end
local get_abs_avg = function(m1, m2)
  local dist = 0
  local e = m1[1][1]
  local abs = type(e) == "table" and e.abs or math.abs
  for i = 1, #m1 do
    for j = 1, #m1[1] do
      dist = dist + abs(m1[i][j] - m2[i][j])
    end
  end
  return dist / (#m1 * 2)
end
function matrix.sqrt(m1, iters)
  assert(#m1 == #m1[1], "matrix not square")
  local iters = iters or math.huge
  local y = matrix.copy(m1)
  local z = matrix(#y, "I")
  local dist = math.huge
  for n = 1, iters do
    local lasty, lastz = y, z
    y, z = matrix.divnum(matrix.add(y, matrix.invert(z)), 2), matrix.divnum(matrix.add(z, matrix.invert(y)), 2)
    local dist1 = get_abs_avg(y, lasty)
    if iters == math.huge and dist <= dist1 then
      return lasty, lastz, get_abs_avg(matrix.mul(lasty, lasty), m1)
    end
    dist = dist1
  end
  return y, z, get_abs_avg(matrix.mul(y, y), m1)
end
function matrix.root(m1, root, iters)
  assert(#m1 == #m1[1], "matrix not square")
  local iters = iters or math.huge
  local mx = matrix.copy(m1)
  local my = matrix.mul(mx:invert(), mx:pow(root - 1))
  local dist = math.huge
  for n = 1, iters do
    local lastx, lasty = mx, my
    mx, my = mx:mulnum(root - 1):add(my:invert()):divnum(root), my:mulnum(root - 1):add(mx:invert()):divnum(root):mul(my:invert():pow(root - 2)):mul(my:mulnum(root - 1):add(mx:invert())):divnum(root)
    local dist1 = get_abs_avg(mx, lastx)
    if iters == math.huge and dist <= dist1 then
      return lastx, lasty, get_abs_avg(matrix.pow(lastx, root), m1)
    end
    dist = dist1
  end
  return mx, my, get_abs_avg(matrix.pow(mx, root), m1)
end
function matrix.normf(mtx)
  local mtype = matrix.type(mtx)
  local result = 0
  for i = 1, #mtx do
    for j = 1, #mtx[1] do
      local e = mtx[i][j]
      if mtype ~= "number" then
        e = e:abs()
      end
      result = result + e ^ 2
    end
  end
  local sqrt = type(result) == "number" and math.sqrt or result.sqrt
  return sqrt(result)
end
function matrix.normmax(mtx)
  local abs = matrix.type(mtx) == "number" and math.abs or mtx[1][1].abs
  local result = 0
  for i = 1, #mtx do
    for j = 1, #mtx[1] do
      local e = abs(mtx[i][j])
      if result < e then
        result = e
      end
    end
  end
  return result
end
local numround = function(num, mult)
  return math.floor(num * mult + 0.5) / mult
end
local tround = function(t, mult)
  for i, v in ipairs(t) do
    t[i] = math.floor(v * mult + 0.5) / mult
  end
  return t
end
function matrix.round(mtx, idp)
  local mult = 10 ^ (idp or 0)
  local fround = matrix.type(mtx) == "number" and numround or tround
  for i = 1, #mtx do
    for j = 1, #mtx[1] do
      mtx[i][j] = fround(mtx[i][j], mult)
    end
  end
  return mtx
end
local numfill = function(_, start, stop, idp)
  return math.random(start, stop) / idp
end
local tfill = function(t, start, stop, idp)
  for i in ipairs(t) do
    t[i] = math.random(start, stop) / idp
  end
  return t
end
function matrix.random(mtx, start, stop, idp)
  local start, stop, idp = start or -10, stop or 10, idp or 1
  local ffill = matrix.type(mtx) == "number" and numfill or tfill
  for i = 1, #mtx do
    for j = 1, #mtx[1] do
      mtx[i][j] = ffill(mtx[i][j], start, stop, idp)
    end
  end
  return mtx
end
function matrix.type(mtx)
  local e = mtx[1][1]
  if type(e) == "table" then
    if e.type then
      return e:type()
    end
    return "tensor"
  end
  return "number"
end
local num_copy = function(num)
  return num
end
local t_copy = function(t)
  local newt = setmetatable({}, getmetatable(t))
  for i, v in ipairs(t) do
    newt[i] = v
  end
  return newt
end
function matrix.copy(m1)
  local docopy = matrix.type(m1) == "number" and num_copy or t_copy
  local mtx = {}
  for i = 1, #m1[1] do
    mtx[i] = {}
    for j = 1, #m1 do
      mtx[i][j] = docopy(m1[i][j])
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.transpose(m1)
  local docopy = matrix.type(m1) == "number" and num_copy or t_copy
  local mtx = {}
  for i = 1, #m1[1] do
    mtx[i] = {}
    for j = 1, #m1 do
      mtx[i][j] = docopy(m1[j][i])
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.subm(m1, i1, j1, i2, j2)
  local docopy = matrix.type(m1) == "number" and num_copy or t_copy
  local mtx = {}
  for i = i1, i2 do
    local _i = i - i1 + 1
    mtx[_i] = {}
    for j = j1, j2 do
      local _j = j - j1 + 1
      mtx[_i][_j] = docopy(m1[i][j])
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.concath(m1, m2)
  assert(#m1 == #m2, "matrix size mismatch")
  local docopy = matrix.type(m1) == "number" and num_copy or t_copy
  local mtx = {}
  local offset = #m1[1]
  for i = 1, #m1 do
    mtx[i] = {}
    for j = 1, offset do
      mtx[i][j] = docopy(m1[i][j])
    end
    for j = 1, #m2[1] do
      mtx[i][j + offset] = docopy(m2[i][j])
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.concatv(m1, m2)
  assert(#m1[1] == #m2[1], "matrix size mismatch")
  local docopy = matrix.type(m1) == "number" and num_copy or t_copy
  local mtx = {}
  for i = 1, #m1 do
    mtx[i] = {}
    for j = 1, #m1[1] do
      mtx[i][j] = docopy(m1[i][j])
    end
  end
  local offset = #mtx
  for i = 1, #m2 do
    local _i = i + offset
    mtx[_i] = {}
    for j = 1, #m2[1] do
      mtx[_i][j] = docopy(m2[i][j])
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.rotl(m1)
  local mtx = matrix:new(#m1[1], #m1)
  local docopy = matrix.type(m1) == "number" and num_copy or t_copy
  for i = 1, #m1 do
    for j = 1, #m1[1] do
      mtx[#m1[1] - j + 1][i] = docopy(m1[i][j])
    end
  end
  return mtx
end
function matrix.rotr(m1)
  local mtx = matrix:new(#m1[1], #m1)
  local docopy = matrix.type(m1) == "number" and num_copy or t_copy
  for i = 1, #m1 do
    for j = 1, #m1[1] do
      mtx[j][#m1 - i + 1] = docopy(m1[i][j])
    end
  end
  return mtx
end
local tensor_tostring = function(t, fstr)
  if not fstr then
    return "[" .. table.concat(t, ",") .. "]"
  end
  local tval = {}
  for i, v in ipairs(t) do
    tval[i] = string.format(fstr, v)
  end
  return "[" .. table.concat(tval, ",") .. "]"
end
local number_tostring = function(e, fstr)
  return fstr and string.format(fstr, e) or e
end
function matrix.tostring(mtx, formatstr)
  local ts = {}
  local mtype = matrix.type(mtx)
  local e = mtx[1][1]
  local tostring = mtype == "tensor" and tensor_tostring or type(e) == "table" and e.tostring or number_tostring
  for i = 1, #mtx do
    local tstr = {}
    for j = 1, #mtx[1] do
      tstr[j] = tostring(mtx[i][j], formatstr)
    end
    ts[i] = table.concat(tstr, "\t")
  end
  return table.concat(ts, "\n")
end
function matrix.print(...)
  print(matrix.tostring(...))
end
function matrix.latex(mtx, align)
  local align = align or "c"
  local str = "$\\left( \\begin{array}{" .. string.rep(align, #mtx[1]) .. "}\n"
  local getstr = matrix.type(mtx) == "tensor" and tensor_tostring or number_tostring
  for i = 1, #mtx do
    str = str .. "\t" .. getstr(mtx[i][1])
    for j = 2, #mtx[1] do
      str = str .. " & " .. getstr(mtx[i][j])
    end
    if i == #mtx then
      str = str .. "\n"
    else
      str = str .. " \\\\\n"
    end
  end
  return str .. "\\end{array} \\right)$"
end
function matrix.rows(mtx)
  return #mtx
end
function matrix.columns(mtx)
  return #mtx[1]
end
function matrix.size(mtx)
  if matrix.type(mtx) == "tensor" then
    return #mtx, #mtx[1], #mtx[1][1]
  end
  return #mtx, #mtx[1]
end
function matrix.getelement(mtx, i, j)
  if mtx[i] and mtx[i][j] then
    return mtx[i][j]
  end
end
function matrix.setelement(mtx, i, j, value)
  if matrix.getelement(mtx, i, j) then
    mtx[i][j] = value
    return 1
  end
end
function matrix.ipairs(mtx)
  local i, j, rows, columns = 1, 0, #mtx, #mtx[1]
  local function iter()
    j = j + 1
    if j > columns then
      i, j = i + 1, 1
    end
    if i <= rows then
      return i, j
    end
  end
  return iter
end
function matrix.scalar(m1, m2)
  return m1[1][1] * m2[1][1] + m1[2][1] * m2[2][1] + m1[3][1] * m2[3][1]
end
function matrix.cross(m1, m2)
  local mtx = {}
  mtx[1] = {
    m1[2][1] * m2[3][1] - m1[3][1] * m2[2][1]
  }
  mtx[2] = {
    m1[3][1] * m2[1][1] - m1[1][1] * m2[3][1]
  }
  mtx[3] = {
    m1[1][1] * m2[2][1] - m1[2][1] * m2[1][1]
  }
  return setmetatable(mtx, matrix_meta)
end
function matrix.len(m1)
  return math.sqrt(m1[1][1] ^ 2 + m1[2][1] ^ 2 + m1[3][1] ^ 2)
end
function matrix.replace(m1, func, ...)
  local mtx = {}
  for i = 1, #m1 do
    local m1i = m1[i]
    local mtxi = {}
    for j = 1, #m1i do
      mtxi[j] = func(m1i[j], ...)
    end
    mtx[i] = mtxi
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix.elementstostrings(mtx)
  local e = mtx[1][1]
  local tostring = type(e) == "table" and e.tostring or tostring
  return matrix.replace(mtx, tostring)
end
function matrix.solve(m1)
  assert(matrix.type(m1) == "symbol", "matrix not of type 'symbol'")
  local mtx = {}
  for i = 1, #m1 do
    mtx[i] = {}
    for j = 1, #m1[1] do
      mtx[i][j] = tonumber(loadstring("return " .. m1[i][j][1])())
    end
  end
  return setmetatable(mtx, matrix_meta)
end
function matrix_meta.__add(...)
  return matrix.add(...)
end
function matrix_meta.__sub(...)
  return matrix.sub(...)
end
function matrix_meta.__mul(m1, m2)
  if getmetatable(m1) ~= matrix_meta then
    return matrix.mulnum(m2, m1)
  elseif getmetatable(m2) ~= matrix_meta then
    return matrix.mulnum(m1, m2)
  end
  return matrix.mul(m1, m2)
end
function matrix_meta.__div(m1, m2)
  if getmetatable(m1) ~= matrix_meta then
    return matrix.mulnum(matrix.invert(m2), m1)
  elseif getmetatable(m2) ~= matrix_meta then
    return matrix.divnum(m1, m2)
  end
  return matrix.div(m1, m2)
end
function matrix_meta.__unm(mtx)
  return matrix.mulnum(mtx, -1)
end
local option = {
  ["*"] = function(m1)
    return matrix.conjugate(m1)
  end,
  T = function(m1)
    return matrix.transpose(m1)
  end
}
function matrix_meta.__pow(m1, opt)
  return option[opt] and option[opt](m1) or matrix.pow(m1, opt)
end
function matrix_meta.__eq(m1, m2)
  if matrix.type(m1) ~= matrix.type(m2) then
    return false
  end
  if #m1 ~= #m2 or #m1[1] ~= #m2[1] then
    return false
  end
  for i = 1, #m1 do
    for j = 1, #m1[1] do
      if m1[i][j] ~= m2[i][j] then
        return false
      end
    end
  end
  return true
end
function matrix_meta.__tostring(...)
  return matrix.tostring(...)
end
function matrix_meta.__call(...)
  matrix.print(...)
end
matrix_meta.__index = {}
for k, v in pairs(matrix) do
  matrix_meta.__index[k] = v
end
local symbol_meta = {}
symbol_meta.__index = symbol_meta
local symbol = symbol_meta
function symbol_meta.new(o)
  return setmetatable({
    tostring(o)
  }, symbol_meta)
end
symbol_meta.to = symbol_meta.new
setmetatable(symbol_meta, {
  __call = function(_, s)
    return symbol_meta.to(s)
  end
})
function symbol_meta.tostring(e, fstr)
  return string.format(fstr, e[1])
end
function symbol_meta:type()
  if getmetatable(self) == symbol_meta then
    return "symbol"
  end
end
function symbol_meta:gsub(from, to)
  return symbol.to(string.gsub(self[1], from, to))
end
function symbol_meta.makereplacer(...)
  local tosub = {}
  local args = {
    ...
  }
  for i = 1, #args, 2 do
    tosub[args[i]] = args[i + 1]
  end
  local function func(a)
    return tosub[a] or a
  end
  return function(sym)
    return symbol.to(string.gsub(sym[1], "%a", func))
  end
end
function symbol_meta.abs(a)
  return symbol.to("(" .. a[1] .. "):abs()")
end
function symbol_meta.sqrt(a)
  return symbol.to("(" .. a[1] .. "):sqrt()")
end
function symbol_meta.__add(a, b)
  return symbol.to(a .. "+" .. b)
end
function symbol_meta.__sub(a, b)
  return symbol.to(a .. "-" .. b)
end
function symbol_meta.__mul(a, b)
  return symbol.to("(" .. a .. ")*(" .. b .. ")")
end
function symbol_meta.__div(a, b)
  return symbol.to("(" .. a .. ")/(" .. b .. ")")
end
function symbol_meta.__pow(a, b)
  return symbol.to("(" .. a .. ")^(" .. b .. ")")
end
function symbol_meta.__eq(a, b)
  return a[1] == b[1]
end
function symbol_meta.__tostring(a)
  return a[1]
end
function symbol_meta.__concat(a, b)
  return tostring(a) .. tostring(b)
end
matrix.symbol = symbol
return matrix
