config = {
  ver = "1.9.0",
  verAndroid = "1.9.0",
  debugVer = "0.0.26"
}
