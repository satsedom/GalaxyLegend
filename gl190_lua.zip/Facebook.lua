FACEBOOK_ACTION_STATUS = {
  IDLE = 1,
  DOING = 2,
  SUCCESS = 3,
  FAILED
}
FACEBOOK_ACTION_TYPE = {
  LOGIN = 1,
  SHARE_TEXT = 2,
  SHARE_LINK = 3,
  GET_FRIEND_LIST = 4,
  INVITE_FRIEND = 5,
  SEND_GIFT_MSG = 6,
  GET_INVITEABLE_FRIEND_LIST = 7,
  SHARE_STORY = 8,
  SHARE_STORY_TEMPER = 9
}
Facebook = {
  mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE,
  mUserId = "",
  mToken = "",
  mUserName = "",
  mEmail = "",
  mError = nil,
  mLoginCallback = nil,
  mGetFriendListCallback = nil,
  mGetInviteableFriendListCallback = nil,
  mShareTextCallback = nil,
  mShareLinkCallback = nil,
  mShareStoryCallback = nil,
  mInviteFriendsCallback = nil,
  mSendGiftMsgToFriendCallback = nil,
  mActionList = {},
  mActionStatus = FACEBOOK_ACTION_STATUS.IDLE,
  mImgUrl = nil,
  mIsBindFacebookAccount = false,
  mbindFacebookId = nil,
  mBindInfo = nil,
  mNeedCheckValid = false,
  mLogInV2 = false
}
function Facebook.LoginCallback(success, idOrError, token, username, email)
  if success then
    Facebook.mError = nil
    Facebook.mUserId = idOrError
    Facebook.mToken = token
    Facebook.mUserName = username
    Facebook.mEmail = email
    print(idOrError)
    print(token)
    Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.SUCCESS
    Facebook:SaveFacebookInfo(idOrError, username)
  else
    DebugOut("idOrError 111 = ", idOrError)
    Facebook.mError = idOrError
    Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE
    Facebook:ClearActionList()
  end
  Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  print("Facebook.LoginCallback " .. tostring(success))
  if success and Facebook.mNeedCheckValid then
    DebugOut("111111111")
    if Facebook.mLogInV2 then
      valid = Facebook:CheckFacebookAccountValiedV2(idOrError, token, username, email)
    else
      valid = Facebook:CheckFacebookAccountValied(idOrError, token, username, email)
    end
    DebugOut("22222222")
    if not valid then
      print("Facebook.LoginCallback ckeck valid failed.")
      Facebook:ClearActionList()
      Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE
      return
    end
  end
  if Facebook.mLoginCallback then
    DebugOut("gogogogogogogo111")
    Facebook.mLoginCallback(success, idOrError, token, username, email)
    Facebook.mLoginCallback = nil
  end
end
function Facebook.GetFriendListCallback(success, friendListStr)
  Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  if success then
    print(friendListStr)
  else
  end
  print("Facebook.GetFriendList " .. tostring(success))
  local friends = ext.json.parse(friendListStr)
  DebugOut("friends = ", friends)
  DebugTable(friends)
  if Facebook.mGetFriendListCallback then
    Facebook.mGetFriendListCallback(success, friends)
    Facebook.mGetFriendListCallback = nil
  end
end
function Facebook.ShareTextCallback(success)
  Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  if success then
  else
    Facebook.mError = idOrError
  end
  print("Facebook.ShareTextCallback " .. tostring(success))
  if Facebook.mShareTextCallback then
    Facebook.mShareTextCallback(success)
    Facebook.mShareTextCallback = nil
  end
end
function Facebook.ShareLinkCallback(success, msg)
  Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  if success then
  else
    Facebook.mError = idOrError
    if msg then
      local startPos, endPos = string.find(msg, "error_code")
      if startPos then
        Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE
      end
    end
  end
  DebugOut(msg)
  print("Facebook.ShareLinkCallback " .. tostring(success))
  if Facebook.mShareLinkCallback then
    Facebook.mShareLinkCallback(success)
    Facebook.mShareLinkCallback = nil
  end
end
function Facebook.ShareStoryCallback(success, msg)
  if success then
  else
  end
  DebugOut(msg)
  print("Facebook.mShareStoryCallback " .. tostring(success))
  if Facebook.mShareStoryCallback then
    Facebook.mShareStoryCallback(success)
    Facebook.mShareStoryCallback = nil
  else
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  end
end
function Facebook.InviteFriendsCallback(success, msg)
  Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  if success then
  else
    Facebook.mError = idOrError
    if msg then
      local startPos, endPos = string.find(msg, "error_code")
      if startPos then
        local isUserCancel = false
        local params = LuaUtils:string_split(msg, "&")
        for k, v in pairs(params) do
          if v then
            params2 = LuaUtils:string_split(v, "=")
            if params2 and #params2 == 2 and "error_code" == params2[1] and "4201" == params2[2] then
              isUserCancel = true
            end
          end
        end
        if not isUserCancel then
          Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE
        end
      end
    end
  end
  DebugOut(msg)
  print("Facebook.InviteFriendsCallback " .. tostring(success))
  if Facebook.mInviteFriendsCallback then
    Facebook.mInviteFriendsCallback(success)
    Facebook.mInviteFriendsCallback = nil
  end
end
function Facebook.SendGiftMsgToFriendCallback(success, msg)
  Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  if success then
  else
  end
  DebugOut(msg)
  print("Facebook.SendGiftMsgToFriendCallback " .. tostring(success))
  if Facebook.mSendGiftMsgToFriendCallback then
    Facebook.mSendGiftMsgToFriendCallback(success)
    Facebook.mSendGiftMsgToFriendCallback = nil
  end
end
function Facebook:Reset()
  Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  Facebook.mActionList = {}
  Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE
  Facebook.mHeadMap = {}
end
function Facebook:SetupFacebookInfo(success, idOrError, token, username, email)
  Facebook.mError = nil
  Facebook.mUserId = idOrError
  Facebook.mToken = token
  Facebook.mUserName = username
  Facebook.mEmail = email
end
function Facebook:SetStatus(status)
  Facebook.mActionStatus = status
end
function Facebook:GetStatus()
  return Facebook.mActionStatus
end
function Facebook:ClearActionList()
  if Facebook.mActionList and #Facebook.mActionList > 0 then
    for k, v in pairs(Facebook.mActionList) do
      if v.data.callback then
        v.data.callback(false)
      end
    end
  end
  Facebook.mActionList = {}
end
function Facebook:AddAction(action, pos)
  DebugOut("AddAction :")
  DebugTable(action)
  if not Facebook.mActionList then
    Facebook.mActionList = {}
  end
  if pos and pos > 0 and pos <= #Facebook.mActionList then
    table.insert(Facebook.mActionList, pos, action)
  else
    table.insert(Facebook.mActionList, action)
  end
end
function Facebook:IsBindFacebook()
  return Facebook.mIsBindFacebookAccount
end
function Facebook:LoginWithNoUI()
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  if ext.socialShare.FB_LoginWithNoUI then
    ext.socialShare.FB_LoginWithNoUI()
    return
  elseif AutoUpdate.isAndroidDevice and ext.socialShare and ext.socialShare.FB_IsLogin and ext.socialShare.FB_IsLogin() then
    ext.socialShare.FB_Login()
  end
end
function Facebook:Login(callback, checkValid, useV2)
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  if useV2 then
    Facebook.mLogInV2 = true
  else
    Facebook.mLogInV2 = false
  end
  if Facebook:GetStatus() == FACEBOOK_ACTION_STATUS.DOING then
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  end
  local isDo = false
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    Facebook.mNeedCheckValid = checkValid
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.DOING)
    Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.DOING
    isDo = true
  end
  local function doLogin()
    if isDo then
      Facebook.mLoginCallback = callback
      ext.socialShare.FB_Login()
    end
  end
  if checkValid and not Facebook:IsBindFacebook() then
    DebugOut("Need bind facebook account.")
    local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
    local function okCallback()
      doLogin()
    end
    local cancelCallback = function()
      Facebook:Reset()
    end
    local tip = GameLoader:GetGameText("LC_MENU_FACEBOOK_NOT_BOUND_ACCOUNT")
    GameUIGlobalScreen:ShowMessageBox(2, "", tip, okCallback, cancelCallback)
  else
    doLogin()
  end
end
function Facebook:LoginV2(callback, checkValid)
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  Facebook.mLogInV2 = true
  if Facebook:GetStatus() == FACEBOOK_ACTION_STATUS.DOING then
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
  end
  local isDo = false
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    Facebook.mNeedCheckValid = checkValid
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.DOING)
    Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.DOING
    isDo = true
  end
  local function doLogin()
    if isDo then
      DebugOut("do logint!!!")
      Facebook.mLoginCallback = callback
      ext.socialShare.FB_Login()
    end
  end
  if checkValid then
    DebugOut("Need bind facebook account.")
    doLogin()
  else
    doLogin()
  end
end
function Facebook:Logout()
end
function Facebook:GetFriendList(callback)
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  if Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.FAILED then
    return
  elseif Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.IDLE then
    Facebook:Login(nil, true)
  end
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.DOING)
    Facebook.mGetFriendListCallback = callback
    ext.socialShare.FB_GetFriendList()
  else
    local action = {
      actionType = FACEBOOK_ACTION_TYPE.GET_FRIEND_LIST,
      data = {callback = callback}
    }
    Facebook:AddAction(action)
  end
end
function Facebook:GetCanFetchInvitableFriendList()
  if ext.socialShare.FB_GetInvitableFriends then
    return true
  end
  return false
end
function Facebook:GetInvitableFriendList(excludeFriends, callback)
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  if not Facebook:GetCanFetchInvitableFriendList() then
    return
  end
  if Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.FAILED then
    return
  elseif Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.IDLE then
    Facebook:Login(nil, true)
  end
  local excludeFriendsStr = ""
  if excludeFriends then
    excludeFriendsStr = table.concat(excludeFriends, ",")
  end
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.DOING)
    Facebook.mGetFriendListCallback = callback
    ext.socialShare.FB_GetInvitableFriends(excludeFriendsStr)
  else
    local action = {
      actionType = FACEBOOK_ACTION_TYPE.GET_INVITEABLE_FRIEND_LIST,
      data = {excludeFriends = excludeFriends, callback = callback}
    }
    Facebook:AddAction(action)
  end
end
function Facebook:ShareText(text, callback)
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  if Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.FAILED then
    return
  elseif Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.IDLE then
    Facebook:Login(nil, true)
  end
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.DOING)
    Facebook.mShareTextCallback = callback
    ext.socialShare.FB_ShareText(text)
  else
    local action = {
      actionType = FACEBOOK_ACTION_TYPE.SHARE_TEXT,
      data = {text = text, callback = callback}
    }
    Facebook:AddAction(action)
  end
end
function Facebook:ShareLink(gameUrl, title, subTitle, describe, picUrl, callback)
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  if Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.FAILED then
    return
  elseif Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.IDLE then
    Facebook:Login(nil, true)
  end
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.DOING)
    Facebook.mShareLinkCallback = callback
    ext.socialShare.FB_ShareLink(gameUrl, title, subTitle, describe, picUrl)
  else
    local action = {
      actionType = FACEBOOK_ACTION_TYPE.SHARE_LINK,
      data = {
        gameUrl = gameUrl,
        title = title,
        subTitle = subTitle,
        describe = describe,
        picUrl = picUrl,
        callback = callback
      }
    }
    Facebook:AddAction(action)
  end
end
function Facebook:InviteFriends(inviteTitle, inviteMsg, friendsList, callback)
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  if Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.FAILED then
    return
  elseif Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.IDLE then
    Facebook:Login(nil, true)
  end
  local friendsListStr = ""
  if friendsList then
    friendsListStr = table.concat(friendsList, ",")
  end
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    Facebook.mInviteFriendsCallback = callback
    ext.socialShare.FB_InviteFriends(Facebook.mUserId, Facebook.mToken, inviteTitle, inviteMsg, friendsListStr)
  else
    local action = {
      actionType = FACEBOOK_ACTION_TYPE.INVITE_FRIEND,
      data = {
        inviteTitle = inviteTitle,
        inviteMsg = inviteMsg,
        inviteFriendsList = friendsList,
        callback = callback
      }
    }
    Facebook:AddAction(action)
  end
end
function Facebook:SendGiftMsgToFriend(inviteTitle, inviteMsg, friendIdList, callback)
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  if Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.FAILED then
    return
  elseif Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.IDLE then
    Facebook:Login(nil, true)
  end
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    if friendIdList and #friendIdList > 0 then
      local friendIds = ""
      for i = 1, #friendIdList do
        friendIds = friendIds .. friendIdList[i]
        if i < #friendIdList then
          friendIds = friendIds .. "\001"
        end
      end
      DebugTable(friendIdList)
      DebugOut("friendIds " .. friendIds)
      Facebook.mSendGiftMsgToFriendCallback = callback
      ext.socialShare.FB_SendGift(inviteTitle, inviteMsg, "1629062513983940", friendIds)
    else
      DebugOut("friendIdList is nil or empty.")
      if callback then
        callback(false)
      end
    end
  else
    local action = {
      actionType = FACEBOOK_ACTION_TYPE.SEND_GIFT_MSG,
      data = {
        inviteTitle = inviteTitle,
        inviteMsg = inviteMsg,
        friendIdList = friendIdList,
        callback = callback
      }
    }
    Facebook:AddAction(action)
  end
end
function Facebook:IsHasHeadIconFile(fbId)
  if Facebook.mHeadMap and Facebook.mHeadMap[fbId] then
    return true
  else
    return false
  end
end
function Facebook:GetHeadIcon(fbId, callback)
  local fileName = "fb2" .. tostring(fbId) .. ".png"
  local localPath = "data2/fb2" .. tostring(fbId) .. ".png"
  local url = "https://graph.facebook.com/" .. tostring(fbId) .. "/picture?width=80&height=80"
  if Facebook.mHeadMap and Facebook.mHeadMap[fbId] then
    ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
    if callback then
      callback(fbId, fileName)
    end
    return true
  end
  ext.http.requestDownload({
    url,
    method = "GET",
    localpath = localPath,
    progressCallback = function(percent)
    end,
    callback = function(statusCode, filename, errstr)
      print("downloading filename ", filename)
      if 200 == statusCode and (nil == errstr or "" == errstr) then
        ext.UpdateAutoUpdateFile(localPath, 0, 0, 0)
        if not Facebook.mHeadMap then
          Facebook.mHeadMap = {}
        end
        Facebook.mHeadMap[fbId] = fileName
        if callback then
          callback(fbId, fileName)
        end
      else
        DebugOut("Download facebook head icon failed. ")
      end
    end
  })
end
function Facebook:Update()
  if Facebook.mActionStatus ~= FACEBOOK_ACTION_STATUS.DOING and #Facebook.mActionList > 0 then
    local action = Facebook.mActionList[1]
    if action.actionType == FACEBOOK_ACTION_TYPE.LOGIN then
      Facebook:Login(nil, true)
    elseif action.actionType == FACEBOOK_ACTION_TYPE.SHARE_TEXT then
      Facebook:ShareText(action.data.text, action.data.callback)
    elseif action.actionType == FACEBOOK_ACTION_TYPE.SHARE_LINK then
      Facebook:ShareLink(action.data.gameUrl, action.data.title, action.data.subTitle, action.data.describe, action.data.picUrl, action.data.callback)
    elseif action.actionType == FACEBOOK_ACTION_TYPE.GET_FRIEND_LIST then
      Facebook:GetFriendList(action.data.callback)
    elseif action.actionType == FACEBOOK_ACTION_TYPE.GET_INVITEABLE_FRIEND_LIST then
      Facebook:GetInvitableFriendList(action.data.excludeFriends, action.data.callback)
    elseif action.actionType == FACEBOOK_ACTION_TYPE.INVITE_FRIEND then
      Facebook:InviteFriends(action.data.inviteTitle, action.data.inviteMsg, action.data.inviteFriendsList, action.data.callback)
    elseif action.actionType == FACEBOOK_ACTION_TYPE.SEND_GIFT_MSG then
      Facebook:SendGiftMsgToFriend(action.data.inviteTitle, action.data.inviteMsg, action.data.friendIdList, action.data.callback)
    elseif action.actionType == FACEBOOK_ACTION_TYPE.SHARE_STORY then
      Facebook:ShareGraphStory(action.data.objectTypeWithNamespace, action.data.objectType, action.data.ActionType, action.data.storyTitle, action.data.storeDesc, action.data.imgUrl, action.data.callback)
    elseif action.actionType == FACEBOOK_ACTION_TYPE.SHARE_STORY_TEMPER then
      Facebook:ShareGraphStoryTemper(action.data.objectTypeWithNamespace, action.data.objectType, action.data.ActionType, action.data.storyTitle, action.data.storeDesc, action.data.imgUrl, action.data.callback)
    end
    table.remove(Facebook.mActionList, 1)
  end
end
function Facebook:IsSupportFacebook()
  if IPlatformExt.getConfigValue("PlatformName") == "Huawei" then
    return false
  end
  if ext.socialShare.IsSupportFacebook and ext.socialShare.IsSupportFacebook() then
    return true
  end
  return false
end
function Facebook:IsFacebookEnabled()
  if IPlatformExt.getConfigValue("PlatformName") == "Huawei" then
    return false
  end
  local isSysNotSupport = ext.GetPlatform() == "iOS" and GameUtils:GetLeftNumFromOSVersion(ext.GetOSVersion()) and GameUtils:GetLeftNumFromOSVersion(ext.GetOSVersion()) < 6
  return not isSysNotSupport and not GameUtils:IsChinese() and not GameUtils:IsSpaceLancer() and IPlatformExt.getConfigValue("UseExtLogin") ~= "True" and not GameUtils:IsQihooApp()
end
function Facebook:IsLoginedIn()
  if not Facebook:IsSupportFacebook() then
    return false
  end
  if ext.socialShare and ext.socialShare.FB_IsLogin then
    local islogin = ext.socialShare.FB_IsLogin()
    if not islogin then
      Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE
    end
  else
    Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE
  end
  return Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.SUCCESS
end
function Facebook:HasPublishPermission()
  if not Facebook:IsSupportFacebook() then
    return false
  end
  if ext.socialShare then
    if ext.socialShare.FB_HasPublishPermission then
      return ext.socialShare.FB_HasPublishPermission()
    else
      return true
    end
  else
    return false
  end
end
function Facebook:CheckAccountBind()
  local loginInfo = GameUtils:GetLoginInfo()
  DebugOut("check valid in facebook = ")
  DebugTable(loginInfo)
  if IPlatformExt.getConfigValue("UseExtLogin") == "True" or GameUtils:IsQihooApp() then
    Facebook.mIsBindFacebookAccount = false
    if Facebook:IsLoginedIn() and Facebook.mbindFacebookId ~= Facebook.mUserId then
      Facebook:Reset()
    end
  elseif GameUtils:IsFacebookAccount(loginInfo.AccountInfo) then
    DebugOut("check valid in facebook is a facebook account")
    Facebook.mIsBindFacebookAccount = true
    Facebook.mbindFacebookId = loginInfo.AccountInfo.passport
    if ext.socialShare and ext.socialShare.FB_GetAccessToken then
      local curAccessToken = ext.socialShare.FB_GetAccessToken()
      if curAccessToken == loginInfo.AccountInfo.password then
        Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.SUCCESS
        Facebook.mUserId = loginInfo.AccountInfo.passport
        Facebook.mToken = loginInfo.AccountInfo.password
        Facebook.mUserName = loginInfo.AccountInfo.displayName
        Facebook.mEmail = ""
        Facebook:SaveFacebookInfo(Facebook.mUserId, Facebook.mUserName)
        Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.SUCCESS
        Facebook:SetStatus(FACEBOOK_ACTION_STATUS.IDLE)
      end
    end
    if Facebook:IsLoginedIn() and Facebook.mbindFacebookId ~= Facebook.mUserId then
      Facebook:Reset()
    end
    Facebook:SendFacebookPassport(loginInfo.AccountInfo.passport)
  elseif loginInfo.AccountInfo and loginInfo.AccountInfo.passport and "" ~= loginInfo.AccountInfo.passport then
    GameUtils:RequestAccountPlayerTable(loginInfo.AccountInfo, self.RequestAccountPlayerTableCallback, self.RequestAccountPlayerTableErrorCallback)
  end
  DebugOut("Facebook bind :" .. tostring(Facebook.mIsBindFacebookAccount))
end
function Facebook.RequestAccountPlayerTableCallback(content)
  DebugOut("check facebook bind callback.")
  Facebook.mBindInfo = content
  if content.multi_acc and #content.multi_acc > 0 then
    for k, v in ipairs(content.multi_acc) do
      if v.bind_type == GameUtils.AccountType.facebook then
        Facebook.mIsBindFacebookAccount = true
        Facebook.mbindFacebookId = v.bind_passport
        Facebook:SendFacebookPassport(v.bind_passport)
      end
      if v.origin_type == GameUtils.AccountType.facebook then
        Facebook.mIsBindFacebookAccount = true
        Facebook.mbindFacebookId = v.origin_passport
        Facebook:SendFacebookPassport(v.origin_passport)
      end
    end
  end
  if Facebook:IsLoginedIn() and Facebook.mbindFacebookId ~= Facebook.mUserId then
    Facebook:Reset()
  end
  DebugOut("Facebook bind :" .. tostring(Facebook.mIsBindFacebookAccount))
end
function Facebook:SendFacebookPassport(facebookPassport)
  local req = {passport = facebookPassport}
  NetMessageMgr:SendMsg(NetAPIList.update_passport_req.Code, req, nil, false, nil)
end
function Facebook:SendNameToServer(fbId, userName)
  local successCallback = function(content)
  end
  local param = {fbid = fbId, name = userName}
  local requestParam = GameUtils:combineUrlParamTable(param)
  local requestType = "facebook_info/put_info?" .. requestParam
  GameUtils:HTTP_SendRequest(requestType, nil, successCallback, true, Facebook.GetUserNameFailedCallback, "GET", "notencrypt")
end
function Facebook:SaveFacebookInfo(fbId, userName)
  local fbMap = GameSettingData.fbMap
  fbMap = fbMap or {}
  if fbId and userName then
    if not fbMap[fbId] or fbMap[fbId] and fbMap[fbId] ~= userName then
      Facebook:SendNameToServer(fbId, userName)
    end
    fbMap[fbId] = userName
    GameSettingData.fbMap = fbMap
    GameUtils:SaveSettingData()
  end
end
function Facebook.GetUserNameCallback()
end
function Facebook.GetUserNameFailedCallback(statusCode, responseContent)
end
function Facebook:GetFacebookUserNameById(fbId, callback)
  local fbMap = GameSettingData.fbMap
  if fbMap and fbMap[fbId] then
    return fbMap[fbId]
  else
    local function successCallback(content)
      if callback and content and content.name then
        DebugTable(content)
        if not GameSettingData.fbMap then
          GameSettingData.fbMap = {}
        end
        GameSettingData.fbMap[fbId] = content.name
        callback(content.name)
      end
    end
    local requestParam = {fbid = fbId}
    GameUtils:HTTP_SendRequest("facebook_info/get_info", requestParam, successCallback, true, Facebook.GetUserNameFailedCallback, "GET", "notencrypt")
  end
  return ""
end
function Facebook:ShowDownloadTip()
  if IPlatformExt.getConfigValue("PlatformName") == "Huawei" then
    return
  end
  DebugOut("You need download for facebook.")
  local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
  local okCallback = function()
    GameGlobalData.OpenUrl()
  end
  local cancelCallback = function()
  end
  local tip = GameLoader:GetGameText("LC_MENU_FACEBOOK_VERSION_ERROR")
  GameUIGlobalScreen:ShowMessageBox(2, "", tip, okCallback, cancelCallback)
end
function Facebook.mBindSuccessCallback()
  local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
  GameWaiting:HideLoadingScreen()
  DebugOut("Facebook.mBindSuccessCallback")
  Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.SUCCESS
  if Facebook.mLoginCallback then
    local ret = Facebook.mLoginCallback(true, Facebook.mUserId, Facebook.mToken, Facebook.mUserName, Facebook.mEmail)
    Facebook.mLoginCallback = nil
    return ret
  end
  return false
end
function Facebook.mBindFailedCallback()
  local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
  GameWaiting:HideLoadingScreen()
  DebugOut("Facebook.mBindFailedCallback")
  Facebook.mLoginStatus = FACEBOOK_ACTION_STATUS.IDLE
  if Facebook.mLoginCallback then
    local ret = Facebook.mLoginCallback(false)
    Facebook.mLoginCallback = nil
    return ret
  end
  return false
end
function Facebook:BindFacebook(fbId, token, username, email)
  local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
  GameWaiting:ShowLoadingScreen()
  local GameSetting = LuaObjectManager:GetLuaObject("GameSetting")
  local loginInfo = GameUtils:GetLoginInfo()
  if IPlatformExt.getConfigValue("UseExtLogin") == "True" or GameUtils:IsQihooApp() then
    GameWaiting:HideLoadingScreen()
  elseif not loginInfo.AccountInfo then
    DebugOut("guest account.")
    GameSetting.mDelegateBindSuccessCallback = Facebook.mBindSuccessCallback
    GameSetting.mDelegateBindFailedCallback = Facebook.mBindFailedCallback
    GameSetting.FacebookLoginCallback(true, fbId, token, username, email)
  elseif GameUtils:IsFacebookAccount(loginInfo.AccountInfo) then
    DebugOut("facebook account.")
    GameWaiting:HideLoadingScreen()
  else
    DebugOut("tap4fun account.")
    GameSetting.mDelegateBindSuccessCallback = Facebook.mBindSuccessCallback
    GameSetting.mDelegateBindFailedCallback = Facebook.mBindFailedCallback
    GameSetting.FacebookLoginCallback(true, fbId, token, username, email)
  end
end
function Facebook:BindFacebookV2(fbId, token, username, email)
  local GameWaiting = LuaObjectManager:GetLuaObject("GameWaiting")
  GameWaiting:ShowLoadingScreen()
  local GameSetting = LuaObjectManager:GetLuaObject("GameSetting")
  local loginInfo = GameUtils:GetLoginInfo()
  if IPlatformExt.getConfigValue("UseExtLogin") == "True" or GameUtils:IsQihooApp() then
    GameWaiting:HideLoadingScreen()
  elseif not loginInfo.AccountInfo then
    DebugOut("guest account.")
    GameSetting.mDelegateBindSuccessCallback = Facebook.mBindSuccessCallback
    GameSetting.FacebookLoginCallback(true, fbId, token, username, email)
  elseif GameUtils:IsFacebookAccount(loginInfo.AccountInfo) then
    DebugOut("facebook account.")
    GameWaiting:HideLoadingScreen()
  else
    DebugOut("tap4fun account.")
    GameSetting.mDelegateBindSuccessCallback = Facebook.mBindSuccessCallback
    GameSetting.FacebookLoginCallback(true, fbId, token, username, email)
  end
end
function Facebook:CheckFacebookAccountValied(fbId, token, username, email)
  if Facebook:IsBindFacebook() then
    if Facebook.mbindFacebookId == fbId then
      return true
    else
      local GameTip = LuaObjectManager:GetLuaObject("GameTip")
      local tip = GameLoader:GetGameText("LC_MENU_FACEBOOK_WRONG_ID_ALERT")
      GameTip:Show(tip)
      return false
    end
  else
    Facebook:BindFacebook(fbId, token, username, email)
    return false
  end
end
function Facebook:CheckFacebookAccountValiedV2(fbId, token, username, email)
  if Facebook:IsBindFacebook() then
    DebugOut("check1111")
    if Facebook.mbindFacebookId == fbId then
      return true
    else
      local GameSetting = LuaObjectManager:GetLuaObject("GameSetting")
      GameSetting.mFBAccount = {
        passport = Facebook.mUserId,
        password = Facebook.mToken,
        accType = GameUtils.AccountType.facebook,
        displayName = Facebook.mUserName
      }
      GameSetting:ShowChangeAccountDialog()
      DebugOut("check2222")
      return false
    end
  else
    DebugOut("check33333")
    Facebook:BindFacebookV2(fbId, token, username, email)
    return false
  end
end
function Facebook:CanShareStory()
  if ext.GetBundleIdentifier() == "com.ts.galaxyempire2_android_global" then
    return false
  end
  if ext.socialShare and ext.socialShare.FB_ShareGraphStory then
    return true
  end
  return false
end
function Facebook:GetAppLinkUrl()
  return "https://fb.me/492788254226111"
end
function Facebook:ShareGraphStory(objectTypeWithNamespace, objectType, actionTypeWithNameSpace, storyTitle, storeDesc, imgUrl, callback)
  DebugOut("Facebook:ShareGraphStory")
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  DebugOut("Facebook:ShareGraphStory222222")
  if Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.FAILED then
    return
  elseif Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.IDLE then
    Facebook:Login(nil, true)
  end
  local appLinkUrl = Facebook:GetAppLinkUrl()
  DebugOut("Facebook:ShareGraphStory333333")
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    DebugOut("Facebook:ShareGraphStory44444")
    if ext.socialShare and ext.socialShare.FB_ShareGraphStory then
      Facebook:SetStatus(FACEBOOK_ACTION_STATUS.DOING)
      Facebook.mShareStoryCallback = callback
      DebugOut("Facebook:ShareGraphStory555555")
      ext.socialShare.FB_ShareGraphStory(objectTypeWithNamespace, objectType, actionTypeWithNameSpace, storyTitle, storeDesc, imgUrl, appLinkUrl)
    end
  else
    local action = {
      actionType = FACEBOOK_ACTION_TYPE.SHARE_STORY,
      data = {
        imgUrl = imgUrl,
        storyTitle = storyTitle,
        objectTypeWithNamespace = objectTypeWithNamespace,
        objectType = objectType,
        ActionType = actionTypeWithNameSpace,
        storeDesc = storeDesc,
        appLinkUrl = appLinkUrl,
        callback = callback
      }
    }
    Facebook:AddAction(action)
  end
end
function Facebook:ShareGraphStoryTemper(objectTypeWithNamespace, objectType, actionTypeWithNameSpace, storyTitle, storeDesc, imgUrl, callback)
  DebugOut("Facebook:ShareGraphStory")
  if not Facebook:IsSupportFacebook() then
    Facebook:ShowDownloadTip()
    return
  end
  DebugOut("Facebook:ShareGraphStory222222")
  if Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.FAILED then
    return
  elseif Facebook.mLoginStatus == FACEBOOK_ACTION_STATUS.IDLE then
    Facebook:Login(nil, true)
  end
  DebugOut("Facebook:ShareGraphStory333333")
  if Facebook:GetStatus() ~= FACEBOOK_ACTION_STATUS.DOING then
    DebugOut("Facebook:ShareGraphStory44444")
    Facebook:SetStatus(FACEBOOK_ACTION_STATUS.DOING)
    Facebook.mShareStoryCallback = callback
    if ext.socialShare and ext.socialShare.FB_ShareGraphStory then
      DebugOut("Facebook:ShareGraphStory555555")
      local objectJson = Facebook:MakeStoryParam(objectTypeWithNamespace, objectType, actionTypeWithNameSpace, storyTitle, storeDesc, imgUrl)
      ext.socialShare.FB_ShareGraphStoryTemper(objectJson, actionTypeWithNameSpace)
    end
  else
    local action = {
      actionType = FACEBOOK_ACTION_TYPE.SHARE_STORY_TEMPER,
      data = {
        imgUrl = imgUrl,
        title = storyTitle,
        objectTypeWithNamespace = objectTypeWithNamespace,
        objectType = objectType,
        ActionType = ActionType,
        storeDesc = storeDesc,
        callback = callback,
        storyTitle = storyTitle
      }
    }
    Facebook:AddAction(action)
  end
end
function Facebook:MakeStoryParam(objectTypeWithNamespace, objectType, actionTypeWithNameSpace, storyTitle, storeDesc, imgUrl)
  local objectJson = {}
  objectJson["og:type"] = objectTypeWithNamespace
  objectJson["og:title"] = storyTitle
  objectJson["og:description"] = storeDesc
  objectJson["og:image"] = imgUrl
  objectJson.myType = objectType
  return ext.json.generate(objectJson)
end
