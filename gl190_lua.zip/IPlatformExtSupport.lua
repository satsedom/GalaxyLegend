IPlatformExt.Login = IPlatformExt.Login or IPlatformExt.login or function(...)
  return
end
IPlatformExt.Logout = IPlatformExt.Logout or IPlatformExt.logout or IPlatformExt.Loginout or IPlatformExt.loginout or function(...)
  return
end
IPlatformExt.Charge = IPlatformExt.Charge or IPlatformExt.charge or function(...)
  return
end
IPlatformExt.ChargeFinish = IPlatformExt.ChargeFinish or IPlatformExt.chargeFinish or function(...)
  return
end
IPlatformExt.RequestUnfinishedCharge = IPlatformExt.RequestUnfinishedCharge or IPlatformExt.requestUnfinishedCharge or function(...)
  return
end
IPlatformExt.RegCallBackFunc = IPlatformExt.RegCallBackFunc or IPlatformExt.regCallBackFunc or function(...)
  return
end
IPlatformExt.RecordGameInfo = IPlatformExt.RecordGameInfo or IPlatformExt.recordGameInfo or function(...)
  return
end
IPlatformExt.getConfigValue = IPlatformExt.getConfigValue or function(...)
  return ""
end
IPlatformExt.isAchievement_support = IPlatformExt.isAchievement_support or function(...)
  return false
end
IPlatformExt.unlock_Achievement = IPlatformExt.unlock_Achievement or function(...)
  return
end
IPlatformExt.show_Achievement = IPlatformExt.show_Achievement or function(...)
  return
end
IPlatformExt.isLeaderBoard_support = IPlatformExt.isLeaderBoard_support or function(...)
  return false
end
IPlatformExt.submit_LeaderBoardScore = IPlatformExt.submit_LeaderBoardScore or function(...)
  return
end
IPlatformExt.show_LeaderBord = IPlatformExt.show_LeaderBord or function(...)
  return
end
IPlatformExt.setUpProductList = IPlatformExt.setUpProductList or function(...)
  return
end
