local cost = GameData.alliance.cost
table.insert(cost, {donation = 1})
table.insert(cost, {donation = 2})
table.insert(cost, {donation = 3})
