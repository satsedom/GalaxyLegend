local GL_lua_class = {}
function luaClass(super)
  local class_type = {}
  class_type.ctor = false
  class_type.super = super
  function class_type.new(...)
    local obj = {}
    do
      local create
      function create(c, ...)
        if c.super then
          create(c.super, ...)
        end
        if c.ctor then
          c.ctor(obj, ...)
        end
      end
      create(class_type, ...)
    end
    setmetatable(obj, {
      __index = GL_lua_class[class_type]
    })
    return obj
  end
  local vtbl = {}
  GL_lua_class[class_type] = vtbl
  setmetatable(class_type, {
    __newindex = function(t, k, v)
      vtbl[k] = v
    end
  })
  if super then
    setmetatable(vtbl, {
      __index = function(t, k)
        local ret = GL_lua_class[super][k]
        vtbl[k] = ret
        return ret
      end
    })
  end
  return class_type
end
