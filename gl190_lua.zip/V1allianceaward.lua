local award = GameData.alliance.award
table.insert(award, {
  level = 1,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 2,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 3,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 4,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 5,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 6,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 7,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 8,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 9,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 10,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 11,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 12,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 13,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 14,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
table.insert(award, {
  level = 15,
  prestige_chairman = 150,
  prestige_manager = 125,
  prestige_member = 100,
  brick_chairman = 1000,
  brick_manager = 100,
  brick_member = 1
})
