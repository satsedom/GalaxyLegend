function dofile(n)
  local f, err = loadfile(n)
  if f then
    return f(), err
  else
    return nil, err
  end
end
immanentversion = nil
function ext.dofile(n)
  ext.UpdateAutoUpdateFile(n, "", 0, 0)
  dofile(n)
end
if ext.addFlurryEvent then
  local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
  ext.addFlurryEvent("Step_InitLua", {COUNTRY = countryStr})
end
g_SaveNewFteData = false
if g_SaveNewFteData then
  math.randomseed(tostring(os.time()):reverse():sub(1, 6))
  g_FTEGroupId = math.random(1, 9999999)
end
function ext.sendNewFteData(step)
  if g_SaveNewFteData then
    print(" ext.sendNewFteData ", step, g_FTEGroupId)
    local url = "http://54.200.10.68/gamers/fte"
    local httpheader = {
      ["User-Agent"] = "Tap4fun client",
      ["Accept-Encoding"] = "gzip",
      Appid = ext.GetBundleIdentifier(),
      clientv = ext.GetAppVersion(),
      shiqu = ext.GetTimeZone(),
      platform = ext.GetChannel(),
      macAddress = ext.GetIOSMacAddress(),
      udid = ext.GetIOSOpenUdid(),
      OSVersion = ext.GetOSVersion()
    }
    ext.http.requestBasic({
      url,
      param = nil,
      body = ext.ENC2(ext.json.generate({progress = step, group = g_FTEGroupId})),
      format = nil,
      method = "POST",
      mode = "normal",
      timeout = nil,
      localpath = nil,
      header = httpheader,
      callback = function(statusCode, responseContent, errstr)
        print("sendNewFteData---------------NOW CALL BACK HTTP------------")
        print("NOW STATUS CODE::" .. statusCode .. tostring(responseContent))
      end,
      progressCallback = nil,
      authCallback = nil
    })
  end
end
if g_SaveNewFteData then
  ext.sendNewFteData("FTE_InitLua")
end
function ext.getFontFile(fontName)
  print("======================fuck fontName ", fontName)
  if GameSettingData and GameSettingData.Save_Lang and GameSettingData.Save_Lang ~= "en" then
    return "data2/GalaxyEmpire2.ttf"
  end
  if fontName == "GalaxyEmpire2TitleGlobal-Bold" then
    return "data2/GalaxyEmpire2TitleGlobal.ttf"
  elseif fontName == "GalaxyEmpire2Title-Bold" then
    return "data2/GalaxyEmpire2Title.ttf"
  elseif fontName == "Galaxy Empire 2 Light" then
    return "data2/GalaxyEmpire2Light.ttf"
  else
    return "data2/GalaxyEmpire2.ttf"
  end
end
function ext.http.requestDownload(varTable)
  ext.http.requestBasic({
    varTable[1],
    body = varTable.body,
    format = varTable.format,
    method = varTable.method,
    mode = "download",
    timeout = varTable.timeout,
    localpath = varTable.localpath,
    header = {
      ["User-Agent"] = "Tap4fun client",
      ["Accept-Encoding"] = "gzip"
    },
    callback = function(statusCode, ...)
      AutoUpdate.lastRequestInfoRecord.url = varTable[1] or AutoUpdate.lastRequestInfoRecord.url
      AutoUpdate.lastRequestInfoRecord.statusCode = statusCode or AutoUpdate.lastRequestInfoRecord.statusCode
      varTable.callback(statusCode, ...)
    end,
    progressCallback = varTable.progressCallback,
    authCallback = varTable.authCallback
  })
end
math.randomseed(os.time())
ext.http.quest_index = math.random(10000)
function ext.http.request(varTable)
  local urlParam = ""
  local urlBody = varTable.body or ""
  local urlMethod = string.lower(varTable.method or "get")
  if varTable.param ~= nil then
    local empty = true
    for k, v in pairs(varTable.param) do
      urlParam = urlParam .. tostring(k) .. "=" .. tostring(v) .. "&"
      empty = false
    end
    if not empty then
      urlParam = "?" .. urlParam
    end
    print("http params : ", urlParam)
  end
  if urlMethod == "post" then
    urlBody = ext.ENC2(urlBody)
  end
  local questIndexString = ext.ENC2(tostring(ext.http.quest_index))
  ext.http.quest_index = ext.http.quest_index + 1
  local sig = varTable[1] .. urlParam .. ext.GetAKEY() .. questIndexString .. ext.GetIOSOpenUdid()
  sig = ext.ENC1(sig)
  local osversion = tonumber(ext.GetOSVersion())
  local lastLoginSever = -1
  local idfa = ""
  if ext.GetPlatform() == "iOS" then
    idfa = ext.GetIDFA()
  end
  local httpheader = {
    ["User-Agent"] = "Tap4fun client",
    ["Accept-Encoding"] = "gzip",
    requestindex = questIndexString,
    sig = sig,
    Appid = ext.GetBundleIdentifier(),
    resv = AutoUpdate.localVersion,
    clientv = ext.GetAppVersion(),
    Locale = ext.GetGameLocale(),
    shiqu = ext.GetTimeZone(),
    platform = ext.GetChannel(),
    macAddress = ext.GetIOSMacAddress(),
    udid = ext.GetIOSOpenUdid(),
    lastLoginServer = lastLoginSever,
    OSVersion = ext.GetOSVersion(),
    AutoUpdateVersion = AutoUpdate.localVersion,
    IDFA = idfa
  }
  if varTable.header ~= nil then
    for k, v in pairs(varTable.header) do
      httpheader[k] = v
    end
  end
  ext.http.requestBasic({
    varTable[1],
    param = urlParam,
    body = urlBody,
    format = varTable.format,
    method = varTable.method,
    mode = varTable.mode,
    timeout = varTable.timeout,
    localpath = varTable.localpath,
    header = httpheader,
    callback = function(statusCode, ...)
      AutoUpdate.lastRequestInfoRecord.url = varTable[1] or AutoUpdate.lastRequestInfoRecord.url
      AutoUpdate.lastRequestInfoRecord.statusCode = statusCode or AutoUpdate.lastRequestInfoRecord.statusCode
      varTable.callback(statusCode, ...)
    end,
    progressCallback = varTable.progressCallback,
    authCallback = varTable.authCallback
  })
end
function ext.onAlertCanceled(tag)
  if tag == 1 then
    AutoUpdate.ipAddrAttempedTime = 0
    AutoUpdate.isDownloadFinish = true
  end
end
function ext.GetGameLocale()
  return ext.DeviceToGameLocale(ext.GetDeviceLanguage())
end
function ext.DeviceToGameLocale(str)
  if ext.SNSdkType == "kakao" then
    return "kr"
  end
  if string.find(str, "en") == 1 then
    return "en"
  elseif string.find(str, "zh_Hans") == 1 then
    return "cn"
  elseif string.find(str, "zh_Hant") == 1 then
    return "zh"
  elseif string.find(str, "ja") == 1 then
    return "jp"
  elseif string.find(str, "de") == 1 then
    return "ger"
  elseif string.find(str, "fr") == 1 then
    return "fr"
  elseif string.find(str, "ko") == 1 then
    return "kr"
  elseif string.find(str, "it") == 1 then
    return "it"
  elseif string.find(str, "pt") == 1 then
    return "po"
  elseif string.find(str, "es") == 1 then
    return "sp"
  elseif string.find(str, "ru") == 1 then
    return "ru"
  elseif string.find(str, "nl") == 1 then
    return "nl"
  elseif string.find(str, "tr") == 1 then
    return "tr"
  elseif string.find(str, "id") == 1 then
    return "ido"
  elseif string.find(str, "in") == 1 then
    return "ido"
  else
    return "en"
  end
end
function ext.isLangFR()
  local localLang = ext.GetGameLocale()
  if GameSettingData and GameSettingData.Save_Lang then
    localLang = GameSettingData.Save_Lang
  end
  if localLang == "fr" then
    return true
  end
  return false
end
function ext.changeFontSize(oldSize, fontName)
  return oldSize
end
function ext.AdjustFontBaseLine(baseline, fontName)
  return baseline
end
function ext.QueryAppConfig(category)
  local str2int = {
    AppleID = 0,
    AppStoreUrl = 1,
    Chartboost_AppID = 2,
    Chartboost_AppSignature = 3,
    PlayHaven_Token = 4,
    PlayHaven_Secret = 5,
    Tapjoy_AppID = 6,
    Tapjoy_SecretKey = 7,
    Account_Level20_Url = 26
  }
  local i = str2int[category]
  assert(i)
  return ext._QueryAppConfig(i)
end
ext.RegisteFlashClass("FlashDownloading_t")
function FlashDownloading_t:fscommand(cmd, arg)
  if cmd == "ERROR_OK" then
    AutoUpdate.errorstr = nil
    AutoUpdate.showerror = false
    if AutoUpdate.localAppVersion < AutoUpdate.lowestAppVersion then
      ext.http.openURL(AutoUpdate.appStoreUrl)
    end
  elseif cmd == "SEND_REPORT" then
    AutoUpdate.SendReport()
  elseif cmd == "CONFIRM_REPORT" then
    AutoUpdate.ConfirmSend()
  elseif "OPEN_CONTACT_US_PAGE" == cmd then
    AutoUpdate.errorstr = nil
    AutoUpdate.showerror = false
    AutoUpdate.openTap4FunContactLoginError()
  end
end
AutoUpdate = {
  isDeveloper = IPlatformExt.getConfigValue("ForceDev") == "True" or false,
  isLzmaSupport = true,
  isLzma3to1Support = true,
  isSupportSetProductList = true,
  isShareStorySupport = true,
  inited = false,
  currentState = nil,
  fileCorrupted = false,
  totleTaskNum = -1,
  finishedTaskNum = 0,
  currentTaskPercent = 0,
  totalTaskPercent = 0,
  isDownloadFinish = true,
  errorstr = nil,
  showerror = false,
  localVersion = 0,
  serverVersion = 0,
  localAppVersion = 0,
  serverAppVersion = 0,
  lowestAppVersion = 0,
  url = "",
  appStoreUrl = "",
  fakeFileDownloadPercent = 0,
  isDownloadingFakeFile = true,
  isProgressBarVisible = false,
  needUpdate = true,
  canStartUpdate = true,
  canEndUpdate = true,
  isSupportQuickStartGame = true,
  isQuickStartGame = false,
  isQuickStartGameVerOk = false,
  isQuickStartGameVerNtfRecv = false,
  lastRequestInfoRecord = {url = "", statusCode = 0},
  bundleIdentifierType = {
    BUNDLE_IDENTIFIER_NORMAL_WORLD = "com.tap4fun.galaxyempire2",
    BUNDLE_IDENTIFIER_NORMAL_CN = "com.tap4fun.galaxyempire2.chinese",
    BUNDLE_IDENTIFIER_NORMAL_TANGO = "com.tap4fun.galaxyempire2.tango",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID = "com.tap4fun.galaxyempire2_android",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID_DELUXE = "com.tap4fun.galaxyempire2_android_deluxe",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID_LOCAL = "com.tap4fun.galaxyempire2_android_local",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID_TANGO = "com.tap4fun.galaxyempire2_android_tango",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID_MYCARD = "com.tap4fun.galaxyempire2_android_mycard",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID_AMAZON = "com.tap4fun.galaxyempire2_android_amazon",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID_PLATFORM_QIHOO = "com.tap4fun.galaxyempire2_android.platform.qihoo360",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID_GLOBAL = "com.ts.galaxyempire2_android_global",
    BUNDLE_IDENTIFIER_NORMAL_ANDROID_SPACELANCER = "com.ts.spacelancer"
  },
  stateShowGameLogo = {},
  statePlayVideo = {},
  stateAfterVideo = {},
  stateCheckLocalFile = {},
  stateCheckConfig = {},
  stateCheckVersion = {},
  stateDownloadFilelist = {},
  stateDownloadNewFiles = {currentTask = nil},
  stateWrongAppVersion = {},
  stateEnterGame = {},
  stateQuickStartGame = {}
}
AutoUpdate.isAndroidDevice = ext.GetPlatform() == "Android"
AutoUpdate.isWPDevice = ext.GetPlatform() == "WinPhone"
function AutoUpdate.getTimeHourStr()
  local time = os.time()
  local timeStr = os.date("!%H", time)
  return timeStr or "Unknow"
end
function AutoUpdate:setState(state)
  local AutoUpdate = AutoUpdate
  AutoUpdate.currentState = state
  if AutoUpdate.currentState.GainFocus ~= nil then
    AutoUpdate.currentState:GainFocus()
  end
end
function AutoUpdate.LoadText()
  if AutoUpdate.gameloader ~= nil then
    return
  end
  AutoUpdate.gameloader = LuaLoader:new()
  local isRowData = false
  if ext.IsFileExist then
    if ext.IsFileExist("SETTING.raw") then
      print("Load SETTING.raw")
      local settingData = ext.LoadRawData("SETTING.raw")
      print(settingData)
      if settingData then
        local fun = loadstring(settingData)
        if fun then
          fun()
          isRowData = true
        end
      end
    end
    if not isRowData then
      print("Load SETTING.tfl")
      ext.dofile("SETTING.tfl")
      ext.dofile("GameUtils.tfl")
      if ext.SaveRawData and GameSettingData then
        ext.SaveRawData("SETTING.raw", GameUtils:formatSaveString(GameSettingData, "GameSettingData"))
      end
    end
  else
    print("ext.IsFileExist false, Load SETTING.tfl ")
    ext.dofile("SETTING.tfl")
  end
  if GameSettingData == nil then
    GameSettingData = {}
    GameSettingData.DebugVersion = "0.0.0"
    GameSettingData.FirstEnterGame = true
  end
  for k, v in pairs(GameSettingData) do
    if type(k) == "string" and string.find(k, "File:") == 1 then
      local fileName = string.sub(k, 6, -1)
      ext.UpdateAutoUpdateFile(fileName, v, 0, 0)
    end
  end
  local textLoaded = false
  if GameSettingData and GameSettingData.Save_Lang then
    local lang = GameSettingData.Save_Lang
    textLoaded = AutoUpdate.gameloader:LoadGameText(lang, {"menu"})
    print("load text from savefile")
  end
  if not textLoaded then
    local locale = ext.GetGameLocale()
    GameSettingData.Save_Lang = locale
    local lang = GameSettingData.Save_Lang
    textLoaded = AutoUpdate.gameloader:LoadGameText(lang, {"menu"})
  end
  if not textLoaded then
    AutoUpdate.gameloader:LoadGameText("en", {"menu"})
  end
end
function AutoUpdate.LoadFlash()
  if g_loadingBgInSplash ~= nil then
    return
  end
  g_loadingBgInSplash = FlashDownloading_t:new()
  g_loadingBgInSplash:Load("data2/downloading.tfs", ext.isLangFR())
  g_loadingBgInSplash:InvokeASCallback("_root", "showSplashTangoLogo", ext.GetBundleIdentifier() == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_TANGO or ext.GetBundleIdentifier() == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_TANGO)
  if GameSettingData and GameSettingData.Save_Lang then
    local lang = GameSettingData.Save_Lang
    if string.find(lang, "ru") == 1 then
      g_loadingBgInSplash:InvokeASCallback("_root", "setLanagerFrame", "ru")
    end
  end
  g_loadingBgInSplash:InvokeASCallback("_root", "setLoadingFrame", -1)
  g_loadingBgInSplash:InvokeASCallback("_root", "setTotalLoadingFrame", -1)
end
function AutoUpdate:SetStepDot(dot)
  if g_loadingBgInSplash then
    g_loadingBgInSplash:InvokeASCallback("_root", "SetStepDot", dot)
  end
end
function AutoUpdate.stateShowGameLogo:GainFocus()
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_ShowGameLogo", {COUNTRY = countryStr})
  end
end
function AutoUpdate.stateShowGameLogo:Update(dt)
  if os.time() - AutoUpdate.lastOStItime > 2 then
    AutoUpdate:setState(AutoUpdate.statePlayVideo)
  end
end
function AutoUpdate.statePlayVideo:GainFocus()
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_StartVideo", {COUNTRY = countryStr})
  end
  GameSettingData.FirstEnterGame = true
  if not ext.IsRestartGame() then
    if GameSettingData.FirstEnterGame then
      if ext.addFlurryEvent then
        local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
        ext.addFlurryEvent("Step_StartVideo_NotSkip", {COUNTRY = countryStr})
      end
      GameSettingData.FirstEnterGame = false
      if AutoUpdate.isAndroidDevice then
        ext.video.playMovie("video/cut_scene.mp4", true)
      else
        print("Play Video")
        ext.video.playMovie("video/cut_scene.mov", true)
      end
    else
      if ext.addFlurryEvent then
        local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
        ext.addFlurryEvent("Step_StartVideo_Skip_NotFirstLaunch", {COUNTRY = countryStr})
      end
      AutoUpdate:setState(AutoUpdate.stateAfterVideo)
    end
  elseif ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_StartVideo_Skip_Restart", {COUNTRY = countryStr})
  end
  dofile("config.tfl")
  AutoUpdate.debugVersion = config.debugVer
end
function AutoUpdate.statePlayVideo:Update(dt)
  if ext.IsRestartGame() or ext.video.isMovieFinished() then
    AutoUpdate:setState(AutoUpdate.stateAfterVideo)
  end
end
function AutoUpdate.stateAfterVideo:GainFocus()
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_EndVideo", {COUNTRY = countryStr})
  end
  dofile("config.tfl")
  AutoUpdate.debugVersion = config.debugVer
end
function AutoUpdate.stateAfterVideo:Update(dt)
  AutoUpdate:setState(AutoUpdate.stateCheckLocalFile)
end
function AutoUpdate.stateCheckLocalFile:CheckLocalFile()
  if AutoUpdate.isLzma3to1Support then
    if ext.IsArm64 and ext.IsArm64() then
      dofile("ofl_lzma_3to1_64.tfl")
    else
      dofile("ofl_lzma_3to1.tfl")
    end
  elseif ext.IsArm64 and ext.IsArm64() then
    dofile("ofl_lzma_64.tfl")
  else
    dofile("ofl_lzma.tfl")
  end
  AutoUpdate.localVersion = originfilelist.version
  if AutoUpdate.isLzma3to1Support then
    ext.dofile("lfl_lzma_3to1.tfl")
  else
    ext.dofile("lfl_lzma.tfl")
  end
  local _, _, AppVer1, AppVer2, AppVer3 = string.find(ext.GetAppVersion(), "(%d+).(%d+).(%d+)")
  AutoUpdate.localAppVersion = tonumber(AppVer3) + 100 * tonumber(AppVer2) + 10000 * tonumber(AppVer1)
  if localfilelist ~= nil and localfilelist.appversion ~= nil and localfilelist.appversion == AutoUpdate.localAppVersion then
    AutoUpdate.localVersion = localfilelist.version
    for k, v in pairs(localfilelist) do
      if type(v) == "table" then
        local originfile = originfilelist[k]
        if originfile == nil then
          originfilelist[k] = {
            version = 0,
            serverversion = 0,
            crc = ""
          }
          originfile = originfilelist[k]
        end
        if v.version >= originfile.version then
          originfile.version = v.version
          originfile.serverversion = v.serverversion
          originfile.crc = v.crc
          ext.UpdateAutoUpdateFile(k, v.crc, v.version, v.serverversion)
        end
      end
    end
  end
  localfilelist = nil
end
function AutoUpdate.stateCheckLocalFile:GainFocus()
  print("stateCheckLocalFile FocusGain")
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_CheckLocalFile", {COUNTRY = countryStr})
  end
  if GameSettingData.EnableMusic or GameSettingData.EnableMusic == nil then
    ext.audio.playBackgroundMusic("sound/GE2_LoadingAnimation.mp3")
  end
  AutoUpdate.stateCheckLocalFile:CheckLocalFile()
  for k, v in pairs(originfilelist) do
    if type(v) == "table" then
      local crc = ext.crc32.crc32(k)
      if crc ~= v.crc then
        print("File:" .. k .. " crc check failed! " .. crc .. "/" .. v.crc)
        v.version = 0
        AutoUpdate.fileCorrupted = true
      end
    end
  end
end
function AutoUpdate.stateCheckLocalFile:Update(dt)
  AutoUpdate:setState(AutoUpdate.stateCheckConfig)
end
function AutoUpdate.stateCheckConfig:GainFocus()
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_CheckConfig", {COUNTRY = countryStr})
  end
  local AutoUpdate = AutoUpdate
  AutoUpdate.ipAddrAttempedTime = 0
  AutoUpdate.isDownloadFinish = true
  ext.DisableIdleTimer(true)
  AutoUpdate:SetStepDot(".")
end
function AutoUpdate.stateCheckConfig:Update(dt)
  local destIpAddrPool = AutoUpdate.destIpAddrPool
  if AutoUpdate.isDownloadFinish == true then
    AutoUpdate.isDownloadFinish = false
    do
      local destIpAddr = destIpAddrPool[AutoUpdate.ipAddrAttempedTime + 1]
      print("AutoUpdate.ipAddrAttempedTime ", AutoUpdate.ipAddrAttempedTime)
      AutoUpdate.ipAddrAttempedTime = AutoUpdate.ipAddrAttempedTime + 1
      if not destIpAddr then
        local msg = AutoUpdate.gameloader:GetGameText("LC_MENU_NO_UPDATA_SERVER_MAILFORHELP")
        msg = string.format(msg, AutoUpdate.MailReceiver)
        AutoUpdate.errorstr = msg
        return
      end
      local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
      if ext.addFlurryEvent then
        ext.addFlurryEvent("Step_TryConnGateway_" .. AutoUpdate.ipAddrAttempedTime, {COUNTRY = countryStr, IPADD = destIpAddr})
      end
      local _url = "http://" .. destIpAddr .. "/servers/update_addr"
      if AutoUpdate.IfHTTPSEnabled() then
        _url = "https://" .. destIpAddr .. "/servers/update_addr"
      end
      if g_SaveNewFteData then
        ext.sendNewFteData("FTE_TryConnGateway_" .. AutoUpdate.ipAddrAttempedTime)
      end
      ext.http.request({
        _url,
        param = {background = 0},
        mode = "notencrypt",
        callback = function(statusCode, content, errstr)
          AutoUpdate.is_interstitial = 0
          AutoUpdate.is_show_apps = 0
          AutoUpdate.isDownloadFinish = true
          content = content or {}
          local extra_error = "Error:1_" .. 1 .. "_" .. statusCode
          if statusCode ~= 200 then
            if statusCode == 298 then
              AutoUpdate.isDownloadFinish = false
              ext.showAlert(content.error .. extra_error, 1)
              if ext.addFlurryEvent then
                ext.addFlurryEvent("Step_TryConnGateway_Failed_298", {COUNTRY = countryStr, IPADD = destIpAddr})
              end
            elseif AutoUpdate.ipAddrAttempedTime == #destIpAddrPool then
              AutoUpdate.ipAddrAttempedTime = 0
              local msg = AutoUpdate.gameloader:GetGameText("LC_MENU_NO_UPDATA_SERVER_MAILFORHELP")
              msg = string.format(msg, AutoUpdate.MailReceiver)
              AutoUpdate.errorstr = msg .. extra_error
              if ext.addFlurryEvent then
                ext.addFlurryEvent("Step_TryConnGateway_Failed_ALL", {COUNTRY = countryStr, IPADD = destIpAddr})
              end
            elseif ext.addFlurryEvent then
              ext.addFlurryEvent("Step_TryConnGateway_Failed_" .. statusCode, {COUNTRY = countryStr, IPADD = destIpAddr})
            end
          elseif content.error and content.error ~= "" then
            AutoUpdate.isDownloadFinish = false
            ext.showAlert(content.error .. extra_error, 1)
            if ext.addFlurryEvent then
              ext.addFlurryEvent("Step_TryConnGateway_Failed_200_Msg", {
                COUNTRY = countryStr,
                MSG = "error" .. statusCode,
                ERRORCONTENT = content.error or "unknow",
                IPADD = destIpAddr
              })
            end
          elseif not content.url then
            print("ERROR:AutoUpdate url is null")
            local msg = AutoUpdate.gameloader:GetGameText("LC_MENU_NO_UPDATA_SERVER_MAILFORHELP")
            msg = string.format(msg, AutoUpdate.MailReceiver)
            AutoUpdate.errorstr = msg .. extra_error
            if ext.addFlurryEvent then
              ext.addFlurryEvent("Step_TryConnGateway_Failed_200_URLIsNull", {COUNTRY = countryStr, IPADD = destIpAddr})
            end
          elseif not content.lowestv then
            local msg = AutoUpdate.gameloader:GetGameText("LC_MENU_NO_UPDATA_SERVER_MAILFORHELP")
            msg = string.format(msg, AutoUpdate.MailReceiver)
            AutoUpdate.errorstr = msg .. extra_error
            if ext.addFlurryEvent then
              ext.addFlurryEvent("Step_TryConnGateway_Failed_200_NoLowestv", {COUNTRY = countryStr, IPADD = destIpAddr})
            end
          else
            if ext.addFlurryEvent then
              ext.addFlurryEvent("Step_TryConnGateway_Success", {COUNTRY = countryStr})
            end
            if g_SaveNewFteData then
              ext.sendNewFteData("FTE_TryConnGateway_Success")
            end
            if AutoUpdate.gameGateway == "" then
              if 1 <= AutoUpdate.ipAddrAttempedTime and AutoUpdate.ipAddrAttempedTime <= #destIpAddrPool then
                local _url2 = "http://" .. AutoUpdate.destIpAddrPool[AutoUpdate.ipAddrAttempedTime] .. "/"
                if AutoUpdate.IfHTTPSEnabled() then
                  _url2 = "https://" .. AutoUpdate.destIpAddrPool[AutoUpdate.ipAddrAttempedTime] .. "/"
                end
                AutoUpdate.gameGateway = _url2
              else
                local _url3 = "http://" .. AutoUpdate.destIpAddrPool[1] .. "/"
                if AutoUpdate.IfHTTPSEnabled() then
                  _url3 = "https://" .. AutoUpdate.destIpAddrPool[1] .. "/"
                end
                AutoUpdate.gameGateway = _url3
              end
            end
            AutoUpdate.url = content.url .. "/"
            AutoUpdate.appStoreUrl = ext.QueryAppConfig("AppStoreUrl")
            print("AutoUpdate.appStoreUrl: ", AutoUpdate.appStoreUrl)
            if AutoUpdate.isDeveloper then
              if ext.addFlurryEvent then
                ext.addFlurryEvent("Step_EnterGame_Develop_Mode", {COUNTRY = countryStr})
              end
              AutoUpdate:setState(AutoUpdate.stateEnterGame)
            else
              local _, _, AppVer1, AppVer2, AppVer3 = string.find(content.lowestv, "(%d+).(%d+).(%d+)")
              AutoUpdate.lowestAppVersion = tonumber(AppVer3) + tonumber(AppVer2) * 100 + tonumber(AppVer1) * 10000
              print("lowestv:" .. tostring(content.lowestv))
              print("lowestAppVersion:" .. tostring(AutoUpdate.lowestAppVersion))
              if AutoUpdate.localAppVersion < AutoUpdate.lowestAppVersion then
                AutoUpdate:setState(AutoUpdate.stateWrongAppVersion)
              else
                AutoUpdate:setState(AutoUpdate.stateCheckVersion)
              end
            end
          end
        end
      })
    end
  end
end
function AutoUpdate.stateCheckVersion:GainFocus()
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_CheckVersion", {COUNTRY = countryStr})
  end
  print("stateCheckVersion FocusGain")
  local AutoUpdate = AutoUpdate
  AutoUpdate.totleTaskNum = -1
  AutoUpdate.isDownloadFinish = true
  AutoUpdate:SetStepDot("..")
end
function AutoUpdate.stateCheckVersion:Update(dt)
  if AutoUpdate.isDownloadFinish then
    AutoUpdate.isDownloadFinish = false
    local fullUrlOfVer = AutoUpdate.url .. "ver.txt"
    ext.http.request({
      fullUrlOfVer,
      mode = "notencrypt",
      callback = function(statusCode, content, errstr)
        local extra_error = "Error:1_" .. 2 .. "_" .. statusCode
        local AutoUpdate = AutoUpdate
        AutoUpdate.isDownloadFinish = true
        if errstr ~= nil then
          AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_CONNECT_ERROR") .. extra_error
          return
        end
        if statusCode ~= 200 then
          AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_CONNECT_ERROR") .. extra_error
          return
        end
        print("checkversion:", content)
        local _, _, filetag, serverVersion, AppVer1, AppVer2, AppVer3, debugVersion = string.find(content, [[
(%a+)
(%d+)
(%d+).(%d+).(%d+)
(%S+)]])
        if filetag ~= "tag" then
          AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_CONNECT_ERROR") .. extra_error
          return
        end
        AutoUpdate.serverVersion = tonumber(serverVersion)
        AutoUpdate.serverAppVersion = tonumber(AppVer3) + 100 * tonumber(AppVer2) + 10000 * tonumber(AppVer1)
        AutoUpdate.debugVersion = debugVersion
        print("localAppVersion ", AutoUpdate.localAppVersion)
        print("serverAppVersion ", AutoUpdate.serverAppVersion)
        print("debugVersion ", AutoUpdate.debugVersion)
        print("isCorrupted ", AutoUpdate.fileCorrupted)
        print("localVersion", AutoUpdate.localVersion)
        print("serverversion", AutoUpdate.serverVersion)
        if AutoUpdate.localAppVersion > AutoUpdate.serverAppVersion then
          AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_SERVER_UNDER_MAINTENANCE_CHAR") .. extra_error
          return
        elseif AutoUpdate.localVersion < AutoUpdate.serverVersion or AutoUpdate.fileCorrupted then
          AutoUpdate:setState(AutoUpdate.stateDownloadFilelist)
        else
          AutoUpdate:setState(AutoUpdate.stateEnterGame)
        end
      end
    })
  end
end
function AutoUpdate.stateWrongAppVersion:Update(dt)
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_WrongAppVersion", {COUNTRY = countryStr})
  end
  if not AutoUpdate.canStartUpdate then
    return
  end
  AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_NEW_VERSION")
end
function AutoUpdate.stateDownloadFilelist:GainFocus()
  print("stateDownloadFilelist FocusGain")
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_StartDownload", {COUNTRY = countryStr})
  end
  local AutoUpdate = AutoUpdate
  AutoUpdate.totleTaskNum = -1
  AutoUpdate.isDownloadFinish = true
  AutoUpdate.downloadStartSend = true
  AutoUpdate.downloadPercent20Send = true
  AutoUpdate.downloadPercent40Send = true
  AutoUpdate.downloadPercent50Send = true
  AutoUpdate.downloadPercent60Send = true
  AutoUpdate.downloadPercent80Send = true
  AutoUpdate.downloadPercent100Send = true
end
function AutoUpdate.stateDownloadFilelist:Update(dt)
  if not AutoUpdate.canStartUpdate then
    return
  end
  local AutoUpdate = AutoUpdate
  if AutoUpdate.totleTaskNum == -1 then
    if AutoUpdate.isDownloadFinish then
      AutoUpdate.isDownloadFinish = false
      local downloadFileListName
      if AutoUpdate.isLzma3to1Support then
        downloadFileListName = "ofl_lzma_3to1.tfl"
        if ext.IsArm64 and ext.IsArm64() then
          downloadFileListName = "ofl_lzma_3to1_64.tfl"
        end
      else
        downloadFileListName = "ofl_lzma.tfl"
        if ext.IsArm64 and ext.IsArm64() then
          downloadFileListName = "ofl_lzma_64.tfl"
        end
      end
      if ext.addFlurryEvent then
        local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
        ext.addFlurryEvent("DL_FileListStart", {
          COUNTRY = countryStr,
          FileListName = downloadFileListName,
          Time = AutoUpdate.getTimeHourStr()
        })
      end
      local localPathName = ""
      if AutoUpdate.isLzma3to1Support then
        localPathName = "fl_lzma_3to1.tfl"
      else
        localPathName = "fl_lzma.tfl"
      end
      ext.http.requestDownload({
        AutoUpdate.url .. downloadFileListName,
        method = "GET",
        localpath = localPathName,
        progressCallback = function(percent)
          print("fl_lzma_3to1.tfl percent:" .. percent)
        end,
        callback = function(statusCode, filename, errstr)
          local extra_error = "Error:1_" .. 3 .. "_" .. statusCode
          local AutoUpdate = AutoUpdate
          AutoUpdate.isDownloadFinish = true
          print("downloading filename ", filename)
          print("downloading error ", errstr)
          print("downloading statusCode", statusCode)
          if errstr ~= nil then
            if ext.addFlurryEvent then
              local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
              ext.addFlurryEvent("DL_FileListFailed_HaveErr", {
                Time = AutoUpdate.getTimeHourStr(),
                FileListName = filename,
                COUNTRY = countryStr,
                StateCode = "error_" .. statusCode,
                ErrorMsg = errstr or "unknow"
              })
            end
            AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_CONNECT_ERROR") .. extra_error
            return
          end
          if statusCode ~= 200 then
            if ext.addFlurryEvent then
              local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
              ext.addFlurryEvent("DL_FileListFailed_Not200", {
                Time = AutoUpdate.getTimeHourStr(),
                FileListName = filename,
                COUNTRY = countryStr,
                StateCode = "error_" .. statusCode,
                ErrorMsg = errstr or "unknow"
              })
            end
            AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_CONNECT_ERROR") .. extra_error
            return
          end
          if filename ~= nil then
            if originfilelist == nil then
              if ext.addFlurryEvent then
                local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
                ext.addFlurryEvent("DL_FileListFailed_OFLIsNull_1", {
                  Time = AutoUpdate.getTimeHourStr(),
                  FileListName = filename,
                  COUNTRY = countryStr,
                  StateCode = "error_" .. statusCode,
                  ErrorMsg = errstr or "unknow"
                })
              end
              AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_WRONG_OFL_FILE") .. extra_error
              return
            end
            local oflcopy = {}
            for k, v in pairs(originfilelist) do
              oflcopy[k] = v
            end
            originfilelist = nil
            local ret, err = dofile(filename)
            if err then
              local trimedFileName = string.match(filename, ".+/([^/]*%w+)$")
              AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_WRONG_UPDATE_FILE") .. trimedFileName .. extra_error
              if ext.addFlurryEvent then
                local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
                ext.addFlurryEvent("DL_FileListFailed_DofileErr", {
                  Time = AutoUpdate.getTimeHourStr(),
                  TrimedFileName = trimedFileName,
                  COUNTRY = countryStr,
                  StateCode = "error_" .. statusCode,
                  ErrorMsg = errstr or "unknow"
                })
              end
              return
            end
            if originfilelist == nil then
              if ext.addFlurryEvent then
                local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
                ext.addFlurryEvent("DL_FileListFailed_OFLIsNull_2", {
                  Time = AutoUpdate.getTimeHourStr(),
                  FileListName = filename,
                  COUNTRY = countryStr,
                  StateCode = "error_" .. statusCode,
                  ErrorMsg = errstr or "unknow"
                })
              end
              AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_WRONG_OFL_FILE") .. extra_error
              return
            end
            if ext.addFlurryEvent then
              local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
              ext.addFlurryEvent("DL_FileListSuccessed", {
                Time = AutoUpdate.getTimeHourStr(),
                FileListName = filename,
                COUNTRY = countryStr
              })
            end
            filelist = {}
            for k, v in pairs(originfilelist) do
              filelist[k] = v
            end
            originfilelist = oflcopy
            AutoUpdate.totleTaskNum = 0
            AutoUpdate.finishedTaskNum = 0
            local originfilelist = originfilelist
            for k, v in pairs(filelist) do
              if type(v) == "table" then
                local originfile = originfilelist[k]
                if originfile == nil then
                  originfilelist[k] = {
                    version = 0,
                    serverversion = 0,
                    crc = ""
                  }
                  originfile = originfilelist[k]
                end
                if originfile.crc ~= v.crc then
                  originfile.version = 0
                elseif originfile.crc == v.crc and originfile.crc ~= "" then
                  originfile.version = v.serverversion
                end
                originfile.crc = v.crc
                originfile.serverversion = v.serverversion
              end
            end
            for k, v in pairs(originfilelist) do
              if filelist[k] then
                if type(v) == "table" and v.serverversion > v.version then
                  AutoUpdate.totleTaskNum = AutoUpdate.totleTaskNum + 1
                end
              else
                originfilelist[k] = nil
              end
            end
            filelist = nil
            print("-----------totleTaskNum:" .. AutoUpdate.totleTaskNum)
          end
        end
      })
    end
  else
    AutoUpdate:setState(AutoUpdate.stateDownloadNewFiles)
  end
end
function AutoUpdate.stateDownloadNewFiles:GainFocus()
  print("AutoUpdate.stateDownloadNewFiles:GainFocus")
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_StartDownloadFile", {COUNTRY = countryStr})
  end
  AutoUpdate.isDownloadFinish = true
  AutoUpdate.finishedTaskNum = 0
  AutoUpdate.totalTaskPercent = 0
  AutoUpdate.fakeFileDownloadPercent = 0
  AutoUpdate.isDownloadingFakeFile = true
  AutoUpdate.needUpdate = true
  if AutoUpdate.totleTaskNum == 0 then
    AutoUpdate.isDownloadingFakeFile = false
  end
end
function AutoUpdate.stateDownloadNewFiles:Update(dt)
  if not AutoUpdate.isDownloadFinish then
    return
  end
  local preResName = AutoUpdate.gameloader:GetGameText("LC_MENU_AUTO_DOWNLOAD_RES")
  preResName = preResName or "Resource"
  for k, v in pairs(originfilelist) do
    if v and type(v) == "table" and v.serverversion > v.version then
      self.currentTask = v
      AutoUpdate.isDownloadFinish = false
      g_loadingBgInSplash:InvokeASCallback("_root", "setDownloadingFileName", preResName .. " " .. AutoUpdate.finishedTaskNum + 1)
      g_loadingBgInSplash:InvokeASCallback("_root", "setDownloadFilesInfo", AutoUpdate.finishedTaskNum, AutoUpdate.totleTaskNum)
      if ext.addFlurryEvent then
        local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
        ext.addFlurryEvent("DL_FileStart", {
          COUNTRY = countryStr,
          FileName = "" .. k
        })
      end
      ext.http.requestDownload({
        AutoUpdate.url .. k,
        localpath = k,
        progressCallback = function(percent)
          AutoUpdate.currentTaskPercent = percent
        end,
        callback = function(statusCode, filename, errstr)
          local AutoUpdate = AutoUpdate
          local stateDownloadNewFiles = AutoUpdate.stateDownloadNewFiles
          AutoUpdate.isDownloadFinish = true
          AutoUpdate.currentTaskPercent = 0
          local extra_error = "Error:1_" .. 4 .. "_" .. statusCode .. "_" .. (stateDownloadNewFiles.currentTask.crc or 0)
          if statusCode == 404 then
            local err = string.format("can not find file %s on the server", k)
            print("AutoUpdateError : ", err)
            self.currentTask.version = self.currentTask.serverversion
            AutoUpdate.finishedTaskNum = AutoUpdate.finishedTaskNum + 1
            if AutoUpdate.isLzma3to1Support then
              ext.SaveFileTable("lfl_lzma_3to1.tfl", AutoUpdate.localVersion, AutoUpdate.localAppVersion)
            else
              ext.SaveFileTable("lfl_lzma.tfl", AutoUpdate.localVersion, AutoUpdate.localAppVersion)
            end
            if ext.addFlurryEvent then
              local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
              ext.addFlurryEvent("DL_FileFailed_404", {
                Time = AutoUpdate.getTimeHourStr(),
                FileName = filename,
                COUNTRY = countryStr,
                StatusCode = "error_" .. statusCode
              })
            end
          else
            if errstr ~= nil then
              AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_CONNECT_ERROR") .. extra_error
              if ext.addFlurryEvent then
                local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
                ext.addFlurryEvent("DL_FileFailed_HaveErr", {
                  Time = AutoUpdate.getTimeHourStr(),
                  FileName = filename,
                  COUNTRY = countryStr,
                  StatusCode = "error_" .. statusCode,
                  ErrorMsg = errstr or "unknow"
                })
              end
              return
            end
            if statusCode ~= 200 then
              if ext.addFlurryEvent then
                local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
                ext.addFlurryEvent("DL_FileFailed_Not200", {
                  Time = AutoUpdate.getTimeHourStr(),
                  FileName = filename,
                  COUNTRY = countryStr,
                  StateCode = "error_" .. statusCode,
                  ErrorMsg = errstr or "unknow"
                })
              end
              AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_CONNECT_ERROR") .. extra_error
              return
            end
            if filename ~= nil then
              local crcresult = ext.crc32.crc32(filename)
              print("crcresult:" .. crcresult)
              local currentTask = stateDownloadNewFiles.currentTask
              if crcresult ~= currentTask.crc then
                local trimedFileName = string.match(filename, ".+/([^/]*%w+)$")
                AutoUpdate.errorstr = AutoUpdate.gameloader:GetGameText("LC_MENU_CRC_ERROR") .. trimedFileName .. extra_error
                if ext.addFlurryEvent then
                  ext.addFlurryEvent("DL_FileFailed_CRC", {
                    Time = AutoUpdate.getTimeHourStr(),
                    FileName = filename,
                    COUNTRY = countryStr,
                    StateCode = "error_" .. statusCode,
                    ErrorMsg = errstr or "unknow"
                  })
                end
                return
              else
                if ext.addFlurryEvent then
                  local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
                  ext.addFlurryEvent("DL_FileSuccessed", {
                    Time = AutoUpdate.getTimeHourStr(),
                    COUNTRY = countryStr,
                    FileName = filename
                  })
                end
                currentTask.version = currentTask.serverversion
                AutoUpdate.finishedTaskNum = AutoUpdate.finishedTaskNum + 1
                print("file:" .. filename .. " updated to version:" .. currentTask.serverversion)
                ext.UpdateAutoUpdateFile(filename, currentTask.crc, currentTask.version, currentTask.serverversion)
                if AutoUpdate.isLzma3to1Support then
                  ext.SaveFileTable("lfl_lzma_3to1.tfl", AutoUpdate.localVersion, AutoUpdate.localAppVersion)
                else
                  ext.SaveFileTable("lfl_lzma.tfl", AutoUpdate.localVersion, AutoUpdate.localAppVersion)
                end
              end
            end
          end
        end
      })
      return
    end
  end
  AutoUpdate.localVersion = AutoUpdate.serverVersion
  if AutoUpdate.isLzma3to1Support then
    ext.SaveFileTable("lfl_lzma_3to1.tfl", AutoUpdate.localVersion, AutoUpdate.localAppVersion)
  else
    ext.SaveFileTable("lfl_lzma.tfl", AutoUpdate.localVersion, AutoUpdate.localAppVersion)
  end
  AutoUpdate.fileCorrupted = false
  AutoUpdate:setState(AutoUpdate.stateEnterGame)
end
function AutoUpdate.stateEnterGame:GainFocus()
  print("stateEnterGame FocusGain")
  if ext.addFlurryEvent then
    local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
    ext.addFlurryEvent("Step_EnterGame", {COUNTRY = countryStr})
  end
  GameSettingData.DebugVersion = AutoUpdate.debugVersion
  AutoUpdate.canEndUpdate = true
  ext.DisableIdleTimer(false)
end
function AutoUpdate.stateEnterGame:Update(dt)
  if AutoUpdate.canEndUpdate and ext.video.isMovieFinished() then
    AutoUpdate.gameloader = nil
    if g_loadingBgInSplash then
      g_loadingBgInSplash:clearFonts()
    end
    dofile("GameEngineUpdate.tfl")
    if g_loadingBgInSplash then
      g_loadingBgInSplash = nil
    end
  end
end
function AutoUpdate.stateQuickStartGame:GainFocus()
  print("stateQuickStartGame FocusGain")
  AutoUpdate.stateCheckLocalFile:CheckLocalFile()
  AutoUpdate.LoadText()
  if GameSettingData.LastLogin and GameSettingData.LastLogin.ServerInfo and GameSettingData.LastLogin.ServerInfo and (GameSettingData.LastLogin.ServerInfo.ip and GameSettingData.LastLogin.ServerInfo.port or GameSettingData.LastLogin.ServerInfo.is_mix) and GameSettingData.LastLoginSuccess and (nil == GameSettingData.isNeedNormalStartGame or not GameSettingData.isNeedNormalStartGame) and GameSettingData.gameGateway then
    if ext.addFlurryEvent then
      local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
      ext.addFlurryEvent("Step_TryQuickLuanchSuccess", {COUNTRY = countryStr})
    end
    AutoUpdate.gameGateway = GameSettingData.gameGateway
    AutoUpdate.canEndUpdate = true
    ext.DisableIdleTimer(false)
    AutoUpdate.gameloader = nil
    if g_loadingBgInSplash then
      g_loadingBgInSplash:clearFonts()
    end
    dofile("GameEngineUpdate.tfl")
    if g_loadingBgInSplash then
      g_loadingBgInSplash = nil
    end
  else
    if ext.addFlurryEvent then
      local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
      ext.addFlurryEvent("Step_TryQuickLuanchFailed", {COUNTRY = countryStr})
    end
    AutoUpdate.isQuickStartGame = false
    AutoUpdate.LoadFlash()
    AutoUpdate:setState(AutoUpdate.stateAfterVideo)
    return
  end
end
function AutoUpdate.stateQuickStartGame:Update(dt)
  if not AutoUpdate.canEndUpdate or ext.video.isMovieFinished() then
  end
end
function AutoUpdate:SendAutoupdateTrack(stepnum)
  ext.http.request({
    self.gameGateway .. "servers/dlc_track",
    param = {step = stepnum},
    mode = "notencrypt",
    callback = function(statusCode, content, errstr)
    end
  })
end
function AutoUpdate:InitGameGateway()
  local bundleIdentifier = ext.GetBundleIdentifier()
  print("bundleIdentifier = ", bundleIdentifier)
  local DestIpAddrPool_json = IPlatformExt.getConfigValue("ExtDestIpAddrPool")
  local TestIpAddrPool_json = IPlatformExt.getConfigValue("TestIpAddrPool")
  if string.len(TestIpAddrPool_json) > 1 then
    AutoUpdate.destIpAddrPool = ext.json.parse(TestIpAddrPool_json)
  elseif string.len(DestIpAddrPool_json) > 1 then
    AutoUpdate.destIpAddrPool = ext.json.parse(DestIpAddrPool_json)
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_WORLD then
    if AutoUpdate.IfHTTPSEnabled() then
      AutoUpdate.destIpAddrPool = {
        "a.portal-platform.tap4fun.com/gl/url_get/online/ios_world/",
        "origin-oregon-01.portal-platform.tap4fun.com/gl/url_get/online/ios_world/",
        "a.portal-platform.t4f.cn/gl/url_get/online/ios_world/"
      }
    else
      AutoUpdate.destIpAddrPool = {
        "54.201.88.114",
        "ios.gl.gateway.tap4fun.com",
        "ios.gateway.gl.t4f.cn"
      }
    end
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_CN then
    if AutoUpdate.IfHTTPSEnabled() then
      AutoUpdate.destIpAddrPool = {
        "d.portal-platform.tap4fun.com/gl/url_get/online/ios_cn/",
        "d.portal-platform.t4f.cn/gl/url_get/online/ios_cn/"
      }
    else
      AutoUpdate.destIpAddrPool = {
        "112.124.28.96:80",
        "cn.gl.gateway.tap4fun.com",
        "cn.gateway.gl.t4f.cn"
      }
    end
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID or bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_MYCARD or bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_AMAZON or bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_GLOBAL or bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_SPACELANCER then
    if AutoUpdate.IfHTTPSEnabled() then
      AutoUpdate.destIpAddrPool = {
        "a.portal-platform.tap4fun.com/gl/url_get/online/an_world/",
        "origin-oregon-01.portal-platform.tap4fun.com/gl/url_get/online/an_world/",
        "a.portal-platform.t4f.cn/gl/url_get/online/an_world/"
      }
    else
      AutoUpdate.destIpAddrPool = {
        "54.200.10.68",
        "android.gl.gateway.tap4fun.com",
        "android.gateway.gl.t4f.cn"
      }
    end
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_DELUXE then
    if AutoUpdate.IfHTTPSEnabled() then
      AutoUpdate.destIpAddrPool = {
        "a.portal-platform.tap4fun.com/gl/url_get/online/an_deluxe_world/",
        "origin-oregon-01.portal-platform.tap4fun.com/gl/url_get/online/an_deluxe_world/",
        "a.portal-platform.t4f.cn/gl/url_get/online/an_deluxe_world/"
      }
    else
      AutoUpdate.destIpAddrPool = {
        "54.186.58.44",
        "deluxe.android.gateway.gl.tap4fun.com",
        "deluxe.android.gateway.gl.t4f.cn"
      }
    end
  elseif bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_LOCAL or bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_PLATFORM_QIHOO then
    if AutoUpdate.IfHTTPSEnabled() then
      AutoUpdate.destIpAddrPool = {
        "d.portal-platform.tap4fun.com/gl/url_get/online/an_cn/",
        "d.portal-platform.t4f.cn/gl/url_get/online/an_cn/"
      }
    else
      AutoUpdate.destIpAddrPool = {
        "115.29.13.113",
        "local.gl.gateway.tap4fun.com",
        "local.gateway.gl.t4f.cn"
      }
    end
  end
  AutoUpdate.gameGateway = ""
end
function AutoUpdate:Update(dt)
  if self.inited == false then
    self.inited = true
    AutoUpdate:InitGameGateway()
    local bundleIdentifier = ext.GetBundleIdentifier()
    local isQihooApp = bundleIdentifier == AutoUpdate.bundleIdentifierType.BUNDLE_IDENTIFIER_NORMAL_ANDROID_PLATFORM_QIHOO
    if AutoUpdate.isSupportQuickStartGame and not ext.IsRestartGame() and IPlatformExt.getConfigValue("UseExtLogin") ~= "True" and not isQihooApp then
      if ext.addFlurryEvent then
        local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
        ext.addFlurryEvent("Step_TryQuickLaunchStart", {COUNTRY = countryStr})
      end
      AutoUpdate.isQuickStartGame = true
      AutoUpdate:setState(AutoUpdate.stateQuickStartGame)
    else
      if ext.addFlurryEvent then
        local countryStr = ext.GetDeviceCountry and ext.GetDeviceCountry() or "unknow"
        ext.addFlurryEvent("Step_StandardLaunchStart", {COUNTRY = countryStr})
      end
      AutoUpdate.isQuickStartGame = false
      AutoUpdate.LoadText()
      AutoUpdate.LoadFlash()
      AutoUpdate:setState(AutoUpdate.stateAfterVideo)
    end
    return
  end
  if g_loadingBgInSplash ~= nil then
    if self.errorstr ~= nil then
      if not self.showerror then
        self.showerror = true
        AutoUpdate.needUpdate = true
        local textOk = AutoUpdate.gameloader:GetGameText("LC_MENU_TITLE_VERIFY") or "confirm"
        local textContactUs = AutoUpdate.gameloader:GetGameText("LC_MENU_LOCAL_TEXT_CONTACTUS") or "contact us"
        g_loadingBgInSplash:InvokeASCallback("_root", "showContactUs", self.errorstr, textOk, textContactUs)
      end
      return
    end
    if self.totleTaskNum > 0 then
      self.totalTaskPercent = math.floor(self.finishedTaskNum / self.totleTaskNum * 100) + 1 / self.totleTaskNum * self.currentTaskPercent
      g_loadingBgInSplash:InvokeASCallback("_root", "setLoadingFrame", math.floor(self.currentTaskPercent))
      g_loadingBgInSplash:InvokeASCallback("_root", "setTotalLoadingFrame", math.floor(self.totalTaskPercent))
      if self.downloadStartSend then
        self.downloadStartSend = false
        self:SendAutoupdateTrack(1)
      end
      if self.totalTaskPercent >= 20 and self.downloadPercent20Send then
        self.downloadPercent20Send = false
        self:SendAutoupdateTrack(2)
      end
      if self.totalTaskPercent >= 40 and self.downloadPercent40Send then
        self.downloadPercent40Send = false
        self:SendAutoupdateTrack(3)
      end
      if self.totalTaskPercent >= 50 and self.downloadPercent50Send then
        self.downloadPercent50Send = false
        self:SendAutoupdateTrack(4)
      end
      if self.totalTaskPercent >= 60 and self.downloadPercent60Send then
        self.downloadPercent60Send = false
        self:SendAutoupdateTrack(5)
      end
      if self.totalTaskPercent >= 80 and self.downloadPercent80Send then
        self.downloadPercent80Send = false
        self:SendAutoupdateTrack(6)
      end
      if self.totalTaskPercent >= 100 and self.downloadPercent100Send then
        self.downloadPercent100Send = false
        self:SendAutoupdateTrack(7)
      end
    end
  end
  AutoUpdate.currentState:Update(dt)
end
function AutoUpdate:IfHTTPSEnabled()
  local enabled = false
  if not AutoUpdate.isAndroidDevice then
    enabled = true
  end
  return enabled
end
function AutoUpdate:ConfirmSend()
  g_loadingBgInSplash:InvokeASCallback("_root", "showConfirmMenu", AutoUpdate.gameloader:GetGameText("LC_MENU_CONTRACT_ALERT"))
end
AutoUpdate.MailReceiver = "support@contact.tap4fun.com"
function AutoUpdate:SendReport()
  local version = ext.GetAppVersion()
  local openUDID = ext.GetIOSOpenUdid()
  local receiver = AutoUpdate.MailReceiver
  local catagory = "AutoUpdate Issue"
  local lang = ext.GetDeviceLanguage()
  if lang == "zh_Hans" then
    lang = "zh-Hans"
  elseif lang == "zh_Hant" then
    lang = "zh-Hant"
  end
  local channel = ext.GetChannel()
  local DeviceType = ext.GetDeviceName()
  local osVersion = ext.GetOSVersion()
  local version = ext.GetAppVersion()
  local account = ""
  if GameSettingData and GameSettingData.Tap4funAccount then
    account = GameSettingData.Tap4funAccount.passport
  end
  local preTitle = "DO NOT DELETE"
  if GameSettingData and GameSettingData.Save_Lang == "cn" then
    preTitle = "\232\175\183\229\139\191\229\136\160\233\153\164"
  end
  local UTCTime = os.date("%Y-%m-%d %H:%M:%S", os.time())
  local title = string.format("GalaxyLegend %s [%s]", catagory, ext.GetPlatform())
  local content = string.format([[
 
                                    
                                    
                                    
                                    
                                    
                                    
    ------ %s -------               
    UTC Time: %s                    
    Game: %s                        
    Version:%s                      
    Account:%s                      
    OpenUDID:%s                     
    Category:%s                     
    Language:%s                     
    Channel:%s                      
    Device Type:%s                  
    OS Version:%s                   
    CS:0			                
    ]], preTitle, UTCTime, "GalaxyLegend", version, account, openUDID, catagory, lang, channel, DeviceType, osVersion)
  if not ext.sysmail.SendMail(receiver, title, content) then
    g_loadingBgInSplash:InvokeASCallback("_root", "showContactErr", AutoUpdate.gameloader:GetGameText("LC_MENU_BIND_MAIL_CHAR"))
  else
    AutoUpdate.errorstr = nil
    AutoUpdate.showerror = false
    if AutoUpdate.localAppVersion < AutoUpdate.lowestAppVersion then
      ext.http.openURL(AutoUpdate.appStoreUrl)
    end
  end
end
function AutoUpdate.openTap4FunContactLoginError()
  local version = ext.GetAppVersion()
  local openudid = ext.GetIOSOpenUdid()
  local username = "1"
  if GameSettingData and GameSettingData.LastLogin and GameSettingData.LastLogin.PlayerInfo and GameSettingData.LastLogin.PlayerInfo.name then
    username = GameSettingData.LastLogin.PlayerInfo.name
  end
  local server = "1"
  if GameSettingData and GameSettingData.LastLogin and GameSettingData.LastLogin.ServerInfo and GameSettingData.LastLogin.ServerInfo.name then
    server = GameSettingData.LastLogin.ServerInfo.name
  end
  local theAppVersion
  if ext.GetPlatform() == "iOS" and AutoUpdate.GetLeftNumFromOSVersion(ext.GetOSVersion()) and AutoUpdate.GetLeftNumFromOSVersion(ext.GetOSVersion()) < 7 then
    ext.showAlert(AutoUpdate.gameloader:GetGameText("LC_MENU_IOS_VERSION_LOWER"), 1)
  else
    ext.http.openFAQ("-1", 0, 0, username, version, "updateError", ext.GetIOSOpenUdid(), server, "")
  end
end
function AutoUpdate.GetLeftNumFromOSVersion(ver)
  if ver == nil or ver == "" or string.sub(ver, 1, 1) == "." then
    return nil
  end
  local vers = AutoUpdate.string_split(ver, ".")
  if #vers == 0 then
    return nil
  end
  if type(tonumber(vers[1])) ~= "number" then
    return nil
  else
    return tonumber(vers[1])
  end
end
function AutoUpdate.string_split(str, sep)
  local r = {}
  for i in string.gmatch(str, string.format("[^%s]+", sep)) do
    table.insert(r, i)
  end
  return r
end
function Update(dt)
  AutoUpdate:Update(dt)
  if AutoUpdate.needUpdate and ext.video.isMovieFinished() and g_loadingBgInSplash ~= nil then
    g_loadingBgInSplash:Update(dt)
  end
end
function Render()
  if AutoUpdate.needUpdate and ext.video.isMovieFinished() and g_loadingBgInSplash ~= nil then
    g_loadingBgInSplash:Render()
  end
end
function OnTouchPressed(x, y)
  if AutoUpdate.needUpdate and ext.video.isMovieFinished() and g_loadingBgInSplash ~= nil then
    g_loadingBgInSplash:OnTouchPressed(x, y)
  end
end
function OnTouchMoved(x, y)
  if AutoUpdate.needUpdate and ext.video.isMovieFinished() and g_loadingBgInSplash ~= nil then
    g_loadingBgInSplash:OnTouchMoved(x, y)
  end
end
function OnTouchReleased(x, y)
  if AutoUpdate.needUpdate and ext.video.isMovieFinished() and g_loadingBgInSplash ~= nil then
    g_loadingBgInSplash:OnTouchReleased(x, y)
  end
end
function OnPause()
end
function OnResume()
end
function OnMultiTouchBegin(x1, y1, x2, y2)
end
function OnMultiTouchMove(x1, y1, x2, y2)
end
function OnMultiTouchEnd(x1, y1, x2, y2)
end
