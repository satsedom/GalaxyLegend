local GameUIStarSystemPort = LuaObjectManager:GetLuaObject("GameUIStarSystemPort")
local GameStateStarSystem = GameStateManager.GameStateStarSystem
function GameStateStarSystem:InitGameState()
end
function GameStateStarSystem:OnFocusGain(previousState)
  self.m_preState = previousState
  self:AddObject(GameUIStarSystemPort)
end
function GameStateStarSystem:OnFocusLost(newState)
  self.m_preState = nil
  self:EraseObject(GameUIStarSystemPort)
end
function GameStateStarSystem:GetPreState()
  return self.m_preState
end
