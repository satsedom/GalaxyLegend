local GameUILargeMap = LuaObjectManager:GetLuaObject("GameUILargeMap")
local GameStateLargeMap = GameStateManager.GameStateLargeMap
local GameObjectBattleReplay = LuaObjectManager:GetLuaObject("GameObjectBattleReplay")
local GameUIGlobalScreen = LuaObjectManager:GetLuaObject("GameUIGlobalScreen")
local GameStateBattlePlay = GameStateManager.GameStateBattlePlay
require("data1/Bit.tfl")
require("data1/GameLargeMapUILayer.tfl")
GameUILargeMap.UIList = {}
GameUILargeMap.UIGroupList = {}
GameUILargeMap.BGList = {}
GameUILargeMap.StarList = {}
GameUILargeMap.baseData = nil
GameUILargeMap.ShipList = {}
GameUILargeMap.PlayerData = {}
GameUILargeMap.MyPlayerData = nil
GameUILargeMap.pendingBlock = {}
GameUILargeMap.needUpdateBlock = {}
GameUILargeMap.CurShowUPRow = 0
GameUILargeMap.CurShowDownRow = 0
GameUILargeMap.CurShowLeftCol = 0
GameUILargeMap.CurShowRightCol = 0
function GameUILargeMap:OnInitGame()
  GameGlobalData:RegisterDataChangeCallback("battle_supply", self._ActionTimesChangeCallback)
end
function GameUILargeMap:OnAddToGameState()
  DebugOut("GameUILargeMap:OnAddToGameState")
  self:LoadFlashObject()
  self:GetFlashObject():InvokeASCallback("_root", "initFlashObj")
  GameUILargeMap:ReqMainMapData()
end
function GameUILargeMap:OnEraseFromGameState()
  self:UnloadFlashObject()
  GameUILargeMap.UIList = {}
  GameUILargeMap.UIGroupList = {}
  GameUILargeMap.BGList = {}
  GameUILargeMap.StarList = {}
  GameUILargeMap.baseData = nil
  GameUILargeMap.ShipList = {}
  GameUILargeMap.PlayerData = {}
  GameUILargeMap.MyPlayerData = nil
  GameUILargeMap.pendingBlock = {}
  GameUILargeMap.needUpdateBlock = {}
  GameUILargeMap.CurShowUPRow = 0
  GameUILargeMap.CurShowDownRow = 0
  GameUILargeMap.CurShowLeftCol = 0
  GameUILargeMap.CurShowRightCol = 0
  collectgarbage("collect")
end
function GameUILargeMap.LargeMapRouteNtf(content)
  if not GameUILargeMap:GetFlashObject() or GameUILargeMap.MyPlayerData == nil then
    return
  end
  for k, v in pairs(content.route_list) do
    if v.type > 0 and v.move_points[1] ~= nil then
      GameUILargeMap:AddShip(v.player_id, v.move_points[1])
      GameUILargeMap:AddMoveEvent(v.player_id, v.time, v.cur_time, v.move_points)
      GameUILargeMap:RemoveShipFormBlock(v.move_points[1], v.player_id)
    end
  end
end
function GameUILargeMap.LargeMapBlockNtf(content)
  DebugOut("GameUILargeMap.LargeMapBlockNtf")
  if not GameUILargeMap:GetFlashObject() or GameUILargeMap.MyPlayerData == nil then
    return
  end
  GameUILargeMap:GenerateBlockData(content)
end
function GameUILargeMap.LargeMapEventNtf(content)
  if not GameUILargeMap:GetFlashObject() or GameUILargeMap.MyPlayerData == nil then
    return
  end
  for k, v in ipairs(content.event_list) do
    GameUILargeMap:OnEventFunc(v)
  end
end
function GameUILargeMap:OnFSCommand(cmd, arg)
  if cmd == "close" then
    if GameStateLargeMap.m_preState ~= GameStateBattlePlay then
      GameStateManager:SetCurrentGameState(GameStateLargeMap.m_preState)
    else
      GameStateManager:SetCurrentGameState(GameStateManager.GameStateMainPlanet)
    end
  end
  if cmd == "updateUIMC" then
    if not GameUILargeMap.pendingBlock[tonumber(arg) + 1] then
      table.insert(GameUILargeMap.needUpdateBlock, tonumber(arg))
      GameUILargeMap.pendingBlock[tonumber(arg) + 1] = tonumber(arg)
    end
  elseif cmd == "updateBgMC" then
    local item = GameUILargeMap.BGList[tonumber(arg) + 1]
    self:GetFlashObject():InvokeASCallback("_root", "UpdateBgMC", item)
  elseif cmd == "TouchBlock" then
    local item = GameUILargeMap.UIList[tonumber(arg) + 1]
    DebugTable(item)
    if item.owner ~= GameUILargeMap.MyPlayerData.owner_code then
      GameUILargeMap:ReqRouteData(2, tonumber(arg))
    else
      GameUILargeMap:ReqRouteData(1, tonumber(arg))
    end
  elseif cmd == "ShipArrive" then
    local shipid, blockId = unpack(LuaUtils:string_split(arg, ","))
    local ship = GameUILargeMap.ShipList[tonumber(shipid)]
    if ship then
      ship.pos = tonumber(blockId)
    end
  elseif cmd == "refrshBlock" then
    local upRow, downRow, leftCol, rightCol = unpack(LuaUtils:string_split(arg, ","))
    GameUILargeMap:ReqUIBlockData(tonumber(upRow), tonumber(downRow), tonumber(leftCol), tonumber(rightCol), false)
    GameUILargeMap:RemoveUnUseUI(upRow, downRow, leftCol, rightCol)
  elseif cmd == "updateBlockPlayer" then
    local item = GameUILargeMap.PlayerData[tonumber(arg)]
    self:GetFlashObject():InvokeASCallback("_root", "UpdatePlayerItem", item)
  elseif cmd == "GetMoreExe" then
  elseif cmd == "LocalSelf" and GameUILargeMap.MyPlayerData then
    self:GetFlashObject():InvokeASCallback("_root", "SetCenterPosition", GameUILargeMap.MyPlayerData.pos)
  end
end
function GameUILargeMap.LargeMapBaseCallBack(msgType, content)
  if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.large_map_base_req.Code then
    if content.code ~= 0 then
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  elseif msgType == NetAPIList.large_map_base_ack.Code then
    GameUILargeMap.MyPlayerData = content.my_info
    GameUILargeMap:GenerateBaseData(content)
    GameUILargeMap:InitUI()
    GameUILargeMap:InitBg()
    GameUILargeMap:InitStar()
    GameUILargeMap:SetPositionForCenter()
    GameUILargeMap:UpdateBg()
    return true
  end
  return false
end
function GameUILargeMap:RemoveUnUseUI(upRow, downRow, leftCol, rightCol)
  GameUILargeMap.CurShowUPRow = 0
  GameUILargeMap.CurShowDownRow = 0
  GameUILargeMap.CurShowLeftCol = 0
  GameUILargeMap.CurShowRightCol = 0
  if GameUILargeMap.CurShowDownRow == 0 or GameUILargeMap.CurShowRightCol == 0 then
    return
  end
  if upRow < GameUILargeMap.CurShowUPRow then
    for i = downRow + 1, GameUILargeMap.CurShowDownRow do
      for j = GameUILargeMap.CurShowLeftCol, GameUILargeMap.CurShowRightCol do
        local id = (i - 1) * GameUILargeMap.baseData.col_count + j - 1
        GameUILargeMap.UIList[id + 1] = nil
      end
    end
  elseif upRow > GameUILargeMap.CurShowUPRow then
    for i = GameUILargeMap.CurShowUPRow, upRow - 1 do
      for j = GameUILargeMap.CurShowLeftCol, GameUILargeMap.CurShowRightCol do
        local id = (i - 1) * GameUILargeMap.baseData.col_count + j - 1
        GameUILargeMap.UIList[id + 1] = nil
      end
    end
  end
  if leftCol < GameUILargeMap.CurShowLeftCol then
    for i = GameUILargeMap.CurShowUPRow, GameUILargeMap.CurShowDownRow do
      for j = rightCol + 1, GameUILargeMap.CurShowRightCol do
        local id = (i - 1) * GameUILargeMap.baseData.col_count + j - 1
        GameUILargeMap.UIList[id + 1] = nil
      end
    end
  elseif leftCol > GameUILargeMap.CurShowLeftCol then
    for i = GameUILargeMap.CurShowUPRow, GameUILargeMap.CurShowDownRow do
      for j = GameUILargeMap.CurShowLeftCol, leftCol - 1 do
        local id = (i - 1) * GameUILargeMap.baseData.col_count + j - 1
        GameUILargeMap.UIList[id + 1] = nil
      end
    end
  end
  GameUILargeMap.CurShowUPRow = upRow
  GameUILargeMap.CurShowDownRow = downRow
  GameUILargeMap.CurShowLeftCol = leftCol
  GameUILargeMap.CurShowRightCol = rightCol
  collectgarbage("collect")
end
function GameUILargeMap:GenerateBaseData(content)
  local data = {}
  data.colCount = content.col_count
  data.rowCount = content.row_count
  data.centerId = content.center_id
  GameUILargeMap.baseData = data
  GameUILargeMap.BGList = content.bg_list
  for k, v in ipairs(content.nebula_list) do
    local item = {}
    item.frame = v.frame
    item.id = v.id
    item.px = v.pos_x
    item.py = v.pos_y
    GameUILargeMap.StarList[#GameUILargeMap.StarList + 1] = item
  end
end
function GameUILargeMap:InitUI()
  if self:GetFlashObject() and GameUILargeMap.baseData then
    self:GetFlashObject():InvokeASCallback("_root", "initUI", GameUILargeMap.baseData)
  end
end
function GameUILargeMap:UpdateUI()
  if self:GetFlashObject() and GameUILargeMap.baseData then
    self:GetFlashObject():InvokeASCallback("_root", "UpdateUI")
  end
end
function GameUILargeMap:InitBg()
  if self:GetFlashObject() and GameUILargeMap.BGList then
    self:GetFlashObject():InvokeASCallback("_root", "initBg")
  end
end
function GameUILargeMap:UpdateBg()
  if self:GetFlashObject() and GameUILargeMap.BGList then
    self:GetFlashObject():InvokeASCallback("_root", "UpdateBg")
  end
end
function GameUILargeMap:InitStar()
  if self:GetFlashObject() and GameUILargeMap.StarList then
    self:GetFlashObject():InvokeASCallback("_root", "initStar", GameUILargeMap.StarList)
  end
end
function GameUILargeMap:UpdateStar()
  if self:GetFlashObject() and GameUILargeMap.StarList then
    self:GetFlashObject():InvokeASCallback("_root", "UpdateStar")
  end
end
function GameUILargeMap:SetPositionForCenter()
  if GameUILargeMap.baseData then
    self:GetFlashObject():InvokeASCallback("_root", "SetCenterPosition", GameUILargeMap.baseData.centerId)
  end
end
function GameUILargeMap:AddShip(shipId, BlockId)
  if GameUILargeMap:GetFlashObject() then
    GameUILargeMap:GetFlashObject():InvokeASCallback("_root", "AddShip", shipId, BlockId)
  end
end
function GameUILargeMap:AddMoveEvent(shipId, useTime, curTime, points)
  if GameUILargeMap:GetFlashObject() then
    GameUILargeMap:GetFlashObject():InvokeASCallback("_root", "AddShipPath", shipId, useTime, curTime, points)
  end
end
function GameUILargeMap:UpdateMyLocal()
  if GameUILargeMap:GetFlashObject() then
    GameUILargeMap:GetFlashObject():InvokeASCallback("_root", "UpdateMyLocal", GameUILargeMap.MyPlayerData)
  end
end
function GameUILargeMap:RefreshUIMC(id)
  GameUILargeMap:OnFSCommand("updateUIMC", id)
end
function GameUILargeMap:RequestEnemyMatrix(blockId)
  local param = {block = blockId}
  NetMessageMgr:SendMsg(NetAPIList.large_map_enemy_req.Code, param, GameUILargeMap.enemyMatrixCallback, true, nil)
end
function GameUILargeMap.enemyMatrixCallback(msgType, content)
  if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.large_map_enemy_req.Code then
    if content.code ~= 0 then
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  elseif msgType == NetAPIList.large_map_enemy_ack.Code then
    GameStateManager.GameStateFormation.enemyForce = content.force
    GameStateManager.GameStateFormation.isNeedRequestMatrixInfo = false
    GameStateManager.GameStateFormation.enemyMatrixData = content.matrix
    GameStateManager:SetCurrentGameState(GameStateManager.GameStateFormation)
    return true
  end
  return false
end
function GameUILargeMap:onBattle(eventid)
  local function _callback(msgtype, content)
    if msgtype == NetAPIList.common_ack.Code and content.api == NetAPIList.large_map_battle_req.Code then
      if content.code ~= 0 then
        GameUIGlobalScreen:ShowAlert("error", content.code, nil)
      else
        local battleplay = GameStateManager.GameStateBattlePlay
        if GameObjectBattleReplay.GroupBattleReport and 0 < #GameObjectBattleReplay.GroupBattleReport then
          battleplay:InitBattle(battleplay.MODE_PLAY, GameObjectBattleReplay.GroupBattleReport[1].report)
          GameStateBattlePlay:RegisterOverCallback(function()
            GameStateManager:SetCurrentGameState(GameStateLargeMap)
          end, nil)
          GameStateBattlePlay.curBattleType = "largemap"
          GameStateManager:SetCurrentGameState(battleplay)
        end
      end
      return true
    end
    return false
  end
  local param = {}
  param.event_id = eventid
  NetMessageMgr:SendMsg(NetAPIList.large_map_battle_req.Code, param, _callback, true, nil)
end
function GameUILargeMap:ReqMainMapData()
  NetMessageMgr:SendMsg(NetAPIList.large_map_base_req.Code, nil, GameUILargeMap.LargeMapBaseCallBack, true, nil)
end
function GameUILargeMap.LargeMapBlockCallBack(msgType, content)
  if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.large_map_block_req.Code then
    if content.code ~= 0 then
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  elseif msgType == NetAPIList.large_map_block_ack.Code then
    GameUILargeMap:GenerateBlockData(content)
    GameUILargeMap:UpdateUI()
    return true
  end
  return false
end
function GameUILargeMap:GenerateBlockData(content)
  for k, v in pairs(content.block_list) do
    local OldItem = GameUILargeMap.UIList[v.id + 1]
    local needChangeColor = false
    local item = {}
    if OldItem then
      needChangeColor = v.owner ~= OldItem.owner
      item.sa = OldItem.sa
      item.sa1 = OldItem.sa1
      item.sb = OldItem.sb
      item.sb1 = OldItem.sb1
      item.sc = OldItem.sc
      item.sc1 = OldItem.sc1
      if needChangeColor and GameUILargeMap.UIGroupList[OldItem.owner] and GameUILargeMap.UIGroupList[OldItem.owner][OldItem.id] then
        GameUILargeMap.UIGroupList[OldItem.owner][OldItem.id] = nil
      end
    end
    item.id = v.id
    item.show = v.show
    item.type = v.type
    item.owner = v.show and v.owner or 0
    item.color = needChangeColor and 0 or GameUILargeMap:GetSameWonerColor(v.owner)
    item.isMy = v.owner == GameUILargeMap.MyPlayerData.owner_code
    item.status = v.status
    item.haveMe = false
    item.Players = {}
    for k1, v1 in pairs(v.player_list) do
      local player = {}
      player.playerId = v1.player_id
      player.shipFrame = v1.ship_frame
      player.BlockId = v.id
      item.Players[#item.Players + 1] = player
      if v1.player_id == GameUILargeMap.MyPlayerData.player_id then
        if GameUILargeMap.MyPlayerData.pos ~= item.id then
          GameUILargeMap.MyPlayerData.pos = item.id
        end
        item.haveMe = true
      end
    end
    GameUILargeMap.UIList[item.id + 1] = item
    if 0 < item.color then
      if GameUILargeMap.UIGroupList[v.owner] and LuaUtils:table_size(GameUILargeMap.UIGroupList[v.owner]) == 0 then
        GameUILargeMap.UIGroupList[v.owner][item.id] = item
      else
        GameUILargeMap.UIGroupList[v.owner] = {}
        GameUILargeMap.UIGroupList[v.owner][item.id] = item
      end
    end
    if (needChangeColor or OldItem and v.status ~= OldItem.status) and not GameUILargeMap.pendingBlock[tonumber(v.id) + 1] then
      table.insert(GameUILargeMap.needUpdateBlock, tonumber(v.id))
      GameUILargeMap.pendingBlock[tonumber(v.id) + 1] = tonumber(v.id)
    end
  end
end
function GameUILargeMap:OnPendingBlock()
  for k, v in pairs(GameUILargeMap.pendingBlock) do
    local item = GameUILargeMap.UIList[v + 1]
    if item then
      item.color = 0
    end
    GameUILargeMap:RefreshUIMC(v)
  end
end
function GameUILargeMap:UpdateUIByFrame()
  local upLimit = #GameUILargeMap.needUpdateBlock > 10 and 10 or #GameUILargeMap.needUpdateBlock
  for i = 1, upLimit do
    local id = table.remove(GameUILargeMap.needUpdateBlock, 1)
    local item = GameUILargeMap.UIList[id + 1]
    if item == nil then
      table.insert(GameUILargeMap.needUpdateBlock, id)
    else
      GameUILargeMap.pendingBlock[id + 1] = nil
      GameUILargeMap:SetUIBlockData(item)
      self:GetFlashObject():InvokeASCallback("_root", "UpdateUIMC", item)
    end
  end
end
function GameUILargeMap:ReqUIBlockData(upRow, downRow, leftCol, rightCol, forceWait)
  local param = {}
  param.col_left = leftCol
  param.col_right = rightCol
  param.row_up = upRow
  param.row_down = downRow
  NetMessageMgr:SendMsg(NetAPIList.large_map_block_req.Code, param, GameUILargeMap.LargeMapBlockCallBack, forceWait, nil)
end
function GameUILargeMap:SetUIBlockData(item)
  if (item.color == 0 or item.sa == nil or item.sb == nil or item.sc == nil or item.sa1 == nil or item.sb1 == nil or item.sc1 == nil) and 0 < item.owner then
    local color = 31
    local color2 = 0
    local dealColor = true
    local oddoff = (math.floor(item.id / GameUILargeMap.baseData.colCount) + 1) % 2 ~= 0 and 1 or 0
    local ouoff = (math.floor(item.id / GameUILargeMap.baseData.colCount) + 1) % 2 == 0 and 1 or 0
    item.color = GameUILargeMap:GetSameWonerColor(item.owner)
    if item.color > 0 then
      dealColor = false
    end
    local ca1, sa1, sca1 = GameUILargeMap:GetColorByIDCore(item.id, item.id - 1, item.owner, "sa")
    if dealColor and sca1 then
      color = ca1
      dealColor = false
    elseif dealColor then
      color2 = bit:_or(color2, ca1)
    end
    item.sa1 = sa1
    local cc1, sc1, scc1 = GameUILargeMap:GetColorByIDCore(item.id, item.id - GameUILargeMap.baseData.colCount - 1 + oddoff, item.owner, "sc")
    if dealColor and scc1 then
      color = cc1
      dealColor = false
    elseif dealColor then
      color2 = bit:_or(color2, cc1)
    end
    item.sc1 = sc1
    local cb1, sb1, scb1 = GameUILargeMap:GetColorByIDCore(item.id, item.id - GameUILargeMap.baseData.colCount + oddoff, item.owner, "sb")
    if dealColor and scb1 then
      color = cb1
      dealColor = false
    elseif dealColor then
      color2 = bit:_or(color2, cb1)
    end
    item.sb1 = sb1
    local ca, sa, sca = GameUILargeMap:GetColorByIDCore(item.id, item.id + 1, item.owner, "sa1")
    if dealColor and sca then
      color = ca
      dealColor = false
    elseif dealColor then
      color2 = bit:_or(color2, ca)
    end
    item.sa = sa
    local cb, sb, scb = GameUILargeMap:GetColorByIDCore(item.id, item.id + GameUILargeMap.baseData.colCount - ouoff, item.owner, "sb1")
    if dealColor and scb then
      color = cb
      dealColor = false
    elseif dealColor then
      color2 = bit:_or(color2, cb)
    end
    item.sb = sb
    local cc, sc, scc = GameUILargeMap:GetColorByIDCore(item.id, item.id + GameUILargeMap.baseData.colCount + 1 - ouoff, item.owner, "sc1")
    if dealColor and scc then
      color = cc
      dealColor = false
    elseif dealColor then
      color2 = bit:_or(color2, cc)
    end
    item.sc = sc
    if dealColor then
      color = bit:_xor(color, color2)
    end
    if item.color == 0 then
      item.color = GameUILargeMap:SelectColor(color)
    end
  elseif 0 >= item.owner then
    item.sa = false
    item.sa1 = false
    item.sb = false
    item.sb1 = false
    item.sc = false
    item.sc1 = false
    item.color = 1
  end
  if item.color > 0 and 0 < item.owner then
    if GameUILargeMap.UIGroupList[item.owner] and LuaUtils:table_size(GameUILargeMap.UIGroupList[item.owner]) == 0 then
      GameUILargeMap.UIGroupList[item.owner][item.id] = item
    else
      GameUILargeMap.UIGroupList[item.owner] = {}
      GameUILargeMap.UIGroupList[item.owner][item.id] = item
    end
  end
end
function GameUILargeMap:GetSameWonerColor(owner)
  for k, v in pairs(GameUILargeMap.UIGroupList[owner] or {}) do
    if v.color > 0 then
      return v.color
    end
  end
  return 0
end
function GameUILargeMap:SelectColor(color)
  local value = 0
  if 0 < bit:_and(color, 1) then
    value = 1
  elseif 0 < bit:_and(color, 2) then
    value = 2
  elseif 0 < bit:_and(color, 4) then
    value = 4
  elseif 0 < bit:_and(color, 8) then
    value = 8
  elseif 0 < bit:_and(color, 16) then
    value = 16
  end
  if value == 0 then
    DebugOut("dont find color:", color)
  end
  return value
end
function GameUILargeMap:GetColorByIDCore(srcid, id, owner, bNum)
  local color = 0
  local samecolor = false
  local showbar = owner > 0
  if id < 0 or id >= GameUILargeMap.baseData.colCount * GameUILargeMap.baseData.rowCount then
    return color, showbar, samecolor
  end
  if not GameUILargeMap:CheckBlockId(srcid, id) then
    return color, showbar, samecolor
  end
  local item = GameUILargeMap.UIList[tonumber(id) + 1]
  color = item and item.color or 0
  if item and item.owner == owner and item.color ~= 0 then
    samecolor = true
  end
  if item and item.owner == owner then
    showbar = false
    if item[bNum] ~= false then
      item[bNum] = false
      self:GetFlashObject():InvokeASCallback("_root", "UpdateUIMC", item)
    end
  elseif item and item[bNum] ~= true and 0 < item.owner then
    item[bNum] = true
    self:GetFlashObject():InvokeASCallback("_root", "UpdateUIMC", item)
  end
  return color, showbar, samecolor
end
function GameUILargeMap:CheckBlockId(srcid, id)
  if id < 0 then
    return false
  end
  local item = GameUILargeMap.UIList[id + 1]
  if item and item.show == false then
    return false
  end
  local ouoff = (math.floor(srcid / GameUILargeMap.baseData.colCount) + 1) % 2 == 0
  if srcid % GameUILargeMap.baseData.colCount == 0 then
    if ouoff then
      if math.abs(id - srcid) == GameUILargeMap.baseData.colCount or id - srcid == 1 then
        return true
      else
        return false
      end
    elseif srcid - id == 1 then
      return false
    else
      return true
    end
  elseif (srcid + 1) % GameUILargeMap.baseData.colCount == 0 then
    if ouoff then
      if id - srcid == 1 then
        return false
      else
        return true
      end
    elseif srcid - id == 1 or math.abs(id - srcid) == GameUILargeMap.baseData.colCount then
      return true
    else
      return false
    end
  end
  return true
end
function GameUILargeMap:GetNearBlockID(Item)
  local srcId = Item.id
  local oddoff = (math.floor(srcId / GameUILargeMap.baseData.colCount) + 1) % 2 ~= 0 and 1 or 0
  local ouoff = (math.floor(srcId / GameUILargeMap.baseData.colCount) + 1) % 2 == 0 and 1 or 0
  local list = {}
  local id1 = srcId + GameUILargeMap.baseData.colCount - ouoff
  local id2 = srcId + GameUILargeMap.baseData.colCount + 1 - ouoff
  local id3 = srcId - 1
  local id4 = srcId - GameUILargeMap.baseData.colCount - 1 + oddoff
  local id5 = srcId - GameUILargeMap.baseData.colCount + oddoff
  local id6 = srcId + 1
  if GameUILargeMap:CheckBlockId(srcId, id1) and id1 ~= (Item.father and Item.father.id or nil) then
    local item = {}
    item.id = id1
    item.father = Item
    table.insert(list, item)
  end
  if GameUILargeMap:CheckBlockId(srcId, id2) and id2 ~= (Item.father and Item.father.id or nil) then
    local item = {}
    item.id = id2
    item.father = Item
    table.insert(list, item)
  end
  if GameUILargeMap:CheckBlockId(srcId, id3) and id3 ~= (Item.father and Item.father.id or nil) then
    local item = {}
    item.id = id3
    item.father = Item
    table.insert(list, item)
  end
  if GameUILargeMap:CheckBlockId(srcId, id4) and id4 ~= (Item.father and Item.father.id or nil) then
    local item = {}
    item.id = id4
    item.father = Item
    table.insert(list, item)
  end
  if GameUILargeMap:CheckBlockId(srcId, id5) and id5 ~= (Item.father and Item.father.id or nil) then
    local item = {}
    item.id = id5
    item.father = Item
    table.insert(list, item)
  end
  if GameUILargeMap:CheckBlockId(srcId, id6) and id6 ~= (Item.father and Item.father.id or nil) then
    local item = {}
    item.id = id6
    item.father = Item
    table.insert(list, item)
  end
  return list
end
function GameUILargeMap:GetSearchStartItemPath(Item, pathList)
  if Item.father then
    table.insert(pathList, 1, Item.father.id)
    GameUILargeMap:GetSearchStartItemPath(Item.father, pathList)
  else
    return
  end
end
function GameUILargeMap:GetSearchEndItemPath(Item, pathList)
  if Item.father then
    DebugTable(pathList)
    table.insert(pathList, Item.father.id)
    GameUILargeMap:GetSearchEndItemPath(Item.father, pathList)
  else
    return
  end
end
function GameUILargeMap:SearchPathPoints(srcId, dstId)
  local pointList = {}
  local srcList = {}
  local dstList = {}
  local itemsrc = {}
  itemsrc.id = srcId
  itemsrc.father = nil
  local itemdst = {}
  itemdst.id = dstId
  itemdst.father = nil
  srcList[srcId] = itemsrc
  dstList[dstId] = itemdst
  local findItem = false
  local findID
  while true do
    local newSrcList = {}
    local newDstList = {}
    for k, v in pairs(srcList) do
      local item = v
      local nearlist = GameUILargeMap:GetNearBlockID(item)
      for k1, v1 in pairs(nearlist) do
        if srcList[v1.id] == nil and newSrcList[v1.id] == nil then
          newSrcList[v1.id] = v1
          if dstList[v1.id] then
            findItem = true
            findID = v1.id
            break
          end
        end
      end
      if findItem then
        break
      end
    end
    srcList = newSrcList
    if findItem then
      break
    end
    for k, v in pairs(dstList) do
      local item = v
      local nearlist = GameUILargeMap:GetNearBlockID(item)
      for k1, v1 in pairs(nearlist) do
        if dstList[v1.id] == nil and newDstList[v1.id] == nil then
          newDstList[v1.id] = v1
          if srcList[v1.id] then
            findItem = true
            findID = v1.id
            break
          end
        end
      end
      if findItem then
        break
      end
    end
    dstList = newDstList
    if findItem then
      break
    end
  end
  if findID then
    DebugOut(findID)
    DebugTable(srcList[findID])
    DebugTable(dstList[findID])
    GameUILargeMap:GetSearchStartItemPath(srcList[findID], pointList)
    table.insert(pointList, findID)
    GameUILargeMap:GetSearchEndItemPath(dstList[findID], pointList)
  end
  DebugTable(pointList)
  return pointList
end
function GameUILargeMap:ReqRouteData(ty, targetId)
  local param = {}
  param.target_id = targetId
  param.type = ty
  NetMessageMgr:SendMsg(NetAPIList.large_map_route_req.Code, param, GameUILargeMap.LargeMapRouteCallBack, true, nil)
end
function GameUILargeMap.LargeMapRouteCallBack(msgType, content)
  if msgType == NetAPIList.common_ack.Code and content.api == NetAPIList.large_map_route_req.Code then
    if content.code ~= 0 then
      GameUIGlobalScreen:ShowAlert("error", content.code, nil)
    end
    return true
  elseif msgType == NetAPIList.large_map_route_ack.Code then
    local item = GameUILargeMap.UIList[content.move_points[#content.move_points] + 1]
    if item.owner ~= GameUILargeMap.MyPlayerData.owner_code then
      item.status = 2
      GameUILargeMap:RefreshUIMC(item.id)
    end
    GameUILargeMap:GenerateRouteData(content)
    return true
  end
  return false
end
function GameUILargeMap:GenerateRouteData(content)
  if content.type > 0 and 0 < #content.move_points then
    GameUILargeMap:AddShip(content.player_id, content.move_points[1])
    GameUILargeMap:AddMoveEvent(content.player_id, content.time, content.cur_time, content.move_points)
    GameUILargeMap:RemoveShipFormBlock(content.move_points[1], content.player_id)
  end
end
function GameUILargeMap:OnEventFunc(event)
  if event.event_type == 1 then
  elseif event.event_type == 2 then
    GameUILargeMap:onBattle(event.event_id)
  elseif event.event_type == 3 then
  end
end
function GameUILargeMap:RemoveShipFormBlock(id, playerID)
  local item = GameUILargeMap.UIList[tonumber(id) + 1]
  if item then
    for k, v in pairs(item.Players) do
      if v.playerId == playerID then
        table.remove(item.Players, k)
        break
      end
    end
    GameUILargeMap:RefreshUIMC(id)
  end
end
function GameUILargeMap:Update(dt)
  local flashObj = GameUILargeMap:GetFlashObject()
  if flashObj then
    flashObj:Update(dt)
    flashObj:InvokeASCallback("_root", "OnUpdate", dt)
    GameUILargeMap:UpdateUIByFrame()
  end
end
function GameUILargeMap.serverCallback(msgtype, content)
  if msgtype == NetAPIList.common_ack.Code then
    return true
  end
  if msgtype == NetAPIList.supply_info_ack.Code then
    return true
  end
  return false
end
if AutoUpdate.isAndroidDevice then
  function GameUILargeMap.OnAndroidBack()
    GameUILargeMap:OnFSCommand("close")
  end
end
