local Monsters = GameData.ChapterMonsterAct8.Monsters
Monsters[801001] = {
  ID = 801001,
  durability = 86266,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801002] = {
  ID = 801002,
  durability = 69073,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801003] = {
  ID = 801003,
  durability = 11762,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801004] = {
  ID = 801004,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801005] = {
  ID = 801005,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801006] = {
  ID = 801006,
  durability = 86266,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801007] = {
  ID = 801007,
  durability = 69073,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801008] = {
  ID = 801008,
  durability = 11762,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801009] = {
  ID = 801009,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801010] = {
  ID = 801010,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801011] = {
  ID = 801011,
  durability = 86266,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[801012] = {
  ID = 801012,
  durability = 69073,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801013] = {
  ID = 801013,
  durability = 11762,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801014] = {
  ID = 801014,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[801015] = {
  ID = 801015,
  durability = 34687,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801016] = {
  ID = 801016,
  durability = 129249,
  Avatar = "head45",
  Ship = "ship39"
}
Monsters[801017] = {
  ID = 801017,
  durability = 69072,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801018] = {
  ID = 801018,
  durability = 11762,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801019] = {
  ID = 801019,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801020] = {
  ID = 801020,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801021] = {
  ID = 801021,
  durability = 86265,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801022] = {
  ID = 801022,
  durability = 69072,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801023] = {
  ID = 801023,
  durability = 11762,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801024] = {
  ID = 801024,
  durability = 34687,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801025] = {
  ID = 801025,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801026] = {
  ID = 801026,
  durability = 86266,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801027] = {
  ID = 801027,
  durability = 69072,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801028] = {
  ID = 801028,
  durability = 11762,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801029] = {
  ID = 801029,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801030] = {
  ID = 801030,
  durability = 34686,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801031] = {
  ID = 801031,
  durability = 92409,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801032] = {
  ID = 801032,
  durability = 73987,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801033] = {
  ID = 801033,
  durability = 12581,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801034] = {
  ID = 801034,
  durability = 37143,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[801035] = {
  ID = 801035,
  durability = 37143,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801036] = {
  ID = 801036,
  durability = 138468,
  Avatar = "head45",
  Ship = "ship39"
}
Monsters[801037] = {
  ID = 801037,
  durability = 73989,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[801038] = {
  ID = 801038,
  durability = 12581,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801039] = {
  ID = 801039,
  durability = 37143,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[801040] = {
  ID = 801040,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802001] = {
  ID = 802001,
  durability = 92410,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802002] = {
  ID = 802002,
  durability = 73988,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802003] = {
  ID = 802003,
  durability = 12581,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802004] = {
  ID = 802004,
  durability = 37143,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802005] = {
  ID = 802005,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802006] = {
  ID = 802006,
  durability = 92412,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802007] = {
  ID = 802007,
  durability = 73988,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802008] = {
  ID = 802008,
  durability = 12581,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802009] = {
  ID = 802009,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802010] = {
  ID = 802010,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802011] = {
  ID = 802011,
  durability = 92410,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802012] = {
  ID = 802012,
  durability = 73987,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802013] = {
  ID = 802013,
  durability = 12581,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802014] = {
  ID = 802014,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802015] = {
  ID = 802015,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802016] = {
  ID = 802016,
  durability = 138468,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[802017] = {
  ID = 802017,
  durability = 73989,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[802018] = {
  ID = 802018,
  durability = 12581,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802019] = {
  ID = 802019,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802020] = {
  ID = 802020,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[802021] = {
  ID = 802021,
  durability = 92409,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802022] = {
  ID = 802022,
  durability = 73988,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802023] = {
  ID = 802023,
  durability = 12581,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802024] = {
  ID = 802024,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802025] = {
  ID = 802025,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802026] = {
  ID = 802026,
  durability = 92410,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802027] = {
  ID = 802027,
  durability = 73988,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802028] = {
  ID = 802028,
  durability = 12581,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802029] = {
  ID = 802029,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802030] = {
  ID = 802030,
  durability = 37144,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802031] = {
  ID = 802031,
  durability = 98554,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802032] = {
  ID = 802032,
  durability = 78903,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802033] = {
  ID = 802033,
  durability = 13400,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802034] = {
  ID = 802034,
  durability = 39601,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802035] = {
  ID = 802035,
  durability = 39602,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802036] = {
  ID = 802036,
  durability = 147681,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[802037] = {
  ID = 802037,
  durability = 78904,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802038] = {
  ID = 802038,
  durability = 13400,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802039] = {
  ID = 802039,
  durability = 39601,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[802040] = {
  ID = 802040,
  durability = 39601,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[803001] = {
  ID = 803001,
  durability = 62527,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803002] = {
  ID = 803002,
  durability = 47462,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803003] = {
  ID = 803003,
  durability = 13400,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[803004] = {
  ID = 803004,
  durability = 19951,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803005] = {
  ID = 803005,
  durability = 26501,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803006] = {
  ID = 803006,
  durability = 62526,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803007] = {
  ID = 803007,
  durability = 47461,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803008] = {
  ID = 803008,
  durability = 13400,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803009] = {
  ID = 803009,
  durability = 19950,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803010] = {
  ID = 803010,
  durability = 26501,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803011] = {
  ID = 803011,
  durability = 62528,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803012] = {
  ID = 803012,
  durability = 47461,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803013] = {
  ID = 803013,
  durability = 13400,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803014] = {
  ID = 803014,
  durability = 19950,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803015] = {
  ID = 803015,
  durability = 26500,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803016] = {
  ID = 803016,
  durability = 93641,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[803017] = {
  ID = 803017,
  durability = 47462,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803018] = {
  ID = 803018,
  durability = 13400,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803019] = {
  ID = 803019,
  durability = 19950,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803020] = {
  ID = 803020,
  durability = 26501,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803021] = {
  ID = 803021,
  durability = 62527,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803022] = {
  ID = 803022,
  durability = 47462,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803023] = {
  ID = 803023,
  durability = 13400,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[803024] = {
  ID = 803024,
  durability = 19950,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803025] = {
  ID = 803025,
  durability = 26501,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803026] = {
  ID = 803026,
  durability = 62527,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[803027] = {
  ID = 803027,
  durability = 47462,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803028] = {
  ID = 803028,
  durability = 13400,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803029] = {
  ID = 803029,
  durability = 19951,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803030] = {
  ID = 803030,
  durability = 26501,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803031] = {
  ID = 803031,
  durability = 66419,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803032] = {
  ID = 803032,
  durability = 50411,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803033] = {
  ID = 803033,
  durability = 14219,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803034] = {
  ID = 803034,
  durability = 21179,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803035] = {
  ID = 803035,
  durability = 28139,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803036] = {
  ID = 803036,
  durability = 99478,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[803037] = {
  ID = 803037,
  durability = 50411,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803038] = {
  ID = 803038,
  durability = 14219,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803039] = {
  ID = 803039,
  durability = 21179,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[803040] = {
  ID = 803040,
  durability = 28139,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[804001] = {
  ID = 804001,
  durability = 62938,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804002] = {
  ID = 804002,
  durability = 47626,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804003] = {
  ID = 804003,
  durability = 14219,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804004] = {
  ID = 804004,
  durability = 21180,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804005] = {
  ID = 804005,
  durability = 28139,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804006] = {
  ID = 804006,
  durability = 62939,
  Avatar = "head36",
  Ship = "ship37"
}
Monsters[804007] = {
  ID = 804007,
  durability = 47628,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804008] = {
  ID = 804008,
  durability = 14219,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804009] = {
  ID = 804009,
  durability = 21180,
  Avatar = "head36",
  Ship = "ship37"
}
Monsters[804010] = {
  ID = 804010,
  durability = 28139,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804011] = {
  ID = 804011,
  durability = 62940,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804012] = {
  ID = 804012,
  durability = 47627,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804013] = {
  ID = 804013,
  durability = 14220,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804014] = {
  ID = 804014,
  durability = 21180,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804015] = {
  ID = 804015,
  durability = 28139,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804016] = {
  ID = 804016,
  durability = 94258,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804017] = {
  ID = 804017,
  durability = 47627,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804018] = {
  ID = 804018,
  durability = 14219,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804019] = {
  ID = 804019,
  durability = 21180,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804020] = {
  ID = 804020,
  durability = 28139,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804021] = {
  ID = 804021,
  durability = 62938,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804022] = {
  ID = 804022,
  durability = 47627,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804023] = {
  ID = 804023,
  durability = 14219,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804024] = {
  ID = 804024,
  durability = 21179,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804025] = {
  ID = 804025,
  durability = 28139,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804026] = {
  ID = 804026,
  durability = 62938,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804027] = {
  ID = 804027,
  durability = 47627,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804028] = {
  ID = 804028,
  durability = 14219,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804029] = {
  ID = 804029,
  durability = 21179,
  Avatar = "head36",
  Ship = "ship37"
}
Monsters[804030] = {
  ID = 804030,
  durability = 28140,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804031] = {
  ID = 804031,
  durability = 66626,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804032] = {
  ID = 804032,
  durability = 50412,
  Avatar = "head36",
  Ship = "ship37"
}
Monsters[804033] = {
  ID = 804033,
  durability = 15039,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804034] = {
  ID = 804034,
  durability = 22408,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804035] = {
  ID = 804035,
  durability = 29778,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804036] = {
  ID = 804036,
  durability = 99788,
  Avatar = "head42",
  Ship = "ship39"
}
Monsters[804037] = {
  ID = 804037,
  durability = 50412,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804038] = {
  ID = 804038,
  durability = 15039,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804039] = {
  ID = 804039,
  durability = 22408,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[804040] = {
  ID = 804040,
  durability = 29778,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[805001] = {
  ID = 805001,
  durability = 66625,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805002] = {
  ID = 805002,
  durability = 50412,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805003] = {
  ID = 805003,
  durability = 15039,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805004] = {
  ID = 805004,
  durability = 22408,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805005] = {
  ID = 805005,
  durability = 29778,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805006] = {
  ID = 805006,
  durability = 66626,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805007] = {
  ID = 805007,
  durability = 50412,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805008] = {
  ID = 805008,
  durability = 15039,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805009] = {
  ID = 805009,
  durability = 22408,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805010] = {
  ID = 805010,
  durability = 29777,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805011] = {
  ID = 805011,
  durability = 66624,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805012] = {
  ID = 805012,
  durability = 50413,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[805013] = {
  ID = 805013,
  durability = 15039,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805014] = {
  ID = 805014,
  durability = 22408,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805015] = {
  ID = 805015,
  durability = 29778,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[805016] = {
  ID = 805016,
  durability = 99786,
  Avatar = "head36",
  Ship = "ship39"
}
Monsters[805017] = {
  ID = 805017,
  durability = 50413,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805018] = {
  ID = 805018,
  durability = 15039,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805019] = {
  ID = 805019,
  durability = 22408,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805020] = {
  ID = 805020,
  durability = 29778,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805021] = {
  ID = 805021,
  durability = 66625,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805022] = {
  ID = 805022,
  durability = 50412,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805023] = {
  ID = 805023,
  durability = 15038,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805024] = {
  ID = 805024,
  durability = 22408,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805025] = {
  ID = 805025,
  durability = 29778,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805026] = {
  ID = 805026,
  durability = 66626,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805027] = {
  ID = 805027,
  durability = 50413,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805028] = {
  ID = 805028,
  durability = 15039,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805029] = {
  ID = 805029,
  durability = 22408,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805030] = {
  ID = 805030,
  durability = 29778,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805031] = {
  ID = 805031,
  durability = 70311,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805032] = {
  ID = 805032,
  durability = 53197,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805033] = {
  ID = 805033,
  durability = 15858,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805034] = {
  ID = 805034,
  durability = 23637,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805035] = {
  ID = 805035,
  durability = 31416,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[805036] = {
  ID = 805036,
  durability = 105319,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[805037] = {
  ID = 805037,
  durability = 53197,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805038] = {
  ID = 805038,
  durability = 15858,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[805039] = {
  ID = 805039,
  durability = 23637,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[805040] = {
  ID = 805040,
  durability = 31416,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[806001] = {
  ID = 806001,
  durability = 70311,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806002] = {
  ID = 806002,
  durability = 53198,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806003] = {
  ID = 806003,
  durability = 15858,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806004] = {
  ID = 806004,
  durability = 23637,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806005] = {
  ID = 806005,
  durability = 31416,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806006] = {
  ID = 806006,
  durability = 70312,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806007] = {
  ID = 806007,
  durability = 53197,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806008] = {
  ID = 806008,
  durability = 15858,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806009] = {
  ID = 806009,
  durability = 23637,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806010] = {
  ID = 806010,
  durability = 31416,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806011] = {
  ID = 806011,
  durability = 70311,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806012] = {
  ID = 806012,
  durability = 53197,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806013] = {
  ID = 806013,
  durability = 15858,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806014] = {
  ID = 806014,
  durability = 23637,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806015] = {
  ID = 806015,
  durability = 31416,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806016] = {
  ID = 806016,
  durability = 105316,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806017] = {
  ID = 806017,
  durability = 53197,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806018] = {
  ID = 806018,
  durability = 15858,
  Avatar = "head37",
  Ship = "ship37"
}
Monsters[806019] = {
  ID = 806019,
  durability = 23637,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806020] = {
  ID = 806020,
  durability = 31416,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806021] = {
  ID = 806021,
  durability = 70311,
  Avatar = "head37",
  Ship = "ship37"
}
Monsters[806022] = {
  ID = 806022,
  durability = 53198,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806023] = {
  ID = 806023,
  durability = 15858,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806024] = {
  ID = 806024,
  durability = 23637,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806025] = {
  ID = 806025,
  durability = 31416,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806026] = {
  ID = 806026,
  durability = 70311,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806027] = {
  ID = 806027,
  durability = 53197,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806028] = {
  ID = 806028,
  durability = 15858,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806029] = {
  ID = 806029,
  durability = 23637,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806030] = {
  ID = 806030,
  durability = 31416,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806031] = {
  ID = 806031,
  durability = 73998,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806032] = {
  ID = 806032,
  durability = 55983,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806033] = {
  ID = 806033,
  durability = 16677,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806034] = {
  ID = 806034,
  durability = 24866,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806035] = {
  ID = 806035,
  durability = 33055,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806036] = {
  ID = 806036,
  durability = 110848,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806037] = {
  ID = 806037,
  durability = 55983,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806038] = {
  ID = 806038,
  durability = 16677,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806039] = {
  ID = 806039,
  durability = 24866,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[806040] = {
  ID = 806040,
  durability = 33054,
  Avatar = "head37",
  Ship = "ship39"
}
Monsters[807001] = {
  ID = 807001,
  durability = 73998,
  Avatar = "head44",
  Ship = "ship37"
}
Monsters[807002] = {
  ID = 807002,
  durability = 55982,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807003] = {
  ID = 807003,
  durability = 16677,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807004] = {
  ID = 807004,
  durability = 24866,
  Avatar = "head44",
  Ship = "ship37"
}
Monsters[807005] = {
  ID = 807005,
  durability = 33055,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807006] = {
  ID = 807006,
  durability = 73998,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807007] = {
  ID = 807007,
  durability = 55983,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807008] = {
  ID = 807008,
  durability = 16677,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807009] = {
  ID = 807009,
  durability = 24866,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807010] = {
  ID = 807010,
  durability = 33055,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807011] = {
  ID = 807011,
  durability = 73998,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807012] = {
  ID = 807012,
  durability = 55982,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807013] = {
  ID = 807013,
  durability = 16677,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807014] = {
  ID = 807014,
  durability = 24865,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807015] = {
  ID = 807015,
  durability = 33054,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807016] = {
  ID = 807016,
  durability = 110846,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807017] = {
  ID = 807017,
  durability = 55983,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807018] = {
  ID = 807018,
  durability = 16677,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807019] = {
  ID = 807019,
  durability = 24865,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807020] = {
  ID = 807020,
  durability = 33054,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807021] = {
  ID = 807021,
  durability = 73997,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807022] = {
  ID = 807022,
  durability = 55982,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807023] = {
  ID = 807023,
  durability = 16677,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807024] = {
  ID = 807024,
  durability = 24865,
  Avatar = "head44",
  Ship = "ship37"
}
Monsters[807025] = {
  ID = 807025,
  durability = 33055,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807026] = {
  ID = 807026,
  durability = 73998,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807027] = {
  ID = 807027,
  durability = 55982,
  Avatar = "head44",
  Ship = "ship37"
}
Monsters[807028] = {
  ID = 807028,
  durability = 16677,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807029] = {
  ID = 807029,
  durability = 24866,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807030] = {
  ID = 807030,
  durability = 33054,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807031] = {
  ID = 807031,
  durability = 81371,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807032] = {
  ID = 807032,
  durability = 61554,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807033] = {
  ID = 807033,
  durability = 18315,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807034] = {
  ID = 807034,
  durability = 27323,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807035] = {
  ID = 807035,
  durability = 36331,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807036] = {
  ID = 807036,
  durability = 121905,
  Avatar = "head43",
  Ship = "ship39"
}
Monsters[807037] = {
  ID = 807037,
  durability = 61554,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807038] = {
  ID = 807038,
  durability = 18315,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807039] = {
  ID = 807039,
  durability = 27324,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[807040] = {
  ID = 807040,
  durability = 36332,
  Avatar = "head44",
  Ship = "ship39"
}
Monsters[808001] = {
  ID = 808001,
  durability = 81370,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808002] = {
  ID = 808002,
  durability = 61553,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808003] = {
  ID = 808003,
  durability = 18315,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808004] = {
  ID = 808004,
  durability = 27323,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808005] = {
  ID = 808005,
  durability = 36332,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808006] = {
  ID = 808006,
  durability = 81371,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808007] = {
  ID = 808007,
  durability = 61553,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[808008] = {
  ID = 808008,
  durability = 18315,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808009] = {
  ID = 808009,
  durability = 27323,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808010] = {
  ID = 808010,
  durability = 36331,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[808011] = {
  ID = 808011,
  durability = 81370,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808012] = {
  ID = 808012,
  durability = 61553,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808013] = {
  ID = 808013,
  durability = 18316,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808014] = {
  ID = 808014,
  durability = 27323,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808015] = {
  ID = 808015,
  durability = 36331,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808016] = {
  ID = 808016,
  durability = 121905,
  Avatar = "head39",
  Ship = "ship39"
}
Monsters[808017] = {
  ID = 808017,
  durability = 61553,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808018] = {
  ID = 808018,
  durability = 18316,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808019] = {
  ID = 808019,
  durability = 27323,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808020] = {
  ID = 808020,
  durability = 36331,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808021] = {
  ID = 808021,
  durability = 81371,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808022] = {
  ID = 808022,
  durability = 61553,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808023] = {
  ID = 808023,
  durability = 18315,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808024] = {
  ID = 808024,
  durability = 27323,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808025] = {
  ID = 808025,
  durability = 36332,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808026] = {
  ID = 808026,
  durability = 81371,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808027] = {
  ID = 808027,
  durability = 61554,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808028] = {
  ID = 808028,
  durability = 18316,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808029] = {
  ID = 808029,
  durability = 27323,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808030] = {
  ID = 808030,
  durability = 36332,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[808031] = {
  ID = 808031,
  durability = 88743,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808032] = {
  ID = 808032,
  durability = 67124,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808033] = {
  ID = 808033,
  durability = 19954,
  Avatar = "head46",
  Ship = "ship37"
}
Monsters[808034] = {
  ID = 808034,
  durability = 29781,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808035] = {
  ID = 808035,
  durability = 39608,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808036] = {
  ID = 808036,
  durability = 132964,
  Avatar = "head43",
  Ship = "ship39"
}
Monsters[808037] = {
  ID = 808037,
  durability = 67124,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808038] = {
  ID = 808038,
  durability = 19954,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808039] = {
  ID = 808039,
  durability = 29781,
  Avatar = "head46",
  Ship = "ship39"
}
Monsters[808040] = {
  ID = 808040,
  durability = 39608,
  Avatar = "head46",
  Ship = "ship39"
}
